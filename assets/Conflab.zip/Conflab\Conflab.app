﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Conflab · Multi-Provider Collaboration</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07090d;
  --surface:#0c1018;
  --surface2:#182433;
  --border:#25354a;
  --border2:#3a526d;
  --text:#a8c0c8;
  --text-dim:#5f849f;
  --text-mid:#9cb9ca;
  --text-bright:#d8eef4;
  --teal:#18d4c0;
  --teal-dim:#0a5048;
  --teal-glow:rgba(24,212,192,0.12);
  --red:#ef4444;
  --green:#22c55e;
  --r:5px;
}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:'JetBrains Mono',monospace;font-size:13px;line-height:1.5;overflow:hidden}
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}

/* ── SHELL ──────────────────────────────────────────────────────── */
#app{display:flex;flex-direction:column;height:100vh;overflow:hidden}
#app-footer{
  flex-shrink:0;height:11px;display:flex;align-items:flex-start;justify-content:center;
  font-size:11px;line-height:1;color:var(--text-dim);letter-spacing:.04em;
  background:rgba(7,9,13,.95);user-select:none
}

/* ── TOP BAR ─────────────────────────────────────────────────── */
.topbar{
  flex-shrink:0;height:40px;display:flex;align-items:center;
  justify-content:space-between;padding:0 14px;
  background:var(--surface);border-bottom:1px solid var(--border);
}
.topbar-l,.topbar-r{display:flex;align-items:center;gap:10px;min-width:0}
.topbar-r{justify-content:flex-end}
.topbar-window-btn{
  width:29px;height:25px;display:flex;align-items:center;justify-content:center;
  padding:0;flex-shrink:0
}
.topbar-window-btn svg{width:15px;height:15px;display:block}
.topbar-window-btn.close-blocked{color:var(--red);border-color:rgba(239,68,68,.45)}
.logo{font-family:'Syne',sans-serif;font-size:15px;font-weight:800;
  letter-spacing:.1em;color:var(--text-bright)}
.logo em{color:var(--teal);font-style:normal}
.conv-topic-wrap{
  display:flex;align-items:center;gap:0;min-width:0;
  padding-bottom:2px;margin-bottom:-2px;overflow:visible
}
.conv-topic-label{
  font-family:'Syne',sans-serif;font-size:14px;font-weight:700;
  letter-spacing:.08em;color:var(--text-dim);white-space:nowrap;user-select:none
}
.conv-badge{
  font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:500;
  letter-spacing:.015em;color:var(--text-dim);max-width:380px;
  overflow:visible;white-space:nowrap;display:inline-flex;align-items:center;min-width:0;
  padding-bottom:2px;margin-bottom:-2px
}
.conv-badge-text{
  display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  line-height:1.2;padding-bottom:2px;margin-bottom:-2px
}
/* ── PANEL FRAME (title on border) ──────────────────────────── */
.panel{position:relative;border:1px solid var(--border);
  border-radius:var(--r);background:var(--surface);margin:10px 12px 0}
.panel-label{
  position:absolute;top:-8px;left:14px;padding:0 6px;background:var(--bg);
  font-family:'Syne',sans-serif;font-size:9px;font-weight:700;
  letter-spacing:.2em;color:var(--teal);pointer-events:none;z-index:2;
}

/* ── HISTORY ────────────────────────────────────────────────── */
.hist-hdr{position:absolute;top:6px;right:10px;display:flex;align-items:center;
  gap:6px;font-size:10px;color:var(--text-dim);z-index:2}
.history-search-bar{
  position:absolute;top:-12px;right:10px;display:flex;align-items:center;gap:3px;
  background:var(--bg);padding:0 5px;z-index:3
}
.history-search-input{
  width:min(360px,34vw);height:18px;background:var(--surface);border:1px solid var(--border);
  border-radius:3px;color:var(--text);font-size:10px;padding:1px 6px;outline:none
}
.history-search-input:focus{border-color:var(--teal-dim)}
.history-search-input.flash-ok{animation:history-search-ok 1.05s ease}
.history-search-input.flash-fail{animation:history-search-fail 1.05s ease}
.history-search-input.search-busy{animation:history-search-busy 1.1s ease-in-out infinite}
.history-search-btn{
  width:20px;height:18px;display:flex;align-items:center;justify-content:center;
  padding:0;border:1px solid var(--border);border-radius:3px;background:var(--surface);
  color:var(--text-dim);font-size:11px;line-height:1;cursor:pointer
}
.history-search-btn:hover:not(:disabled){color:var(--text-bright);border-color:var(--teal-dim)}
.history-search-btn.on{color:var(--teal);border-color:var(--teal-dim);background:rgba(24,212,192,.08)}
.history-search-btn:disabled{opacity:.25;cursor:default}
@keyframes history-search-ok{0%,20%,40%,60%,80%,100%{color:var(--text)}10%,30%,50%{color:#86efac}}
@keyframes history-search-fail{0%,20%,40%,60%,80%,100%{color:var(--text)}10%,30%,50%{color:#fca5a5}}
@keyframes history-search-busy{0%,100%{color:var(--text)}50%{color:var(--text-bright)}}
#history-list{gap:1px;}
.h-item{display:flex;align-items:center;gap:5px;padding:2px 6px;border-radius:3px;
  cursor:pointer;overflow:hidden;white-space:nowrap;transition:background .1s}
.h-item:hover{background:var(--surface2)}
.h-item.sel{background:rgba(24,212,192,.12);box-shadow:inset 0 0 0 1px var(--teal-dim)}
.h-ts{font-size:10px;color:var(--teal);flex-shrink:0}
.h-sum{font-size:11px;color:var(--text-dim);overflow:hidden;text-overflow:ellipsis;flex:1}
.h-dots{display:flex;gap:2px;flex-shrink:0}
.h-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}

/* ── DIRECTOR ───────────────────────────────────────────────── */
#director-panel{flex-shrink:0;border-color:var(--teal-dim);display:flex;flex-direction:column}
#director-panel .panel-label{color:var(--teal)}

/* Director top-right controls */
.dir-topctrl{position:absolute;top:5px;right:8px;display:flex;gap:2px;z-index:3}

#dir-thread{padding:6px 14px 0;overflow:hidden;flex:1 1 auto;height:26px;min-height:26px}
.d-msg{display:flex;gap:8px;align-items:center;font-size:12px;padding:1px 0}
.d-ts{font-size:10px;color:var(--teal);flex-shrink:0}
.d-txt{color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.d-rdots{display:flex;gap:2px;flex-shrink:0}
.d-att{font-size:10px;color:var(--text-dim);flex-shrink:0}
.ctx-sep{display:flex;align-items:center;gap:8px;padding:3px 0;
  font-family:'Syne',sans-serif;font-size:9px;letter-spacing:.18em;color:var(--text-dim)}
.ctx-sep::before,.ctx-sep::after{content:'';flex:1;height:1px;background:var(--border)}
.ctx-sep span{color:var(--teal)}

.dir-input-wrap{padding:8px 12px 0;flex-shrink:0;display:flex;flex-direction:column}
.dir-bottom-section{flex-shrink:0}
#dir-input{
  height:56px;min-height:56px;width:100%;background:var(--surface2);
  border:1px solid var(--border);border-radius:4px;
  color:var(--text-bright);font-family:'JetBrains Mono',monospace;font-size:12px;
  padding:8px 10px;resize:none;outline:none;transition:border-color .2s;
}
#dir-input:focus{border-color:var(--teal-dim);box-shadow:0 0 0 1px var(--teal-glow)}
#dir-input::placeholder{color:var(--text-dim);font-style:italic}
#dir-input.is-locked{
  color:var(--text-dim);cursor:not-allowed;background:rgba(255,255,255,.035);
}
.dir-assist-nav{display:flex;align-items:center;gap:4px}
.dir-assist-count{
  min-width:40px;text-align:center;color:var(--text-dim);
  font-family:'JetBrains Mono',monospace;font-size:11px;
}
.dir-turn-timer{
  min-width:96px;padding:0 4px;text-align:center;line-height:1;
  font-family:'JetBrains Mono',monospace;font-size:27.5px;letter-spacing:.04em;
  color:var(--text-bright);opacity:.95;transition:opacity .15s,color .15s;
}
.dir-turn-timer.is-dim{opacity:.38}
.dir-turn-timer.is-countdown{color:var(--red)}
.bs-generating{
  animation:flicker 1s steps(1,end) infinite;
}

#att-strip{display:flex;flex-wrap:wrap;gap:5px;padding:5px 12px 0;min-height:0;flex-shrink:0}
.att-chip{display:flex;align-items:center;gap:5px;background:var(--surface2);
  border:1px solid var(--border2);padding:2px 8px;border-radius:3px;
  font-size:10px;color:var(--text-dim)}
.chip-x{cursor:pointer;transition:color .1s}.chip-x:hover{color:var(--red)}

.dir-toolbar{display:flex;align-items:center;gap:4px;padding:5px 4px 6px;flex-shrink:0}
.tl,.tr{display:flex;align-items:center;gap:4px}
.tr{margin-left:auto}
.dir-toolbar-main{display:flex;align-items:center;gap:5px;flex-shrink:0;min-width:0}
.routing-label{font-size:9px;letter-spacing:.1em;color:var(--text-dim);flex-shrink:0}
.dir-ai-state{
  font-size:9px;letter-spacing:.08em;color:var(--text-dim);white-space:nowrap;
  padding:0 4px;flex-shrink:0
}
.dir-ai-state{color:var(--text-bright)}

.r-wrap{display:flex;flex-direction:column;align-items:center;gap:1px;
  cursor:pointer;opacity:.28;transition:opacity .15s;user-select:none}
.r-wrap.on{opacity:1}
.r-dot{width:11px;height:11px;border-radius:50%;border:2px solid transparent;transition:border-color .15s}
.r-wrap.on .r-dot{border-color:rgba(255,255,255,.4)}
.r-num{font-size:8px;color:var(--text-dim);line-height:1}


/* ── LOG PANEL MODES ──────────────────────────────────────────── */
.log-label-toggle{cursor:pointer;pointer-events:all;transition:color .15s;text-decoration:underline;text-decoration-style:dotted;text-underline-offset:3px}
.log-label-toggle:hover{color:var(--text-bright)}
/* Full view entries */
.lv-dir{border-left:3px solid var(--teal);padding:6px 10px;margin:4px 0;background:var(--surface2);border-radius:0 3px 3px 0;transition:background .15s}
.lv-dir:hover{background:var(--surface3,var(--border))}
.lv-dir.history-search-hit,.lv-agent.history-search-hit{background:rgba(24,212,192,.12);box-shadow:inset 0 0 0 1px var(--teal-dim)}
.lv-search-mark{background:rgba(24,212,192,.28);color:var(--text-bright);border-radius:2px;padding:0 1px}
.lv-dir-hdr{font-size:10px;color:var(--teal);letter-spacing:.06em;margin-bottom:3px}
.lv-dir-body{font-size:12px;color:var(--text);white-space:pre-wrap;word-break:break-word}
.lv-dir-files{font-size:10px;color:var(--text-dim);margin-top:3px}
.lv-agent{border-left:3px solid var(--ac);padding:5px 10px 5px 20px;margin:2px 0}
.lv-agent-hdr{font-size:10px;letter-spacing:.06em;margin-bottom:2px}
.lv-agent-body{font-size:12px;color:var(--text);white-space:pre-wrap;word-break:break-word}
.tool-use{margin-bottom:8px;padding:7px 9px;border:1px solid var(--border);border-radius:6px;
  background:rgba(255,255,255,.02);font-size:9px;line-height:1.5;color:var(--text-dim)}
.tool-use.empty{display:none}
.tool-use-line{font-size:9px;color:var(--text-mid);margin-bottom:3px;letter-spacing:.02em}
.tool-use-results{margin:3px 0 0 10px;padding:0}
.tool-use-result{margin:2px 0;word-break:break-word}
.tool-use-result-link{display:block;margin:0 -4px;padding:2px 4px;border-radius:4px;color:inherit;text-decoration:none;cursor:pointer}
.tool-use-result-link:hover,.tool-use-result-link:focus-visible{background:rgba(24,212,192,0.09);outline:none}
.tool-use-result-title{color:var(--text)}
.tool-use-result-url{color:var(--teal)}
.tool-use-result-snippet{color:var(--text-dim)}
.tool-use details{margin-top:4px}
.tool-use summary{cursor:pointer;color:var(--text-mid);list-style:none}
.tool-use summary::-webkit-details-marker{display:none}
.tool-use-summary-body{margin-top:5px;padding-left:10px;color:var(--text)}
.tool-use-preview{border-style:dashed;background:rgba(24,212,192,.04)}
.compact-gap{display:block;height:.75em}
.lv-sep{display:flex;align-items:center;gap:8px;padding:4px 0;font-family:'Syne',sans-serif;font-size:9px;letter-spacing:.18em;color:var(--text-dim)}
.lv-sep::before,.lv-sep::after{content:'';flex:1;height:1px;background:var(--border)}
.lv-sep span{color:var(--teal)}

/* ── RESIZE HANDLES ───────────────────────────────────────────── */
.resize-handle{
  height:6px;cursor:ns-resize;background:transparent;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;
}
.resize-handle::after{
  content:'';display:block;width:40px;height:2px;
  background:var(--border2);border-radius:1px;
  transition:background .15s;
}
.resize-handle:hover::after{background:var(--teal-dim)}
#dir-thread-resize{height:8px;cursor:row-resize;flex-shrink:0;background:transparent;
  position:relative;z-index:5;display:flex;align-items:center;justify-content:center}
#dir-thread-resize:hover{background:rgba(24,212,192,.08)}
#dir-thread-resize::after{
  content:'';display:block;width:40px;height:2px;
  background:var(--border2);border-radius:1px;transition:background .15s;
}
#dir-thread-resize:hover::after{background:var(--teal-dim)}

@keyframes interrupt-pulse{0%,100%{opacity:1}50%{opacity:.6}}

/* ── AGENT GRID ─────────────────────────────────────────────── */
#agent-grid{flex:1;min-height:0;display:grid;grid-template-columns:repeat(2,1fr);
  grid-auto-rows:1fr;gap:8px;padding:8px 12px 3px;overflow-y:auto}

@keyframes spk-pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.4);opacity:0.65}}
.spk-speaking{animation:spk-pulse 0.75s ease-in-out infinite;color:var(--teal)!important}
@keyframes persona-gen-pulse{0%,100%{opacity:1}50%{opacity:.2}}
#pe-gen-status.is-active{animation:flicker 1s steps(1,end) infinite;font-weight:700;letter-spacing:.04em}
#pe-gen-status.is-error{color:var(--red)!important;animation:none}

/* ── AGENT PANEL ────────────────────────────────────────────── */
.agent-panel{position:relative;border:1px solid var(--border);border-radius:var(--r);
  background:var(--surface);display:flex;flex-direction:column;min-height:150px;overflow:hidden}
@keyframes agent-setup-required-pulse{
  0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,.12)}
  50%{box-shadow:0 0 0 2px rgba(239,68,68,.55),0 0 18px rgba(239,68,68,.22)}
}
.agent-panel.needs-persona-setup{animation:agent-setup-required-pulse 1.35s ease-in-out infinite}
/* expanded state: span all columns */
/* solo mode handled by JS — hides other panels, expands one to fill grid */

/* ── Download cards ── */
.dl-card{display:flex;align-items:center;gap:8px;padding:8px 12px;
  background:var(--surface2);border-bottom:1px solid var(--border);cursor:default;
  min-width:0;overflow:hidden}
.dl-card-icon{font-size:16px;flex-shrink:0;opacity:.8}
.dl-card-info{flex:1;min-width:0;overflow:hidden}
.dl-card-name{font-size:11px;color:var(--text);font-family:'JetBrains Mono',monospace;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dl-card-meta{font-size:10px;color:var(--text-dim);margin-top:2px}
.dl-card-btn{flex-shrink:0;padding:3px 8px;font-size:10px;border-radius:3px;
  border:1px solid var(--teal-dim);color:var(--teal);background:transparent;
  cursor:pointer;font-family:inherit;letter-spacing:.04em;white-space:nowrap}
.dl-card-btn:hover{background:rgba(24,212,192,.1)}
/* In drawer downloads list */
.dl-drawer-item{display:flex;align-items:center;gap:8px;padding:10px 12px;
  border-bottom:1px solid var(--border);min-width:0;overflow:hidden}
.dl-drawer-agent{font-size:9px;color:var(--text-dim);letter-spacing:.05em;margin-top:2px}

/* Agent panel header strip — label + controls in a fixed bar */
.a-header{display:flex;align-items:center;justify-content:space-between;
  padding:0 8px;height:26px;flex-shrink:0;border-bottom:1px solid var(--border);
  background:var(--surface);position:relative}
.a-label{
  font-family:'Syne',sans-serif;font-size:10px;font-weight:700;letter-spacing:.16em;
  white-space:nowrap;text-overflow:ellipsis;flex:1;overflow:hidden;min-width:0
}
.a-label-btn{
  width:100%;display:flex;align-items:center;gap:6px;min-width:0;padding:3px 8px 3px 0;
  border:none;background:transparent;color:inherit;cursor:pointer;text-align:left
}
.a-label-btn:hover .a-label-text{text-decoration:underline}
.a-label-btn:focus-visible{
  outline:1px solid var(--teal-dim);outline-offset:1px;border-radius:5px
}
.a-label-btn.is-empty{
  color:var(--red)!important;border:1px dashed rgba(239,68,68,.45);border-radius:5px;
  padding:3px 8px;background:rgba(127,29,29,.12)
}
.a-label-btn.is-missing{
  color:#facc15!important;border:1px solid rgba(250,204,21,.35);border-radius:5px;
  padding:3px 8px;background:rgba(120,84,0,.12)
}
.a-label-btn.is-setup-required{animation:agent-setup-required-pulse 1.35s ease-in-out infinite}
.a-label-prefix,.a-label-text{min-width:0;overflow:hidden;text-overflow:ellipsis}
.a-label-prefix{flex-shrink:0;opacity:.82}
.a-label-text{display:block}
.a-label-chevron{flex-shrink:0;opacity:.58;font-size:9px}
.a-ctrl{display:flex;gap:2px;flex-shrink:0}
.a-ctrl-gap{width:6px;flex-shrink:0}
.a-active-toggle{
  min-width:74px;height:22px;padding:0 10px;border-radius:999px;background:transparent;
  border:1px solid currentColor;font-family:'JetBrains Mono',monospace;font-size:10px;
  display:inline-flex;align-items:center;justify-content:center;text-align:center;
  letter-spacing:.04em;cursor:pointer;transition:opacity .15s,background .15s,border-color .15s,color .15s
}
.a-active-toggle.on{opacity:1;box-shadow:inset 0 0 0 1px currentColor}
.a-active-toggle.off{opacity:.4}
.a-active-toggle:hover{opacity:1}
.a-log{flex:1;min-height:0;padding:8px 12px 6px;overflow-y:auto;display:flex;flex-direction:column;gap:0;outline:none}
.a-entry{padding:5px 0;border-bottom:1px solid var(--border);font-size:12px;line-height:1.55}
.a-entry:last-child{border-bottom:none}
.e-role{font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;margin-bottom:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-dim)}
.e-body{color:var(--text);white-space:pre-wrap;word-break:break-word}
.e-files{margin-top:4px;display:flex;flex-wrap:wrap;gap:4px}
.e-file{font-size:10px;color:var(--text-dim);background:var(--surface2);
  border:1px solid var(--border);padding:1px 7px;border-radius:3px}
.a-status{padding:5px 12px;font-size:10px;font-style:italic;color:var(--text-dim);
  border-top:1px solid var(--border);background:var(--surface2)}
.a-status.thinking{color:var(--teal);animation:flicker 1.4s infinite}
.a-status.ready{color:var(--green)}
.a-status.warn{color:#facc15}
.a-status.fail{color:#fca5a5}
@keyframes flicker{0%,100%{opacity:1}50%{opacity:.45}}
.api-error-indicator{
  margin-top:6px;padding:8px 10px;border:1px solid rgba(239,68,68,.35);border-radius:6px;
  background:rgba(127,29,29,.18);color:#fecaca
}
.api-error-indicator .kind{
  font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#fda4af;
  margin-bottom:4px
}
.api-error-indicator .msg{font-size:11px;line-height:1.45}
.api-error-indicator .retry{
  margin-top:8px;padding:4px 10px;font-size:10px;border-radius:4px;
  border:1px solid rgba(248,113,113,.45);color:#fecaca;background:transparent;cursor:pointer
}
.api-error-indicator .retry:hover{background:rgba(248,113,113,.08)}
.a-retry-btn{opacity:.28;transition:opacity .15s,background .15s,color .15s}
.a-retry-btn.is-ready{opacity:1;color:#fecaca;border-color:rgba(248,113,113,.45)}
.a-retry-btn.is-ready:hover{background:rgba(248,113,113,.1)}
.a-retry-btn:disabled{opacity:.22;cursor:default}
.round-failure-banner{
  display:none;margin:8px 12px 0;padding:9px 11px;border:1px solid rgba(248,113,113,.35);
  border-radius:7px;background:rgba(127,29,29,.18);color:#fecaca
}
.round-failure-banner.is-open{display:block}
.round-failure-banner .head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.round-failure-banner .msg{font-size:11px;line-height:1.5;color:#fecaca}
.round-failure-banner .acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
.round-failure-banner .acts button{
  padding:4px 10px;font-size:10px;border-radius:4px;border:1px solid rgba(248,113,113,.35);
  background:transparent;color:#fecaca;cursor:pointer
}
.round-failure-banner .acts button:hover{background:rgba(248,113,113,.08)}
.agent-empty{flex:1}
.agent-picker{
  position:absolute;top:34px;left:8px;right:8px;z-index:30;background:var(--surface);
  border:1px solid var(--border2);border-radius:6px;box-shadow:0 10px 28px rgba(0,0,0,.35);
  max-height:260px;overflow-y:auto;padding:6px;display:none
}
.agent-picker.open{display:block}
.agent-picker-head{
  display:flex;align-items:center;justify-content:space-between;padding:4px 6px 8px;
  border-bottom:1px solid var(--border);margin-bottom:6px
}
.agent-picker-title{
  font-family:'Syne',sans-serif;font-size:9px;letter-spacing:.14em;color:var(--teal)
}
.agent-picker-item{
  width:100%;text-align:left;border:1px solid var(--border);background:var(--surface2);
  color:var(--text);padding:8px;border-radius:5px;margin-bottom:6px;cursor:pointer
}
.agent-picker-item:hover{border-color:var(--teal-dim)}
.agent-picker-item strong{font-size:11px;color:var(--text-bright)}
.agent-picker-item .meta{font-size:10px;color:var(--text-dim)}
.model-picker-shell{position:relative}
.model-picker-summary{
  width:100%;display:flex;align-items:center;justify-content:space-between;gap:8px;
  font-size:11px;cursor:pointer;min-height:34px;border-color:var(--border);color:var(--text)
}
.model-picker-summary:hover{border-color:var(--teal-dim)}
.mps-main{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-bright)}
.mps-price{flex-shrink:0;font-size:10px;color:var(--text-dim);text-align:right}
.mps-price.mp-free{color:var(--green)}
.model-picker{
  position:absolute;top:calc(100% + 6px);left:0;right:0;z-index:35;background:var(--surface);
  border:1px solid var(--border2);border-radius:6px;box-shadow:0 10px 28px rgba(0,0,0,.35);
  max-height:320px;overflow:hidden;padding:6px;display:none
}
.model-picker.open{display:block}
.model-picker-head{padding:4px 6px 8px;border-bottom:1px solid var(--border);margin-bottom:6px}
.model-picker-filters{display:flex;gap:10px;flex-wrap:wrap}
.model-picker-filters label{font-size:10px;color:var(--text);display:flex;align-items:center;gap:4px}
.model-picker-list{max-height:240px;overflow-y:auto;padding:2px}
.model-picker-empty{padding:8px;font-size:10px;color:var(--text-dim)}
.model-picker-item{
  width:100%;text-align:left;display:flex;gap:8px;align-items:center;margin-bottom:4px;
  border:1px solid transparent;background:transparent;color:var(--text);font-family:inherit;
  font-size:11px;padding:6px 8px;border-radius:5px;cursor:pointer
}
.model-picker-item:hover{background:var(--surface2);border-color:var(--teal-dim)}
.model-picker-item.selected{background:rgba(24,212,192,.1);border-color:var(--teal-dim)}
.mp-main{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-bright)}
.mp-price{flex-shrink:0;font-size:10px;color:var(--text-dim);text-align:right}
.mp-free{color:var(--green)}
.model-picker-warning{display:none;margin-top:6px;font-size:10px;line-height:1.4;color:var(--yellow)}

/* color variants */
.ac-teal  {border-color:#0a4038}.ac-teal   .a-label{color:#18d4c0}
.ac-blue  {border-color:#1d3a5e}.ac-blue   .a-label{color:#60a5fa}
.ac-pink  {border-color:#5e1d42}.ac-pink   .a-label{color:#f472b6}
.ac-violet{border-color:#3a1d5e}.ac-violet .a-label{color:#a78bfa}
.ac-orange{border-color:#5e3a1d}.ac-orange .a-label{color:#fb923c}
.ac-yellow{border-color:#5e5a1d}.ac-yellow .a-label{color:#facc15}

/* ── DRAWER ─────────────────────────────────────────────────── */
.drawer{position:fixed;left:0;top:0;bottom:0;width:500px;background:var(--surface);
  border-right:1px solid var(--border);z-index:100;transform:translateX(-100%);
  transition:transform .22s ease;display:flex;flex-direction:column;
  overflow:hidden}
.drawer.open{transform:translateX(0)}
.drw-bg{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99;display:none}
.drw-bg.open{display:block}

/* Drawer top bar */
.drw-top{display:flex;align-items:center;justify-content:space-between;
  padding:10px 14px;border-bottom:1px solid var(--border);flex-shrink:0}
.drw-logo{font-family:'Syne',sans-serif;font-size:13px;font-weight:800;
  letter-spacing:.1em;color:var(--text-bright)}
.drw-logo em{color:var(--teal);font-style:normal}

/* Drawer nav tabs */
.drw-nav{display:flex;border-bottom:1px solid var(--border);flex-shrink:0}
.drw-tab{flex:1;padding:5px 2px;background:transparent;border:none;
  font-family:'Syne',sans-serif;font-size:12px;line-height:18px;font-weight:700;letter-spacing:0;
  color:var(--text-dim);cursor:pointer;border-bottom:2px solid transparent;
  transition:color .15s,border-color .15s;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.drw-tab:hover:not(:disabled){color:var(--text)}
.drw-tab.active{color:var(--teal);border-bottom-color:var(--teal)}
.drw-tab:disabled{opacity:0.3;cursor:not-allowed}

/* Drawer panels */
.drw-panel{flex:1;overflow-y:auto;display:none;flex-direction:column}
.drw-panel.active{display:flex}

/* Conversations panel */
.conv-list{flex:1;overflow-y:auto;padding:8px}
.drw-acts{padding:10px 12px;display:flex;gap:8px;border-bottom:1px solid var(--border);flex-shrink:0}
.c-row{display:flex;align-items:center;gap:0;padding:1px 8px;border-radius:4px;
  cursor:pointer;user-select:none}
.c-row:hover{background:var(--surface2)}
.c-row.sel .c-label{color:var(--teal);font-weight:700}
.c-row.drag-source{opacity:.55}
.c-row.drop-target-active,
.root-pill.drop-target-active{
  background:rgba(24,212,192,.14)!important;
  box-shadow:inset 0 0 0 1px var(--teal-dim);
}
.c-icon{
  width:12px;
  min-width:12px;
  font-size:12px;
  color:var(--text-dim);
  flex-shrink:0;
  display:flex;
  align-items:center;
  justify-content:flex-start;
}
.c-caret{
  width:22px;
  font-size:25px;
  line-height:1;
  color:var(--text-dim);
  flex-shrink:0;
  display:flex;
  align-items:center;
  justify-content:center;
  transform:translateY(-3px) scale(1.24);
  transform-origin:center center;
}
.c-caret-empty{transform:translate(1px,-1px) scale(.62)}
.c-label{
  font-size:12px;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;
  margin-left:6px;
}
.c-row.c-conv .c-icon{font-size:16px}
.c-icon-persona{
  width:14px;
  min-width:14px;
}
.c-icon-persona svg{
  width:14px;
  height:14px;
  display:block;
}
.c-row.c-conv .c-label{margin-left:10px}
.c-warn{font-size:10px;color:var(--red);margin-left:6px;flex-shrink:0}
.tree-rename-input{
  width:100%;
  margin-left:6px;
  padding:3px 8px;
  font-size:11px;
  border-radius:3px;
  border:1px solid var(--teal-dim);
  background:var(--surface2);
  color:var(--text-bright);
  outline:none;
}
.tree-ctx-menu{
  position:fixed;
  z-index:260;
  min-width:120px;
  background:var(--surface);
  border:1px solid var(--border2);
  border-radius:6px;
  padding:4px;
  display:none;
  box-shadow:0 10px 28px rgba(0,0,0,.35);
}
.tree-ctx-menu button{
  width:100%;
  text-align:left;
  border:none;
  background:transparent;
  color:var(--text);
  font-family:'Syne',sans-serif;
  font-size:10px;
  letter-spacing:.06em;
  padding:7px 8px;
  border-radius:4px;
  cursor:pointer;
}
.tree-ctx-menu button:hover{background:var(--surface2)}
.tree-ctx-menu button.tree-ctx-danger{color:var(--red)}
.popup-menu{
  position:fixed;
  z-index:275;
  min-width:160px;
  background:var(--surface);
  border:1px solid var(--border2);
  border-radius:6px;
  padding:4px;
  display:none;
  box-shadow:0 12px 28px rgba(0,0,0,.4);
}
.popup-menu button{
  width:100%;
  text-align:left;
  border:none;
  background:transparent;
  color:var(--text);
  font-family:'Syne',sans-serif;
  font-size:10px;
  letter-spacing:.06em;
  padding:8px 9px;
  border-radius:4px;
  cursor:pointer;
}
.popup-menu button:hover{background:var(--surface2)}
.popup-menu button.popup-danger{color:var(--red)}
.tree-root-target{
  width:100%;display:flex;align-items:center;gap:6px;
  font-size:10px;line-height:1.4;padding:5px 6px;border-radius:4px;
  cursor:pointer;user-select:none;color:var(--text-dim);border:1px solid transparent;
}
.tree-root-target:hover{background:var(--surface2)}
.tree-root-target.sel{
  border-color:var(--teal-dim);
  background:rgba(24,212,192,.06);
}
.tree-root-target.sel #drw-conv-folder,
.tree-root-target.sel #drw-persona-folder{color:var(--teal)!important;font-weight:700}

/* Personas panel */
.p-list{padding:8px;flex:1;overflow-y:auto}
.p-form{padding:12px 14px;flex:1;overflow-y:auto;border-top:1px solid var(--border);scrollbar-gutter:stable}
.p-form-title{font-family:'Syne',sans-serif;font-size:10px;font-weight:700;
  letter-spacing:.14em;color:var(--teal);margin-bottom:14px}
.persona-form-section{
  border:1px solid var(--border);border-radius:6px;background:var(--surface2);
  padding:10px 10px 4px;margin-bottom:10px
}
.persona-form-section details>summary{
  cursor:pointer;list-style:none;font-family:'Syne',sans-serif;font-size:9px;
  letter-spacing:.14em;color:var(--teal);margin-bottom:8px
}
.persona-form-section #pe-setup-summary{font-size:10px;font-weight:700}
@keyframes persona-setup-empty-pulse{
  0%,100%{background:rgba(24,212,192,.07);border-color:rgba(24,212,192,.32);box-shadow:0 0 0 0 rgba(24,212,192,0)}
  50%{background:rgba(24,212,192,.14);border-color:rgba(24,212,192,.68);box-shadow:0 0 0 1px rgba(24,212,192,.28),0 0 16px rgba(24,212,192,.18)}
}
.persona-form-section #pe-setup-summary.persona-setup-empty{
  display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  border:1px solid rgba(24,212,192,.32);border-radius:5px;padding:6px 8px;
  background:rgba(24,212,192,.07);animation:persona-setup-empty-pulse 1.35s ease-in-out infinite;
  will-change:background-color,border-color,box-shadow
}
.persona-inline-toggle details>summary{font-size:10px;font-weight:700}
.persona-form-section details:not([open])>summary{margin-bottom:0}
.persona-form-section details>summary::-webkit-details-marker{display:none}
.persona-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 8px}
.persona-form-grid .fg{margin-bottom:0}
.persona-panel-divider{border-top:1px solid var(--border);margin:0 -14px 10px}
.persona-inline-toggle{margin-top:8px}
.persona-mode-note{
  display:none;width:100%;padding:7px 10px;border:1px solid var(--teal-dim);border-radius:5px;
  color:var(--teal);font-size:10px;line-height:1.45;background:rgba(24,212,192,.07)
}
.persona-age-control{display:flex;align-items:center;gap:8px}
.persona-age-control input[type=range]{flex:1;accent-color:var(--teal)}
.persona-age-control .age-num{width:72px;flex-shrink:0}
.dir-web-budget,.dir-round-budget{
  display:flex;align-items:center;gap:2px;flex-shrink:0
}
.dir-web-budget .routing-label,.dir-round-budget .routing-label{margin-bottom:0;white-space:nowrap}
.dir-web-budget input[type=range]{width:56px;accent-color:var(--teal)}
.dir-round-budget input[type=range]{width:112px;accent-color:var(--teal)}
.dir-slider-val{min-width:18px;font-size:10px;color:var(--text-dim);text-align:right;flex-shrink:0}
.dir-web-budget .dir-slider-val,
.dir-round-budget .dir-slider-val{min-width:14px;text-align:left}
.dir-web-budget.is-disabled,.dir-round-budget.is-disabled{opacity:.45}
.dir-toolbar-radios{display:flex;align-items:center;gap:8px;flex-shrink:0}
.dir-radio-group{
  display:flex;align-items:center;gap:4px;min-height:28px;padding:2px 6px;border:1px solid var(--border);
  border-radius:999px;background:rgba(255,255,255,.03);flex-shrink:0
}
.dir-radio-group.is-disabled{opacity:.5}
.dir-radio-label{font-size:9px;letter-spacing:.08em;color:var(--text-dim);white-space:nowrap}
.dir-radio-pill{position:relative;display:inline-flex}
.dir-radio-pill input{
  position:absolute;opacity:0;pointer-events:none;width:0;height:0
}
.dir-radio-pill span{
  display:inline-flex;align-items:center;justify-content:center;height:22px;padding:0 8px;
  border:1px solid transparent;border-radius:999px;font-size:10px;color:var(--text-dim);
  line-height:1;background:transparent;cursor:pointer;box-sizing:border-box;
  transition:color .15s,border-color .15s,background .15s
}
.dir-radio-pill input:checked+span{
  color:var(--text-bright);border-color:var(--border2);background:rgba(24,212,192,.12)
}
.dir-radio-pill input:focus-visible+span{
  outline:1px solid var(--teal-dim);outline-offset:1px
}
.dir-radio-pill input:disabled+span{opacity:.45;cursor:not-allowed}
.dir-radio-subcontrol{
  display:flex;align-items:center;gap:6px;flex-shrink:0;margin-left:4px;padding-left:8px;
  border-left:1px solid var(--border);opacity:.45;transition:opacity .15s,background .15s,border-color .15s
}
.dir-radio-subcontrol.is-active{opacity:1}
.dir-radio-subcontrol.is-active .dir-radio-sublabel,
.dir-radio-subcontrol.is-active .dir-slider-val{color:var(--text-bright)}
.dir-radio-sublabel{
  font-size:9px;letter-spacing:.08em;color:var(--text-dim);white-space:nowrap
}
.dir-radio-subcontrol input[type=range]{width:56px;accent-color:var(--teal)}
.conv-edit-title{display:flex;align-items:center;gap:8px}
.conv-edit-lock{display:none;font-size:18px;color:var(--text-dim);cursor:default}
.conv-edit-lock.on{display:inline-flex;align-items:center}
.conv-edit-locked-field{
  color:var(--text-dim)!important;cursor:not-allowed;background:rgba(255,255,255,.035)!important
}
.persona-ai-setup-title{display:flex;align-items:center;justify-content:space-between;gap:8px}
.persona-ai-lock{
  display:inline-flex;align-items:center;justify-content:center;
  padding:0;border:0;background:transparent;
  color:var(--text-dim);font-size:18px;line-height:1;cursor:pointer
}
.persona-ai-lock.is-unlocked{color:var(--text-bright)}
.persona-ai-lock:hover{color:var(--text)}
.persona-ai-lock:focus-visible{outline:1px solid var(--teal);outline-offset:2px;border-radius:4px}
.persona-dirty-hint{display:none;align-items:center;gap:8px;flex-wrap:wrap;margin:2px 0 8px;font-size:10px;line-height:1.45;color:var(--text-dim)}
.persona-readonly-line{display:flex;align-items:flex-start;gap:8px;font-size:11px;line-height:1.5;margin:4px 0;color:var(--text)}
.persona-readonly-line .label{min-width:84px;color:var(--text-dim)}
.helper-note{font-size:10px;color:var(--text-dim);padding:4px 0 0;line-height:1.45}
.settings-note{font-size:10px;color:var(--text-dim);line-height:1.45;margin:-4px 0 0}
.s-section .tagline{font-weight:400;color:var(--text-dim);font-size:9px}
.s-section.compact-top{margin-top:10px}
.settings-grid-2{
  display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;align-items:start
}
.settings-grid-2 .fg{margin-bottom:0}
.persona-slider-row{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.persona-slider-row label{flex:1;font-size:10px;color:var(--text)}
.persona-slider-row input[type=range]{flex:1.4;accent-color:var(--teal)}
.persona-slider-row .val{
  min-width:34px;text-align:right;font-size:10px;color:var(--text-dim)
}
.persona-defcon-green{box-shadow:inset 0 0 0 1px rgba(34,197,94,.25)}
.persona-defcon-yellow{box-shadow:inset 0 0 0 1px rgba(250,204,21,.25)}
.persona-defcon-red{
  box-shadow:inset 0 0 0 1px rgba(239,68,68,.45),0 0 8px rgba(239,68,68,.2)
}
.world-budget{
  border:1px solid var(--border);border-radius:5px;padding:8px;margin-bottom:8px;background:var(--surface)
}
.world-budget-head{
  display:flex;align-items:center;justify-content:space-between;margin-bottom:6px
}
.world-budget-title{font-size:10px;color:var(--text-bright)}
.world-budget-rem{font-size:10px;color:var(--text-dim)}
.world-budget-row{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.world-budget-row label{flex:1;font-size:10px;color:var(--text)}
.world-budget-row input{width:62px}
.check-grid{
  display:grid;grid-template-columns:1fr 1fr;gap:4px 10px
}
.check-grid label{font-size:10px;color:var(--text);display:flex;align-items:center;gap:6px}
.p-readonly-note{
  font-size:10px;
  color:var(--text-dim);
  margin-bottom:10px;
  line-height:1.45;
}

/* Settings panel */
.s-form{padding:12px;flex:1;overflow-y:auto}
.s-section{font-family:'Syne',sans-serif;font-size:9px;font-weight:700;
  letter-spacing:.16em;color:var(--teal);margin:14px 0 8px;
  padding-bottom:4px;border-bottom:1px solid var(--border)}
.s-section:first-child{margin-top:0}
.s-form .fg{margin-bottom:10px}
.root-pill{
  width:100%;
  font-size:11px;
  padding:7px 10px;
  background:var(--surface2);
  border-radius:4px;
  border:1px solid rgba(239,68,68,.4);
  color:var(--red);
  transition:border-color .2s,color .2s;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
}
.root-pill.clickable{cursor:pointer}
.root-pill.info{cursor:default}
.mission-view{
  min-height:148px;
  max-height:216px;
  overflow-y:auto;
  white-space:pre-wrap;
  word-break:break-word;
  background:var(--surface2);
  border:1px solid var(--border);
  border-radius:4px;
  color:var(--text-bright);
  font-family:'JetBrains Mono',monospace;
  font-size:12px;
  line-height:1.55;
  padding:8px 10px;
  cursor:default;
}
.mission-view:focus{outline:none;border-color:var(--border)}

/* ── MODALS ─────────────────────────────────────────────────── */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.78);z-index:200;
  display:flex;align-items:center;justify-content:center}
#modal-app-dialog{z-index:500}
.modal-box{background:var(--surface);border:1px solid var(--border2);
  border-radius:6px;padding:24px;width:440px;max-width:94vw;max-height:90vh;overflow-y:auto}
.session-suspended-overlay{
  position:fixed;inset:0;z-index:12000;display:none;align-items:center;justify-content:center;
  padding:24px;background:radial-gradient(circle at top,rgba(24,212,192,.08),transparent 34%),rgba(5,7,10,.95)
}
.startup-workspace-loading-overlay{
  position:fixed;inset:0;z-index:11000;display:none;background:rgba(5,7,10,.04);
  cursor:wait;pointer-events:auto
}
body.startup-workspace-loading,
body.startup-workspace-loading *{cursor:wait!important}
.session-suspended-card{
  width:min(560px,94vw);padding:24px 22px 20px;border:1px solid rgba(239,68,68,.38);
  border-radius:18px;background:linear-gradient(180deg,rgba(26,10,12,.98),rgba(12,16,24,.98));
  box-shadow:0 24px 80px rgba(0,0,0,.48),0 0 0 1px rgba(255,255,255,.02) inset;
  text-align:center
}
.session-suspended-kicker{
  font-family:'Syne',sans-serif;font-size:10px;font-weight:700;letter-spacing:.22em;color:var(--red);
  margin-bottom:10px
}
.session-suspended-title{
  font-family:'Syne',sans-serif;font-size:28px;font-weight:700;letter-spacing:.02em;color:var(--text-bright);
  line-height:1.08;margin-bottom:12px
}
.session-suspended-body{
  font-size:13px;line-height:1.6;color:var(--text-mid);max-width:44ch;margin:0 auto 12px
}
.session-suspended-status{
  min-height:40px;margin:0 auto 18px;padding:10px 12px;border:1px solid rgba(58,82,109,.55);
  border-radius:10px;background:rgba(255,255,255,.03);font-size:11px;line-height:1.45;color:var(--text-dim)
}
.session-suspended-card .bp{min-width:168px}
body.session-suspended #app,
body.session-suspended .drawer,
body.session-suspended .drw-bg,
body.session-suspended .modal-bg{
  pointer-events:none!important;
  user-select:none
}
.m-title{font-family:'Syne',sans-serif;font-size:12px;font-weight:700;
  letter-spacing:.12em;color:var(--text-bright);margin-bottom:20px}
.examples-modal-title{
  font-family:'Syne',sans-serif;font-size:17px;font-weight:700;
  letter-spacing:.09em;color:var(--text-bright);margin-bottom:12px
}
.examples-modal-head{
  display:flex;align-items:flex-start;justify-content:space-between;gap:12px
}
.examples-modal-head .examples-modal-title{margin-bottom:0}
.m-sub{font-size:9px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
  color:var(--teal);margin:16px 0 10px;padding-bottom:5px;border-bottom:1px solid var(--border)}
.fg{margin-bottom:14px}
.p-form .fg{margin-bottom:8px}
.fl{display:block;font-size:9px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
  color:var(--text-dim);margin-bottom:5px}
.fi,.fs,.ft{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:4px;
  color:var(--text-bright);font-family:'JetBrains Mono',monospace;font-size:12px;
  padding:7px 10px;outline:none;transition:border-color .15s}
.fi:focus,.fs:focus,.ft:focus{border-color:var(--teal-dim)}
.ft{resize:vertical;min-height:78px}
.m-acts{display:flex;align-items:center;gap:8px;justify-content:flex-end;
  margin-top:20px;padding-top:14px;border-top:1px solid var(--border)}
.m-sp{flex:1}
.app-dialog-message{
  font-size:12px;line-height:1.65;color:var(--text);white-space:pre-wrap;
  word-break:break-word;margin-bottom:0
}
.app-dialog-input-wrap{margin-top:14px;margin-bottom:0}
.app-dialog-input-wrap[hidden]{display:none!important}

/* checkboxes in modals */
.chk-row{display:flex;align-items:center;gap:8px;padding:4px 0;cursor:pointer}
.chk-row input[type=checkbox]{accent-color:var(--teal);width:13px;height:13px}
.chk-label{font-size:11px;color:var(--text)}

/* color swatches */
.swatches{display:flex;gap:8px;flex-wrap:wrap;padding-top:4px}
.swatch{width:22px;height:22px;border-radius:50%;cursor:pointer;
  border:2px solid transparent;transition:border-color .15s,transform .1s}
.swatch:hover{transform:scale(1.15)}
.swatch.sel{border-color:#fff}

/* ── BUTTONS ─────────────────────────────────────────────────── */
.bi{background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--text);cursor:pointer;
  padding:4px 7px;border-radius:3px;font-size:14px;line-height:1;
  transition:color .15s,background .15s,border-color .15s}
.bi:hover{color:var(--text-bright);background:rgba(255,255,255,.08);border-color:var(--border2)}
.bi:disabled{opacity:.35;cursor:not-allowed;color:var(--text-dim);background:rgba(255,255,255,.02);border-color:var(--border)}
.bi:disabled:hover{color:var(--text-dim);background:rgba(255,255,255,.02);border-color:var(--border)}
.bi .btn-icon-svg{width:14px;height:14px;display:block}
.bs{background:var(--surface2);border:1px solid var(--border2);color:var(--text-bright);
  cursor:pointer;padding:4px 11px;border-radius:3px;font-family:'Syne',sans-serif;
  font-size:10px;font-weight:600;letter-spacing:.06em;transition:border-color .15s,color .15s}
.bs:hover{border-color:var(--teal-dim);color:var(--text-bright)}
.bs:disabled{opacity:.35;cursor:not-allowed;color:var(--text-dim);border-color:var(--border)}
.bs:disabled:hover{color:var(--text-dim);border-color:var(--border)}
#btn-assist{min-width:94px;text-align:center}
#btn-send{min-width:108px;text-align:center}
.bp{background:var(--teal);border:none;color:#020e0c;cursor:pointer;
  padding:6px 16px;border-radius:3px;font-family:'Syne',sans-serif;
  font-size:11px;font-weight:700;letter-spacing:.06em;transition:opacity .15s}
.bp:hover{opacity:.85}.bp:disabled{opacity:.3;cursor:not-allowed}
.bp-stop{
  background:rgba(239,68,68,.12)!important;
  color:var(--red)!important;
  border:1px solid rgba(239,68,68,.35)!important;
  animation:interrupt-pulse 1.4s infinite;
}
.bp-stop:hover{background:rgba(239,68,68,.25)!important;opacity:1!important}
.bg-btn{background:var(--surface2);border:1px solid var(--border2);color:var(--text);
  cursor:pointer;padding:5px 13px;border-radius:3px;font-family:'Syne',sans-serif;
  font-size:11px;font-weight:600;letter-spacing:.06em;transition:border-color .15s,color .15s}
.bg-btn:hover{border-color:var(--teal-dim);color:var(--text-bright)}
.bg-btn:disabled{opacity:.3;cursor:not-allowed}
.bd{color:var(--red)}.bd:hover{background:rgba(239,68,68,.1);color:var(--red)}
#ds-btn-delete{
  width:32px;height:32px;padding:0;
  font-size:24px;line-height:1;
  display:inline-flex;align-items:center;justify-content:center;
}
.dialog-btn-primary{background:var(--teal);border:none;color:#020e0c}
.dialog-btn-muted{opacity:.45}

#mic-btn.mic-on{animation:mic-pulse 1.1s infinite}
@keyframes mic-pulse{0%,100%{color:var(--red)}50%{color:var(--text-dim)}}

.fs-pill{font-size:10px;color:var(--text-dim);padding:2px 8px;border:1px solid var(--border);
  border-radius:10px;cursor:pointer;transition:border-color .15s;white-space:nowrap}
.fs-pill:hover{border-color:var(--border2);color:var(--text)}
.fs-pill.linked{border-color:var(--teal-dim);color:var(--teal)}
.msel{background:var(--surface2);border:1px solid var(--border2);color:var(--text-bright);
  font-family:inherit;font-size:10px;padding:2px 5px;border-radius:3px;cursor:pointer;outline:none}
.msel:hover{border-color:var(--teal-dim);color:var(--text-bright)}
.msel:disabled{opacity:.35;cursor:not-allowed;color:var(--text-dim);border-color:var(--border)}

/* empty */
#empty-cover{grid-column:1/-1;display:flex;flex-direction:column;align-items:center;
  justify-content:flex-start;gap:10px;padding:24px 0 34px;color:var(--text-dim);overflow:auto}
#empty-cover>img{margin-top:6px}
.eb{font-family:'Syne',sans-serif;font-size:40px;font-weight:800;
  color:var(--border2);letter-spacing:.04em}
.es{font-size:22px;order:3}
.empty-logo-wrap{order:1;position:relative;display:inline-block;margin-top:6px}
.empty-logo-wrap>img{display:block}
.empty-version{
  position:absolute;bottom:0;right:-36px;font-size:10px;color:var(--text-mid);
  letter-spacing:.08em;user-select:none;
  opacity:.75
}
.empty-info-box{
  width:min(1080px,96vw);border:1px solid var(--border);background:rgba(12,16,24,.76);
  border-radius:6px;padding:14px 16px;color:var(--text-mid);line-height:1.55;order:4;
  margin-top:10px
}
.empty-info-title-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
.empty-info-actions{display:flex;align-items:center;gap:8px}
.empty-info-actions .bs{font-size:10px;padding:4px 10px}
.empty-info-license{
  margin-top:10px;padding-top:8px;border-top:1px solid var(--border);font-size:10px;
  color:var(--text-dim);line-height:1.5
}
.empty-info-title{
  font-family:'Syne',sans-serif;font-size:17px;letter-spacing:.09em;
  color:var(--text-bright);margin-bottom:0
}
.empty-info-note{font-size:10px;color:var(--text-dim);margin-top:5px}

.md-doc{font-size:11px;line-height:1.6;color:var(--text-mid)}
.md-doc h1,.md-doc h2,.md-doc h3,.md-doc h4,.md-doc h5,.md-doc h6{
  margin:12px 0 6px;color:var(--text-bright);font-family:'Syne',sans-serif;letter-spacing:.03em
}
.md-doc h1{font-size:17px}
.md-doc h2{font-size:14px}
.md-doc h3{font-size:12px}
.md-doc h4,.md-doc h5,.md-doc h6{font-size:11px}
.md-doc p{margin:8px 0}
.md-doc ul,.md-doc ol{margin:7px 0 7px 18px;padding:0}
.md-doc li{margin:4px 0}
.md-doc hr{border:none;border-top:1px solid var(--border);margin:12px 0}
.md-doc blockquote{
  margin:10px 0;padding:8px 10px;border-left:3px solid var(--teal-dim);
  background:rgba(255,255,255,.02);color:var(--text)
}
.md-doc code{
  font-family:'JetBrains Mono',monospace;background:rgba(255,255,255,.06);padding:1px 4px;border-radius:3px
}
.md-doc pre{
  margin:10px 0;padding:10px;border:1px solid var(--border);border-radius:4px;overflow:auto;
  background:rgba(0,0,0,.24)
}
.md-doc pre code{background:none;padding:0}
.md-doc table{width:100%;border-collapse:collapse;margin:10px 0}
.md-doc th,.md-doc td{border:1px solid var(--border);padding:6px 8px;vertical-align:top;text-align:left}
.md-doc th{color:var(--text-bright);background:rgba(255,255,255,.02)}
.md-doc a{color:var(--teal)}
.md-doc img{max-width:100%;height:auto;border-radius:6px;display:block;margin:12px auto}
.e-body .md-doc,.lv-agent-body .md-doc{white-space:normal;word-break:normal}
.md-doc .download-viewer-summary-image-slot{margin:12px 0 16px}
.download-viewer-summary-image-wrap{
  border:1px solid var(--border);border-radius:8px;background:rgba(255,255,255,.02);padding:10px
}
.download-viewer-summary-image-wrap img{max-width:100%;max-height:52vh;display:block;border-radius:6px;margin:0 auto}
.download-viewer-summary-image-placeholder{
  border:1px dashed var(--border2);border-radius:8px;padding:12px 14px;font-size:10px;letter-spacing:.05em;
  text-transform:uppercase;color:var(--text-dim);background:rgba(255,255,255,.015)
}
.download-viewer-summary-image-slot.is-loading .download-viewer-summary-image-placeholder{
  animation:imageDialogStatusPulse 1s ease-in-out infinite
}
.md-overview{max-height:none;overflow:visible;padding-right:0}
.md-overview th:first-child,.md-overview td:first-child{width:1%;white-space:nowrap;padding-right:12px}

#modal-examples{
  background:transparent;
  align-items:flex-start;
  padding:0;
}
.examples-modal-box{
  width:min(1320px,96vw)!important;max-width:min(1320px,96vw)!important;
  max-height:calc(100vh - 16px)!important;
  display:flex;flex-direction:column;padding:18px 20px 16px;overflow:hidden
}
.download-viewer-box{
  width:min(900px,94vw)!important;max-width:min(900px,94vw)!important;
  height:min(82vh,900px);display:flex;flex-direction:column;padding:16px;overflow:hidden
}
.download-viewer-toolbar{
  display:flex;align-items:center;gap:8px;padding:0 0 10px;border-bottom:1px solid var(--border);
  margin-bottom:12px
}
.download-viewer-body{flex:1;min-height:0;overflow:auto}
.download-viewer-html-shell{
  width:100%;border:1px solid var(--border);border-radius:8px;background:#fff;overflow:hidden
}
.download-viewer-frame{
  width:100%;min-height:560px;border:0;background:#fff;display:block
}
.download-viewer-pre{
  margin:0;padding:12px;border:1px solid var(--border);border-radius:6px;background:rgba(0,0,0,.24);
  color:var(--text);font-family:'JetBrains Mono',monospace;font-size:11px;line-height:1.6;white-space:pre-wrap;word-break:break-word
}
.image-modal-box{
  width:min(1040px,96vw)!important;max-width:min(1040px,96vw)!important;
  height:min(88vh,980px);display:flex;flex-direction:column;padding:16px;overflow:hidden
}
.image-dialog-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap}
.image-dialog-head-left{display:flex;align-items:center;gap:8px;min-width:0;flex-wrap:wrap}
.image-dialog-title{flex-shrink:0}
.image-topbar{
  display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr) minmax(0,1.35fr);
  gap:8px;align-items:center;margin-bottom:8px
}
.image-source-options{display:flex;gap:8px;flex-wrap:wrap;font-size:13px;color:var(--text);align-items:center}
.image-source-options label{display:flex;align-items:center;gap:4px;white-space:nowrap}
.image-source-note{font-size:11px;color:var(--text-dim);line-height:1.4}
.image-source-note.is-warning{color:var(--warn)}
.image-field-row{display:flex;align-items:center;gap:6px;min-width:0}
.image-field-label{
  display:block;margin-bottom:6px;font-size:15px;letter-spacing:.02em;color:var(--text-mid);font-family:'Syne',sans-serif;line-height:1
}
.image-field-label-inline{margin-bottom:0;min-width:0;flex:0 0 auto}
.image-field-row .fs,.image-field-row .image-model-row{flex:1;min-width:0}
.image-model-block{display:flex;align-items:center;gap:6px}
.image-model-row{display:flex;align-items:center;gap:6px;min-width:0}
.model-picker-summary.is-disabled{opacity:.55;cursor:not-allowed;pointer-events:none}
.image-preview-row{
  display:grid;grid-template-columns:44px minmax(0,1fr) 44px;gap:10px;align-items:center;margin-bottom:8px
}
.image-nav-btn{
  height:44px;border:1px solid var(--border2);border-radius:999px;background:rgba(255,255,255,.03);color:var(--text);
  font-size:16px;cursor:pointer
}
.image-nav-btn:disabled{opacity:.3;cursor:default}
.image-preview-shell{
  border:1px solid var(--border);border-radius:8px;padding:12px;background:rgba(255,255,255,.02);
  display:flex;align-items:center;justify-content:center;height:min(58vh,475px);text-align:center;position:relative
}
.image-preview-frame{
  width:auto;height:auto;max-width:100%;max-height:100%;margin:0 auto;
  border:1px dashed var(--border2);border-radius:6px;background:
    linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015)),
    rgba(0,0,0,.22);
  display:inline-flex;align-items:center;justify-content:center;overflow:hidden;flex:0 1 auto
}
.image-preview-frame img{width:100%;height:100%;object-fit:contain;display:block}
.image-preview-empty{
  width:100%;height:100%;padding:28px 16px;text-align:center;font-size:11px;color:var(--text-dim);line-height:1.6;
  display:flex;align-items:center;justify-content:center
}
.image-preview-delete{
  position:absolute;top:12px;right:12px;z-index:2
}
.image-preview-export{
  position:absolute;top:12px;left:12px;z-index:2;min-width:72px
}
.image-preview-export:disabled{opacity:.45;cursor:default}
.image-prompt-panel{
  flex:1;min-height:0;border:1px solid var(--border);border-radius:8px;background:rgba(255,255,255,.02);
  display:flex;flex-direction:column;padding:12px;overflow:auto;scrollbar-gutter:stable
}
.image-prompt-head{display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-shrink:0}
.image-prompt-title{
  font-family:'Syne',sans-serif;font-size:11px;letter-spacing:.08em;color:var(--teal);flex:1;
  display:flex;align-items:center;gap:8px;min-width:0;flex-wrap:wrap
}
.image-prompt-summary-label{
  font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:.03em;color:var(--text-dim);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%
}
.image-prompt-actions{display:flex;align-items:center;gap:6px}
.image-prompt-actions button{min-width:32px}
.image-prompt-actions .bs{min-width:auto}
.image-prompt-text{
  min-height:88px;max-height:160px;resize:vertical;margin-bottom:10px;font-family:'JetBrains Mono',monospace;flex-shrink:0
}
.image-chat-history{
  flex:1;min-height:72px;border:1px solid var(--border);border-radius:6px;background:rgba(0,0,0,.18);
  padding:10px;overflow:auto;margin-bottom:10px
}
.image-chat-msg{margin-bottom:10px}
.image-chat-msg:last-child{margin-bottom:0}
.image-chat-role{font-size:9px;letter-spacing:.08em;color:var(--text-dim);font-family:'Syne',sans-serif;margin-bottom:3px}
.image-chat-body{font-size:11px;color:var(--text);line-height:1.55;white-space:pre-wrap;word-break:break-word}
.image-chat-input-row{display:flex;gap:8px;align-items:flex-end;flex-shrink:0}
.image-chat-input{min-height:56px;max-height:120px;resize:none;font-family:'JetBrains Mono',monospace}
.image-dialog-status{font-size:10px;color:var(--text-dim);line-height:1.5;margin-top:8px;min-height:16px;flex-shrink:0}
@keyframes imageDialogStatusPulse{
  0%,100%{opacity:1;color:var(--teal)}
  50%{opacity:.45;color:var(--text-dim)}
}
.image-dialog-status.busy{animation:flicker 1s steps(1,end) infinite}
.dir-ai-state.is-busy{animation:flicker 1s steps(1,end) infinite}
.fs-picker-status-state.is-busy,.fs-picker-empty.is-busy{animation:flicker 1s steps(1,end) infinite}
.prompt-lock-toggle{
  display:inline-flex;align-items:center;justify-content:center;
  width:28px;height:28px;vertical-align:middle;margin-left:4px;
  border:0;padding:0;background-color:transparent;cursor:pointer;
  color:var(--text-mid);font-size:17px;line-height:1
}
.prompt-lock-toggle.locked{color:var(--text-bright)}
.prompt-lock-toggle.unlocked{color:var(--text-mid)}
.prompt-lock-toggle.is-passive{cursor:default}
.prompt-lock-toggle:disabled{opacity:.6;cursor:default}
.prompt-lock-toggle:focus-visible{
  outline:none;box-shadow:none
}
.image-summary-btn.is-active{background:rgba(80,214,200,.18);border-color:var(--teal);color:var(--text-bright)}
.image-generate-row{
  display:flex;justify-content:center;padding-top:4px;flex-shrink:0;position:sticky;bottom:0;
  background:linear-gradient(to bottom, rgba(12,16,24,0), rgba(12,16,24,.96) 35%);margin-top:2px;padding-bottom:0
}
.examples-modal-body{flex:1;min-height:0;overflow:auto;padding-right:8px}
.fs-picker-box{
  width:min(820px,94vw)!important;max-width:min(820px,94vw)!important;
  max-height:min(90vh,640px);display:flex;flex-direction:column;
  padding:16px;overflow:hidden
}
@media (max-width: 900px){
  .image-topbar{grid-template-columns:1fr 1fr}
}
@media (max-width: 700px){
  .image-topbar{grid-template-columns:1fr}
  .image-dialog-head-left{align-items:flex-start;gap:8px}
  .image-source-options{font-size:12px;gap:8px}
  .image-field-row,.image-model-block{align-items:flex-start;flex-direction:column}
  .image-field-label-inline{min-width:0;flex-basis:auto}
  .image-preview-row{grid-template-columns:1fr}
  .image-nav-btn{width:100%}
}
.fs-picker-box .m-title{margin-bottom:10px}
.fs-picker-box .m-acts{margin-top:6px}
.fs-picker-toolbar{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.fs-picker-breadcrumb{
  flex:1;display:flex;flex-wrap:wrap;gap:4px;align-items:center;min-width:0;
  padding:3px 6px;border:1px solid var(--line);border-radius:6px;background:rgba(12,20,24,.88)
}
.fs-picker-crumb{
  border:1px solid transparent;background:transparent;color:var(--text);
  border-radius:4px;padding:1px 6px;font-size:11px;cursor:pointer
}
.fs-picker-crumb:hover{background:var(--surface2)}
.fs-picker-crumb.current{
  background:rgba(24,212,192,.10);
  border-color:var(--teal-dim);color:var(--teal)
}
.fs-picker-actions{
  display:flex;align-items:flex-start;gap:8px;margin-top:6px;min-height:24px;flex-wrap:nowrap
}
.fs-picker-roots{display:flex;flex:1 1 auto;flex-wrap:wrap;gap:4px;min-width:0;max-height:58px;overflow:auto;align-items:center}
.fs-picker-actions>.m-sp{display:none}
.fs-picker-root{
  border:1px solid var(--line);background:rgba(255,255,255,.03);color:var(--text-mid);
  border-radius:6px;padding:3px 8px;font-size:10px;letter-spacing:.05em;cursor:pointer
}
.fs-picker-root.active,.fs-picker-root.current{
  background:rgba(24,212,192,.10);
  border-color:var(--teal-dim);color:var(--teal)
}
.fs-picker-root.unavailable{opacity:.45;border-style:dashed;cursor:not-allowed}
.fs-picker-root .fs-picker-root-kicker{color:var(--text-dim);margin-right:4px}
.fs-picker-root.current .fs-picker-root-kicker{color:var(--teal)}
.fs-picker-sort-wrap{display:flex;flex:0 0 auto;align-items:center;gap:4px;white-space:nowrap}
.fs-picker-sort-label{
  color:var(--text-dim);font-size:10px;letter-spacing:.05em;font-family:'JetBrains Mono',monospace
}
.fs-picker-sort-btn{
  border:1px solid var(--line);background:rgba(255,255,255,.03);color:var(--text);
  border-radius:6px;padding:3px 8px;font-size:10px;letter-spacing:.05em;cursor:pointer;white-space:nowrap
}
.fs-picker-sort-btn:hover,.fs-picker-root:hover:not(.unavailable){background:var(--surface2)}
.fs-picker-sort-btn.active{
  background:rgba(24,212,192,.10);
  border-color:var(--teal-dim);color:var(--teal)
}
.fs-picker-count{
  color:var(--text-dim);font-size:10px;letter-spacing:.05em;white-space:nowrap;
  font-family:'JetBrains Mono',monospace
}
.fs-picker-status{
  min-height:14px;margin-bottom:4px;font-size:10px;color:var(--text-dim);
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  font-family:'JetBrains Mono',monospace
}
.fs-picker-status .fs-picker-status-hint{flex:0 1 auto;opacity:.8}
.fs-picker-status .fs-picker-status-state{flex:0 0 auto;text-align:right}
.fs-picker-list{
  flex:0 0 408px;height:408px;min-height:408px;max-height:408px;overflow-y:scroll;overflow-x:hidden;
  border:1px solid var(--line);border-radius:8px;background:rgba(8,14,18,.92);padding:4px
}
.fs-picker-empty{
  padding:22px 16px;color:var(--text-dim);font-size:12px;text-align:center
}
.fs-picker-row{
  display:flex;align-items:center;gap:6px;height:16px;padding:1px 8px;box-sizing:border-box;
  border-radius:4px;cursor:pointer
}
.fs-picker-row:hover{background:var(--surface2)}
.fs-picker-row.active{background:var(--surface2)}
.fs-picker-row.selected .fs-picker-name{color:var(--teal);font-weight:700}
.fs-picker-icon{
  width:14px;min-width:14px;flex:0 0 14px;text-align:center;font-size:12px;color:var(--text-dim);
  font-family:inherit
}
.fs-picker-name{
  flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  font-size:12px;color:var(--text)
}
.fs-picker-meta{
  flex:0 0 auto;font-size:10px;letter-spacing:.04em;color:var(--text-dim);
  font-family:'JetBrains Mono',monospace
}
.fs-picker-subtle{font-size:10px;color:var(--text-dim);letter-spacing:.05em}
</style>
</head>
<body>

<!-- ═══ DRAWER ════════════════════════════════════════════════════ -->
<div id="drw-bg" class="drw-bg" onclick="drawerClose()"></div>
<div id="drawer" class="drawer">

  <!-- Top bar -->
  <div class="drw-top">
    <img data-shared-logo-target="drawer" alt="Conflab" style="height:22px;object-fit:contain">
    <button class="bi" onclick="drawerClose()">✕</button>
  </div>

  <!-- Nav tabs: Settings · Personas · Conversations -->
  <div class="drw-nav">
    <button class="drw-tab" id="tab-settings"   onclick="switchDrawerTab('settings')" title="Configure Conflab, API keys, and helpers">SETTINGS</button>
    <button class="drw-tab active" id="tab-convs" onclick="switchDrawerTab('convs')" title="Your saved and active conversations">CONVERSATIONS</button>
    <button class="drw-tab" id="tab-personas"   onclick="switchDrawerTab('personas')" title="AI agent personas available to conversations">PERSONAS</button>
    <button class="drw-tab" id="tab-downloads" onclick="switchDrawerTab('downloads')" title="Results, summaries, images, and logs for this conversation">RESULTS</button>
  </div>

  <!-- ── SETTINGS PANEL ──────────────────────────────────────────── -->
  <div class="drw-panel" id="drw-settings">
    <div class="s-form">
      <div class="fg">
        <div id="set-folder-note" class="root-pill clickable" onclick="pickConflabFolder()" title="Click to choose root folder">
          Choose Root Folder: No Root Folder
        </div>
      </div>

      <div class="s-section">Mission Statement</div>
      <div class="fg">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <label class="fl" style="margin:0">Global behavior policy</label>
          <button class="bs" id="set-mission-edit-btn" type="button" onclick="openMissionStatementDialog()" title="Edit mission statement">&#9998; Edit</button>
        </div>
        <div id="set-mission-view" class="mission-view" tabindex="0" aria-readonly="true"></div>
        <textarea id="set-mission" style="display:none" aria-hidden="true"></textarea>
      </div>

      <div class="s-section">Display Timezone</div>
      <div class="fg">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
          <select id="set-timezone" class="fs" style="flex:1" onchange="updateTzAbbr()">
            <optgroup label="United States">
              <option value="America/New_York">Eastern — New York</option>
              <option value="America/Chicago">Central — Chicago</option>
              <option value="America/Denver">Mountain — Denver</option>
              <option value="America/Phoenix">Mountain — Phoenix (no DST)</option>
              <option value="America/Los_Angeles">Pacific — Los Angeles</option>
              <option value="America/Anchorage">Alaska — Anchorage</option>
              <option value="Pacific/Honolulu">Hawaii — Honolulu</option>
            </optgroup>
            <optgroup label="Canada">
              <option value="America/Toronto">Eastern — Toronto</option>
              <option value="America/Vancouver">Pacific — Vancouver</option>
            </optgroup>
            <optgroup label="Europe">
              <option value="Europe/London">London (GMT/BST)</option>
              <option value="Europe/Paris">Paris (CET/CEST)</option>
              <option value="Europe/Berlin">Berlin (CET/CEST)</option>
              <option value="Europe/Amsterdam">Amsterdam</option>
              <option value="Europe/Zurich">Zurich</option>
              <option value="Europe/Stockholm">Stockholm</option>
              <option value="Europe/Moscow">Moscow (MSK)</option>
            </optgroup>
            <optgroup label="Asia / Pacific">
              <option value="Asia/Dubai">Dubai (GST)</option>
              <option value="Asia/Kolkata">India (IST)</option>
              <option value="Asia/Bangkok">Bangkok (ICT)</option>
              <option value="Asia/Singapore">Singapore (SGT)</option>
              <option value="Asia/Shanghai">China (CST)</option>
              <option value="Asia/Tokyo">Tokyo (JST)</option>
              <option value="Asia/Seoul">Seoul (KST)</option>
              <option value="Australia/Sydney">Sydney (AEST/AEDT)</option>
              <option value="Pacific/Auckland">Auckland (NZST/NZDT)</option>
            </optgroup>
            <optgroup label="Other">
              <option value="UTC">UTC</option>
            </optgroup>
          </select>
          <span id="set-tz-abbr" style="font-size:10px;color:var(--teal);font-family:'JetBrains Mono',monospace;
            white-space:nowrap;flex-shrink:0;min-width:36px"></span>
        </div>
      </div>

      <div class="s-section">Director Panel Color <span class="tagline">(color reserved for director)</span></div>
      <div class="fg">
        <div id="set-director-sw" style="display:flex;gap:6px;flex-wrap:wrap"></div>
      </div>

      <div class="s-section">Default Layout</div>
      <div class="settings-grid-2">
        <div class="fg"><label class="fl">Agents per Row</label>
          <select id="set-cols" class="fs">
            <option value="1">1 — single column</option>
            <option value="2" selected>2 — side by side</option>
            <option value="3">3 — three across</option>
          </select>
        </div>
        <div class="fg"><label class="fl">Starting Agent Count</label>
          <select id="set-agent-count" class="fs">
            <option value="2" selected>2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
          </select>
        </div>
      </div>

      <div class="s-section compact-top">AI Helper <span class="tagline">(required to manage Conflab)</span></div>
      <div class="fg model-picker-shell" id="set-helper-model-shell">
        <div id="set-helper-model-summary" class="root-pill info model-picker-summary" onclick="toggleModelPicker('helper')">OpenRouter · Auto (Free Router) · Free</div>
        <input id="set-helper-model" type="hidden" value="openrouter/free">
        <div id="set-helper-model-picker" class="model-picker">
          <div class="model-picker-head">
            <div class="model-picker-filters">
              <label><input type="radio" name="set-helper-model-tier" value="free" checked onchange="refreshModelPicker('helper')"> Free</label>
              <label><input type="radio" name="set-helper-model-tier" value="popular" onchange="refreshModelPicker('helper')"> Popular</label>
              <label><input type="radio" name="set-helper-model-tier" value="all" onchange="refreshModelPicker('helper')"> All Models</label>
            </div>
            <input type="text" class="fi" id="set-helper-model-search" placeholder="Search models..." style="margin-top:6px;font-size:11px;padding:4px 8px" oninput="refreshModelPicker('helper')">
          </div>
          <div id="set-helper-model-list" class="model-picker-list"></div>
        </div>
        <div class="helper-note">Used for Conflab AI tasks: Director, Persona support, Summaries, etc. Higher-quality models produce better results.</div>
      </div>

      <div class="s-section">AI API Key - OpenRouter</div>
      <div class="fg">
        <input id="set-key-openrouter" class="fi" type="password" placeholder="sk-or-v1-...">
      </div>
      <div id="set-key-openrouter-status" class="settings-note"></div>
      <div class="settings-note">
        Free key at
        <a href="https://openrouter.ai/keys" target="_blank" style="color:var(--teal)">openrouter.ai/keys</a>
        - free models available.
      </div>

      <div class="s-section compact-top">Web Search API Key - Brave Search</div>
      <div class="fg">
        <input id="set-key-brave" class="fi" type="password" placeholder="BSA...">
      </div>
      <div id="set-key-brave-status" class="settings-note"></div>
      <div class="settings-note">
        Free tier available at
        <a href="https://brave.com/search/api" target="_blank" style="color:var(--teal)">brave.com/search/api</a>.
      </div>

      <div style="padding-top:8px;border-top:1px solid var(--border);margin-top:8px">
        <button class="bp" id="btn-save-settings" style="width:100%" onclick="saveSettings()" disabled>Save Settings</button>
        <div id="set-init-msg" style="display:none;margin-top:8px;font-size:10px;line-height:1.4;color:var(--red)">
          This workspace needs initialization. Click Save Settings to continue.
        </div>
      </div>
    </div>
  </div>

  <!-- ── PERSONAS PANEL ──────────────────────────────────────────── -->
    <div class="drw-panel" id="drw-personas">
    <div id="persona-list-view" style="display:flex;flex-direction:column;flex:1;overflow:hidden">
      <div class="drw-acts" style="flex-direction:column;gap:6px;align-items:flex-start">
        <div style="display:flex;gap:6px;width:100%">
          <button class="bp" onclick="treeStartInlineCreate(PERSONA_TREE_VIEW)" style="flex:1">+ Category</button>
          <button class="bp" onclick="personaNew()" style="flex:1">+ Persona</button>
        </div>
        <div id="persona-mode-note" class="persona-mode-note"></div>
        <div id="persona-root-target" class="root-pill info tree-root-target" title="Current workspace root folder">Root Folder: No Root Folder</div>
      </div>
      <div id="persona-no-folder" style="display:none;padding:16px;font-size:11px;color:var(--text-dim);text-align:center;line-height:1.6">
        Set a Root Folder in Settings to save personas to disk.
      </div>
      <div class="conv-list" id="persona-list"></div>
    </div>
    <div id="persona-edit-view" style="display:none;flex-direction:column;flex:1;overflow:hidden">
      <div class="drw-acts" style="justify-content:space-between">
        <button class="bg-btn" onclick="personaListBack()">← Back</button>
        <button class="bi bd" id="btn-del-persona" onclick="personaDelete()" title="Delete persona">🗑</button>
      </div>
      <div class="p-form" style="flex:1;overflow-y:auto">
        <input type="hidden" id="pe-id">
        <input type="hidden" id="pe-path">
        <input type="hidden" id="pe-uuid">

        <div class="persona-form-section">
          <div class="p-form-title persona-ai-setup-title"><span>AI Setup</span><button class="persona-ai-lock" id="pe-ai-lock-btn" type="button" onclick="togglePersonaEditorLock()" title="Unlock persona editing" aria-label="Unlock persona editing">🔒</button></div>
          <div class="fg model-picker-shell" id="pe-model-shell"><label class="fl">AI Model</label>
            <div id="pe-model-summary" class="root-pill info model-picker-summary" onclick="toggleModelPicker('persona')">OpenRouter · Auto (Free Router) · Free</div>
            <input id="pe-model" type="hidden" value="openrouter/free">
            <div id="pe-model-warning" class="model-picker-warning"></div>
            <div id="pe-model-picker" class="model-picker">
              <div class="model-picker-head">
                <div class="model-picker-filters">
                  <label><input type="radio" name="pe-model-tier" value="free" checked onchange="refreshModelPicker('persona')"> Free</label>
                  <label><input type="radio" name="pe-model-tier" value="popular" onchange="refreshModelPicker('persona')"> Popular</label>
                  <label><input type="radio" name="pe-model-tier" value="all" onchange="refreshModelPicker('persona')"> All Models</label>
                </div>
                <input type="text" class="fi" id="pe-model-search" placeholder="Search models..." style="margin-top:6px;font-size:11px;padding:4px 8px" oninput="refreshModelPicker('persona')">
              </div>
              <div id="pe-model-list" class="model-picker-list"></div>
            </div>
          </div>
          <div class="fg"><label class="fl">TTS</label>
            <select id="pe-voice" class="fs"><option value="">— None (silent) —</option></select>
          </div>
        </div>

        <div class="persona-panel-divider"></div>

        <div class="persona-form-section">
          <details id="pe-setup-details">
            <summary id="pe-setup-summary" class="persona-setup-empty" title="No persona will be assigned. Click to create one.">Persona Setup -- None (click to add)</summary>
            <div class="helper-note">The description is what the AI sees at runtime. Sliders and clusters are an authoring view. Edit either side, then resync.</div>
            <div class="persona-form-grid">
              <div class="fg"><label class="fl">Occupation / Role</label>
                <select id="pe-occupation" class="fs"></select>
              </div>
              <div class="fg"><label class="fl">Gender</label>
                <select id="pe-gender" class="fs">
                  <option value="">— Select —</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Non-binary">Non-binary</option>
                </select>
              </div>
              <div class="fg"><label class="fl">Age</label>
                <div class="persona-age-control">
                  <input id="pe-age-slider" type="range" min="5" max="100" step="1" value="25" oninput="syncPersonaAgeFromSlider()" onchange="syncPersonaAgeFromSlider()">
                  <input id="pe-age" class="fi age-num" type="number" min="5" max="100" step="1" value="25" oninput="syncPersonaAgeFromInput()" onchange="syncPersonaAgeFromInput()">
                </div>
              </div>
            </div>
            <div class="fg"><label class="fl" style="display:flex;align-items:center;justify-content:space-between;gap:6px"><span>Name</span><button class="bs" id="pe-generate-name-btn" type="button" style="font-size:9px;padding:4px 10px" onclick="generatePersona()">Generate Name + Description</button></label>
              <div style="display:flex;gap:6px">
                <input id="pe-name" class="fi" type="text" maxlength="64" placeholder="e.g. Dr. Maya Chen" style="flex:1">
              </div>
            </div>
            <div class="fg"><label class="fl">Persona Description</label>
              <textarea id="pe-backstory" class="ft" style="min-height:120px" placeholder="How this persona thinks, speaks, and approaches problems."></textarea>
            </div>
            <div id="pe-gen-status" style="font-size:10px;color:var(--teal);margin-bottom:6px;display:none">Generating...</div>

            <div class="persona-inline-toggle">
              <details>
                <summary>Persona Sliders</summary>
                <div style="display:flex;justify-content:flex-end;margin-bottom:8px">
                  <button class="bs" id="pe-slider-lock-btn" type="button" onclick="togglePersonaSliderLock()">🔒 Range Locked (-5..+5)</button>
                </div>
                <div id="pe-slider-list"></div>
              </details>
            </div>

            <div class="persona-inline-toggle">
              <details>
                <summary>Background</summary>
                <div class="persona-form-grid">
                  <div class="fg"><label class="fl">Cultural Background</label><select id="pe-culture" class="fs"></select></div>
                  <div class="fg"><label class="fl">Region</label><select id="pe-region" class="fs"></select></div>
                  <div class="fg"><label class="fl">Education Level</label><select id="pe-education" class="fs"></select></div>
                  <div class="fg"><label class="fl">Socioeconomic Background</label><select id="pe-socioeconomic" class="fs"></select></div>
                </div>
              </details>
            </div>

            <div class="persona-inline-toggle">
              <details>
                <summary>Worldview</summary>
                <div id="pe-world-political"></div>
                <div id="pe-world-religious"></div>
                <div id="pe-world-epistemology"></div>
              </details>
            </div>

            <div class="persona-inline-toggle">
              <details>
                <summary>Life Experiences</summary>
                <label class="fl">Disability</label>
                <div id="pe-disabilities" class="check-grid" style="margin-bottom:10px"></div>
                <label class="fl">Mental Health Condition</label>
                <div id="pe-mental-health" class="check-grid" style="margin-bottom:10px"></div>
                <label class="fl">Life Stage</label>
                <div id="pe-life-stage" class="check-grid"></div>
              </details>
            </div>
          </details>
        </div>

        <div id="pe-dirty-hint" class="persona-dirty-hint" style="display:none">
          <span id="pe-dirty-hint-msg"></span>
          <button id="pe-dirty-hint-btn" class="bs" type="button" style="display:none;margin-left:8px"></button>
        </div>
        <div style="display:flex;gap:8px">
          <button class="bg-btn" id="btn-persona-cancel" style="flex:1" onclick="personaListBack()">Cancel</button>
          <button class="bp" id="btn-persona-use" style="display:none;flex:1" onclick="personaUseCurrentAiSetup()" title="Apply AI model and voice to this agent">Use</button>
          <button class="bp" id="btn-persona-save" style="flex:1" onclick="personaSave()">Save</button>
          <button class="bp" id="btn-persona-clone" style="flex:1" onclick="personaCloneCurrent()" title="Clone this persona">Clone</button>
        </div>
      </div>
    </div>
  </div><div class="drw-panel active" id="drw-convs">
    <div id="conv-list-view" style="display:flex;flex-direction:column;flex:1;overflow:hidden">
      <div class="drw-acts" style="flex-direction:column;gap:6px;align-items:flex-start">
        <div style="display:flex;gap:6px;width:100%">
          <button class="bp" onclick="treeStartInlineCreate(CONV_TREE_VIEW)" style="flex:1">+ Category</button>
          <button class="bp" onclick="createConversationFromPanel()" style="flex:1">+ Conversation</button>
        </div>
        <div id="conv-root-target" class="root-pill info tree-root-target" title="Current workspace root folder">Root Folder: No Root Folder</div>
      </div>
      <div id="conv-no-folder" style="display:none;padding:16px;font-size:11px;color:var(--text-dim);text-align:center;line-height:1.6">
        Set a Root Folder in Settings to save conversations to disk.
      </div>
      <div class="conv-list" id="conv-list"></div>
    </div>
    <div id="conv-edit-view" style="display:none;flex-direction:column;flex:1;overflow:hidden">
      <div class="drw-acts" style="justify-content:space-between">
        <button class="bg-btn" onclick="conversationListBack()">← Back</button>
        <button class="bi bd" id="btn-del-conv" onclick="deleteConversationFromDialog()" title="Delete conversation">🗑</button>
      </div>
      <div class="p-form" style="flex:1;overflow-y:auto">
        <div class="m-title conv-edit-title" style="margin-bottom:14px">CONVERSATION <span id="conv-edit-lock" class="conv-edit-lock" title="These conversation-editor fields are locked after the conversation has at least one round.">🔒</span></div>
        <div class="fg"><label class="fl">Conversation Name</label>
          <input id="ds-name" class="fi" type="text" maxlength="64" placeholder="Rename this conversation">
        </div>
        <div class="fg"><label class="fl">Description / Objective of Conversation</label>
          <textarea id="ds-topic-objective" class="ft" placeholder="e.g., I'm comparing two job offers and need help thinking through the tradeoffs"></textarea>
        </div>
        <div class="fg"><label class="fl">Brief description of participants you'd like in this conversation</label>
          <div class="helper-note" style="padding-top:0;margin-bottom:6px">Used to auto-generate participants when setting up agents</div>
          <textarea id="ds-participant-description" class="ft" placeholder="e.g., Medical professionals with experience in ophthalmology"></textarea>
        </div>
        <div class="m-acts">
          <span class="m-sp"></span>
          <button id="ds-btn-cancel" class="bg-btn" onclick="conversationListBack()">Cancel</button>
          <button id="ds-btn-save" class="bp" onclick="saveDirSettings()">Save</button>
          <button id="ds-btn-go" class="bp" onclick="goConversation()">Go</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ── RESULTS PANEL ────────────────────────────────────────────── -->
  <div class="drw-panel" id="drw-downloads">
    <div class="drw-acts" style="flex-direction:column;gap:6px;align-items:flex-start">
      <div id="downloads-root-target" class="root-pill info tree-root-target" title="Current workspace root folder">Root Folder: No Root Folder</div>
      <div style="font-size:10px;color:var(--text-dim);line-height:1.6">
        Persistent browser of conversation results, summaries, images, and logs.
      </div>
    </div>
    <div id="downloads-empty" style="padding:24px 16px;font-size:11px;color:var(--text-dim);text-align:center;line-height:1.8">
      No persistent results found yet.<br>
      <span style="opacity:.6">Results appear here after agents produce files or saved artifacts.</span>
    </div>
    <div class="conv-list" id="downloads-tree"></div>
  </div>

</div>

<div id="cat-menu" class="tree-ctx-menu" role="menu" aria-hidden="true">
  <button id="cat-menu-rename" type="button">Rename</button>
  <button id="cat-menu-delete" type="button" class="tree-ctx-danger">Delete</button>
  <button id="cat-menu-cancel" type="button">Cancel</button>
</div>
<div id="pcat-menu" class="tree-ctx-menu" role="menu" aria-hidden="true">
  <button id="pcat-menu-rename" type="button">Rename</button>
  <button id="pcat-menu-delete" type="button" class="tree-ctx-danger">Delete</button>
  <button id="pcat-menu-cancel" type="button">Cancel</button>
</div>
<div id="popup-menu" class="popup-menu" role="menu" aria-hidden="true"></div>

<!-- ═══ MISSION STATEMENT MODAL ═════════════════════════════════ -->
<div id="modal-mission-edit" class="modal-bg" style="display:none" onclick="closeMissionStatementDialog(event)">
  <div class="modal-box" style="width:min(860px,94vw);max-width:min(860px,94vw)" onclick="event.stopPropagation()">
    <div class="m-title">EDIT MISSION STATEMENT</div>
    <div style="font-size:11px;color:var(--text-dim);line-height:1.6;margin-bottom:12px">
      <div>Read-only by default. Editing requires explicit confirmation because this changes behavior for all conversations.</div>
      <div style="margin-top:6px">- Future responses in old conversations will also use the updated mission statement.</div>
      <div>- This change only applies to the current workspace. New workspaces start from the built-in default unless you edit them too.</div>
    </div>
    <div class="fg" style="margin-bottom:0">
      <label class="fl">Global behavior policy</label>
      <textarea id="mission-edit-input" class="ft" style="min-height:300px;resize:none"></textarea>
    </div>
    <div class="m-acts">
      <span class="m-sp"></span>
      <button class="bg-btn" type="button" onclick="closeMissionStatementDialog()">Cancel</button>
      <button class="bp" type="button" onclick="saveMissionStatementDialog()">Apply</button>
    </div>
  </div>
</div>

<div id="modal-api-error" class="modal-bg" style="display:none" onclick="closeApiErrorDialog(event)">
  <div class="modal-box" style="width:min(560px,94vw);max-width:min(560px,94vw)" onclick="event.stopPropagation()">
    <div class="m-title" id="api-error-title" style="color:#facc15">API Error</div>
    <div id="api-error-message" style="font-size:12px;line-height:1.6;color:var(--text);margin-bottom:10px"></div>
    <div id="api-error-suggestion" style="font-size:11px;line-height:1.6;color:var(--text-dim)"></div>
    <div class="m-acts">
      <button class="bg-btn" id="api-error-open-settings" type="button" style="display:none" onclick="openSettingsFromApiError()">Open Settings</button>
      <span class="m-sp"></span>
      <button class="bp" type="button" onclick="closeApiErrorDialog()">OK</button>
    </div>
  </div>
</div>
<div id="modal-app-dialog" class="modal-bg" style="display:none" onclick="handleAppDialogBackdrop(event)">
  <div class="modal-box" style="width:min(520px,94vw);max-width:min(520px,94vw)" onclick="event.stopPropagation()">
    <div class="m-title" id="app-dialog-title">NOTICE</div>
    <div id="app-dialog-message" class="app-dialog-message"></div>
    <div id="app-dialog-input-wrap" class="fg app-dialog-input-wrap" hidden>
      <label id="app-dialog-input-label" class="fl">Value</label>
      <input id="app-dialog-input" class="fi" type="text" maxlength="128" autocomplete="off">
    </div>
    <div class="m-acts">
      <span class="m-sp"></span>
      <button id="app-dialog-cancel" class="bg-btn" type="button" onclick="cancelAppDialog()">Cancel</button>
      <button id="app-dialog-ok" class="bp" type="button" onclick="submitAppDialog()">OK</button>
    </div>
  </div>
</div>

<div id="modal-fs-picker" class="modal-bg" style="display:none" onclick="handleFsPickerBackdrop(event)">
  <div class="modal-box fs-picker-box" onclick="event.stopPropagation()">
    <div class="m-title" id="fs-picker-title">SELECT FILES (for upload)</div>
    <div class="fs-picker-toolbar">
      <button class="bi" type="button" onclick="fsPickerGoHome()" title="Go to home folder">⌂</button>
      <button class="bi" type="button" onclick="fsPickerGoUp()" title="Go up one folder">↑</button>
      <div id="fs-picker-breadcrumb" class="fs-picker-breadcrumb"></div>
    </div>
    <div id="fs-picker-status" class="fs-picker-status"></div>
    <div id="fs-picker-list" class="fs-picker-list"></div>
    <div class="fs-picker-actions">
      <div id="fs-picker-roots" class="fs-picker-roots"></div>
      <span class="m-sp"></span>
      <div id="fs-picker-sort-wrap" class="fs-picker-sort-wrap">
        <span class="fs-picker-sort-label">Sort:</span>
        <button id="fs-picker-sort-alphabetical" class="fs-picker-sort-btn" type="button" onclick="fsPickerChooseSort('alphabetical')">Alphabetical</button>
        <button id="fs-picker-sort-size" class="fs-picker-sort-btn" type="button" onclick="fsPickerChooseSort('size')">Size</button>
        <button id="fs-picker-sort-time" class="fs-picker-sort-btn" type="button" onclick="fsPickerChooseSort('time')">Time</button>
      </div>
      <span id="fs-picker-selected-count" class="fs-picker-count" style="display:none"></span>
    </div>
    <div class="m-acts">
      <button class="bg-btn" type="button" onclick="cancelFsPicker()">Cancel</button>
      <span class="m-sp"></span>
      <button id="fs-picker-confirm" class="bp" type="button" onclick="confirmFsPicker()">Select</button>
    </div>
  </div>
</div>

<div id="modal-examples" class="modal-bg" style="display:none" onclick="closeExamplesModal(event)">
  <div class="modal-box examples-modal-box" onclick="event.stopPropagation()">
    <div class="examples-modal-head">
      <div class="m-title examples-modal-title">CONFLAB USE CASE EXAMPLES:</div>
      <button class="bi" type="button" onclick="closeExamplesModal()" title="Close examples">✕</button>
    </div>
    <div id="examples-md-body" class="md-doc examples-modal-body"></div>
  </div>
</div>

<div id="modal-download-viewer" class="modal-bg" style="display:none" onclick="closeDownloadViewer(event)">
  <div class="modal-box download-viewer-box" onclick="event.stopPropagation()">
    <div class="download-viewer-toolbar">
      <div class="m-title" id="download-viewer-title" style="margin-bottom:0">VIEWER</div>
      <span style="flex:1"></span>
      <button class="bi bd" id="download-viewer-delete" type="button" onclick="deleteViewedArtifact()" title="Delete this saved artifact" style="display:none">🗑</button>
      <button class="bi" id="download-viewer-print" type="button" onclick="printViewedArtifact()" title="Print or save as PDF" aria-label="Print or save as PDF"><svg class="btn-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9V4h12v5"></path><rect x="6" y="14" width="12" height="6" rx="1"></rect><path d="M6 17H4a2 2 0 0 1-2-2v-4a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v4a2 2 0 0 1-2 2h-2"></path><circle cx="18" cy="12" r=".8" fill="currentColor" stroke="none"></circle></svg></button>
      <button class="bg-btn" id="download-viewer-download" type="button" onclick="downloadViewedArtifact()">Export</button>
      <button class="bp" type="button" onclick="closeDownloadViewer()">Close</button>
    </div>
    <div id="download-viewer-body" class="download-viewer-body"></div>
  </div>
</div>

<div id="modal-image-dialog" class="modal-bg" style="display:none" onclick="closeImageDialog(event)">
  <div class="modal-box image-modal-box" onclick="event.stopPropagation()">
    <div class="examples-modal-head image-dialog-head" style="margin-bottom:10px">
      <div class="image-dialog-head-left">
        <div class="m-title examples-modal-title image-dialog-title" style="margin-bottom:0">Image Generation:</div>
        <div class="image-source-options">
          <label><input id="img-source-summary" type="radio" name="img-source" value="from-summary" onchange="onImageSourceChange(this.value)"> From Summary</label>
          <label><input id="img-source-scratch" type="radio" name="img-source" value="from-scratch" onchange="onImageSourceChange(this.value)"> From Scratch</label>
          <span id="img-source-note" class="image-source-note" style="display:none"></span>
        </div>
      </div>
      <button class="bi" type="button" onclick="closeImageDialog()" title="Close image dialog">✕</button>
    </div>
    <div class="image-topbar">
      <div class="image-field-row">
        <label class="image-field-label image-field-label-inline" for="img-style">Style</label>
        <select id="img-style" class="fs" onchange="onImageSettingChange()"></select>
      </div>
      <div class="image-field-row">
        <label class="image-field-label image-field-label-inline" for="img-aspect">Aspect Ratio</label>
        <select id="img-aspect" class="fs" onchange="onImageSettingChange()"></select>
      </div>
      <div class="image-model-block model-picker-shell image-field-row">
        <label class="image-field-label image-field-label-inline" for="img-model-summary">Model</label>
        <div class="image-model-row">
          <div id="img-model-summary" class="root-pill clickable model-picker-summary" onclick="toggleModelPicker('image')">OpenRouter: FLUX.2 Klein 4B <span class="mps-price mp-free">Free</span></div>
        </div>
        <input id="img-model" type="hidden" value="black-forest-labs/flux.2-klein-4b">
        <div id="img-model-picker" class="model-picker">
          <div class="model-picker-head">
            <div class="model-picker-filters">
              <label><input type="radio" name="img-model-tier" value="free" checked onchange="refreshModelPicker('image')"> Free</label>
              <label><input type="radio" name="img-model-tier" value="popular" onchange="refreshModelPicker('image')"> Popular</label>
              <label><input type="radio" name="img-model-tier" value="all" onchange="refreshModelPicker('image')"> All Models</label>
            </div>
            <input type="text" class="fi" id="img-model-search" placeholder="Search image models..." style="margin-top:6px;font-size:11px;padding:4px 8px" oninput="refreshModelPicker('image')">
          </div>
          <div class="model-picker-list" id="img-model-list"></div>
        </div>
      </div>
    </div>
    <div class="image-preview-row">
      <button id="img-prev-btn" class="image-nav-btn" type="button" onclick="stepImagePrompt(-1)">&lt;</button>
      <div id="img-preview-shell" class="image-preview-shell">
        <div id="img-preview-frame" class="image-preview-frame" style="aspect-ratio:1 / 1">
          <button class="bs image-preview-export" id="img-export-btn" type="button" onclick="exportCurrentImagePrompt()">Export</button>
          <div id="img-preview-empty" class="image-preview-empty">No image yet for this prompt.</div>
          <img id="img-preview-image" alt="Generated image preview" style="display:none">
        </div>
        <button class="bi bd image-preview-delete" id="img-delete-image-btn" type="button" onclick="deleteGeneratedImage()" title="Delete this image and keep the prompt">🗑</button>
      </div>
      <button id="img-next-btn" class="image-nav-btn" type="button" onclick="stepImagePrompt(1)">&gt;</button>
    </div>
    <div class="image-prompt-panel">
      <div class="image-prompt-head">
        <div id="img-prompt-title" class="image-prompt-title">Prompt</div>
        <div class="image-prompt-actions">
          <button class="bs" id="img-clone-btn" type="button" onclick="cloneImagePrompt()" title="Create a new prompt from this one">Clone</button>
          <button class="bs image-summary-btn" id="img-use-summary-btn" type="button" onclick="toggleImageUseInSummary()" title="Use this image in summary views">Use in Summary</button>
          <button class="bi bd" id="img-delete-btn" type="button" onclick="deleteImagePrompt()" title="Delete this prompt and its image">🗑</button>
        </div>
      </div>
      <textarea id="img-prompt-text" class="ft image-prompt-text" placeholder="Describe the image prompt..." oninput="onImagePromptTextInput()"></textarea>
      <div id="img-chat-history" class="image-chat-history"></div>
      <div class="image-chat-input-row">
        <textarea id="img-chat-input" class="ft image-chat-input" placeholder="Ask the AI Helper about this prompt..." onkeydown="handleImageChatKeydown(event)"></textarea>
        <button class="bs" id="img-chat-send" type="button" onclick="submitImageChat()">Submit</button>
      </div>
      <div id="img-dialog-status" class="image-dialog-status"></div>
      <div class="image-generate-row">
        <button class="bp" id="img-generate-btn" type="button" onclick="generateImageFromPrompt()">Generate</button>
      </div>
    </div>
  </div>
</div>

<!-- ═══ APP ══════════════════════════════════════════════════════ -->
<div id="app">
  <div class="topbar">
    <div class="topbar-l">
      <button class="bi" onclick="drawerOpen()" style="color:#899faa">☰</button>
      <img id="conflab-logo" data-shared-logo-target="topbar" alt="Conflab" style="height:26px;object-fit:contain;cursor:pointer" onclick="drawerOpen()">
      <span id="topbar-version" style="position:relative;top:5px;left:-6px;font-size:9px;color:var(--text-mid);opacity:.75;letter-spacing:.06em;font-family:'JetBrains Mono',monospace;margin-left:4px;user-select:none"></span>
      <span class="conv-topic-wrap" id="conv-topic-wrap" style="display:none">
        <span class="conv-topic-label" id="conv-topic-label">TOPIC:</span>
        <span class="conv-badge" id="conv-badge"><span class="conv-badge-text" id="conv-badge-text"></span></span>
      </span>
    </div>
    <div class="topbar-r" style="display:flex;align-items:center;gap:8px">
      <span style="font-size:10px;color:var(--text-dim);letter-spacing:.05em;white-space:nowrap">Root Folder:</span><span id="fs-pill" class="fs-pill" title="Change Conflab root folder" style="max-width:480px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--red);border-color:rgba(239,68,68,.4)">No Root Folder</span>
      <button class="bi topbar-window-btn" id="btn-fullscreen" type="button" onclick="toggleFullscreen()" title="Toggle fullscreen" aria-label="Toggle fullscreen">
        <svg id="fs-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
          fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="15 3 21 3 21 9"/>
          <polyline points="9 21 3 21 3 15"/>
          <line x1="21" y1="3" x2="14" y2="10"/>
          <line x1="3" y1="21" x2="10" y2="14"/>
        </svg>
      </button>
      <button class="bi topbar-window-btn" id="btn-close-window" type="button" onclick="closeConflabWindow()" title="Close Conflab window" aria-label="Close Conflab window">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
          fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
  </div>
  <!-- HISTORY / LOG -->
  <div class="panel" id="history-panel" style="display:flex;flex-direction:column;flex-shrink:0;overflow:visible">
    <span class="panel-label log-label-toggle" id="log-toggle-label"
      onclick="toggleLogMode()" title="Click to switch Summary ↔ Full View">HISTORY · SUMMARY</span>
    <div class="history-search-bar" id="history-search-bar">
      <input id="history-search-input" class="history-search-input" type="text"
        placeholder="Search history..." oninput="onHistorySearchInputChange()" onkeydown="onHistorySearchInputKey(event)" title="History search text">
      <button class="history-search-btn" id="history-smart-search-btn" type="button"
        onclick="runHistorySearch('smart')" title="Smart history search">✦</button>
      <button class="history-search-btn" id="history-exact-search-btn" type="button"
        onclick="runHistorySearch('exact')" title="Exact history search">⌕</button>
      <button class="history-search-btn" id="history-prev-search-btn" type="button"
        onclick="navigateHistorySearchResult(-1)" title="Previous search result" disabled>−</button>
      <button class="history-search-btn" id="history-next-search-btn" type="button"
        onclick="navigateHistorySearchResult(1)" title="Next search result" disabled>+</button>
    </div>
    <div id="history-list" style="height:112px;overflow-y:auto;padding:14px 10px 8px"></div>
  </div>
  <div class="resize-handle" id="hist-resize"></div>

  <!-- DIRECTOR -->
  <div class="panel" id="director-panel">
    <span class="panel-label">DIRECTOR</span>
    <div id="round-failure-banner" class="round-failure-banner"></div>
    <div id="dir-thread"></div>
    <div id="dir-thread-resize" title="Drag to resize message area"></div>
    <div class="dir-input-wrap">
      <textarea id="dir-input"
        placeholder="Type or dictate… (Enter to send, Shift+Enter for newline)"
        onfocus="onDirectorInputManualIntent()"
        onpointerdown="onDirectorInputManualIntent()"
        oninput="onDirectorInputChange()"
        onkeydown="onDirKey(event)"></textarea>
    </div>
    <div class="dir-bottom-section">
    <div id="att-strip"></div>
    <div class="dir-toolbar">
      <div class="tl">
        <button class="bi" id="btn-attach" onclick="triggerFile()" title="Attach files" style="display:flex;align-items:center;justify-content:center;padding:4px 6px">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
            style="transform:rotate(45deg)">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>
          </svg>
        </button>
        <button class="bi" id="mic-btn" onclick="toggleMic()" title="Dictate at cursor" style="display:flex;align-items:center;justify-content:center;padding:4px 6px">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="9" y="2" width="6" height="11" rx="3"/>
            <path d="M5 10a7 7 0 0 0 14 0"/>
            <line x1="12" y1="19" x2="12" y2="22"/>
            <line x1="9" y1="22" x2="15" y2="22"/>
          </svg>
        </button>
        <!-- Global TTS controls -->
        <button class="bi" id="tts-master-btn" onclick="toggleTtsMaster()"
          title="Voice playback on/off"
          style="display:flex;align-items:center;justify-content:center;padding:4px 6px;opacity:0.35">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
          </svg>
        </button>
        <div id="tts-rate-wrap" style="display:flex;align-items:center;gap:2px">
          <span id="tts-rate-val" style="font-size:10px;color:var(--text-dim);min-width:24px;text-align:right">1x</span>
          <input id="tts-rate-slider" type="range" min="1" max="4" step="0.1" value="1"
            oninput="onTtsRateInput(this.value)" title="Playback speed"
            style="width:50px;accent-color:var(--teal)">
        </div>
      </div>
      <div class="dir-toolbar-main">
        <div class="dir-web-budget" id="dir-web-budget-wrap">
          <span class="routing-label">WEB:</span>
          <span id="dir-web-budget-val" class="dir-slider-val">2x</span>
          <input id="dir-web-budget-slider" type="range" min="0" max="5" step="1" value="2" oninput="syncDirectorWebBudgetFromSlider()" onchange="syncDirectorWebBudgetFromSlider()">
        </div>
        <div class="dir-round-budget" id="dir-rounds-wrap">
          <span class="routing-label">CONTEXT:</span>
          <span id="dir-rounds-val" class="dir-slider-val">10</span>
          <input id="dir-rounds-slider" type="range" min="5" max="50" step="5" value="10" oninput="syncDirectorRoundsFromSlider()" onchange="syncDirectorRoundsFromSlider()">
        </div>
        <div class="dir-toolbar-radios">
          <div class="dir-radio-group" id="dir-director-toolbar-group">
            <span class="dir-radio-label">Director:</span>
            <label class="dir-radio-pill">
              <input id="dir-director-human" type="radio" name="dir-toolbar-director" value="human" onchange="setConversationDirectorTypeFromToolbar(this.value)">
              <span>Human</span>
            </label>
            <label class="dir-radio-pill">
              <input id="dir-director-ai" type="radio" name="dir-toolbar-director" value="ai" onchange="setConversationDirectorTypeFromToolbar(this.value)">
              <span>AI</span>
            </label>
            <div class="dir-radio-subcontrol" id="dir-ai-countdown-toolbar-wrap">
              <span class="dir-radio-sublabel">SPEED:</span>
              <span id="dir-ai-countdown-val" class="dir-slider-val">3s</span>
              <input id="dir-ai-countdown-slider" type="range" min="3" max="60" step="1" value="3" oninput="syncDirectorAiCountdownFromSlider()" onchange="syncDirectorAiCountdownFromSlider()">
            </div>
          </div>
          <div class="dir-radio-group" id="dir-mode-toolbar-group">
            <span class="dir-radio-label">Mode:</span>
            <label class="dir-radio-pill">
              <input id="dir-mode-parallel" type="radio" name="dir-toolbar-mode" value="parallel" onchange="setConversationModeFromToolbar(this.value)">
              <span>Parallel</span>
            </label>
            <label class="dir-radio-pill">
              <input id="dir-mode-sequential" type="radio" name="dir-toolbar-mode" value="sequential" onchange="setConversationModeFromToolbar(this.value)">
              <span>Sequential</span>
            </label>
            <label class="dir-radio-pill">
              <input id="dir-mode-free-form" type="radio" name="dir-toolbar-mode" value="free_form" onchange="setConversationModeFromToolbar(this.value)">
              <span>Free Form</span>
            </label>
            <div class="dir-radio-subcontrol" id="dir-pace-wrap">
              <span class="dir-radio-sublabel">PACE:</span>
              <span id="dir-pace-val" class="dir-slider-val">3s</span>
              <input id="dir-pace-slider" type="range" min="0" max="30" step="1" value="3" oninput="syncDirectorPaceFromSlider()" onchange="syncDirectorPaceFromSlider()">
            </div>
          </div>
        </div>
        <button class="bs" id="btn-assist" onclick="runDirectorAssist()" disabled title="Refine the current Director draft">Prompt Assist</button>
        <div class="dir-assist-nav" id="dir-assist-nav" style="display:none">
          <button class="bi" id="btn-assist-prev" onclick="goDirectorAssistPrev()" title="Previous Assist version" disabled>&lt;</button>
          <span class="dir-assist-count" id="dir-assist-count">1 / 1</span>
          <button class="bi" id="btn-assist-next" onclick="goDirectorAssistNext()" title="Next Assist version" disabled>&gt;</button>
        </div>
        <span class="dir-ai-state" id="dir-ai-state" style="display:none"></span>
      </div>
      <div class="tr">
        <span class="dir-turn-timer is-dim" id="dir-turn-timer" style="display:none">0:00</span>
        <button class="bs" id="btn-add" onclick="addAgent()">+ Agent</button>
        <select id="col-sel" class="msel" onchange="setAgentCols(this.value)">
          <option value="1">1 col</option>
          <option value="2" selected>2 col</option>
          <option value="3">3 col</option>
        </select>
        <button class="bi" id="btn-summary" onclick="downloadConversationSummaryMd(event)" title="Save AI-generated conversation summary to the Results drawer"
          style="font-size:11px;padding:4px 8px">Summary ⤓</button>
        <button class="bi" id="btn-dl-full" onclick="downloadFullHistoryMd(event)" title="Save conversation log to the Results drawer"
          style="font-size:11px;padding:4px 8px">Log ⤓</button>
        <button class="bi" id="btn-image" onclick="openImageDialog()" title="Open image creation dialog"
          style="font-size:11px;padding:4px 8px">Image</button>
        <button class="bp" id="btn-send" onclick="onDirectorPrimaryAction()" disabled>Submit →</button>
      </div>
    </div>
    </div><!-- /dir-bottom-section -->
  </div>

  <div class="resize-handle" id="dir-resize"></div>
  <!-- AGENT GRID -->
  <div id="agent-grid">
    <div id="empty-cover">
      <div class="empty-logo-wrap"><img id="shared-conflab-logo-source" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA0MAAACgBAMAAAA81qptAAAAG1BMVEVHcEz///////////////////////////////8W/R0OAAAACXRSTlMAi9GgFjjvYMmWWS9wAAAZlUlEQVR42uxdTVfbShI157WOtyhtwixnlMTTyygCnGUbzGOW9hjiNUpQWJpnwOvRm+fxz56WZFvVX+qWLEA5R0UgHLAldd++VbeqP+h0WmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttV/U6J7vR20Xvrahii+nbde9DH/YJ7q8WbpBEPjHTzcj1uVlaYFGN7PlsX+8XN6MRla3RfuOG/qWpKevPRjR7OEsiqLVqs++Rv7yulQX0M5o9oAD9sEsCNzjJ2qD6daooTfzV446I8X7DbZrB2KWfTeqDm1yMUTpaHet13H+aEKiKPSYxWv26a2iaHBd4gYjxj8XGvafTL2A/kW81GLvTwPJ/+3trJf/4iJ5q4X1x2jbyvwBx1W7yvHzi8wNLZy6BcacTYnbXr6PQgLbS0gcRUfUmoHYl54g8E1M+j0Ms7ut+/PiAfct9JIP1tv9QwBRSGwQ8lbj7ZieuBj7iQVBZYiGLg7YePQTf9EzvHbqsjuxV7rsjql/SQZv2js+Zr9xM19lRaEVDxCDKPkSDcaW7/d9V8bIxQaMz9fpbQi7813xHb5t2Ma6G0JkhxDpj/Mu2z3buKKb60xBS0+NEBUZw8x/sqIBeh9p2toPbVC+VFBo6+0K33+e3ykqjr3f8kc65BydR2wgmtcGEeutBWwh3QeirIseLXzrH/ex1qWHjx1TKL988Ase4doOItjzpSCyCEd1sog1mGveeF+ImN8zYoT+CPWti8n9Y5GuY79xChFyGY+QBUTez8oQ2ciFGiHqcs2d7w0R66JijBB6DhMklKMvHYHRI0UFHHIWvuEBrm1YBLqxTohI/RD9xrXuqAaI3OJw0FkwhNaFzuL7uIBHyISQ6x5T3fs5iD6+GItiFUSVRTff64P9IfKzLtJfI0ziUKwbgyT57a0mlDNyoQff7GuPdQhDiNhdfglHhx741tEaWMSkr/4Ss8ikiEhM+qdaTzfxLR7gbz2zoyPxav6qEFVlkSN07rwOiFx8rZfbLAyZQIpJpHuObmD3BGMzi0hhatQcFnWFQdmrBSJ3QPVJuyK6it/G8fexuiyH93uAc/7e41+BRRdC047qgUjBxrSO3ZXk9jpTd0QAbvWXsiJo5eaSUlDqa2kxRF7/5CUgIjWz6EEcffVApKtTvBfFdqxtp6pBTmD9AOoxe8735K2+MqyDKH5tFiFp+NN6IHKVJdXhPREBSlMhT9R4JM0sqcjDhf398cDo6BJtTF/G0a3qY5Hju2X0QgmIeqqk9X1sOQqZ3uo/SpGo67slMBobISrydI2BqCu17KQmiFSD+CJMQo+Fm0t/9VMa4WoS+eqaKlZlZ+diklyWRZy82XgA/l8aWGssow6llh3VBJGiIuu8l6rEJIqipBciPltKPV9/jorVZ9LswF0yc7GdZJEg6s8rs6jQHaggqhiLJvZyWbhfgP1kiol9Yd8FfiDN3swlRXcQisqtH31/uk7mkW8W/UhqplDnpPIACY6vR5QyDzqa4cBGsogQxXeVWZTO5mutNhYhhduwhOjp5mm2sZubp6flQ2D0mGc8S4gXgYormn0JYy+f5mMu46cYN7HoymCGfONaxNVzMUfW1lKNLLorXLtA64LI8a3cgwIiWfmhGd+Dx1LcA5PKKRDCNLiziLxsGilO/xcndEQSBcIM60iq3h0hE4u8/ueqLPpRtgZaBSKEDnwrKWYFEetjXBiMnoX0LpkX4tISNIk2ii9OUloulFOExGd9kiaSJoEpN5IgSlKjiiwqXaauxKKpfdJpARG98rWilwWMkIuwyhLPDASkfo/jABWUDVZNzs5M5SwpFhGdYDCy6O41WCTXFkyT41NDintVoBeGYV5ZiOM4elTl9ZP7Xd+JenjBx5ojTR3cL1T+53Kt5tNrsagSRLlawEs/vxKtDBG3EIIfwugZqDlC+j3FjHei2rZFvPgEOkEqhM10pQ8yrcSQe+VcscwANZlFebPxpW+jF0wQdaCr48e5E0I3t/qkGzXPm+IqERb3DiXdSc2TK9LElaToiLf6jBoci8CkOLJKXgshSta1IuBo+Ouch3xWr5tWvYxSB7S+K6osYP3yiCEfjows8sgdajCLpkAjLGyK3UYWwZ4cKNiR1U1Iv2AFyjBMJd24KD0oKoEsYKlBdAnnhVXpBsaiBYgbQ5titxmiA2VixEJJTqI1UVSxAZhnSdoqdAAaWi+V48E8MUIUq5eZNINFo7wlj6AAVnApM0QgFvgwA/sN+rnCRQOdq3tF7WxhmxcImcTAzKL4trmxiEPFsUleLSDy1XHgeQ0Kj3dFG2Voov1+CiwrsSCT8jQaG2OResQ0g0WgtsAtBTrdAyLQlxj++Cv0LHPD0AmFtJWfNPFLrTz/bHR06t5uRiyacqBM9dW1EhCBbBhzkpvkyeLPwl0jiEmLD9JMk2muTjsJdmpkEYk92lQWYc61DS3qC5UhGobCevdClA5Oisogx6aEnA9cRhatvH6vobHI4bPVrkWx2wKihbJzvsGtD9RY9RBfwZVQe8aWDbVL+pQsSkJfM1nU5d8MouxJ7RD1M61AkoT+r/JberslNtgkUhXrSoXn6jV8itSoEbFI9GwWotYMEX1QOSQnzNcsrA7Lu+RhiW1qokTv6SACuwTJp2ayaCK0emIeqKVi0QBqtN2QJf39Jk0MS5plTzfQQLQCcyOxvMykCbEIYWGgTcx4lxLdp8qWeXel3RwX/7HN2QNcaoSUEJH/gUlgIm/ZawKLQDPmosOfV4ZopPQw33g9V/oEjBJ6LjPd4k3Aov/CWWB5y14TYtGBWPEBCu9kN4HT4QRyqQIQgOiZ5GnRXmUQwzo/lafjPCOA6ONBqNyc2iAWXUjSS/bfIzQaXd7Mlk/WEHXz2Yi8a1A/h+i2Qiga2m/1VIDa07AIncVAef9oYCx6kEr7wONTdMOQWSZrCQOMdyUXM0RDxRNRUOa2bRk/mnAZyS0GIw1EH7lkLRa37DWARUhuwzDviTEK4NkTJ5YQwcAOXgEEnXZRlOVIPLZ8i6YExEGUjxyS1tZRw2KRpBY66ArOak7gwsJDWxaBq4LO3M1EELAevdK8lmm/tArVgRqiH2CaUdHlDWDRgTw/5MBJbUeVoRsgotDPncKOiXcY0fIIoVLVH7nuStWxKJus3/V5n6KGxaKJXO5E3MibKGrLJhaNMNZp7uzsHcN5FBqI/LJqgdMLmGocHUUrsCNN2MjSABbJagGsa8cBhTTaNdIEEThPCD7Qs+2RIUafbN1MzXt4FjEciO7R3j4WjfJjEg6pLMeSy03lgui0WFldaaqdz9sZV6Zt0V4QubS8c4SJEcciYZk5v2Xv7VnkqFqQe4dknZojR/78foGir64CtY4avcs75u8VYlG3vKDjzpM41ECEOvQMZq8fmxWLQO14vFPMDjzGh+a+8EjJItjZSYq7xJrlwqhve3yVSdlYlbklFdjTsqjze6w7zeTtWaSeBl9AncoGIhaKLuB+S8FcYQ8WhVMRFrvi7NSZPUQTK4i4NbLcMpN99hfRWiBSLSahu4M1xwmJJrKngAs3ggAHyWfyEYgbGbnzIQFEVdIidFFec3OPeqqHqCOkRtSeRdvppph8/RB/+fJlzf59Xadrnee0BoiAjj2U3B/r3+QUCyw7LfujMaiGRRVCEbzro70nt4KIXsBa6j0twaI4rwwzRx6S8D4MM/XBefPKschRL2y8wrvtrjDejktDxI12eGRJZy+IsL2fPFBWJCQW5bVU9v/qJKeRece4t53sX+erIJKfkNVhHY5upxYwJ2NTcmWXGqpyP1uIBpyY6N7vGvWhaRAxKGK4ZY/aswjyKT95aq1lUUmIdIvmHnDSIiSs0CgLUTDmsh8wMVMJokWVVnaV1ULJ0aFutCbxtqtBqDTHojgm3CKVWClbK0KEErXgqzTSdLurf6Gc6LSDCD/yESdfzx3fNgwiBtK7TSenZ9x8so9FO3B2ni49FmMtKMOqsShXC8LR3F3fT9Uct2v1qCRERx1u0rbzm3nzr0F9+i8HUXKkCtntB/teIhYRTxGXpIUQVR1dPjcqvM8JemJtGaJo6ejG/PIEsCtiTxa5LwDRRm8SAY49TtKqRdENhZMw0AxvjpnP3Fx+7NsDJ89s5cKjxtF5/3g1R+fYQsRSo1hRS93jmKZaWDQVTo+4YknoP9P5kvQyOzeHj664Wo7t2aju+GVYVM3RDQohQsP01JStv6L7QxTvDxHN91Vn23qd5K/LZAe48SnRgCLu0tZ5EXeK1cEbQ2RgEToDomxXS7XJi9IF0C/DIpTFX+z66bvQu6yYs3FoaJIHqvQvh9DyEOFTNUT/2RMi67wI2UOUoZGdXkjI7UboVGZRHHs1xKLt4+P0eAq0SP5yS/K3uMZZvRvDLfFXftApDxEXjnKIyIc9C0DzF2BRx7kHdbf+vBAiIoju+IVi0QWnjicZQMzZZZzanSZ/nHm940oQgUPTuvXV6CpVF4pjEUPkWXH82ZvKBdqZ4uz00LTWefUn408K0mMn+TtgeW0oG0/T00oQARoBiFZ7QtSrAtGpgUVMz4BC3Wb7k20sehm5sNmel5HGwcHGMv2dL1nYnDjfPakG0eD/7V1Ld6M4FqZOieNtuUni2bZzxs1WphN7KSq40ks7tkMvp8gpKss4CXFvG8+487MHCTCSkEDCSdigk3qcxOH1cXXf3xVGuhskI4wmyQh0pQ4R8uK4FL5RkKJYgtDxfhHA3HtWxgACHtNdLvnzwOrmnDsQPKtB5EhpHamSwmNTeqfKv+RqSJFxa1O1wz/VpCh+T7+IxBYyrvHFuZNhlN7IdRFoA4eNUQTRik81rv2NJWZZpaWoSWL8cxOIlkpZV0G6ZJiWmajH6Eod6G8AUaJtYKKIMATX51NnN00g2qXmnFn9MKqLtMA1y/WbZyRAXE+iqFi7oFxeoli7kK9LaipZWoFfK0XnjnQ9HA0RZnYjiCBzmh30bycdgrc8RCwRJ0AKEBns9CeYXykYSx6Mvv2sXKRlKFQA0Zor4Cvw3752QccvwszAtCLCa+IjOrCFfw6MmZYUYbGcWaLU68txjRF0HZ3qbarV0YksmqwGplVuVABhxtPmJsK6S6259ZoIAbOhgIGuFLGEdIMyRPGR1ajKjpHZr6tGZSBCL3SW4YfRcjVqz+n/g7CQXJ876UYHnSiKMP1o/izSpNGidFC9pv5+OSQZf2/gGNGpkS/6m6O0ppvOcdIte0N71XIdnZspIhyay9bJLHooXCKYZoh6sBQSU4CoJyim/lr0zzdxjGg2TdVCOhfWdUawWhFc0k0Sv7dcjbrs54oo3eSm1sTw/RUV4CbPAXeUn+hDJFICfxTNK40co4VuxTBQ6C/iDJdbm2WGbk2KsKH9lIXmdpkigudz4K+fswqtbJtLjz3Rh4h+OHlc4tOocMT/c1wESNWkk1BASnURJpLK/NeYyHqbughMMo2UKSJn/GwA358XAe7nw4YFtSECIrfevM/FqFmDkdvXvU8T6kGUJl9jymBoS4rw3CcTO89gNt0RjJK/LwwAomjFWHMoJc7gj6oiReWMNABFCdDrXQN7Qdb/XfEbEgtDDhFyAypccIda0kVgc5Drv3Jz2/kNIxZFfp+15tJW1wd9iKha5NxoB2fDo5pdTahrLywUeBf466Z4iuz9l5akCPySf2qJwxfpRocncpu+b+VxBUL0n7+3J/oQGSKruwhTjn5vsNNV0DpLfqGgf7DoylgZRHgWI93jb/9sSRcBkvtOTAYfx+UwQtPxCdGVEW3NgYIfaNIAIkFf/w0VemyijDaa9gLDAWSoSRETS43jx3ak6Po8rbbsFR7RP+SOez7ttALSswp5ZkZViBbl3Zd2DJskXnU7jFwZ82YVRMZZXJtbeHdd9NkZY6kH/3KoNB5iUxBsFIdDXhOigi6AmkQ5+oLqssIGz+R0rcMBlNzSQoGPrgzRV/HY5o+UIvQ1jZM/5ZbCdByl93TFFu5sZCU3ulJ0+O1grzAbTWnjUnF9TenIrEqI2LEW7eiiR2xhG24G0M7Z/S9FqIiwpCWKTzIbVwkiUTXIC5XWDL1anVninLN07pOdnIWUISo621uTIoB3NsO9oxURziCAomirtJVP3kaKrujO7Lq9CpUZhhc61gLdvcbdQCVE4PN927rITCzt8ZrkWFOI5pwNdpGpAGkOrTFEVBfY0K6LdqOXUtHqtU6MzoTSCSDVUuRdxi3rot4uMbSnOwJQAtTrSYaICTk46GTLA9KFaCOAyBvTuf0afYLZ7rmEr6lh0IGlfPRKNUSUc9CSLnKdTICIEO0mnImaMVoj9imfaEcXhMbGC9XdVucavZR4aMBBWyrki9hZ8UgHIib52oYU3RQFEIkQ/X24+MxRvShc7YXErVCCSPgKf2Nosasav8F1YMc8UzR6Ui/qXlYMaamGCBhnAnvhI3XRo6xMhaQh6LHIrrDwVzGMKhh7AtKhEXEtWRM+Kkmu/WTZUQ7qEulpIq4JsU6KjKugXSmiyop2Y0aNzjb9aC4JLc81IeoJJ9MARhPvK9xXN4jjUuoP8NYCkqbDGCHiH0sdRKZtl+ToA6XIvMv9oWSb+5UdpOV5sjeR2VoU2O7FZH2ICVIO7UB6ubOQrgnlL+iiCiCCUfJ2WdIJU7UQgdtWpai3y43tBKNoxb18EqsMMhEXFSl6EupqhM1uquTxpywl+BKL2IJKkXckhAmwPlE5u1QLUS9o06Jzi33u9XTtqYrnhR5EtCqgi7zwTkdVfO4lqbk/74eEz+B1yAwCc1mR9rYDyU63qCKAqIeIpLbs1qRoWVhzk/V6ZVSJkSs2W2shosmdqG0GH/+G7YcPI6FLExyy0yPBDmuROPzMtxyxg8QhVHZ0ayACNI/rx0sR+Gt6kKLI31Z/vifmrVRgu7dknn2PDlImSvlOMFZyEeatbzHLa/VU0LiaPiFgtUQQ+1ZV57qSFJVdo4+TIkAZ3NvtpvrzEsbYWojYAdLsZnbG3vn+nn+A3jJkpnPNS5dzYXh+nh12TvlLADxCZRO9FiLsONttSZF5nhlzaaKo5tOWMENTS6W+gNI8gOHes3vIPjxlFOLsJWQfzY+Sghv4FDEhZDEC3oLvcCrHaxUg+nT/4VIECoMuN7odx7qoGX8iri6sgYgzp7hrApf8FhL+GqHCNbsM6KFPTP13ryD+oo2BwYr17TjyB8EzUYAIBJw2ejO/KFoLl7/2fZSlXNNOIiJDtbVOdOma8HxliDy/X7nPADJm3KYnQe7DcLKe4faxcRjacSzrR3TFjYEwASn16Lz1xunzQiSwKBQgMm7fSYr68oakKXmZwE3uFSnFusT2AnW+bYkc1Sk/Ii5cfWnHJWaJMF1BzP0M5yyQMOzGiApML4Sq+KnsolCBqHdvv4sUwQqaijlx9B6HdoZPdS6hHAx9FkEEHYv+cmANtSN5QIG4RTQm+MRFVTH+D+05PVX02ELoiO9+AJpBxNs1byZFlRCRgAGedaNejfakS3YGJeelomrmuDyZeEhNn4ppkrfv9PsC+9rLmqNGEAE+lvpmukjhWqkA5ynQOPRE73wVr8FSWMBh5+NEmQdzaIfGU8MbQCT0bZWkCNgtSRHXRA3U7QVt4k1Z9TXARl38WkP+kWx6MVsR2dNHCIpNXCWIiMEQf6wU5b4r9a1aKeqJgt1aEAmiB2nb76tdx3RkD+9pXf+pwTYnNlnVIPoU0BV1EsrA94BIbzqGcGjQ8tiNBr0Er2WLoQSZPfqhfZtSCiJ9iFgP7gOlyNXqdUOi7kWNZyUx683LYSyy6thv7e+YSron/X1O4smrQZSonLgViJZ6hdEie2F5pBDhFyWs2+gS45stbgD6QhQZR0Fk0jvdx0FERzgV6mhozpD+XB8iaUDqJqjVRKN/S2O6ahI8MaQQxSobnfESt6GLTM1uRBHbwfJIbY3tSPAY1Nh0ey4lyxp0DnTqTj5A4DgpMtygjY1Ol6YFCB54M25UHqOzajnaf5/L5dlyBuunaqmyoPwNVIUIjNowuvWsBSDUXcujtzkSkz7DaYnYzlq07SFFFp98624uu0sL9iOP5p3UMhU4iP5bef+3B1+aoZe7it8TooVuv6jAeV0eZ08VGCXqmKL1LUiYX4ej7yuZbWkRgEjSowKjyarizF+LEEY1YVSvqPvbM1Jkvx9EoEi1wC9KB78uS4UaRINV3aG9yxDH5mwmOUHIefeCfHmaJXJg5BXJXRlGllN58m+0FFVu92f5OxRLA0DgbSEC+sNRTVgaMqVyPmegYIyAzSjAM2VImUI8fM0CqHYocDlJhM4ZkOwfOOTApZZC5Xmp2Xk1tGuf8x5/ZhyRfoxuoQoRYopEkdrRy2wH9eeDA7VBXcC/DGPsINF1QaP7CIlCUU5iI3A/8GaWI+D+jGpu7dtIFSIzFJoLwRH5InkwmEgRuio+oEiNiKjd5DQ/X3Iex7Is/C9Z7CaTPErPUFzeZhSGedwU4xMGiRoB5d3jCg5WSAQyyyHZd/oDz6jZff5g/KJKPP8UsdG6wyOlCFboogaj1F1KfSEFKdquPWRoLNO3pmEY7vcjnHbtb1fiB2yWtQsiX2C97ePXpQ8t6MCtytsBKOrFajABEJE0AjF1o9IZAV75v9xKX1qge3D6KgF9PtkpShUtCte/9jc4o75drzxDfwFv5pPEeKT5drzJQu0fGzV46N3qVre61a1udatb3epWt7rVrW51q1vd6la3utWtbnWrW93qFrP+Dz7MEX5BXYWTAAAAAElFTkSuQmCC" alt="Conflab" style="height:80px;object-fit:contain">
      <div class="empty-version" id="empty-version"></div></div>
      <div class="es">Multi-Provider Collaboration</div>
      <div class="empty-info-box">
        <div class="empty-info-title-row">
          <div class="empty-info-title">CONFLAB OVERVIEW:</div>
          <div class="empty-info-actions">
            <button class="bs" type="button" id="btn-overview-examples" onclick="openExamplesModal()">Examples</button>
          </div>
        </div>
        <div id="overview-md-body" class="md-doc md-overview"></div>
        <div class="empty-info-license" id="overview-license-note"></div>
      </div>
    </div>
  </div>
  <div id="app-footer">&copy; Copyright: David Todd - April, 2026</div>
</div>

<div id="startup-workspace-loading-overlay" class="startup-workspace-loading-overlay" aria-hidden="true"></div>

<div id="session-suspended-overlay" class="session-suspended-overlay" aria-live="assertive">
  <div class="session-suspended-card">
    <div class="session-suspended-kicker">TAB INACTIVE</div>
    <div class="session-suspended-title">This tab is no longer active.</div>
    <div class="session-suspended-body">A newer Conflab tab is using this workspace. This tab can no longer do anything.</div>
    <div id="session-suspended-status" class="session-suspended-status"></div>
    <button id="session-suspended-close" class="bp" type="button" onclick="attemptCloseSuspendedTab(false)">Close Tab</button>
  </div>
</div>

<script>
// ══════════════════════════════════════════════════════════════════
const GHOST_COLOR_ID='ghost';
const COLORS=[
  {id:'teal',  hex:'#18d4c0',dim:'#0a4038'},
  {id:'blue',  hex:'#60a5fa',dim:'#1d3a5e'},
  {id:'pink',  hex:'#f472b6',dim:'#5e1d42'},
  {id:'violet',hex:'#a78bfa',dim:'#3a1d5e'},
  {id:'orange',hex:'#fb923c',dim:'#5e3a1d'},
  {id:'yellow',hex:'#facc15',dim:'#5e5a1d'},
  {id:'emerald', hex:'#34d399',dim:'#1a4f45'},
  {id:'crimson', hex:'#f87171',dim:'#5f2626'},
  {id:'indigo',  hex:'#818cf8',dim:'#2b2f63'},
  {id:'lime',    hex:'#a3e635',dim:'#3f6212'},
  {id:GHOST_COLOR_ID, hex:'#94a3b8',dim:'#334155'},
];
const DIRECTOR_COLORS=COLORS.filter(c=>c.id!==GHOST_COLOR_ID);
const DEFAULT_MODELS=[
  {id:'openrouter/free',name:'Auto (Free Router)',free:true},
  {id:'anthropic/claude-sonnet-4',name:'Claude Sonnet 4',free:false},
  {id:'openai/gpt-4o',name:'GPT-4o',free:false},
  {id:'google/gemini-2.5-pro',name:'Gemini 2.5 Pro',free:false},
  {id:'deepseek/deepseek-v3.2',name:'DeepSeek V3.2',free:false},
];
const DEFAULT_IMAGE_MODELS=[
  {id:'black-forest-labs/flux.2-klein-4b',name:'FLUX.2 Klein 4B',free:true},
  {id:'riverflow/riverflow-v2-fast',name:'Riverflow V2 Fast',free:true},
  {id:'google/gemini-2.5-flash-image-preview',name:'Gemini 2.5 Flash Image',free:false},
];
const IMAGE_STYLE_OPTIONS=[
  {id:'photo-realistic',label:'Photo Realistic'},
  {id:'cinematic',label:'Cinematic'},
  {id:'poster-glossy',label:'Poster Glossy'},
  {id:'engineering-diagram',label:'Engineering Diagram'},
  {id:'comic',label:'Comic'},
  {id:'graphic-novel',label:'Graphic Novel'},
  {id:'line-art',label:'Line Art'},
  {id:'black-and-white',label:'Black and White'},
  {id:'sketch-pencil',label:'Sketch / Pencil'},
  {id:'oil-painting',label:'Oil Painting'},
  {id:'watercolor',label:'Watercolor'},
  {id:'minimalist',label:'Minimalist'},
  {id:'isometric',label:'Isometric'},
  {id:'3d-render',label:'3D Render'},
];
const IMAGE_ASPECT_OPTIONS=[
  {id:'1:1',label:'1:1 (square)',ratio:'1 / 1'},
  {id:'4:3',label:'4:3',ratio:'4 / 3'},
  {id:'3:4',label:'3:4',ratio:'3 / 4'},
  {id:'16:9',label:'16:9',ratio:'16 / 9'},
  {id:'9:16',label:'9:16',ratio:'9 / 16'},
];
const DEFS=[
  {name:'Agent 1', color:'teal', persona:''},
  {name:'Agent 2', color:'blue', persona:''},
  {name:'Agent 3', color:'pink', persona:''},
  {name:'Agent 4', color:'violet', persona:''},
];
const IMAGE_OUTPUT_MIME_TYPE='image/jpeg';
const IMAGE_OUTPUT_FILE_EXTENSION='jpg';
const IMAGE_OUTPUT_JPEG_QUALITY=0.9;
const APP_VERSION='v3.93';
const DEFAULT_WEB_SEARCH_BUDGET=2;
const LOCAL_SERVICE_BASE_URL=/^https?:\/\//i.test(String(window.location?.origin||''))
  ? window.location.origin
  : 'http://127.0.0.1:47821';
const CONFLAB_BRIDGE_AUTH_TOKEN=String(window.__CONFLAB_BRIDGE_AUTH_TOKEN||'');
const SERVER_HEARTBEAT_INTERVAL_MS=300000;
let serverHeartbeatTimer=null;
let serverHeartbeatPromise=null;
const SESSION_BROADCAST_CHANNEL_NAME='conflab-session-ownership';
const SESSION_SUPERSEDED_MESSAGE='This tab is no longer active because a newer Conflab tab took over this workspace.';
function ensureModelId(modelId){
  return String(modelId||'').trim()||'openrouter/free';
}
function ensureImageModelId(modelId){
  return String(modelId||'').trim()||DEFAULT_IMAGE_MODELS[0].id;
}
function getDefaultPersonaModel(){
  return ensureModelId(APP_SETTINGS.helperModel||DEFAULT_APP_SETTINGS.helperModel);
}
function formatProviderName(provider){
  const key=String(provider||'').trim().toLowerCase();
  const map={openrouter:'OpenRouter',anthropic:'Anthropic',openai:'OpenAI',google:'Google',deepseek:'DeepSeek',meta:'Meta',mistralai:'Mistral',xai:'xAI',qwen:'Qwen'};
  if(map[key]) return map[key];
  return key?key.replace(/[-_]+/g,' ').replace(/\b\w/g,m=>m.toUpperCase()):'OpenRouter';
}
function fallbackModelName(modelId){
  const raw=ensureModelId(modelId);
  const parts=raw.split('/');
  const leaf=(parts[1]||parts[0]||raw).replace(/:free$/i,'').replace(/[-_]+/g,' ').trim();
  return leaf.replace(/\b\w/g,m=>m.toUpperCase())||raw;
}
function getModelCatalog(key='helper'){
  if(key==='image'){
    return Array.isArray(S.openRouterImageModels)&&S.openRouterImageModels.length?S.openRouterImageModels:DEFAULT_IMAGE_MODELS;
  }
  return Array.isArray(S.openRouterModels)&&S.openRouterModels.length?S.openRouterModels:DEFAULT_MODELS;
}
function isOpenRouterAutoFreeModel(modelId){
  return ensureModelId(modelId)==='openrouter/free';
}
function getFirstAvailableFreeTextModel(){
  const models=Array.isArray(S.openRouterModels)?S.openRouterModels:[];
  const match=models.find(m=>m&&m.free&&m.id&&m.id!=='openrouter/free');
  return match?String(match.id||'').trim():'';
}
async function ensureOpenRouterTextModelsLoadedForRequest(){
  if(S.openRouterModelsLoaded&&Array.isArray(S.openRouterModels)&&S.openRouterModels.length) return S.openRouterModels;
  await fetchOpenRouterModels();
  return Array.isArray(S.openRouterModels)?S.openRouterModels:[];
}
async function resolveHelperOpenRouterModelForRequest(modelId){
  const id=ensureModelId(modelId);
  if(isOpenRouterAutoFreeModel(id)){
    await ensureOpenRouterTextModelsLoadedForRequest();
    const resolved=getFirstAvailableFreeTextModel();
    if(resolved) return resolved;
    throw createApiError(
      'Auto Free Router is unavailable because no free text model is available from the OpenRouter catalog. Select a specific helper model in Settings.',
      400,
      'No free OpenRouter text model available for openrouter/free.'
    );
  }
  if(S.openRouterModelsLoaded&&Array.isArray(S.openRouterModels)&&S.openRouterModels.length&&!S.openRouterModels.some(m=>m.id===id)){
    throw createApiError(`Selected helper model "${id}" is not in the current OpenRouter catalog. Select a different helper model in Settings.`,404,`Unknown helper model: ${id}`);
  }
  return id;
}
function getPopularModelIds(key='helper'){
  const defaults=key==='image'?DEFAULT_IMAGE_MODELS:DEFAULT_MODELS;
  return new Set(defaults.map(m=>m.id));
}
function getModelEntry(modelId,key='helper'){
  const id=key==='image'?ensureImageModelId(modelId):ensureModelId(modelId);
  return getModelCatalog(key).find(m=>m.id===id)||null;
}
function formatModelPricing(pricing){
  if(!pricing) return '';
  const inp=Number.parseFloat(pricing.prompt);
  const out=Number.parseFloat(pricing.completion);
  if(!Number.isFinite(inp)||!Number.isFinite(out)) return '';
  return `$${(inp*1000000).toFixed(2)}/$${(out*1000000).toFixed(2)} 1M`;
}
function stripProviderPrefix(provider,modelName){
  const prov=formatProviderName(provider);
  const raw=String(modelName||'').trim();
  if(!prov||!raw) return raw;
  const escaped=prov.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  let next=raw.replace(new RegExp(`^${escaped}\\s*[:\\-–—|]\\s*`,'i'),'').trim();
  if(next!==raw) return next||raw;
  next=raw.replace(new RegExp(`^${escaped}\\s+`,'i'),'').trim();
  return next||raw;
}
function getModelNameText(modelId,key='helper'){
  const id=key==='image'?ensureImageModelId(modelId):ensureModelId(modelId);
  const providerKey=id.split('/')[0]||'';
  const entry=getModelEntry(id,key);
  const base=entry?String(entry.name||'').trim():fallbackModelName(id);
  return stripProviderPrefix(providerKey,base)||fallbackModelName(id);
}
function getModelDisplayName(modelId,key='helper'){
  const id=key==='image'?ensureImageModelId(modelId):ensureModelId(modelId);
  const entry=getModelEntry(id,key);
  return getModelNameText(id,key)+(entry?.free?' (Free)':'');
}
function getModelSummaryData(modelId,key='helper'){
  const id=key==='image'?ensureImageModelId(modelId):ensureModelId(modelId);
  const entry=getModelEntry(id,key);
  const provider=formatProviderName(id.split('/')[0]||'');
  const modelName=getModelNameText(id,key);
  if(entry){
    const price=entry.free?'Free':formatModelPricing(entry.pricing);
    return{label:`${provider}: ${modelName}`,price,free:!!entry.free};
  }
  return{label:`${provider}: ${modelName}`,price:'Unavailable',free:false};
}
function getModelPickerConfig(key){
  if(key==='image') return{
    inputId:'img-model',summaryId:'img-model-summary',pickerId:'img-model-picker',
    searchId:'img-model-search',listId:'img-model-list',tierName:'img-model-tier',
    warningId:''
  };
  if(key==='persona') return{
    inputId:'pe-model',summaryId:'pe-model-summary',pickerId:'pe-model-picker',
    searchId:'pe-model-search',listId:'pe-model-list',tierName:'pe-model-tier',
    warningId:'pe-model-warning'
  };
  if(key==='helper') return{
    inputId:'set-helper-model',summaryId:'set-helper-model-summary',pickerId:'set-helper-model-picker',
    searchId:'set-helper-model-search',listId:'set-helper-model-list',tierName:'set-helper-model-tier',
    warningId:''
  };
  return null;
}
function getModelPickerTier(key){
  const cfg=getModelPickerConfig(key);
  if(!cfg) return 'free';
  return document.querySelector(`input[name="${cfg.tierName}"]:checked`)?.value||'free';
}
function updateModelPickerSummary(key){
  const cfg=getModelPickerConfig(key);
  if(!cfg) return;
  const input=document.getElementById(cfg.inputId);
  const summary=document.getElementById(cfg.summaryId);
  if(!input||!summary) return;
  input.value=key==='image'?ensureImageModelId(input.value):ensureModelId(input.value);
  const data=getModelSummaryData(input.value,key);
  summary.innerHTML=
    `<span class="mps-main" title="${esc(data.label)}">${esc(data.label)}</span>`+
    `<span class="mps-price${data.free?' mp-free':''}">${esc(data.price||'')}</span>`;
  summary.title=data.label+(data.price?` · ${data.price}`:'');
}
function updatePersonaModelWarning(){
  const warning=document.getElementById('pe-model-warning');
  const input=document.getElementById('pe-model');
  if(!warning||!input) return;
  const modelId=ensureModelId(input.value);
  if(S.openRouterModelsLoaded&&modelId&&!S.openRouterModels.some(m=>m.id===modelId)){
    warning.style.display='block';
    warning.textContent='This model is not in the current OpenRouter catalog. Choose a new model if you plan to keep this persona.';
    return;
  }
  warning.style.display='none';
  warning.textContent='';
}
function closeModelPicker(key){
  const cfg=getModelPickerConfig(key);
  if(!cfg) return;
  document.getElementById(cfg.pickerId)?.classList.remove('open');
  if(S.activeModelPicker===key) S.activeModelPicker='';
}
function closeAllModelPickers(except=''){
  ['persona','helper','image'].forEach(key=>{if(key!==except) closeModelPicker(key);});
}
function refreshModelPicker(key){
  const cfg=getModelPickerConfig(key);
  if(!cfg) return;
  const list=document.getElementById(cfg.listId);
  const input=document.getElementById(cfg.inputId);
  if(!list||!input) return;
  const selectedId=key==='image'?ensureImageModelId(input.value):ensureModelId(input.value);
  const tier=getModelPickerTier(key);
  const q=String(document.getElementById(cfg.searchId)?.value||'').trim().toLowerCase();
  let models=getModelCatalog(key).slice();
  if(tier==='free') models=models.filter(m=>m.free);
  else if(tier==='popular'){
    const ids=getPopularModelIds(key);
    models=models.filter(m=>ids.has(m.id));
  }
  if(q){
    models=models.filter(m=>{
      const provider=formatProviderName(m.id.split('/')[0]||'').toLowerCase();
      return m.id.toLowerCase().includes(q)||String(m.name||'').toLowerCase().includes(q)||provider.includes(q);
    });
  }
  list.innerHTML='';
  if(!models.length){
    list.innerHTML='<div class="model-picker-empty">No models match this filter.</div>';
    return;
  }
  models.forEach(model=>{
    const row=document.createElement('button');
    row.type='button';
    row.className='model-picker-item'+(model.id===selectedId?' selected':'');
    const provider=formatProviderName(model.id.split('/')[0]||'');
    const modelName=stripProviderPrefix(model.id.split('/')[0]||'',model.name||fallbackModelName(model.id))||fallbackModelName(model.id);
    const price=model.free?'Free':formatModelPricing(model.pricing);
    row.innerHTML=
      `<span class="mp-main" title="${esc(`${provider}: ${modelName}`)}">${esc(`${provider}: ${modelName}`)}</span>`+
      `<span class="mp-price${model.free?' mp-free':''}">${esc(price||'')}</span>`;
    row.onclick=()=>selectModelFromPicker(key,model.id);
    list.appendChild(row);
  });
}
function openModelPicker(key){
  const cfg=getModelPickerConfig(key);
  if(!cfg) return;
  closeAllModelPickers(key);
  document.getElementById(cfg.pickerId)?.classList.add('open');
  S.activeModelPicker=key;
  refreshModelPicker(key);
  document.getElementById(cfg.searchId)?.focus();
}
function toggleModelPicker(key){
  if(key==='persona'&&isPersonaEditorLocked()) return;
  const cfg=getModelPickerConfig(key);
  if(!cfg) return;
  const picker=document.getElementById(cfg.pickerId);
  if(!picker) return;
  if(picker.classList.contains('open')) closeModelPicker(key);
  else openModelPicker(key);
}
function selectModelFromPicker(key,modelId){
  const cfg=getModelPickerConfig(key);
  if(!cfg) return;
  const input=document.getElementById(cfg.inputId);
  if(!input) return;
  input.value=key==='image'?ensureImageModelId(modelId):ensureModelId(modelId);
  updateModelPickerSummary(key);
  if(key==='persona') updatePersonaModelWarning();
  if(key==='helper') updateSettingsSaveState();
  if(key==='image') void onImageSettingChange();
  refreshModelPicker(key);
  closeModelPicker(key);
}
function refreshAllModelDisplays(){
  updateModelPickerSummary('persona');
  updateModelPickerSummary('helper');
  updateModelPickerSummary('image');
  updatePersonaModelWarning();
  if(S.activeModelPicker) refreshModelPicker(S.activeModelPicker);
}
async function fetchOpenRouterModels(){
  try{
    const r=await fetchProtectedBridgeJson('/api/openrouter/models',{method:'POST',timeoutMs:60000,timeoutLabel:'OpenRouter model list'});
    if(!r.ok) return;
    const d=await r.json();
    const models=(d.data||[])
      .filter(m=>{
        const modalities=Array.isArray(m?.architecture?.output_modalities)?m.architecture.output_modalities:[];
        return !modalities.length||modalities.includes('text');
      })
      .map(m=>({
        id:String(m.id||'').trim(),
        name:String(m.name||m.id||'').trim(),
        free:Number.parseFloat(m?.pricing?.prompt)===0&&Number.parseFloat(m?.pricing?.completion)===0,
        contextLength:m.context_length||0,
        pricing:m.pricing||null,
        supportsTools:(
          (Array.isArray(m?.supported_parameters)&&(
            m.supported_parameters.includes('tools')||
            m.supported_parameters.includes('tool_choice')
          ))||
          (Array.isArray(m?.supported_features)&&m.supported_features.includes('tool_use'))||
          (m?.architecture?.tool_calling===true)
        )||undefined
      }))
      .filter(m=>m.id)
      .sort((a,b)=>{
        if(a.free!==b.free) return a.free?-1:1;
        const providerCompare=formatProviderName(a.id.split('/')[0]||'').localeCompare(formatProviderName(b.id.split('/')[0]||''));
        if(providerCompare!==0) return providerCompare;
        return a.name.localeCompare(b.name);
      });
    if(models.length){
      S.openRouterModels=models;
      S.openRouterModelsLoaded=true;
      refreshAllModelDisplays();
    }
  }catch(e){
    console.warn('Failed to fetch OpenRouter models:',e);
  }
}

async function fetchProtectedBridgeJson(path,{method='POST',payload=null,signal=null,timeoutMs=LOCAL_TOOL_TIMEOUT_MS,timeoutLabel='Local bridge request'}={}){
  const timeoutRef=createTimeoutSignal(timeoutMs,signal);
  const headers={
    ...(CONFLAB_BRIDGE_AUTH_TOKEN?{'X-Conflab-Bridge-Token':CONFLAB_BRIDGE_AUTH_TOKEN}:{})
  };
  const req={method,headers,signal:timeoutRef.signal};
  if(payload!==null&&payload!==undefined){
    headers['Content-Type']='application/json; charset=utf-8';
    req.body=JSON.stringify(payload||{});
  }
  try{
    return await fetch(getLocalServiceUrl(path),req);
  }catch(e){
    if(signal?.aborted&&e?.name==='AbortError') throw e;
    if(timeoutRef.signal.aborted&&e?.name==='AbortError'){
      throw createApiError(`${timeoutLabel} timed out after ${Math.round(timeoutMs/1000)} seconds.`,408,'timeout');
    }
    throw createApiError('Could not reach the local Conflab bridge. Reload Conflab or restart the local service.',0,e?.message||'');
  }finally{
    timeoutRef.cleanup();
  }
}

function getPayloadErrorMessage(payload){
  const err=payload?.error;
  if(err&&typeof err==='object') return String(err.message||err.code||'');
  return String(err||payload?.message||'');
}
async function fetchOpenRouterImageModels(force=false){
  if(S.openRouterImageModelsLoaded&&!force) return S.openRouterImageModels;
  await ensureProtectedSettingsReadyForProviderUse();
  if(!isProviderKeyConfigured('keyOpenRouter')){
    const err=createApiError('Invalid API key. Check your OpenRouter key in Settings.',401,'Missing OpenRouter API key');
    showHelperApiError(err);
    throw err;
  }
  try{
    const r=await fetchProtectedBridgeJson('/api/openrouter/image-models',{method:'POST',timeoutMs:60000,timeoutLabel:'OpenRouter image model list'});
    if(!r.ok){
      const e=await r.json().catch(()=>({}));
      const msg=getPayloadErrorMessage(e)||('OpenRouter error '+r.status);
      throw createApiError(mapOpenRouterError(r.status,msg),r.status,msg);
    }
    const d=await r.json();
    const models=(d.data||[])
      .filter(m=>{
        const modalities=Array.isArray(m?.architecture?.output_modalities)?m.architecture.output_modalities:[];
        return modalities.includes('image');
      })
      .map(m=>({
        id:String(m.id||'').trim(),
        name:String(m.name||m.id||'').trim(),
        free:Number.parseFloat(m?.pricing?.prompt)===0&&Number.parseFloat(m?.pricing?.completion)===0,
        contextLength:m.context_length||0,
        pricing:m.pricing||null,
        outputModalities:Array.isArray(m?.architecture?.output_modalities)?m.architecture.output_modalities:[]
      }))
      .filter(m=>m.id)
      .sort((a,b)=>{
        if(a.free!==b.free) return a.free?-1:1;
        const providerCompare=formatProviderName(a.id.split('/')[0]||'').localeCompare(formatProviderName(b.id.split('/')[0]||''));
        if(providerCompare!==0) return providerCompare;
        return a.name.localeCompare(b.name);
      });
    if(models.length){
      S.openRouterImageModels=models;
      S.openRouterImageModelsLoaded=true;
      refreshAllModelDisplays();
    }
    return S.openRouterImageModels;
  }catch(e){
    showHelperApiError(e);
    throw e;
  }
}
const OVERVIEW_MD=String.raw`

Conflab lets you convene a panel of AI-powered participants - each with a distinct persona,
expertise, and point of view - and **direct the conversation**. Ask a question, pose a problem,
or explore an idea, and hear it back from multiple angles simultaneously, drawing on multiple
providers so different systems can bring their strengths into the same conversation and
complement one another.

> *This isn't chat with one AI. It's a structured discussion you control.*

---

## How It Works

You create **personas** - an oncologist, a skeptic, a five-year-old, a poet, anyone you can
imagine - and assign them to agent slots. Type your prompt and every agent responds **in parallel**.
They see each other's responses, building on, challenging, and refining the conversation
round by round.

You decide who to address, when to redirect, and when to dig deeper. Agents can also
search the web independently for current data - each researching from their own expert
angle - so your conversations stay grounded in real information.

---

## What People Use It For

| | |
|---|---|
| **Complex Decisions** | Hear a medical question from a specialist, a holistic practitioner, and a patient advocate. Weigh a career move from a mentor, a risk analyst, and your future self. |
| **Education & Learning** | Run a Socratic panel on any topic. Have a physicist, a philosopher, and a journalist each explain the same concept their own way. |
| **Creative Work** | Test your characters' voices. Put your protagonist and antagonist in a room and see what happens. |
| **Strategy & Products** | Simulate a focus group before you build. Pressure-test a pitch with a skeptical customer, a power user, and a competitor analyst. |
| **Science & Academia** | Stress-test a paper with a methodologist, a domain expert, and a hostile reviewer before you submit. |
| **Spiritual Exploration** | Reflect on purpose, values, and belief through multiple wisdom traditions without a single "correct" answer. |
| **Training & Skills** | Rehearse difficult conversations, practice facilitation, or explore group dynamics with personas representing different communication styles. |
| **Personal Reflection** | Journal a major life decision through the lens of a pragmatist, a values coach, and a risk analyst. |
| **Live Research** | Agents independently search the web for current pricing, reviews, evidence, and data. Each expert researches from their own angle and brings back different sources. |

> These are just starting points. The real power is that **you define the panel** -
> any combination of perspectives you can imagine.

---

## Getting Started

Use the **Root Folder** control at top-right to select a working folder, then create a
conversation and assign personas to your agents.

For a full catalog of use-case ideas with example panels, look for the **Examples button**
in the overview panel.

---

##### Disclaimer

*Conflab is an exploration and thinking tool. All responses are AI-generated by the language
models you configure. Personas are simulated roles, not real professionals. Nothing in this
application constitutes medical, legal, financial, therapeutic, or other professional advice.
Always consult qualified professionals for real-world decisions. Use your own judgment -
this is a tool for broadening perspective, not a substitute for expertise.*
`;
const USE_CASES_MD=String.raw`### 35 ways to use multi-perspective conversations

A catalog of scenarios where assembling a panel of distinct voices produces better
thinking than any single conversation could. Each entry describes a situation, suggests
a panel, and explains why the multi-perspective approach matters.

---

---

## Life & Personal

---

### 1. Complex Life Decisions

Life's big crossroads - a health diagnosis, a career change, relocation, retirement
timing, eldercare - rarely have one right answer.

> *Perspectives only - not a substitute for professional medical, legal, or financial advice.*

**Example panel:** Relevant medical or domain specialist, risk analyst, someone
who's been through it, values-oriented advisor

The oncologist tells you about treatment efficacy. The patient advocate tells you about
quality of life. The financial planner tells you what it costs. The person who's been
through it tells you what nobody warns you about. Each perspective surfaces tradeoffs
you wouldn't think of alone.

---

### 2. Informed Product Decisions

Personal buying decisions - cars, appliances, laptops, phones, insurance plans,
tools - where you're the one spending the money. The current process is exhausting:
biased reviews, sponsored videos, and trying to mentally hold five tradeoff
dimensions at once.

**Example panel:** Consumer advocate, technical expert, financial analyst, current owner

Ask about the Tesla Model Y vs. the Ioniq 5 and each persona attacks it from a completely
different angle. The mechanic talks battery degradation. The financial analyst talks
depreciation curves and tax credits. The owner talks about what it's actually like to
live with the car for two years.

---

### 3. Personal Decision Journaling

Major life and career decisions where you need to see your own tradeoffs from outside
your own head.

**Example panel:** Your future self (five years out), risk analyst, values coach, pragmatist

"Should I leave this job?" gets very different answers from each. The future-self
perspective is particularly powerful - it forces you to think about which version of
regret you can live with.

---

### 4. Difficult Conversation Prep

You have a hard conversation coming - with a boss, a family member, a business partner,
an ex. Rehearse it before it happens.

**Example panel:** The other person (as you understand them), empathetic coach, blunt
realist, your own anxious inner voice

Practice different approaches and see how they land. Try being direct. Try being gentle.
See what the other person's persona pushes back on. Hear from the coach when you're
finding the right words and from the realist when you're being avoidant.

---

### 5. Parenting & Family Decisions

School choice, screen time limits, discipline approaches, medical decisions for your
kids, how to handle a bully, when to push and when to back off.

> *Perspectives only - not a substitute for pediatric or psychological professional advice.*

**Example panel:** Pediatrician, child psychologist, experienced parent, child's-perspective
persona

The child's perspective is the one parents rarely get honestly - and it's often the
most important one. How does this decision actually *feel* from their side?

---

---

## Education & Learning

---

### 6. Education & Multi-Expert Learning

Explore any topic through multiple expert lenses simultaneously. A physics concept
explained by a physicist, a philosopher of science, a science journalist, and a curious
10-year-old hits completely differently than a textbook.

**Example panel:** Domain expert, historian of the field, skeptic, plain-language explainer

A teacher could project this in a classroom. A student could stress-test their
understanding by seeing how different experts frame the same idea. The disagreements
between panelists are often where the real learning happens.

---

### 7. Classroom Simulation

You're an educator preparing to teach, and you want to test how a lesson or explanation
lands with students at a specific developmental level.

**Example panel:** A group of 8-year-olds, *or* a classroom of high schoolers, *or*
college freshmen in their first week

Each persona has age-appropriate vocabulary, attention span, and curiosity patterns. A
kindergarten teacher can rehearse a science lesson and see where she loses them. A college
professor can test whether his lecture is pitched right or sailing over heads. The student
personas don't just passively receive - they interrupt, get confused, get bored, and
ask the questions real students ask.

---

### 8. Curriculum & Training Design

You're designing a course, a training module, or a lesson plan and want to pressure-test
it before you're standing in front of real students.

**Example panel:** Teacher, student at the target level, assessment designer, accessibility
reviewer

The student tells you when they're lost. The assessment designer asks how you'll know
learning happened. The accessibility reviewer catches barriers to participation. Improves
lesson flow, comprehension checks, pacing, and inclusivity.

---

### 9. Historical What-Ifs

Convene figures from different eras to discuss a modern problem. The anachronism is
the point - it strips away modern assumptions.

**Example panel:** A Roman senator, an Enlightenment philosopher, a 1960s civil rights
activist, a contemporary technologist

What would Marcus Aurelius think about social media? What would Ada Lovelace say about
machine learning? More educational and thought-provoking than strictly practical, but
genuinely illuminating.

---

---

## Perspectives & Understanding

---

### 10. Generational Perspectives

The same topic discussed across generational lines. Not stereotypes - genuine attempts
at how life stage, historical context, economic reality, and cultural experience shape
perspective.

**Example panel:** Gen Z college student, millennial parent, Gen X professional, baby
boomer retiree, Silent Generation elder

How does each generation see remote work? Social media? Homeownership? Marriage?
Useful for marketing, policy design, family dynamics, and understanding why people who
agree on values can disagree so intensely on specifics.

---

### 11. The Young Mind Test

Deliberately use children's perspectives to stress-test an idea, product, explanation,
or assumption. If you can't explain it to a five-year-old, maybe you don't understand
it well enough yourself.

**Example panel:** A group of 5-year-olds

They will ask "but *why*?" in ways that expose hidden complexity and unexamined
assumptions. They don't have adult jargon tolerance, polite agreement reflexes, or the
habit of pretending they understand when they don't. This is "explain it like I'm five"
turned into an actual multi-round conversation where the five-year-olds push back.

---

### 12. Spiritual & Meaning Exploration

Questions about purpose, faith, doubt, values, and what it means to live well don't
have empirical answers - and that's precisely why multiple perspectives matter.

**Example panel:** Contemplative guide, comparative religion scholar, secular humanist,
gentle skeptic, lived-experience voice

This isn't about finding the "right" answer. It's about sitting with a question from
multiple angles and seeing what resonates. Useful for reflection on grief, purpose,
forgiveness, transitions, and belief itself.

---

### 13. Community & Civic Deliberation

Simulated town hall. You're a city council member, a community organizer, or just a
citizen trying to understand a local issue.

**Example panel:** Long-time residents, new business owners, city planner, environmental
advocate, parent concerned about schools

Test how a policy proposal, zoning change, or community initiative lands across
different constituencies. See where the real opposition will come from and whether
there's common ground nobody has articulated yet.

---

### 14. Legal & Ethical Reasoning

Gray-area decisions where the law, ethics, practical consequences, and stakeholder
impact don't all point the same direction.

> *Perspectives only - not legal advice. Consult a qualified professional before acting.*

**Example panel:** Ethicist, affected party, regulator, pragmatist

A way to see the full landscape of competing concerns and tensions before you talk
to a real lawyer or make a real decision.

---

---

## Professional & Business

---

### 15. Strategy & Product Thinking

Team and business-level product decisions - what to build, how to position it, whether
the business model holds up. (For personal buying decisions, see #2 Informed Product
Decisions.) Convene a simulated focus group and pitch your idea to people who will
actually push back.

**Example panel:** Skeptical customer, power user, competitor analyst, first-time user,
pricing consultant

The disagreements between the power user and the first-time user reveal your real design
tensions. The competitor analyst tells you what the other guys do better. The pricing
consultant questions your business model.

---

### 16. Board & Advisor Prep

You have a board meeting, investor pitch, or advisor session next week. Find the weak
spots before someone finds them for you in the room.

**Example panel:** Investor, operator, skeptic, customer advocate

Pressure-test your strategy memo, decision options, or presentation slides. The investor
wants growth. The operator worries about execution risk. The skeptic challenges every
assumption. The customer advocate asks whether any of this actually helps the user.

---

### 17. Advertising & Campaign Development

You have a product or service and need to develop messaging, taglines, or a full
campaign concept.

**Example panel:** Creative director, target demographic persona, brand strategist,
skeptical consumer, competitor's customer

Pitch your rough concept, get reactions, refine the copy, test tagline options - all in
successive rounds. The creative director and the skeptical consumer will disagree
constantly, and that tension is where good advertising lives.

---

### 18. Focus Testing & Audience Reaction

Broader than advertising - test any idea, message, product concept, or proposal against
a panel representing your intended audience.

**Example panel:** Early adopter, mainstream user, resistant holdout, someone who's never
heard of you

The question shifts from "should we build this?" to "how does this land with real
people?" Watch where enthusiasm drops, where confusion sets in, and where the resistant
holdout accidentally gives you your best marketing angle.

---

### 19. Content Accuracy & Narrative Quality

For articles, newsletters, blog posts, reports, and documentation that need to balance
truth, depth, accessibility, and voice.

**Example panel:** Fact-checker, subject matter expert, reader advocate, copy editor

The fact-checker catches unsupported assertions. The subject matter expert checks
technical accuracy. The reader advocate flags jargon. The copy editor tightens prose.
You don't sacrifice one for the others.

---

### 20. Incident Response

Something has gone wrong - a production outage, a security incident, a data breach,
a PR crisis. You need technical response and external messaging coordinated in one place.

**Example panel:** SRE, security lead, communications lead, product owner

See all perspectives simultaneously instead of sequentially in a chaotic war room. The
SRE diagnoses. The security lead assesses blast radius. The comms lead drafts customer
messaging. The product owner prioritizes recovery.

---

### 21. Internationalization & Localization Review

You're launching a product, campaign, or content in a new market and want to catch
problems before your audience does.

**Example panel:** Local-market user, translator, legal-cultural reviewer, support rep

Catches tone mismatches, cultural missteps, idiomatic failures, and legal issues. The
local user tells you what feels foreign. The translator catches nuance. The support
rep anticipates the tickets that will come in.

---

### 22. Regulatory & Compliance Readiness

You're preparing for an audit, writing policy text, or rolling out something in a
regulated industry.

**Example panel:** Compliance officer, legal risk analyst, operator, customer advocate

The tension between the compliance officer and the operator is where practical policy
lives. One knows the letter of the regulations; the other needs the policy to actually
be workable in practice.

---

---

## Science & Research

---

### 23. Scientific Paper Collaboration

Improve your manuscript's quality before submission - strengthen the claims, methods,
and narrative. (For simulating the actual review process and anticipating reviewer
objections, see #24 Peer-Review Rehearsal.)

**Example panel:** Methodologist, domain scientist, statistician, skeptical reviewer, editor

Each one attacks different weaknesses. The statistician catches the p-hacking the domain
expert missed. The editor says the abstract buries the lead. You revise before the real
reviewers ever see it.

---

### 24. Peer-Review Rehearsal

Anticipate reviewer objections and plan revisions before the real review process
begins. (For improving the manuscript itself, see #23 Scientific Paper Collaboration.)

**Example panel:** Reviewer 1 (methodological stickler), Reviewer 2 (novelty critic),
Reviewer 3 (real-world applicability advocate), Associate Editor

Each reviewer has a different personality and priority. The associate editor weighs
their comments and tells you what you'd actually need to address. Preempt likely
objections and revision requests.

---

### 25. Grant Proposal Shaping

Grant writing is persuasion under constraints. Every reviewer reads with a different
lens, and you need to satisfy all of them.

**Example panel:** Program officer, technical expert, impact evaluator, budget hawk

The program officer tells you your significance section is burying the public health
angle. The budget hawk says your travel line is going to get flagged. You tighten the
significance narrative, feasibility argument, and funding justification before the deadline.

---

### 26. Cross-Disciplinary Research

Ask the same research question from the lens of different fields and see where the
answers converge, diverge, or flatly contradict each other. The intersections are where
the genuinely new ideas live.

**Example panel:** Biologist, ethicist, economist, sociologist

"What should we do about antibiotic resistance?" - The biologist talks phage therapy.
The economist talks incentive structures. The ethicist talks global equity. The
sociologist talks behavioral change. Each field sees something the others miss.

---

---

## Health & Wellbeing

---

### 27. Mental Health Group Simulation

Simulate group therapy or support group dynamics for training and education purposes.
Useful for building empathy, practicing facilitation, and understanding communication
patterns.

**Example panel:** Personas with different patterns - an anxious participant, someone
processing grief, a person with trust barriers, a naturally supportive group member

Therapist trainees can practice reflections, boundaries, and rupture-repair. Facilitators
can rehearse group process skills. Anyone preparing for emotionally complex conversations
can build confidence in a safe space.

> **Important:** Simulation and psychoeducation only. Use fictional composite personas.
> Encourage follow-up with licensed professionals for real care decisions.

---

### 28. Veterinary & Pet Care

Your dog is limping, your cat stopped eating, your horse has a skin condition, your
parrot is pulling feathers. The fundamental difference from human medical conversations
is that the patient can't tell you what's wrong.

> *Perspectives only - not a substitute for veterinary care. See a vet for real health concerns.*

**Example panel:** Veterinarian (species-specific), integrative/holistic vet, experienced
breed handler, pet owner who's been through it

Species matters enormously. Even within species, breed-specific conditions change the
picture completely - a limp in a German Shepherd and a limp in a Dachshund point to
very different things. This extends beyond illness to nutrition, training, behavioral
issues, and end-of-life decisions. "My 14-year-old lab is declining - when is it time?"
answered by a vet, a hospice practitioner, a grief counselor, and someone who's been
through it is a conversation people genuinely need.

---

---

## Creative & Expressive

---

### 29. Creative Writing & Worldbuilding

Characters need to sound like themselves, not like variations of the author. Create
personas for your characters and put them in scenes together to see if their voices
hold up under pressure.

**Example panel:** Your protagonist, antagonist, mentor, love interest - plus a literary
critic and a writing coach

Does your villain actually sound menacing or just petulant? Does your protagonist's
dialogue carry the weight of their backstory? The literary critic evaluates from outside
the story. The writing coach spots where the tension drops.

---

### 30. Everyday Practical Problems

Home repair, DIY projects, car maintenance, yard work, home improvement. The kind of
questions where you'd normally call three different people and get three different answers.

**Example panel:** Licensed contractor, experienced DIYer, building inspector,
budget-conscious homeowner

"I want to install a new kitchen sink" gets process steps, tool lists, common mistakes,
and honest assessments of difficulty level from each perspective. The contractor knows
code. The DIYer knows shortcuts. The inspector knows what gets flagged. The homeowner
asks whether it's worth doing yourself or hiring out.

---

---

## Web-Enabled Research 🌐

*These scenarios benefit from enabling web search on agent personas. Agents
independently research current data from their own expert angle, bringing back
different sources and perspectives grounded in live information. Enable web search
in persona settings (requires a Brave Search API key in Settings).*

---

### 31. Product Comparison with Current Data 🌐

You're deciding between two specific products right now - a car, a laptop, an appliance,
an insurance plan. Generic advice isn't enough; you need current pricing, real reviews,
and actual owner experiences.

> *Enable web search on these personas for current pricing and reviews.*

**Example panel:** Consumer advocate, technical specialist, financial analyst, current owner

Ask about the Ioniq 5 vs. the Model Y and each persona independently researches from
their angle. The mechanic searches for reliability and battery degradation data. The
financial analyst looks up current incentives, depreciation curves, and insurance costs.
The owner finds real community forum posts about what it's like to live with the car.
Each agent brings back different sources - and they can see what the others found.

---

### 32. Current Events Analysis 🌐

Something is happening in the world and you want to understand it from multiple angles
before forming your own view. Headlines give you one take; you want several.

**Example panel:** Geopolitical analyst, economist, historian, investigative journalist

Each agent independently researches the situation, finds different sources, emphasizes
different aspects, and challenges each other's interpretations. The historian searches
for precedents. The economist looks for market impact data. The journalist finds
primary sources. The geopolitical analyst checks regional reactions and alliances.

---

### 33. Investment & Market Research 🌐

You're considering a financial decision - a stock, a real estate market, a business
sector, a retirement allocation - and want current data examined from multiple risk
perspectives before you act.

> *Perspectives only - not a substitute for professional financial advice.*

**Example panel:** Financial analyst, skeptic/bear case, macro economist, risk assessor

The analyst researches fundamentals and recent earnings. The skeptic specifically looks
for warning signs, debt levels, and competitor threats. The economist checks broader
trends and rate environment. The risk assessor searches for comparable situations that
went sideways. Each brings back different data from different sources, and they
challenge each other's conclusions.

---

### 34. Health Decision with Current Evidence 🌐

You've been given a diagnosis or treatment recommendation and want to understand the
current evidence landscape from multiple perspectives before your next appointment.

> *Perspectives only - not a substitute for professional medical advice.*

**Example panel:** Medical specialist, patient advocate, integrative medicine
practitioner, medical ethicist

The specialist searches for recent clinical trial data and treatment protocols. The
patient advocate finds community experiences and quality-of-life reports. The
integrative practitioner looks for complementary approaches with evidence backing.
The ethicist considers the decision framework and what questions you should ask your
doctor. Current, sourced, multi-angle - and you walk into your appointment better
prepared.

---

### 35. Travel Planning with Live Information 🌐

You're planning a trip and want current, practical intelligence - not generic travel
blog advice from three years ago.

**Example panel:** Local culture expert, budget analyst, safety advisor, food critic

The culture expert researches current events, festivals, and exhibitions happening
during your dates. The budget analyst finds current hotel and flight pricing with
specific comparisons. The safety advisor checks current travel advisories, local
conditions, and health requirements. The food critic searches for current restaurant
recommendations, seasonal specialties, and recent reviews. Every recommendation
is grounded in what's actually happening now, not what a guidebook said two years ago.

---

---

##### Disclaimer

*Conflab is an exploration and thinking tool. All responses are AI-generated by the
language models you configure. Personas are simulated roles, not real professionals.
Nothing in this application constitutes medical, legal, financial, therapeutic, or other
professional advice. Always consult qualified professionals for real-world decisions.
Use your own judgment - this is a tool for broadening perspective, not a substitute
for expertise.*
`;
const MIT_USAGE_NOTICE='MIT Usage Notice: This software is provided under the MIT License. You may use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies, provided the MIT license terms are included with substantial portions of the software. The software is provided "as is", without warranty of any kind.';

function syncVersionLabels(){
  const topbar=document.getElementById('topbar-version');
  if(topbar) topbar.textContent=APP_VERSION;
  const empty=document.getElementById('empty-version');
  if(empty) empty.textContent=APP_VERSION;
}

function syncLogoImages(){
  const src=document.getElementById('shared-conflab-logo-source')?.getAttribute('src')||'';
  if(!src) return;
  document.querySelectorAll('img[data-shared-logo-target]').forEach(img=>{
    if(img.getAttribute('src')!==src) img.setAttribute('src',src);
  });
}

const APP_DIALOG_STATE={
  resolve:null,
  kind:'alert',
  cancelValue:false
};

function handleAppDialogKeydown(event){
  const modal=document.getElementById('modal-app-dialog');
  if(!modal||modal.style.display!=='flex') return;
  if(event.key==='Escape'){
    event.preventDefault();
    if(APP_DIALOG_STATE.kind==='alert') submitAppDialog();
    else cancelAppDialog();
    return;
  }
  if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){
    const tag=String(document.activeElement?.tagName||'').toUpperCase();
    if(tag==='TEXTAREA') return;
    event.preventDefault();
    submitAppDialog();
  }
}

function finalizeAppDialog(result){
  const modal=document.getElementById('modal-app-dialog');
  if(modal) modal.style.display='none';
  document.removeEventListener('keydown',handleAppDialogKeydown,true);
  const resolve=APP_DIALOG_STATE.resolve;
  APP_DIALOG_STATE.resolve=null;
  if(resolve) resolve(result);
}

function submitAppDialog(){
  const input=document.getElementById('app-dialog-input');
  if(APP_DIALOG_STATE.kind==='prompt') finalizeAppDialog(input?input.value:'');
  else finalizeAppDialog(true);
}

function cancelAppDialog(){
  finalizeAppDialog(APP_DIALOG_STATE.cancelValue);
}

function handleAppDialogBackdrop(event){
  if(event&&event.target&&event.target.id!=='modal-app-dialog') return;
  if(APP_DIALOG_STATE.kind==='alert') submitAppDialog();
  else cancelAppDialog();
}

function openAppDialog(options={}){
  return new Promise(resolve=>{
    const modal=document.getElementById('modal-app-dialog');
    const titleEl=document.getElementById('app-dialog-title');
    const messageEl=document.getElementById('app-dialog-message');
    const inputWrap=document.getElementById('app-dialog-input-wrap');
    const inputLabel=document.getElementById('app-dialog-input-label');
    const input=document.getElementById('app-dialog-input');
    const cancelBtn=document.getElementById('app-dialog-cancel');
    const okBtn=document.getElementById('app-dialog-ok');
    if(!modal||!titleEl||!messageEl||!inputWrap||!inputLabel||!input||!cancelBtn||!okBtn){
      resolve(options.kind==='prompt'?null:(options.kind==='confirm'?false:true));
      return;
    }
    if(APP_DIALOG_STATE.resolve) APP_DIALOG_STATE.resolve(APP_DIALOG_STATE.cancelValue);
    APP_DIALOG_STATE.resolve=resolve;
    APP_DIALOG_STATE.kind=options.kind||'alert';
    APP_DIALOG_STATE.cancelValue=('cancelValue' in options)?options.cancelValue:(APP_DIALOG_STATE.kind==='prompt'?null:false);
    titleEl.textContent=String(options.title||'NOTICE');
    messageEl.textContent=String(options.message||'');
    inputWrap.hidden=APP_DIALOG_STATE.kind!=='prompt';
    inputLabel.textContent=String(options.inputLabel||'Value');
    input.value=String(options.defaultValue||'');
    input.placeholder=String(options.placeholder||'');
    cancelBtn.style.display=APP_DIALOG_STATE.kind==='alert'?'none':'';
    cancelBtn.textContent=String(options.cancelLabel||'Cancel');
    okBtn.textContent=String(options.okLabel||'OK');
    modal.style.display='flex';
    document.addEventListener('keydown',handleAppDialogKeydown,true);
    setTimeout(()=>{
      if(APP_DIALOG_STATE.kind==='prompt'){
        input.focus();
        input.select();
      }else{
        okBtn.focus();
      }
    },0);
  });
}

async function appAlert(message,options={}){
  return openAppDialog({
    kind:'alert',
    title:options.title||'NOTICE',
    message,
    okLabel:options.okLabel||'OK'
  });
}

async function appConfirm(message,options={}){
  return !!await openAppDialog({
    kind:'confirm',
    title:options.title||'CONFIRM ACTION',
    message,
    okLabel:options.okLabel||'Continue',
    cancelLabel:options.cancelLabel||'Cancel',
    cancelValue:false
  });
}

async function appPrompt(message,defaultValue='',options={}){
  return openAppDialog({
    kind:'prompt',
    title:options.title||'ENTER VALUE',
    message,
    okLabel:options.okLabel||'OK',
    cancelLabel:options.cancelLabel||'Cancel',
    cancelValue:null,
    defaultValue,
    inputLabel:options.inputLabel||'Value',
    placeholder:options.placeholder||''
  });
}

function hidePopupMenu(){
  const menu=document.getElementById('popup-menu');
  if(!menu) return;
  menu.style.display='none';
  menu.setAttribute('aria-hidden','true');
  menu.innerHTML='';
}

function bindPopupMenuHandlers(){
  if(POPUP_MENU_STATE.bound) return;
  POPUP_MENU_STATE.bound=true;
  document.addEventListener('mousedown',event=>{
    const menu=document.getElementById('popup-menu');
    if(!menu||menu.style.display!=='block') return;
    if(menu.contains(event.target)) return;
    hidePopupMenu();
  },true);
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape') hidePopupMenu();
  },true);
}

function showPopupMenu(x,y,actions=[]){
  const menu=document.getElementById('popup-menu');
  if(!menu) return;
  bindPopupMenuHandlers();
  menu.innerHTML='';
  actions.filter(action=>action&&!action.hidden).forEach(action=>{
    const btn=document.createElement('button');
    btn.type='button';
    btn.textContent=String(action.label||'Action');
    if(action.danger) btn.className='popup-danger';
    btn.onclick=async event=>{
      event.preventDefault();
      event.stopPropagation();
      hidePopupMenu();
      await action.onSelect?.();
    };
    menu.appendChild(btn);
  });
  if(!menu.children.length) return;
  menu.style.display='block';
  menu.setAttribute('aria-hidden','false');
  const rect=menu.getBoundingClientRect();
  const vw=window.innerWidth||document.documentElement.clientWidth||0;
  const vh=window.innerHeight||document.documentElement.clientHeight||0;
  menu.style.left=Math.max(8,Math.min(x,vw-rect.width-8))+'px';
  menu.style.top=Math.max(8,Math.min(y,vh-rect.height-8))+'px';
}

function getPopupAnchorPoint(event,fallbackEl=null){
  if(event&&Number.isFinite(event.clientX)&&Number.isFinite(event.clientY)){
    return{x:event.clientX,y:event.clientY};
  }
  const el=fallbackEl||event?.currentTarget||null;
  if(el?.getBoundingClientRect){
    const rect=el.getBoundingClientRect();
    return{x:rect.left+Math.min(rect.width,80)/2,y:rect.bottom-4};
  }
  return{x:window.innerWidth/2,y:window.innerHeight/2};
}

function registerDownloadViewerCleanup(fn){
  if(typeof fn!=='function') return;
  const prev=DOWNLOAD_VIEWER_STATE.closeCleanup;
  DOWNLOAD_VIEWER_STATE.closeCleanup=prev
    ? ()=>{ try{prev();}catch(e){} try{fn();}catch(e){} }
    : fn;
}

function getConversationRefByPath(path=''){
  const key=String(path||'').trim();
  if(!key) return null;
  if(S.conv?.sourcePath===key) return S.conv;
  return S.downloadsTreeIndex?.[key]||S.convTreeIndex?.[key]||null;
}

function canExportViewedArtifact(){
  return DOWNLOAD_VIEWER_STATE.kind==='text';
}

function canPrintViewedArtifact(){
  return DOWNLOAD_VIEWER_STATE.kind==='text';
}

function getViewedArtifactExportTitle(){
  if(/text\/html/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))||/\.html?$/i.test(String(DOWNLOAD_VIEWER_STATE.name||''))) return 'Export HTML file';
  if(/text\/markdown/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))||/\.(?:md|markdown)$/i.test(String(DOWNLOAD_VIEWER_STATE.name||''))) return 'Export Markdown file';
  return 'Export text file';
}

function syncDownloadViewerActions(){
  const deleteBtn=document.getElementById('download-viewer-delete');
  const printBtn=document.getElementById('download-viewer-print');
  const exportBtn=document.getElementById('download-viewer-download');
  const canDelete=!!DOWNLOAD_VIEWER_STATE.deleteItem&&['summary','log'].includes(getDownloadItemKind(DOWNLOAD_VIEWER_STATE.deleteItem));
  const canPrint=canPrintViewedArtifact();
  const canExport=canExportViewedArtifact();
  if(deleteBtn){
    deleteBtn.style.display=canDelete?'':'none';
    deleteBtn.disabled=!canDelete;
  }
  if(printBtn){
    printBtn.style.display=canPrint?'':'none';
    printBtn.disabled=!canPrint;
    printBtn.title='Print or save as PDF';
    printBtn.setAttribute('aria-label','Print or save as PDF');
  }
  if(exportBtn){
    exportBtn.style.display=canExport?'':'none';
    exportBtn.disabled=!canExport;
    exportBtn.textContent='Export';
    exportBtn.title=getViewedArtifactExportTitle();
  }
}

function closeDownloadViewer(event){
  if(event?.target?.id&&event.target.id!=='modal-download-viewer') return;
  const modal=document.getElementById('modal-download-viewer');
  const body=document.getElementById('download-viewer-body');
  if(modal) modal.style.display='none';
  if(body) body.innerHTML='';
  if(DOWNLOAD_VIEWER_STATE.closeCleanup){
    try{DOWNLOAD_VIEWER_STATE.closeCleanup();}catch(e){}
  }
  DOWNLOAD_VIEWER_STATE.kind='';
  DOWNLOAD_VIEWER_STATE.name='';
  DOWNLOAD_VIEWER_STATE.mime='text/plain;charset=utf-8';
  DOWNLOAD_VIEWER_STATE.text='';
  DOWNLOAD_VIEWER_STATE.exportText='';
  DOWNLOAD_VIEWER_STATE.objectUrl='';
  DOWNLOAD_VIEWER_STATE.closeCleanup=null;
  DOWNLOAD_VIEWER_STATE.convPath='';
  DOWNLOAD_VIEWER_STATE.isSummary=false;
  DOWNLOAD_VIEWER_STATE.openedWhileFullscreen=false;
  DOWNLOAD_VIEWER_STATE.deleteItem=null;
  DOWNLOAD_VIEWER_STATE.summaryImageStatus='none';
  DOWNLOAD_VIEWER_STATE.summaryImageSnapshot=null;
  syncDownloadViewerActions();
}

function renderHtmlTextInDownloadViewer(htmlText){
  const body=document.getElementById('download-viewer-body');
  if(!body) return;
  body.innerHTML='<div class="download-viewer-html-shell"><iframe class="download-viewer-frame" sandbox="allow-same-origin"></iframe></div>';
  const frame=body.querySelector('.download-viewer-frame');
  if(!frame) return;
  const normalizedHtml=normalizeConflabArtifactHtmlDocument(htmlText);
  frame.onload=()=>{
    try{
      const doc=frame.contentDocument;
      const nextHeight=Math.max(
        Number(doc?.documentElement?.scrollHeight)||0,
        Number(doc?.body?.scrollHeight)||0,
        560
      );
      frame.style.height=nextHeight+'px';
    }catch(e){}
  };
  frame.srcdoc=String(normalizedHtml||'');
}

function openTextDownloadViewer({name,text,isHtml=true,mime='text/html;charset=utf-8',convPath='',isSummary=false,deleteItem=null}){
  const modal=document.getElementById('modal-download-viewer');
  const title=document.getElementById('download-viewer-title');
  const body=document.getElementById('download-viewer-body');
  if(!modal||!title||!body) return;
  closeDownloadViewer();
  DOWNLOAD_VIEWER_STATE.kind='text';
  DOWNLOAD_VIEWER_STATE.name=name||'download.txt';
  DOWNLOAD_VIEWER_STATE.mime=mime;
  DOWNLOAD_VIEWER_STATE.text=String(text||'');
  DOWNLOAD_VIEWER_STATE.exportText='';
  DOWNLOAD_VIEWER_STATE.convPath=String(convPath||'');
  DOWNLOAD_VIEWER_STATE.isSummary=!!isSummary;
  DOWNLOAD_VIEWER_STATE.openedWhileFullscreen=!!document.fullscreenElement;
  DOWNLOAD_VIEWER_STATE.deleteItem=deleteItem||null;
  title.textContent=String(name||'VIEWER');
  syncDownloadViewerActions();
  if(isHtml){
    renderHtmlTextInDownloadViewer(DOWNLOAD_VIEWER_STATE.text);
  }else if(/text\/markdown/i.test(mime)||/\.(?:md|markdown)$/i.test(String(name||''))){
    body.innerHTML=`<div class="md-doc">${renderMarkdownHtml(DOWNLOAD_VIEWER_STATE.text)}</div>`;
  }else{
    body.innerHTML=`<pre class="download-viewer-pre">${esc(DOWNLOAD_VIEWER_STATE.text)}</pre>`;
  }
  modal.style.display='flex';
  if(isHtml&&DOWNLOAD_VIEWER_STATE.isSummary){
    const viewerMarker=DOWNLOAD_VIEWER_STATE.name+'|'+DOWNLOAD_VIEWER_STATE.convPath;
    queueMicrotask(async()=>{
      const htmlText=await prepareDownloadViewerHtmlExportText();
      if(DOWNLOAD_VIEWER_STATE.kind!=='text') return;
      if((DOWNLOAD_VIEWER_STATE.name+'|'+DOWNLOAD_VIEWER_STATE.convPath)!==viewerMarker) return;
      if(String(htmlText||'')===String(DOWNLOAD_VIEWER_STATE.text||'')) return;
      renderHtmlTextInDownloadViewer(htmlText);
    });
  }
}

async function deleteViewedArtifact(){
  const item=DOWNLOAD_VIEWER_STATE.deleteItem;
  const kind=getDownloadItemKind(item);
  if(!item||!['summary','log'].includes(kind)) return;
  const noun=kind==='summary'?'summary':'log';
  const ok=await appConfirm(`Delete this saved ${noun}?`,{title:`DELETE ${noun.toUpperCase()}`,okLabel:'Delete'});
  if(!ok) return;
  try{
    await item.artifactDirHandle?.removeEntry(item.fileName,{recursive:false});
  }catch(e){
    await appAlert('Could not delete this saved artifact.',{title:'DELETE FAILED'});
    return;
  }
  const convPath=String(DOWNLOAD_VIEWER_STATE.convPath||'').trim();
  closeDownloadViewer();
  if(convPath){
    const synced=await syncDownloadsForConversationPath(convPath,{render:true,expand:false,reconcile:false});
    if(!synced) await scanDownloadsTree();
  }else{
    await scanDownloadsTree();
  }
}

function uint8ArrayToBase64(bytes){
  const arr=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes||[]);
  let out='';
  const chunkSize=0x8000;
  for(let i=0;i<arr.length;i+=chunkSize){
    out+=String.fromCharCode(...arr.subarray(i,i+chunkSize));
  }
  return btoa(out);
}

function injectSummaryImageIntoMarkdown(md,imageMarkdown){
  const src=String(md||'').replace(/\r\n?/g,'\n');
  const heading=src.match(/^(#{1,6}\s+.+)$/m);
  if(!heading||typeof heading.index!=='number'){
    return `${imageMarkdown}\n\n${src}`;
  }
  const insertAt=heading.index+heading[0].length;
  return `${src.slice(0,insertAt)}\n\n${imageMarkdown}\n${src.slice(insertAt)}`;
}

const CONFLAB_ARTIFACT_RUNTIME_CSS=`
.summary-image{
  margin:16px auto 20px !important;
  break-inside:avoid;
  page-break-inside:avoid;
}
.summary-image img{
  display:block;
  margin:0 auto !important;
}
.summary-image.is-portrait img{
  max-width:75% !important;
}
@page {
  size: letter;
  margin: 0.25in;
}
@media print {
  body{
    padding:0 !important;
    background:#fff !important;
  }
  .conflab-deliverable{
    padding:0 44px !important;
    border:0 !important;
    border-radius:0 !important;
    box-shadow:none !important;
  }
  .summary-image.is-portrait img{
    max-width:75% !important;
    max-height:6in !important;
  }
}
`;
function ensureConflabArtifactRuntimeStyle(doc){
  if(!doc) return;
  let head=doc.head;
  if(!head){
    head=doc.createElement('head');
    if(doc.documentElement.firstChild) doc.documentElement.insertBefore(head,doc.documentElement.firstChild);
    else doc.documentElement.appendChild(head);
  }
  let style=doc.querySelector('style[data-conflab-artifact-runtime="1"]');
  if(!style){
    style=doc.createElement('style');
    style.setAttribute('data-conflab-artifact-runtime','1');
    head.appendChild(style);
  }
  style.textContent=CONFLAB_ARTIFACT_RUNTIME_CSS;
}
function normalizeConflabArtifactHtmlDocument(htmlText){
  try{
    const parser=new DOMParser();
    const doc=parser.parseFromString(String(htmlText||''),'text/html');
    if(!doc?.documentElement) return String(htmlText||'');
    const host=doc.querySelector('.conflab-deliverable');
    if(!host) return String(htmlText||'');
    ensureConflabArtifactRuntimeStyle(doc);
    return '<!DOCTYPE html>\n'+doc.documentElement.outerHTML;
  }catch(e){
    return String(htmlText||'');
  }
}

function setHtmlDocumentTitle(htmlText,titleText){
  try{
    const parser=new DOMParser();
    const doc=parser.parseFromString(String(htmlText||''),'text/html');
    if(!doc?.documentElement) return String(htmlText||'');
    let head=doc.head;
    if(!head){
      head=doc.createElement('head');
      if(doc.documentElement.firstChild) doc.documentElement.insertBefore(head,doc.documentElement.firstChild);
      else doc.documentElement.appendChild(head);
    }
    let title=doc.querySelector('title');
    if(!title){
      title=doc.createElement('title');
      head.appendChild(title);
    }
    title.textContent=String(titleText||'Conflab Deliverable');
    return '<!DOCTYPE html>\n'+doc.documentElement.outerHTML;
  }catch(e){
    return String(htmlText||'');
  }
}

function isPortraitImageAspect(aspectId){
  const match=String(aspectId||'').match(/^\s*(\d+(?:\.\d+)?)\s*:\s*(\d+(?:\.\d+)?)\s*$/);
  if(!match) return false;
  const width=Number(match[1])||0;
  const height=Number(match[2])||0;
  return width>0&&height>0&&height>width;
}
function injectSummaryImageIntoHtmlDocument(htmlText,imageSrc,altText='Summary image',aspectId=''){
  try{
    const parser=new DOMParser();
    const doc=parser.parseFromString(String(htmlText||''),'text/html');
    const host=doc.querySelector('.conflab-deliverable')||doc.body;
    if(!host) return String(htmlText||'');
    ensureConflabArtifactRuntimeStyle(doc);
    const figure=doc.createElement('figure');
    figure.className='summary-image';
    if(isPortraitImageAspect(aspectId)) figure.classList.add('is-portrait');
    const img=doc.createElement('img');
    img.setAttribute('src',String(imageSrc||''));
    img.setAttribute('alt',String(altText||'Summary image'));
    figure.appendChild(img);
    const heading=host.querySelector('h1,h2');
    if(heading?.parentNode) heading.insertAdjacentElement('afterend',figure);
    else host.prepend(figure);
    return '<!DOCTYPE html>\n'+doc.documentElement.outerHTML;
  }catch(e){
    return String(htmlText||'');
  }
}

function printHtmlArtifactToPdf(htmlText,docTitle='',opts={}){
  const ifr=document.createElement('iframe');
  const previousTitle=document.title;
  const nextTitle=String(docTitle||'').trim()||previousTitle;
  const fullscreenRestore=createFullscreenRestoreController(opts.restoreFullscreen===true);
  ifr.style.position='fixed';
  ifr.style.left='-9999px';
  ifr.style.width='1px';
  ifr.style.height='1px';
  ifr.setAttribute('sandbox','allow-same-origin allow-modals');
  document.body.appendChild(ifr);
  let restored=false;
  const restoreTitle=()=>{
    if(restored) return;
    restored=true;
    try{ document.title=previousTitle; }catch(e){}
  };
  try{
    document.title=nextTitle;
  }catch(e){}
  ifr.onload=()=>{
    try{
      try{
        if(ifr.contentDocument) ifr.contentDocument.title=nextTitle;
      }catch(e){}
      try{
        ifr.contentWindow?.addEventListener('afterprint',()=>fullscreenRestore.attemptRestore(),{once:true});
      }catch(e){}
      ifr.contentWindow?.focus();
      ifr.contentWindow?.print();
    }finally{
      setTimeout(()=>fullscreenRestore.attemptRestore(),250);
      setTimeout(restoreTitle,1500);
      setTimeout(()=>{
        try{ifr.remove();}catch(e){}
        fullscreenRestore.cleanup();
      },5000);
    }
  };
  ifr.srcdoc=String(htmlText||'');
}
async function prepareDownloadViewerHtmlExportText(){
  if(DOWNLOAD_VIEWER_STATE.kind!=='text') return '';
  const baseHtml=normalizeConflabArtifactHtmlDocument(String(DOWNLOAD_VIEWER_STATE.text||''));
  if(!DOWNLOAD_VIEWER_STATE.isSummary||!/text\/html/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))){
    DOWNLOAD_VIEWER_STATE.exportText=baseHtml;
    return baseHtml;
  }
  if(DOWNLOAD_VIEWER_STATE.exportText){
    return DOWNLOAD_VIEWER_STATE.exportText;
  }
  const convKey=String(DOWNLOAD_VIEWER_STATE.convPath||'');
  const convRef=getConversationRefByPath(convKey);
  if(!convRef){
    DOWNLOAD_VIEWER_STATE.exportText=baseHtml;
    return baseHtml;
  }
  let resolved={
    status:DOWNLOAD_VIEWER_STATE.summaryImageStatus,
    snapshot:DOWNLOAD_VIEWER_STATE.summaryImageSnapshot
  };
  if(!resolved.snapshot){
    resolved=await resolveSummaryImageSelectionForConversation(convRef);
    if(DOWNLOAD_VIEWER_STATE.kind!=='text'||String(DOWNLOAD_VIEWER_STATE.convPath||'')!==convKey){
      return String(DOWNLOAD_VIEWER_STATE.exportText||DOWNLOAD_VIEWER_STATE.text||'');
    }
    DOWNLOAD_VIEWER_STATE.summaryImageStatus=resolved.status;
    DOWNLOAD_VIEWER_STATE.summaryImageSnapshot=resolved.snapshot;
  }
  if(resolved.status==='ok'&&resolved.snapshot?.bytes?.length){
    const snap=resolved.snapshot;
    const dataUrl=`data:${snap.mimeType||IMAGE_OUTPUT_MIME_TYPE};base64,${uint8ArrayToBase64(snap.bytes)}`;
    DOWNLOAD_VIEWER_STATE.exportText=injectSummaryImageIntoHtmlDocument(
      baseHtml,
      dataUrl,
      snap.altText||'Summary image',
      snap.aspect||''
    );
    return DOWNLOAD_VIEWER_STATE.exportText;
  }
  DOWNLOAD_VIEWER_STATE.exportText=baseHtml;
  return baseHtml;
}
function buildBasicPrintableHtmlDocument(titleText,bodyHtml){
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${esc(String(titleText||'Conflab Deliverable'))}</title>
  <style>
    @page { size: letter; margin: 0.25in; }
    body{margin:0;padding:0;background:#fff;color:#111;font-family:"JetBrains Mono","Courier New",monospace}
    .print-shell{padding:0 44px;box-sizing:border-box}
    .print-shell img{display:block;max-width:100%;max-height:9.5in;margin:0 auto}
    .print-shell pre{margin:0;white-space:pre-wrap;word-break:break-word;font-size:12px;line-height:1.6}
  </style>
</head>
<body>
  <div class="print-shell">${bodyHtml}</div>
</body>
</html>`;
}

async function prepareViewedArtifactPrintHtml(){
  const title=String(DOWNLOAD_VIEWER_STATE.name||'download').replace(/\.[^.]+$/,'').trim()||'download';
  if(DOWNLOAD_VIEWER_STATE.kind!=='text') return{htmlText:'',title};
  if(/text\/html/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))||/\.html?$/i.test(String(DOWNLOAD_VIEWER_STATE.name||''))){
    return{
      htmlText:setHtmlDocumentTitle(await prepareDownloadViewerHtmlExportText(),title),
      title
    };
  }
  if(/text\/markdown/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))||/\.(?:md|markdown)$/i.test(String(DOWNLOAD_VIEWER_STATE.name||''))){
    return{
      htmlText:buildBasicPrintableHtmlDocument(title,`<div class="md-doc">${renderMarkdownHtml(String(DOWNLOAD_VIEWER_STATE.text||''))}</div>`),
      title
    };
  }
  return{
    htmlText:buildBasicPrintableHtmlDocument(title,`<pre>${esc(String(DOWNLOAD_VIEWER_STATE.text||''))}</pre>`),
    title
  };
}

async function printViewedArtifact(){
  if(!canPrintViewedArtifact()) return;
  const prepared=await prepareViewedArtifactPrintHtml();
  if(!prepared?.htmlText) return;
  printHtmlArtifactToPdf(prepared.htmlText,prepared.title,{
    restoreFullscreen:DOWNLOAD_VIEWER_STATE.openedWhileFullscreen===true
  });
}

async function downloadViewedArtifact(){
  if(DOWNLOAD_VIEWER_STATE.kind==='text'){
    const htmlText=/text\/html/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))||/\.html?$/i.test(String(DOWNLOAD_VIEWER_STATE.name||''))
      ? await prepareDownloadViewerHtmlExportText()
      : String(DOWNLOAD_VIEWER_STATE.text||'');
    downloadTextAsFile(
      htmlText,
      DOWNLOAD_VIEWER_STATE.name,
      /text\/html/i.test(String(DOWNLOAD_VIEWER_STATE.mime||''))?'text/html;charset=utf-8':DOWNLOAD_VIEWER_STATE.mime
    );
    return;
  }
}

const UPLOAD_FOLDER_STORAGE_KEY='conflab.lastUploadFolder';
const FS_PICKER_STATE={
  resolve:null,
  mode:'folder',
  title:'SELECT ROOT FOLDER (for Conflab workspace)',
  confirmLabel:'Select Folder',
  pickerData:null,
  roots:[],
  shortcuts:[],
  recentWorkspaces:[],
  defaultPaths:{},
  userHome:'',
  currentPath:'',
  entries:[],
  selectedPaths:[],
  activePath:'',
  anchorPath:'',
  sortKey:'alphabetical',
  sortDirections:{alphabetical:'asc',time:'desc',size:'desc'},
  loadToken:0,
  loading:false,
  error:''
};

function fsPickerStorageGet(key){
  try{return String(localStorage.getItem(key)||'');}catch(e){return'';}
}
function fsPickerStorageSet(key,value){
  try{
    if(value) localStorage.setItem(key,String(value));
    else localStorage.removeItem(key);
  }catch(e){}
}
function fsNormalizePath(path){
  const src=String(path||'').trim().replace(/\//g,'\\');
  if(!src) return'';
  if(/^[A-Za-z]:$/.test(src)) return src+'\\';
  return src.replace(/\\+/g,'\\');
}
function fsBasename(path){
  const normalized=fsNormalizePath(path).replace(/\\+$/,'');
  if(!normalized) return'';
  const match=normalized.match(/[^\\]+$/);
  return match?match[0]:normalized;
}
function fsParentPath(path){
  const normalized=fsNormalizePath(path);
  if(!normalized) return'';
  if(/^[A-Za-z]:\\?$/.test(normalized)) return'';
  const trimmed=normalized.replace(/\\+$/,'');
  const idx=trimmed.lastIndexOf('\\');
  if(idx<0) return'';
  const parent=trimmed.slice(0,idx);
  return/^[A-Za-z]:$/.test(parent)?(parent+'\\'):parent;
}
function fsJoinPath(base,name){
  const left=fsNormalizePath(base).replace(/\\+$/,'');
  const right=String(name||'').replace(/[\\/]+/g,'').trim();
  if(!left) return right;
  if(!right) return left;
  return/^[A-Za-z]:$/.test(left)?(`${left}\\${right}`):(`${left}\\${right}`);
}
function fsDisplayNameFromPath(path){
  const normalized=fsNormalizePath(path);
  if(/^[A-Za-z]:\\?$/.test(normalized)) return normalized.replace(/\\$/,'');
  return fsBasename(normalized);
}
function fsPickerEscape(text){
  return String(text||'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
function formatBytes(bytes){
  const n=Math.max(0,Number(bytes||0));
  if(n<1024) return n+' B';
  if(n<1024*1024) return (n/1024).toFixed(1)+' KB';
  if(n<1024*1024*1024) return (n/1024/1024).toFixed(1)+' MB';
  return (n/1024/1024/1024).toFixed(2)+' GB';
}
function fsPickerSortLabel(key){
  if(key==='time') return 'Time';
  if(key==='size') return 'Size';
  return 'Alphabetical';
}
function fsPickerSortDirection(key){
  return FS_PICKER_STATE.sortDirections?.[key]||'asc';
}
function fsPickerSortButtonText(key){
  const label=fsPickerSortLabel(key);
  if(FS_PICKER_STATE.sortKey!==key) return label;
  return `${label} ${fsPickerSortDirection(key)==='desc'?'↑':'↓'}`;
}
function fsPickerCompareNames(a,b){
  return String(a?.name||fsDisplayNameFromPath(a?.path||'')).localeCompare(String(b?.name||fsDisplayNameFromPath(b?.path||'')),undefined,{numeric:true,sensitivity:'base'});
}
function fsPickerEntryTimeValue(entry){
  const raw=entry?.lastModified??entry?.mtime??entry?.modified??0;
  const numeric=Number(raw)||0;
  if(numeric) return numeric<1000000000000?numeric*1000:numeric;
  const parsed=Date.parse(String(raw||''));
  return Number.isNaN(parsed)?0:parsed;
}
function fsPickerFormatTimestamp(entry){
  const ms=fsPickerEntryTimeValue(entry);
  if(!ms) return 'No date';
  const date=new Date(ms);
  if(Number.isNaN(date.getTime())) return 'No date';
  return date.toLocaleString(undefined,{year:'2-digit',month:'numeric',day:'numeric',hour:'numeric',minute:'2-digit'});
}
function fsPickerCompareEntries(a,b){
  const key=FS_PICKER_STATE.sortKey||'alphabetical';
  const dir=fsPickerSortDirection(key)==='desc'?-1:1;
  if(a.kind!==b.kind) return a.kind==='directory'?-1:1;
  if(a.kind==='directory'&&b.kind==='directory'){
    const nameOrder=fsPickerCompareNames(a,b);
    return key==='alphabetical'?nameOrder*dir:nameOrder;
  }
  if(key==='alphabetical'){
    return fsPickerCompareNames(a,b)*dir;
  }
  if(key==='time'){
    const delta=fsPickerEntryTimeValue(a)-fsPickerEntryTimeValue(b);
    if(delta) return delta*dir;
    return fsPickerCompareNames(a,b);
  }
  if(key==='size'){
    const delta=(Number(a.size)||0)-(Number(b.size)||0);
    if(delta) return delta*dir;
    return fsPickerCompareNames(a,b);
  }
  return fsPickerCompareNames(a,b);
}
function fsPickerFileIcon(name,path=''){
  const source=String(name||path||'').toLowerCase();
  const match=source.match(/\.([^.\\/:]+)$/);
  const ext=match?match[1]:'';
  if(['png','jpg','jpeg','gif','webp','svg','bmp','ico'].includes(ext)) return '🖼';
  if(['json','xml','yaml','yml','csv','tsv','ini','toml','log'].includes(ext)) return '📊';
  if(['js','ts','py','ps1','sh','cmd','html','css','go','rs'].includes(ext)) return '📜';
  if(['zip','tar','gz','7z','rar'].includes(ext)) return '📦';
  if(['mp3','wav','ogg','m4a','flac'].includes(ext)) return '🎵';
  if(['mp4','mov','mkv','webm','avi'].includes(ext)) return '🎬';
  return '📄';
}
function fsPickerIconForEntry(entry){
  if(entry?.kind==='directory') return '📁';
  return fsPickerFileIcon(entry?.name||'',entry?.path||'');
}
function bytesToBase64(bytes){
  let binary='';
  const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk){
    binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));
  }
  return btoa(binary);
}
function base64ToBytes(base64){
  const raw=atob(String(base64||''));
  const out=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++) out[i]=raw.charCodeAt(i);
  return out;
}
function sniffImageMime(bytes){
  if(!bytes||!bytes.length) return '';
  if(bytes.length>=8&&bytes[0]===0x89&&bytes[1]===0x50&&bytes[2]===0x4E&&bytes[3]===0x47&&bytes[4]===0x0D&&bytes[5]===0x0A&&bytes[6]===0x1A&&bytes[7]===0x0A) return 'image/png';
  if(bytes.length>=3&&bytes[0]===0xFF&&bytes[1]===0xD8&&bytes[2]===0xFF) return 'image/jpeg';
  if(bytes.length>=12&&bytes[0]===0x52&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x46&&bytes[8]===0x57&&bytes[9]===0x45&&bytes[10]===0x42&&bytes[11]===0x50) return 'image/webp';
  if(bytes.length>=6&&bytes[0]===0x47&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x38&&(bytes[4]===0x37||bytes[4]===0x39)&&bytes[5]===0x61) return 'image/gif';
  return '';
}
function createImageObjectUrl(bytes,mimeType=''){
  const type=String(mimeType||'').trim().toLowerCase()||sniffImageMime(bytes)||'application/octet-stream';
  return URL.createObjectURL(new Blob([bytes],{type}));
}
async function transcodeImageBytes(bytes,inputMimeType='',outputMimeType=IMAGE_OUTPUT_MIME_TYPE,quality=IMAGE_OUTPUT_JPEG_QUALITY){
  const inputType=String(inputMimeType||'').trim().toLowerCase()||sniffImageMime(bytes)||'application/octet-stream';
  const srcUrl=URL.createObjectURL(new Blob([bytes],{type:inputType}));
  try{
    const img=await new Promise((resolve,reject)=>{
      const el=new Image();
      el.onload=()=>resolve(el);
      el.onerror=()=>reject(new Error('Image decode failed.'));
      el.src=srcUrl;
    });
    const width=Math.max(1,Number(img.naturalWidth)||Number(img.width)||1);
    const height=Math.max(1,Number(img.naturalHeight)||Number(img.height)||1);
    const canvas=document.createElement('canvas');
    canvas.width=width;
    canvas.height=height;
    const ctx=canvas.getContext('2d',{alpha:false});
    if(!ctx) throw new Error('Canvas context unavailable.');
    ctx.fillStyle='#000';
    ctx.fillRect(0,0,width,height);
    ctx.drawImage(img,0,0,width,height);
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,outputMimeType,quality));
    if(!blob) throw new Error('Image transcode failed.');
    return{bytes:new Uint8Array(await blob.arrayBuffer()),mimeType:outputMimeType};
  }finally{
    try{URL.revokeObjectURL(srcUrl);}catch(e){}
  }
}
function decodeBytesToText(bytes){
  return new TextDecoder().decode(bytes);
}
async function fsApi(url,options={}){
  const init={method:options.method||'POST',headers:{}};
  if(CONFLAB_BRIDGE_AUTH_TOKEN){
    init.headers['X-Conflab-Bridge-Token']=CONFLAB_BRIDGE_AUTH_TOKEN;
  }
  if(isMutatingFsApiUrl(url)){
    await ensureSessionCanMutate();
  }
  if(Object.prototype.hasOwnProperty.call(options,'body')){
    init.headers['Content-Type']='application/json; charset=utf-8';
    const body={...(options.body||{})};
    if(isMutatingFsApiUrl(url)){
      const session=ensureClientSessionState();
      body.sessionId=session.id;
      body.ownerEpoch=session.ownerEpoch||0;
      body.appVersion=APP_VERSION;
      body.startedAt=session.startedAt;
    }
    init.body=JSON.stringify(body);
  }
  const response=await fetch(url,init);
  const raw=await response.text();
  let payload=null;
  try{payload=raw?JSON.parse(raw):null;}catch(e){payload=null;}
  if(!response.ok||payload?.error){
    const rejectedSessionId=String(payload?.error?.activeSessionId||'').trim();
    const rejectedOwnerEpoch=Math.max(0,parseInt(payload?.error?.ownerEpoch,10)||0);
    if(rejectedSessionId){
      applySessionOwnershipPayload({
        activeSessionId:rejectedSessionId,
        ownerEpoch:rejectedOwnerEpoch,
        message:SESSION_SUPERSEDED_MESSAGE
      });
    }
    const message=payload?.error?.message||payload?.error||raw||`Request failed (${response.status})`;
    const err=new Error(String(message||'Request failed.'));
    err.status=response.status;
    err.code=String(payload?.error?.code||'');
    throw err;
  }
  return payload;
}
async function fsStat(path){
  return fsApi('/api/fs/stat',{body:{path}});
}
async function fsList(path){
  return fsApi('/api/fs/list',{body:{path}});
}
async function fsRead(path){
  return fsApi('/api/fs/read',{body:{path}});
}
async function fsReadMany(paths){
  return fsApi('/api/fs/read-many',{body:{paths}});
}
async function fsEnsureDir(path){
  return fsApi('/api/fs/ensure-dir',{body:{path}});
}
async function fsEnsureFile(path){
  return fsApi('/api/fs/ensure-file',{body:{path}});
}
async function fsWrite(path,value){
  const body={path};
  if(value instanceof ArrayBuffer){
    body.base64=bytesToBase64(new Uint8Array(value));
  }else if(ArrayBuffer.isView(value)){
    body.base64=bytesToBase64(new Uint8Array(value.buffer,value.byteOffset,value.byteLength));
  }else{
    body.text=String(value??'');
  }
  return fsApi('/api/fs/write',{body});
}
async function fsRemove(path,recursive=false){
  return fsApi('/api/fs/remove',{body:{path,recursive:!!recursive}});
}
async function fsMove(sourcePath,targetPath){
  return fsApi('/api/fs/move',{body:{sourcePath,targetPath}});
}
async function fsGetRoots(){
  return fsApi('/api/fs/roots',{method:'GET'});
}
async function fsGetPickerState(){
  return fsApi('/api/picker/state',{method:'GET'});
}
async function fsRecordRecentWorkspace(path){
  const workspacePath=fsNormalizePath(path);
  if(!workspacePath) return null;
  try{
    return await fsApi('/api/picker/recent-workspaces',{body:{path:workspacePath}});
  }catch(e){
    console.warn('Could not save recent workspace:',e);
    return null;
  }
}
async function fsPickerBuildShortcuts(rootsData){
  const provided=Array.isArray(rootsData?.shortcuts)?rootsData.shortcuts:[];
  if(provided.length) return provided;
  const userHome=fsNormalizePath(rootsData?.userHome||'');
  if(!userHome) return [];
  const labels=['Desktop','Downloads','Documents','Pictures','Music','Videos','Screenshots'];
  const basePaths=[userHome];
  try{
    const payload=await fsList(userHome);
    const homeEntries=Array.isArray(payload?.entries)?payload.entries:[];
    homeEntries
      .filter(entry=>entry?.kind==='directory'&&/^OneDrive/i.test(String(entry?.name||'')))
      .forEach(entry=>{
        const path=fsNormalizePath(entry.path);
        if(path&&!basePaths.includes(path)) basePaths.push(path);
      });
  }catch(e){}
  const shortcuts=[];
  for(const label of labels){
    const candidates=[];
    for(const base of basePaths){
      if(label==='Screenshots') candidates.push(fsJoinPath(fsJoinPath(base,'Pictures'),'Screenshots'));
      candidates.push(fsJoinPath(base,label));
    }
    const seen=new Set();
    for(const candidate of candidates){
      const normalized=fsNormalizePath(candidate);
      if(!normalized||seen.has(normalized.toLowerCase())) continue;
      seen.add(normalized.toLowerCase());
      try{
        const stat=await fsStat(normalized);
        if(stat?.exists&&stat.kind==='directory'){
          shortcuts.push({label,path:stat.path||normalized});
          break;
        }
      }catch(e){}
    }
  }
  return shortcuts;
}
function buildBackendFileObject(payload){
  let bytesCache=null;
  return{
    name:String(payload?.name||''),
    size:Number(payload?.size||0),
    type:String(payload?.mimeType||'application/octet-stream'),
    async arrayBuffer(){
      if(!bytesCache) bytesCache=base64ToBytes(payload?.base64||'');
      return bytesCache.buffer.slice(bytesCache.byteOffset,bytesCache.byteOffset+bytesCache.byteLength);
    },
    async text(){
      if(!bytesCache) bytesCache=base64ToBytes(payload?.base64||'');
      return decodeBytesToText(bytesCache);
    }
  };
}
class BackendFileWritable{
  constructor(path){
    this.path=fsNormalizePath(path);
    this.value='';
  }
  async write(value){
    this.value=value;
  }
  async close(){
    await fsWrite(this.path,this.value);
  }
}
class BackendFileHandle{
  constructor(path,meta=null){
    this.kind='file';
    this.path=fsNormalizePath(path);
    this.name=String(meta?.name||fsBasename(this.path)||'');
    this.meta=meta||null;
    this._payloadPromise=null;
  }
  async _readPayload(){
    if(!this._payloadPromise) this._payloadPromise=fsRead(this.path);
    return this._payloadPromise;
  }
  async getFile(){
    return buildBackendFileObject(await this._readPayload());
  }
  async createWritable(){
    return new BackendFileWritable(this.path);
  }
}
class BackendDirectoryHandle{
  constructor(path,meta=null){
    this.kind='directory';
    this.path=fsNormalizePath(path);
    this.name=String(meta?.name||fsDisplayNameFromPath(this.path)||'');
  }
  async getDirectoryHandle(name,options={}){
    const childPath=fsJoinPath(this.path,name);
    const stat=await fsStat(childPath);
    if(stat?.exists){
      if(stat.kind!=='directory') throw new Error('Path is not a directory.');
      return new BackendDirectoryHandle(stat.path,stat);
    }
    if(options?.create){
      const ensured=await fsEnsureDir(childPath);
      return new BackendDirectoryHandle(ensured.path||childPath,ensured);
    }
    throw new Error(`Directory not found: ${name}`);
  }
  async getFileHandle(name,options={}){
    const childPath=fsJoinPath(this.path,name);
    const stat=await fsStat(childPath);
    if(stat?.exists){
      if(stat.kind!=='file') throw new Error('Path is not a file.');
      return new BackendFileHandle(stat.path,stat);
    }
    if(options?.create){
      return new BackendFileHandle(childPath,{name:String(name||''),path:childPath,kind:'file',exists:false});
    }
    throw new Error(`File not found: ${name}`);
  }
  async removeEntry(name,options={}){
    await fsRemove(fsJoinPath(this.path,name),!!options?.recursive);
  }
  async *entries(){
    const payload=await fsList(this.path);
    for(const entry of Array.isArray(payload?.entries)?payload.entries:[]){
      if(entry.kind==='directory') yield [entry.name,new BackendDirectoryHandle(entry.path,entry)];
      else yield [entry.name,new BackendFileHandle(entry.path,entry)];
    }
  }
}
const workspaceFs={
  async stat(path){ return fsStat(path); },
  async setRoot(path,options={}){
    const rootHandle=await resolveConflabRootHandle(path);
    const ok=await ensureConflabRootStructure(rootHandle);
    if(!rootHandle||!ok) throw new Error('Could not access workspace folder.');
    await activateWorkspaceRoot(rootHandle);
    await fsRecordRecentWorkspace(rootHandle.path);
    await claimSessionOwnership('workspace-activate');
    return rootHandle;
  }
};
async function resolveConflabRootPath(basePath){
  const normalized=fsNormalizePath(basePath);
  if(!normalized) return'';
  return fsBasename(normalized).toLowerCase()==='conflab'?normalized:fsJoinPath(normalized,'Conflab');
}
async function resolveConflabRootHandle(basePath){
  const rootPath=await resolveConflabRootPath(basePath);
  if(!rootPath) return null;
  const ensured=await fsEnsureDir(rootPath);
  return new BackendDirectoryHandle(ensured?.path||rootPath,ensured);
}
async function fsPickerConfirmFolderPath(path,source='browse'){
  finalizeFsPicker({
    path,
    currentPath:path,
    paths:path?[path]:[],
    mode:'folder',
    confirmed:true,
    source
  });
  return true;
}
function fsPickerVisibleEntries(){
  const entries=Array.isArray(FS_PICKER_STATE.entries)?FS_PICKER_STATE.entries:[];
  const visible=entries.filter(entry=>!(entry?.kind==='directory'&&String(entry?.name||'').startsWith('.')));
  const modeEntries=FS_PICKER_STATE.mode==='folder'?visible.filter(entry=>entry.kind==='directory'):visible;
  return [...modeEntries].sort(fsPickerCompareEntries);
}
function finalizeFsPicker(result){
  const modal=document.getElementById('modal-fs-picker');
  if(modal) modal.style.display='none';
  document.removeEventListener('keydown',handleFsPickerKeydown,true);
  const resolve=FS_PICKER_STATE.resolve;
  FS_PICKER_STATE.resolve=null;
  if(resolve) resolve(result);
}
function cancelFsPicker(){
  finalizeFsPicker(null);
}
function handleFsPickerBackdrop(event){
  if(event?.target?.id!=='modal-fs-picker') return;
  cancelFsPicker();
}
function fsPickerPathKey(path){
  return fsNormalizePath(path).replace(/\\+$/,'').toLowerCase();
}
function fsPickerIsCurrentWorkspace(path){
  const current=fsPickerPathKey(getActiveWorkspacePath());
  return !!current&&fsPickerPathKey(path)===current;
}
function fsPickerNavigationItems(){
  const items=[];
  const addItem=(kind,label,path,source)=>{
    const normalized=fsNormalizePath(path);
    if(!normalized) return;
    const available=source?.available!==false&&source?.exists!==false;
    items.push({
      kind,
      label:String(label||source?.label||source?.name||normalized),
      path:normalized,
      available,
      current:fsPickerIsCurrentWorkspace(normalized),
      source:source||{}
    });
  };
  if(FS_PICKER_STATE.mode==='folder') return [];
  (Array.isArray(FS_PICKER_STATE.shortcuts)?FS_PICKER_STATE.shortcuts:[])
    .forEach(item=>addItem('shortcut',item.label||item.name||'Shortcut',item.path,item));
  (Array.isArray(FS_PICKER_STATE.roots)?FS_PICKER_STATE.roots:[])
    .forEach(item=>addItem('root',item.label||item.name||'Root',item.path,item));
  const seen=new Set();
  return items.filter(item=>{
    const key=`${item.kind}:${fsPickerPathKey(item.path)}`;
    if(seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
function fsPickerRenderRootButton(item,activeRoot){
  const btn=document.createElement('button');
  btn.type='button';
  const itemKey=fsPickerPathKey(item.path);
  const activeKey=fsPickerPathKey(activeRoot);
  btn.className='fs-picker-root'
    +(itemKey&&itemKey===activeKey?' active':'')
    +(item.current?' current':'')
    +(item.available?'':' unavailable');
  btn.title=item.available?item.path:`Unavailable: ${item.path}`;
  const displayName=String(item.source?.name||fsBasename(item.path)||item.path);
  const label=String(item.label||'');
  const stateLabel=item.current?'Current':'';
  if(stateLabel){
    btn.innerHTML=`<span class="fs-picker-root-kicker">${esc(stateLabel)}</span>${esc(displayName)}`;
  }else{
    btn.textContent=label||displayName;
  }
  btn.onclick=async()=>{
    if(!item.available){
      await appAlert('That location is not currently available.',{title:'LOCATION'});
      return;
    }
    await fsPickerOpenPath(item.path);
  };
  return btn;
}
function renderFsPicker(){
  const modal=document.getElementById('modal-fs-picker');
  if(!modal) return;
  const titleEl=document.getElementById('fs-picker-title');
  const confirmEl=document.getElementById('fs-picker-confirm');
  const breadcrumbEl=document.getElementById('fs-picker-breadcrumb');
  const rootsEl=document.getElementById('fs-picker-roots');
  const actionsEl=rootsEl?.closest('.fs-picker-actions')||null;
  const sortWrapEl=document.getElementById('fs-picker-sort-wrap');
  const countEl=document.getElementById('fs-picker-selected-count');
  const statusEl=document.getElementById('fs-picker-status');
  const listEl=document.getElementById('fs-picker-list');
  if(!titleEl||!confirmEl||!breadcrumbEl||!rootsEl||!sortWrapEl||!countEl||!statusEl||!listEl) return;

  titleEl.textContent=FS_PICKER_STATE.title;
  confirmEl.textContent=FS_PICKER_STATE.confirmLabel;

  const currentPath=fsNormalizePath(FS_PICKER_STATE.currentPath);
  breadcrumbEl.innerHTML='';
  if(currentPath){
    const rootMatch=currentPath.match(/^[A-Za-z]:\\/);
    const root=rootMatch?rootMatch[0]:'';
    const rootBtn=document.createElement('button');
    rootBtn.type='button';
    rootBtn.className='fs-picker-crumb'+(currentPath===root?' current':'');
    rootBtn.textContent=root?root.replace(/\\$/,''):'ROOT';
    rootBtn.onclick=()=>fsPickerOpenPath(root||currentPath);
    breadcrumbEl.appendChild(rootBtn);
    const segs=currentPath.slice(root.length).split('\\').filter(Boolean);
    let running=root||'';
    segs.forEach((seg,idx)=>{
      const sep=document.createElement('span');
      sep.className='fs-picker-subtle';
      sep.textContent='>';
      breadcrumbEl.appendChild(sep);
      running=running?fsJoinPath(running,seg):seg;
      const btn=document.createElement('button');
      btn.type='button';
      btn.className='fs-picker-crumb'+(idx===segs.length-1?' current':'');
      btn.textContent=seg;
      btn.onclick=()=>fsPickerOpenPath(running);
      breadcrumbEl.appendChild(btn);
    });
  }

  rootsEl.innerHTML='';
  const rootItems=fsPickerNavigationItems();
  if(actionsEl) actionsEl.style.display=(FS_PICKER_STATE.mode==='folder'&&!rootItems.length)?'none':'flex';
  rootsEl.style.display=rootItems.length?'flex':'none';
  const activeRoot=(rootItems||[])
    .map(root=>({root,path:fsNormalizePath(root?.path||'')}))
    .filter(item=>item.path)
    .filter(item=>{
      const base=item.path.toLowerCase().replace(/\\+$/,'');
      const current=currentPath.toLowerCase().replace(/\\+$/,'');
      return current===base||current.startsWith(base+'\\');
    })
    .sort((a,b)=>b.path.length-a.path.length)[0]?.path||'';
  for(const root of rootItems){
    rootsEl.appendChild(fsPickerRenderRootButton(root,activeRoot));
  }

  const selectionCount=FS_PICKER_STATE.mode==='file'?FS_PICKER_STATE.selectedPaths.length:0;
  sortWrapEl.style.display=FS_PICKER_STATE.mode==='file'?'flex':'none';
  ['alphabetical','size','time'].forEach(key=>{
    const btn=document.getElementById(`fs-picker-sort-${key}`);
    if(!btn) return;
    const active=FS_PICKER_STATE.sortKey===key;
    btn.textContent=fsPickerSortButtonText(key);
    btn.classList.toggle('active',active);
    btn.setAttribute('aria-pressed',active?'true':'false');
    btn.title=active
      ? `Sorting by ${fsPickerSortLabel(key)} ${fsPickerSortDirection(key)==='desc'?'descending':'ascending'}. Click again to flip.`
      : `Sort by ${fsPickerSortLabel(key)}.`;
  });
  countEl.style.display=selectionCount?'inline':'none';
  countEl.textContent=selectionCount?`${selectionCount} selected`:'';
  confirmEl.disabled=FS_PICKER_STATE.mode==='file'&&!selectionCount;
  const rightText=FS_PICKER_STATE.loading
    ? 'Loading...'
    : (FS_PICKER_STATE.error
      ? FS_PICKER_STATE.error
      : (selectionCount
        ? `${selectionCount} file${selectionCount===1?'':'s'} selected`
        : (FS_PICKER_STATE.mode==='folder'?'Current folder will be selected':'Select one or more files')));
  const hintText=FS_PICKER_STATE.mode==='file'
    ? '↑↓ navigate  Enter open  Esc cancel  Ctrl+A select all'
    : '↑↓ navigate  Enter open  Esc cancel';
  statusEl.innerHTML=
    `<span class="fs-picker-status-hint">${fsPickerEscape(hintText)}</span>`+
    `<span class="fs-picker-status-state${FS_PICKER_STATE.loading?' is-busy':''}">${fsPickerEscape(rightText)}</span>`;

  listEl.innerHTML='';
  listEl.onclick=event=>{
    if(event.target!==listEl||FS_PICKER_STATE.mode!=='file') return;
    FS_PICKER_STATE.selectedPaths=[];
    FS_PICKER_STATE.anchorPath='';
    renderFsPicker();
  };
  if(FS_PICKER_STATE.loading){
    listEl.innerHTML='<div class="fs-picker-empty is-busy">Loading folder contents...</div>';
    return;
  }
  if(FS_PICKER_STATE.error){
    listEl.innerHTML=`<div class="fs-picker-empty">${fsPickerEscape(FS_PICKER_STATE.error)}</div>`;
    return;
  }
  const entries=fsPickerVisibleEntries();
  if(!entries.length){
    listEl.innerHTML='<div class="fs-picker-empty">This folder is empty.</div>';
    return;
  }
  entries.forEach(entry=>{
    const row=document.createElement('div');
    row.className='fs-picker-row';
    if(entry.path===FS_PICKER_STATE.activePath) row.classList.add('active');
    if(FS_PICKER_STATE.selectedPaths.includes(entry.path)) row.classList.add('selected');
    const icon=document.createElement('div');
    icon.className='fs-picker-icon';
    icon.textContent=fsPickerIconForEntry(entry);
    const name=document.createElement('div');
    name.className='fs-picker-name';
    name.textContent=entry.name||fsDisplayNameFromPath(entry.path);
    const meta=document.createElement('div');
    meta.className='fs-picker-meta';
    meta.textContent=entry.kind==='directory'
      ? 'Folder'
      : (FS_PICKER_STATE.sortKey==='time'?fsPickerFormatTimestamp(entry):formatBytes(entry.size||0));
    row.appendChild(icon);
    row.appendChild(name);
    row.appendChild(meta);
    row.addEventListener('click',event=>fsPickerHandleEntryClick(entry,event));
    row.addEventListener('dblclick',event=>fsPickerHandleEntryDoubleClick(entry,event));
    listEl.appendChild(row);
  });
}
async function fsPickerLoadPath(path){
  const target=fsNormalizePath(path);
  if(!target) return;
  const token=(FS_PICKER_STATE.loadToken||0)+1;
  FS_PICKER_STATE.loadToken=token;
  if(target!==FS_PICKER_STATE.currentPath){
    FS_PICKER_STATE.selectedPaths=[];
    FS_PICKER_STATE.anchorPath='';
  }
  FS_PICKER_STATE.loading=true;
  FS_PICKER_STATE.error='';
  renderFsPicker();
  try{
    const payload=await fsList(target);
    if(token!==FS_PICKER_STATE.loadToken) return;
    FS_PICKER_STATE.currentPath=fsNormalizePath(payload?.path||target);
    FS_PICKER_STATE.entries=Array.isArray(payload?.entries)?payload.entries:[];
    FS_PICKER_STATE.activePath=fsPickerVisibleEntries()[0]?.path||'';
    FS_PICKER_STATE.anchorPath='';
    FS_PICKER_STATE.selectedPaths=[];
  }catch(e){
    if(token!==FS_PICKER_STATE.loadToken) return;
    FS_PICKER_STATE.error=e.message||'Could not open folder.';
    FS_PICKER_STATE.entries=[];
    FS_PICKER_STATE.activePath='';
  }finally{
    if(token!==FS_PICKER_STATE.loadToken) return;
    FS_PICKER_STATE.loading=false;
    renderFsPicker();
  }
}
async function fsPickerOpenPath(path){
  await fsPickerLoadPath(path);
}
async function fsPickerGoUp(){
  if(FS_PICKER_STATE.loading) return;
  const parent=fsParentPath(FS_PICKER_STATE.currentPath);
  if(parent) await fsPickerLoadPath(parent);
}
async function fsPickerGoHome(){
  const home=fsNormalizePath(FS_PICKER_STATE.userHome||FS_PICKER_STATE.roots[0]?.path||'');
  if(home) await fsPickerLoadPath(home);
}
function fsPickerChooseSort(key){
  if(FS_PICKER_STATE.mode!=='file') return;
  const nextKey=['alphabetical','size','time'].includes(String(key||''))?String(key):'alphabetical';
  if(FS_PICKER_STATE.sortKey===nextKey){
    FS_PICKER_STATE.sortDirections[nextKey]=fsPickerSortDirection(nextKey)==='desc'?'asc':'desc';
  }else{
    FS_PICKER_STATE.sortKey=nextKey;
  }
  const visible=fsPickerVisibleEntries();
  if(!visible.some(entry=>entry.path===FS_PICKER_STATE.activePath)){
    FS_PICKER_STATE.activePath=visible[0]?.path||'';
  }
  renderFsPicker();
}
function fsPickerSelectFilesByRange(targetPath,additive){
  const files=fsPickerVisibleEntries().filter(entry=>entry.kind==='file');
  const targetIdx=files.findIndex(entry=>entry.path===targetPath);
  const anchorIdx=files.findIndex(entry=>entry.path===FS_PICKER_STATE.anchorPath);
  if(targetIdx<0){
    FS_PICKER_STATE.selectedPaths=[targetPath];
    FS_PICKER_STATE.anchorPath=targetPath;
    return;
  }
  if(anchorIdx<0){
    FS_PICKER_STATE.selectedPaths=additive?[...new Set([...FS_PICKER_STATE.selectedPaths,targetPath])]:[targetPath];
    FS_PICKER_STATE.anchorPath=targetPath;
    return;
  }
  const start=Math.min(anchorIdx,targetIdx);
  const end=Math.max(anchorIdx,targetIdx);
  const range=files.slice(start,end+1).map(entry=>entry.path);
  const next=additive?new Set(FS_PICKER_STATE.selectedPaths):new Set();
  range.forEach(path=>next.add(path));
  FS_PICKER_STATE.selectedPaths=[...next];
}
function fsPickerHandleEntryClick(entry,event){
  FS_PICKER_STATE.activePath=entry.path;
  if(entry.kind==='directory'){
    renderFsPicker();
    return;
  }
  if(FS_PICKER_STATE.mode!=='file') return;
  if(event.shiftKey){
    fsPickerSelectFilesByRange(entry.path,!!(event.ctrlKey||event.metaKey));
  }else if(event.ctrlKey||event.metaKey){
    const selected=new Set(FS_PICKER_STATE.selectedPaths);
    if(selected.has(entry.path)) selected.delete(entry.path);
    else selected.add(entry.path);
    FS_PICKER_STATE.selectedPaths=[...selected];
    FS_PICKER_STATE.anchorPath=entry.path;
  }else{
    FS_PICKER_STATE.selectedPaths=[entry.path];
    FS_PICKER_STATE.anchorPath=entry.path;
  }
  renderFsPicker();
}
function fsPickerHandleEntryDoubleClick(entry,event){
  if(entry.kind==='directory'){
    event.preventDefault();
    fsPickerOpenPath(entry.path);
    return;
  }
  if(FS_PICKER_STATE.mode==='file'){
    FS_PICKER_STATE.selectedPaths=[entry.path];
    FS_PICKER_STATE.anchorPath=entry.path;
    confirmFsPicker();
  }
}
function handleFsPickerKeydown(event){
  const modal=document.getElementById('modal-fs-picker');
  if(!modal||modal.style.display!=='flex') return;
  if(event.key==='Escape'){
    event.preventDefault();
    cancelFsPicker();
    return;
  }
  if((event.key==='Backspace'||(event.key==='ArrowUp'&&event.altKey))&&String(document.activeElement?.tagName||'').toUpperCase()!=='INPUT'){
    event.preventDefault();
    fsPickerGoUp();
    return;
  }
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='a'&&FS_PICKER_STATE.mode==='file'){
    event.preventDefault();
    FS_PICKER_STATE.selectedPaths=fsPickerVisibleEntries().filter(entry=>entry.kind==='file').map(entry=>entry.path);
    if(FS_PICKER_STATE.selectedPaths.length) FS_PICKER_STATE.anchorPath=FS_PICKER_STATE.selectedPaths[0];
    renderFsPicker();
    return;
  }
  const entries=fsPickerVisibleEntries();
  const idx=entries.findIndex(entry=>entry.path===FS_PICKER_STATE.activePath);
  if(event.key==='ArrowDown'&&entries.length){
    event.preventDefault();
    const previous=entries[idx]||entries[0];
    const next=entries[Math.min(idx+1,entries.length-1)]||entries[0];
    if(event.shiftKey&&FS_PICKER_STATE.mode==='file'&&!FS_PICKER_STATE.anchorPath&&previous?.kind==='file'){
      FS_PICKER_STATE.anchorPath=previous.path;
    }
    FS_PICKER_STATE.activePath=next.path;
    if(event.shiftKey&&FS_PICKER_STATE.mode==='file'&&next.kind==='file'){
      fsPickerSelectFilesByRange(next.path,false);
    }
    renderFsPicker();
    return;
  }
  if(event.key==='ArrowUp'&&entries.length&&!event.altKey){
    event.preventDefault();
    const previous=entries[idx]||entries[0];
    const next=entries[Math.max(idx-1,0)]||entries[0];
    if(event.shiftKey&&FS_PICKER_STATE.mode==='file'&&!FS_PICKER_STATE.anchorPath&&previous?.kind==='file'){
      FS_PICKER_STATE.anchorPath=previous.path;
    }
    FS_PICKER_STATE.activePath=next.path;
    if(event.shiftKey&&FS_PICKER_STATE.mode==='file'&&next.kind==='file'){
      fsPickerSelectFilesByRange(next.path,false);
    }
    renderFsPicker();
    return;
  }
  if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){
    event.preventDefault();
    const active=entries.find(entry=>entry.path===FS_PICKER_STATE.activePath)||null;
    if(active?.kind==='directory') fsPickerOpenPath(active.path);
    else if(FS_PICKER_STATE.mode==='file'&&FS_PICKER_STATE.selectedPaths.length) confirmFsPicker();
    else if(active) fsPickerHandleEntryDoubleClick(active,event);
    else confirmFsPicker();
  }
}
async function openFsPicker(options={}){
  if(isSessionInteractionBlocked()) return null;
  let pickerData=null;
  try{
    pickerData=await fsGetPickerState();
  }catch(e){
    pickerData=await fsGetRoots();
  }
  return new Promise(async resolve=>{
    if(FS_PICKER_STATE.resolve) FS_PICKER_STATE.resolve(null);
    FS_PICKER_STATE.resolve=resolve;
    FS_PICKER_STATE.mode=options.mode==='folder'?'folder':'file';
    FS_PICKER_STATE.title=String(options.title||(FS_PICKER_STATE.mode==='folder'?'SELECT ROOT FOLDER (for Conflab workspace)':'SELECT FILES (for upload)'));
    FS_PICKER_STATE.confirmLabel=String(options.confirmLabel||(FS_PICKER_STATE.mode==='folder'?'Select Folder':'Attach Files'));
    FS_PICKER_STATE.pickerData=pickerData||null;
    FS_PICKER_STATE.roots=Array.isArray(pickerData?.roots)?pickerData.roots:[];
    FS_PICKER_STATE.shortcuts=FS_PICKER_STATE.mode==='file'?await fsPickerBuildShortcuts(pickerData):[];
    FS_PICKER_STATE.recentWorkspaces=Array.isArray(pickerData?.recentWorkspaces)?pickerData.recentWorkspaces:[];
    FS_PICKER_STATE.defaultPaths=(pickerData?.defaultPaths&&typeof pickerData.defaultPaths==='object')?pickerData.defaultPaths:{};
    FS_PICKER_STATE.userHome=String(pickerData?.userHome||'');
    FS_PICKER_STATE.currentPath='';
    FS_PICKER_STATE.entries=[];
    FS_PICKER_STATE.selectedPaths=[];
    FS_PICKER_STATE.activePath='';
    FS_PICKER_STATE.anchorPath='';
    FS_PICKER_STATE.sortKey='alphabetical';
    FS_PICKER_STATE.sortDirections={alphabetical:'asc',time:'desc',size:'desc'};
    FS_PICKER_STATE.loadToken=0;
    FS_PICKER_STATE.loading=false;
    FS_PICKER_STATE.error='';

    const candidates=[
      options.startPath||'',
      FS_PICKER_STATE.mode==='folder'?FS_PICKER_STATE.defaultPaths.workspace:FS_PICKER_STATE.defaultPaths.files,
      FS_PICKER_STATE.mode==='folder'?'':fsPickerStorageGet(UPLOAD_FOLDER_STORAGE_KEY),
      FS_PICKER_STATE.userHome,
      FS_PICKER_STATE.roots[0]?.path||''
    ].map(fsNormalizePath).filter(Boolean);
    let startPath='';
    for(const candidate of candidates){
      try{
        const stat=await fsStat(candidate);
        if(stat?.exists&&stat.kind==='directory'){
          startPath=stat.path;
          break;
        }
      }catch(e){}
    }
    const modal=document.getElementById('modal-fs-picker');
    if(modal) modal.style.display='flex';
    document.addEventListener('keydown',handleFsPickerKeydown,true);
    await fsPickerLoadPath(startPath||FS_PICKER_STATE.userHome||FS_PICKER_STATE.roots[0]?.path||'');
  });
}
async function confirmFsPicker(){
  if(FS_PICKER_STATE.mode==='folder'){
    await fsPickerConfirmFolderPath(FS_PICKER_STATE.currentPath,'browse');
    return;
  }
  if(!FS_PICKER_STATE.selectedPaths.length){
    await appAlert('Select at least one file.',{title:'FILES'});
    return;
  }
  finalizeFsPicker({
    paths:[...FS_PICKER_STATE.selectedPaths],
    currentPath:FS_PICKER_STATE.currentPath,
    mode:'file',
    confirmed:true,
    source:'selection'
  });
}

// ── STATE ─────────────────────────────────────────────────────────
const S={
  convs:[],conv:null,fsRoot:null,workspaceReady:false,micOn:false,mic:null,
  micLastFinalIndex:0,micInsertAnchor:0,micInterimStart:0,micInterimEnd:0,
  attachments:[],logMode:'summary',aborts:[],downloads:[],
  drawerTab:'settings',
  historySelectedMsgId:'',
  convTree:[],convTreeIndex:{},convTreeExpanded:{},convTreeSelectedPath:'',
  downloadsTree:[],downloadsTreeIndex:{},downloadsTreeExpanded:{},downloadsTreeSelectedPath:'',
  personaTree:[],personaTreeIndex:{},personaTreeExpanded:{},personaTreeSelectedPath:'',
  personaPickerList:[],
  personaUuidIndex:{},
  personaNameUsage:{full:{},first:{},last:{}},
  openRouterModels:[],
  openRouterModelsLoaded:false,
  openRouterImageModels:[],
  openRouterImageModelsLoaded:false,
  activeModelPicker:'',
  activePersona:null,
  personaEditorLocked:false,
  personaSliderUnlocked:false,
  personaSetupOpenByPath:{},
  personaSetupNewOpen:false,
  personaFormBaseline:'',
  personaLastGeneratedSignature:'',
  personaDirtyDirection:'none',
  directorAssistConvKey:'',
  directorAssistSlots:[],
  directorAssistIndex:-1,
  directorAssistBusy:false,
  directorAssistSource:'',
  directorAssistToken:0,
  directorAssistPressCount:0,
  directorSummaryBusy:false,
  directorSummaryToken:0,
  interruptVisible:false,
  directorTurnTimerInterval:null,
  directorTurnTimerStartedAt:0,
  directorTurnTimerElapsedMs:0,
  directorTurnTimerActive:false,
  directorTurnTimerPhase:'idle',
  directorTurnCountdownStartedAt:0,
  directorTurnTimerLastTickSecond:-1,
  historySearch:{query:'',mode:'',results:[],index:-1,busy:false},
  activeRound:null,
  pendingDispatchTimer:null,
  aiDirectorTimer:null,
  aiDirectorTicker:null,
  aiDirectorToken:0,
  aiDirectorCountdownEndsAt:0,
  aiDirectorStatus:'',
  aiDirectorAutoSending:false,
  _personaFormInit:false,
  agentPersonaPickerFor:'',
  convDialogConv:null,convDialogPath:'',convDialogInitial:null,convDialogIsNew:false,
  catMenuPath:'',catRenamePath:'',catRenameValue:'',catCreateParentPath:null,catCreateValue:'',
  pcatMenuPath:'',pcatRenamePath:'',pcatRenameValue:'',pcatCreateParentPath:null,pcatCreateValue:'',
  dragPayload:null,dragHoverEl:null,
  downloadsReconciledByConvUuid:{}
};
const POPUP_MENU_STATE={bound:false};
const DOWNLOAD_VIEWER_STATE={
  kind:'',
  name:'',
  mime:'text/plain;charset=utf-8',
  text:'',
  exportText:'',
  objectUrl:'',
  closeCleanup:null,
  convPath:'',
  isSummary:false,
  openedWhileFullscreen:false,
  deleteItem:null,
  summaryImageStatus:'none',
  summaryImageSnapshot:null
};
const IMAGE_DIALOG_STATE={
  open:false,
  convPath:'',
  settings:null,
  promptsByMode:{'from-summary':[],'from-scratch':[]},
  draftsByMode:{'from-summary':{text:'',chat_history:[]},'from-scratch':{text:'',chat_history:[]}},
  pendingPromptCreateByMode:{'from-summary':null,'from-scratch':null},
  showScratchDraftSlot:false,
  mode:'from-scratch',
  indexByMode:{'from-summary':-1,'from-scratch':-1},
  previewUrl:'',
  busy:false,
  chatBusy:false,
  generateBusy:false,
  currentPromptDirty:false,
  statusText:'',
  sourceNoteText:'',
  statusBusy:false,
  hasSavedSummaryArtifact:false
};
const DIRECTOR_INPUT_PLACEHOLDER='Type or dictate... (Enter to send, Shift+Enter for newline)';
const MIN_ACTIVE_AGENT_COUNT=2;
const DIRECTOR_INPUT_LOCK_MESSAGE='Select personas for at least two active agents before you can continue.';
const CONVERSATION_MODE_OPTIONS=['parallel','sequential','free_form'];
const DIRECTOR_TYPE_OPTIONS=['human','ai'];
const DEFAULT_CONVERSATION_MODE='parallel';
const DEFAULT_DIRECTOR_TYPE='human';
const OPENROUTER_TIMEOUT_MS=90000;
const AI_DIRECTOR_FAILURE_RETRY_LIMIT=2;
const AI_DIRECTOR_FAILURE_RETRY_DELAY_MS=1500;
const DEFAULT_AI_DIRECTOR_COUNTDOWN=3;
const DEFAULT_CONVERSATION_PACE_DELAY=3;
const SUMMARY_CONTEXT_FALLBACK_TOKENS=8000;
const SUMMARY_CONTEXT_USAGE_RATIO=0.8;
const SUMMARY_EDGE_ROUNDS=3;
const SUMMARY_CHUNK_PROMPT_RESERVE_TOKENS=500;

function getDirectorAssistConvKey(conv){
  if(!conv) return'';
  return String(conv.uuid||conv.sourcePath||conv.id||'');
}

function cloneDirectorAssistSlots(slots){
  return(slots||[]).map(slot=>({
    committed:String(slot?.committed||''),
    tempEdits:(typeof slot?.tempEdits==='string')?slot.tempEdits:null,
    source:normalizeDirectorType(slot?.source||'human')
  }));
}

function getDirectorAssistSlotText(slot){
  if(!slot) return'';
  return typeof slot.tempEdits==='string'?slot.tempEdits:String(slot.committed||'');
}

function getDirectorAssistSlotSource(slot){
  if(!slot) return'';
  return normalizeDirectorType(slot?.source||'human');
}

function cancelDirectorAssistRun({clearDraft=false}={}){
  S.directorAssistToken++;
  S.directorAssistBusy=false;
  S.directorAssistSource='';
  if(clearDraft){
    S.directorAssistSlots=[];
    S.directorAssistIndex=-1;
    S.directorAssistPressCount=0;
  }
}

function resetDirectorAssistState(){
  cancelDirectorAssistRun({clearDraft:true});
}

function hasAgentSelectedPersona(agent){
  if(!agent) return false;
  if(!String(agent.personaUuid||'').trim()) return false;
  const source=getPersonaSourceForAgent(agent);
  return !!source&&!agent.personaMissing;
}

function isAgentReady(agent){
  if(!agent) return false;
  if(String(agent.personaUuid||'').trim()){
    const source=getPersonaSourceForAgent(agent);
    return !!source && !agent.personaMissing;
  }
  if(String(agent.model||'').trim()) return true;
  const slot=getParticipantPlanSlotForAgentSync(S.conv,agent);
  return !!String(slot?.roleBrief||'').trim();
}

function hasAllAgentsConfigured(conv){
  const targetAgents=getFutureRoundTargetAgents(conv);
  return targetAgents.length>=MIN_ACTIVE_AGENT_COUNT&&targetAgents.every(agent=>hasAgentSelectedPersona(agent));
}

function getDirectorInputLockMessage(conv){
  const targetAgents=getFutureRoundTargetAgents(conv);
  if(targetAgents.length<MIN_ACTIVE_AGENT_COUNT){
    return `Keep at least ${MIN_ACTIVE_AGENT_COUNT} active agents and select personas before you can continue.`;
  }
  if(targetAgents.some(agent=>!hasAgentSelectedPersona(agent))){
    return 'Select a persona for every active agent before you can continue.';
  }
  return DIRECTOR_INPUT_LOCK_MESSAGE;
}

function isDirectorInputLocked(conv){
  return!!conv&&!hasAllAgentsConfigured(conv);
}

function getDirectorAssistCurrentText(){
  if(S.directorAssistIndex<0||S.directorAssistIndex>=S.directorAssistSlots.length) return'';
  return getDirectorAssistSlotText(S.directorAssistSlots[S.directorAssistIndex]);
}

function setDirectorAssistCurrentText(nextText){
  const text=String(nextText||'');
  if(!text){
    resetDirectorAssistState();
    return;
  }
  if(S.directorAssistIndex<0||S.directorAssistIndex>=S.directorAssistSlots.length){
    S.directorAssistSlots=[{committed:'',tempEdits:text,source:'human'}];
    S.directorAssistIndex=0;
    return;
  }
  const slot=S.directorAssistSlots[S.directorAssistIndex];
  slot.tempEdits=(text===String(slot.committed||''))?null:text;
  slot.source='human';
}

function getDirectorDraftText(){
  return getDirectorAssistCurrentText();
}

function getDirectorDraftSource(){
  if(S.directorAssistIndex<0||S.directorAssistIndex>=S.directorAssistSlots.length) return'';
  return getDirectorAssistSlotSource(S.directorAssistSlots[S.directorAssistIndex]);
}

function conversationHasAnyMessages(conv){
  return !!conv&&Array.isArray(conv.messages)&&conv.messages.some(msg=>!msg?.isSep);
}

function getDefaultDirectorDraftForConversation(conv){
  if(!conv) return'';
  if(conversationHasAnyMessages(conv)) return'';
  return String(conv.topicObjective||'').trim();
}

function maybeSeedDirectorDraftForConversation(conv){
  if(!conv||S.directorAssistSlots.length) return;
  const seed=getDefaultDirectorDraftForConversation(conv);
  if(!seed) return;
  S.directorAssistSlots=[{committed:'',tempEdits:seed,source:'human'}];
  S.directorAssistIndex=0;
}

function prepareDirectorComposerForConversationEntry(conv){
  if(!conv) return;
  if(!conversationHasAnyMessages(conv)){
    resetDirectorAssistState();
    maybeSeedDirectorDraftForConversation(conv);
  }
}

function onDirectorInputChange(){
  if(isDirectorInputLocked(S.conv)) return;
  const ta=document.getElementById('dir-input');
  if(!ta) return;
  if(S.directorAssistBusy){
    if(S.directorAssistSource==='ai'){
      cancelDirectorAssistRun();
      clearAiDirectorTimers(true);
      if(isAiDirectorMode(S.conv)&&S.directorTurnTimerActive) setDirectorTurnTimerPhase('generating');
      S.aiDirectorStatus='AI waiting for Director';
      syncDirectorAiStatusUi();
    }else{
      return;
    }
  }
  if(S.aiDirectorCountdownEndsAt){
    clearAiDirectorTimers(true);
    if(isAiDirectorMode(S.conv)&&S.directorTurnTimerActive) setDirectorTurnTimerPhase('generating');
    S.aiDirectorStatus='AI waiting for Director';
    syncDirectorAiStatusUi();
  }
  setDirectorAssistCurrentText(ta.value);
  syncDirectorComposerUi();
}

function syncDirectorComposerUi(){
  const c=S.conv;
  const ta=document.getElementById('dir-input');
  const sendBtn=document.getElementById('btn-send');
  const assistBtn=document.getElementById('btn-assist');
  const nav=document.getElementById('dir-assist-nav');
  const prevBtn=document.getElementById('btn-assist-prev');
  const nextBtn=document.getElementById('btn-assist-next');
  const countEl=document.getElementById('dir-assist-count');
  const attachBtn=document.getElementById('btn-attach');
  const micBtn=document.getElementById('mic-btn');
  if(!ta||!sendBtn||!assistBtn||!nav||!prevBtn||!nextBtn||!countEl) return;
  refreshDirectorExportButtons();

  const hasConv=!!c;
  const locked=isDirectorInputLocked(c);
  const busy=!!S.directorAssistBusy;
  const sessionSuspended=!!ensureClientSessionState().suspended;
  const roundActive=getActiveRoundForConversation(c);
  const activeMode=roundActive?getRoundMode(roundActive,c):getConversationMode(c);
  const runtimeBusy=((activeMode==='sequential'||activeMode==='free_form')&&S.aborts.length>0);
  const interruptActive=!!S.interruptVisible||!!S.aborts.length;
  const inputAssistBusy=busy&&S.directorAssistSource!=='ai';
  const draft=getDirectorDraftText();
  const hasDraft=!!draft.trim();
  const allowContinue=!!roundActive&&isSequentialRound(roundActive,c)&&!runtimeBusy&&roundActive.nextSequentialIndex<roundActive.targets.length;
  const hasCompletedRound=getCompletedRoundCount(c)>=1;
  const showNav=hasConv&&!locked&&S.directorAssistSlots.length>1;
  const lockMessage=locked?(getDirectorInputLockMessage(c)||DIRECTOR_INPUT_LOCK_MESSAGE):'';
  const desiredValue=locked?lockMessage:draft;

  if(ta.value!==desiredValue) ta.value=desiredValue;
  ta.placeholder=locked?'':DIRECTOR_INPUT_PLACEHOLDER;
  ta.readOnly=locked||inputAssistBusy||S.aiDirectorAutoSending||sessionSuspended;
  ta.classList.toggle('is-locked',locked);
  ta.title=sessionSuspended?SESSION_SUPERSEDED_MESSAGE:(locked?lockMessage:'');
  if(locked&&S.micOn) stopMic();

  sendBtn.disabled=sessionSuspended||(interruptActive?(!hasConv):(!hasConv||locked||busy||runtimeBusy||(!hasDraft&&!allowContinue)));
  sendBtn.textContent=interruptActive?'⊘ Stop':(allowContinue&&!hasDraft?'Continue →':'Submit →');
  sendBtn.title=sessionSuspended
    ?SESSION_SUPERSEDED_MESSAGE
    :interruptActive
    ?'Stop all agents'
    :(locked
      ?lockMessage
      :(runtimeBusy?'Wait for the current agent response to land first.':'')); 
  sendBtn.classList.toggle('bp-stop',interruptActive);

  assistBtn.disabled=sessionSuspended||!hasConv||locked||busy||(!hasDraft&&!hasCompletedRound);
  assistBtn.textContent=busy?'Generating...':'Prompt Assist';
  assistBtn.classList.toggle('bs-generating',busy);
  assistBtn.title=sessionSuspended
    ?SESSION_SUPERSEDED_MESSAGE
    :locked
    ?lockMessage
    :(!hasDraft&&hasCompletedRound
      ?'Suggest what to ask next based on agent responses.'
      :'Refine the current Director draft');

  nav.style.display=showNav?'flex':'none';
  prevBtn.disabled=busy||S.directorAssistIndex<=0;
  nextBtn.disabled=busy||S.directorAssistIndex>=S.directorAssistSlots.length-1;
  countEl.textContent=`${Math.max(1,S.directorAssistIndex+1)} / ${Math.max(1,S.directorAssistSlots.length)}`;

  if(attachBtn){
    attachBtn.disabled=locked||sessionSuspended;
    attachBtn.title=sessionSuspended?SESSION_SUPERSEDED_MESSAGE:(locked?lockMessage:'Attach files');
  }
  if(micBtn){
    micBtn.disabled=locked||sessionSuspended;
    micBtn.title=sessionSuspended?SESSION_SUPERSEDED_MESSAGE:(locked?lockMessage:'Dictate at cursor');
  }
  syncDirectorActionHeights();
}

function getEmptyCoverHtml(){
  const n=document.getElementById('empty-cover');
  if(!n) return '<div id="empty-cover"><div class="es">Multi-Provider Collaboration</div></div>';
  const clone=n.cloneNode(true);
  const emptyVersion=clone.querySelector('#empty-version');
  if(emptyVersion) emptyVersion.textContent=APP_VERSION;
  return clone.outerHTML;
}
// ── PERSIST (localStorage = session state only; conv data lives on disk) ──
function stoSave(){
  if(S.conv) localStorage.setItem('cl_last_conv', S.conv.sourcePath||S.conv.id||'');
}

// ── FILE SYSTEM ───────────────────────────────────────────────────
async function ensureConflabRootStructure(rootHandle){
  if(!rootHandle) return false;
  try{
    await rootHandle.getDirectoryHandle('Conversations',{create:true});
    await rootHandle.getDirectoryHandle('Personas',{create:true});
    return true;
  }catch(e){return false;}
}

async function activateWorkspaceRoot(rootHandle){
  // Clear current in-memory session immediately when switching roots.
  S.fsRoot=rootHandle||null;
  S.conv=null;
  S.convs=[];
  S.downloadsReconciledByConvUuid={};
  S.downloadsTree=[];
  S.downloadsTreeIndex={};
  S.downloadsTreeExpanded={};
  S.downloadsTreeSelectedPath='';
  S.personaTree=[];
  S.personaTreeIndex={};
  S.personaTreeSelectedPath='';
  S.personaPickerList=[];
  S.personaUuidIndex={};
  S.personaNameUsage={full:{},first:{},last:{}};
  S.activePersona=null;
  S.personaFormBaseline='';
  S.personaLastGeneratedSignature='';
  S.personaDirtyDirection='none';
  S.agentPersonaPickerFor='';
  S.attachments=[];
  setInterruptVisible(false);
  clearDownloads();
  ttsStop();
  stopMic();
  renderAll();

  if(!S.fsRoot){
    S.workspaceReady=false;
    updateFolderUI();
    loadSettingsForm();
    return;
  }

  const loaded=await loadWorkspaceSettingsFromDisk();
  if(!loaded){
    resetAppSettingsToDefaults();
  }
  S.workspaceReady=loaded&&hasWorkspaceApiConfiguration(APP_SETTINGS);
  updateFolderUI();
  loadSettingsForm();

  if(S.workspaceReady){
    await scanConvFolders();
    await scanPersonaFolders();
  }else{
    // Force onboarding path for a new/uninitialized workspace.
    drawerOpen('settings');
    switchDrawerTab('settings');
  }
}

async function pickConflabFolder(){
  if(isSessionInteractionBlocked()) return;
  const pillEl=document.getElementById('fs-pill');
  if(pillEl){
    pillEl.removeEventListener('click',handleRootPillClick);
    pillEl.addEventListener('click',handleRootPillClick);
  }
  try{
    while(true){
    const picked=await openFsPicker({
      mode:'folder',
      title:'SELECT ROOT FOLDER (for Conflab workspace)',
      confirmLabel:'Select Folder'
    });
    if(!picked?.path) return;
    const rootHandle=await resolveConflabRootHandle(picked.path);
    if(!rootHandle){pill('Access denied',false);return;}

    // Confirm before switching/initializing workspace.
    const isInitialized=await workspaceLooksInitialized(rootHandle);
    const actionLine=isInitialized
      ? 'Switch to this Conflab workspace?'
      : 'Are you sure you want to initialize Conflab in this folder?';
    const targetLine='Target folder: '+(rootHandle.name||'(unknown)');
    const proceed=await appConfirm(actionLine+'\n\n'+targetLine+'\n\nContinue?',{title:'WORKSPACE CONFIRMATION',okLabel:'Continue'});
    if(!proceed) return;

    const ok=await ensureConflabRootStructure(rootHandle);
    if(!ok){pill('Access denied',false);return;}

    const activated=await workspaceFs.setRoot(picked.path);
    if(activated){
      const rootPath=await resolveConflabRootPath(picked.path);
      APP_SETTINGS.lastWorkspacePath=rootPath;
      APP_SETTINGS.lastFolderName=rootHandle.name;
      persistAppSettingsToBrowserStorage();
      return;
    }
    }
  }catch(e){
    if(e?.message) pill(e.message,false);
  }
}

function handleRootPillClick(){
  if(isSessionInteractionBlocked()) return;
  // If no root is set, route users to Settings first to choose/configure it.
  if(!S.fsRoot){
    drawerOpen('settings');
    switchDrawerTab('settings');
    return;
  }
  pickConflabFolder();
}

function updateFolderUI(){
  const name=S.fsRoot?S.fsRoot.name:null;
  const hasFolder=!!S.fsRoot;

  // Top bar pill
  const pillEl=document.getElementById('fs-pill');
  if(pillEl){
    pillEl.textContent=name?'📁 '+name:'No Root Folder';
    pillEl.className='fs-pill'+(hasFolder?' linked':'');
    pillEl.style.color=hasFolder?'':'var(--red)';
    pillEl.style.borderColor=hasFolder?'':'rgba(239,68,68,.4)';
    pillEl.style.maxWidth='480px';
  }

  // Settings note — now a clickable pill like the top bar
  const note=document.getElementById('set-folder-note');
  if(note){
    note.textContent=name?('Choose Root Folder: 📁 '+name):'Choose Root Folder: No Root Folder';
    note.style.color=name?'var(--teal)':'var(--red)';
    note.style.borderColor=name?'var(--teal-dim)':'rgba(239,68,68,.4)';
  }

  // Save Settings button state follows folder/workspace readiness + dirty checks
  updateSettingsSaveState();

  // Tabs — Personas, Conversations, and Results disabled until workspace is configured
  const workspaceReady=hasFolder&&!!S.workspaceReady;
  const initMsg=document.getElementById('set-init-msg');
  if(initMsg){
    initMsg.style.display=(hasFolder&&!workspaceReady)?'block':'none';
    initMsg.textContent='Enter an OpenRouter API key and choose a helper model in Settings, then save to unlock the rest of the workspace.';
  }
  const tabConvs=document.getElementById('tab-convs');
  const tabPersonas=document.getElementById('tab-personas');
  const tabDownloads=document.getElementById('tab-downloads');
  if(tabConvs) tabConvs.disabled=!workspaceReady;
  if(tabPersonas) tabPersonas.disabled=!workspaceReady;
  if(tabDownloads) tabDownloads.disabled=!workspaceReady;

  // If on a now-disabled tab, redirect to settings
  if(!workspaceReady){
    const active=document.querySelector('.drw-tab.active');
    if(active&&active.id!=='tab-settings') switchDrawerTab('settings');
  }

  // Drawer folder labels
  const folderInfoText=name?('Root Folder: 📁 '+name):'Root Folder: No Root Folder';
  const convRoot=document.getElementById('conv-root-target');
  const personaRoot=document.getElementById('persona-root-target');
  const downloadsRoot=document.getElementById('downloads-root-target');
  if(convRoot){
    convRoot.textContent=folderInfoText;
    convRoot.style.color=name?'var(--teal)':'var(--red)';
    convRoot.style.borderColor=name?'var(--teal-dim)':'rgba(239,68,68,.4)';
  }
  if(personaRoot){
    personaRoot.textContent=folderInfoText;
    personaRoot.style.color=name?'var(--teal)':'var(--red)';
    personaRoot.style.borderColor=name?'var(--teal-dim)':'rgba(239,68,68,.4)';
  }
  if(downloadsRoot){
    downloadsRoot.textContent=folderInfoText;
    downloadsRoot.style.color=name?'var(--teal)':'var(--red)';
    downloadsRoot.style.borderColor=name?'var(--teal-dim)':'rgba(239,68,68,.4)';
  }

  const convNoFolder=document.getElementById('conv-no-folder');
  const personaNoFolder=document.getElementById('persona-no-folder');
  if(convNoFolder) convNoFolder.style.display=workspaceReady?'none':'block';
  if(personaNoFolder) personaNoFolder.style.display=workspaceReady?'none':'block';
}

let STARTUP_WORKSPACE_LOADING=false;
function isStartupWorkspaceLoading(){
  return !!STARTUP_WORKSPACE_LOADING;
}
function setStartupWorkspaceLoading(active){
  STARTUP_WORKSPACE_LOADING=!!active;
  const overlay=document.getElementById('startup-workspace-loading-overlay');
  const app=document.getElementById('app');
  document.body?.classList.toggle('startup-workspace-loading',STARTUP_WORKSPACE_LOADING);
  if(overlay) overlay.style.display=STARTUP_WORKSPACE_LOADING?'block':'none';
  if(app){
    if(STARTUP_WORKSPACE_LOADING) app.setAttribute('aria-busy','true');
    else app.removeAttribute('aria-busy');
  }
}

function getBackendLastWorkspacePath(pickerData){
  const last=pickerData?.lastWorkspace;
  if(last&&last.exists!==false&&last.available!==false){
    const path=fsNormalizePath(last.path||pickerData?.lastWorkspacePath||'');
    if(path) return path;
  }
  const recent=Array.isArray(pickerData?.recentWorkspaces)?pickerData.recentWorkspaces:[];
  for(const entry of recent){
    if(entry&&entry.exists!==false&&entry.available!==false){
      const path=fsNormalizePath(entry.path||'');
      if(path) return path;
    }
  }
  return '';
}

async function tryReconnectFolder(){
  if(S.fsRoot) return;
  let pickerData=null;
  let lastPath='';
  try{
    pickerData=await fsGetPickerState();
    lastPath=getBackendLastWorkspacePath(pickerData);
  }catch(e){
    console.warn('Workspace reconnect settings read failed:',e);
  }
  if(!lastPath){
    await pickConflabFolder();
    return;
  }
  setStartupWorkspaceLoading(true);
  try{
    let stat=null;
    try{
      stat=await workspaceFs.stat(lastPath);
    }catch(e){
      console.warn('Workspace reconnect check failed:',e);
      return;
    }
    if(stat?.exists===false||(stat?.exists&&stat.kind!=='directory')){
      setStartupWorkspaceLoading(false);
      await pickConflabFolder();
      return;
    }
    if(!stat?.exists||stat.kind!=='directory'){
      setStartupWorkspaceLoading(false);
      await pickConflabFolder();
      return;
    }
    const lastName=fsDisplayNameFromPath(lastPath);
    APP_SETTINGS.lastFolderName=lastName;
    APP_SETTINGS.lastWorkspacePath=lastPath;
    persistAppSettingsToBrowserStorage();
    const activated=await workspaceFs.setRoot(lastPath);
    const rootPath=activated?.path||await resolveConflabRootPath(lastPath);
    if(rootPath) APP_SETTINGS.lastWorkspacePath=rootPath;
    persistAppSettingsToBrowserStorage();
  }catch(e){
    console.warn('Workspace auto-open failed:',e);
    window.pill('Workspace reconnect failed',false);
  }finally{
    setStartupWorkspaceLoading(false);
  }
}

function pill(t,linked){
  // Only used for non-folder messages (e.g. conv count on init)
  // Folder state is managed by updateFolderUI
  if(S.fsRoot) return; // folder set — updateFolderUI owns the pill
  const el=document.getElementById('fs-pill');
  if(!el)return;
  el.textContent=t;el.className='fs-pill'+(linked?' linked':'');
}
// ── FILE SYSTEM v2 — disk is source of truth ─────────────────────
function createDefaultArtifactCounters(){
  return{
    summary:0,
    conversationLog:0,
    agentLog:0,
    imagePromptSummary:0,
    imagePromptScratch:0
  };
}

function normalizeArtifactCounters(raw){
  const defaults=createDefaultArtifactCounters();
  const src=(raw&&typeof raw==='object')?raw:{};
  const out={...defaults};
  Object.keys(defaults).forEach(key=>{
    out[key]=Math.max(0,parseInt(src[key],10)||0);
  });
  return out;
}

function getConversationArtifactCounters(conv){
  if(!conv) return createDefaultArtifactCounters();
  conv.artifactCounters=normalizeArtifactCounters(conv.artifactCounters);
  return conv.artifactCounters;
}

async function reserveConversationArtifactId(conv,key){
  if(!conv||!key) return '001';
  const counters=getConversationArtifactCounters(conv);
  const next=Math.max(0,parseInt(counters[key],10)||0)+1;
  counters[key]=next;
  await writeMetaFile(conv);
  return String(next).padStart(3,'0');
}

function formatRoundLabel(roundValue,fallback=1){
  const round=Math.max(1,Number(roundValue)||Number(fallback)||1);
  return String(round).padStart(3,'0');
}

function formatArtifactRoundSpan(scope){
  const start=Math.max(1,Number(scope?.startRound)||1);
  const end=Math.max(start,Number(scope?.endRound)||start);
  return `R${start}-R${end}`;
}

const CONV_SETTINGS_FILE='settings.json';
const CONV_AGENTS_DIR='agents';
const CONV_LOGS_DIR='logs';
const CONV_DOWNLOADS_DIR='results';
const CONV_DOWNLOADS_SUMMARIES_DIR='summaries';
const CONV_DOWNLOADS_LOGS_DIR='logs';
const CONV_DOWNLOADS_IMAGES_DIR='images';
const IMAGE_PROMPT_MARKER_RE=/<<<PROMPT>>>\s*([\s\S]*?)\s*<<<END_PROMPT>>>/gi;

function buildDirectorSnippet(content,maxLen=128){
  return String(content||'').slice(0,maxLen);
}

function buildRoundLogFileName(roundData){
  const num=String(roundData.round).padStart(4,'0');
  return num+'.json';
}

function formatDirectorSnippetForDisplay(snippet){
  return String(snippet||'').replace(/_/g,' ');
}

function parseDirectorSnippetFromLogFileName(name){
  void name;
  return '';
}

function getRoundLogLogicalKeyFromFileName(name){
  const m=String(name||'').match(/^(\d{4})\.json$/i);
  return String(m?.[1]||'').trim();
}

function normalizeAgentSlotIndex(value){
  const n=parseInt(value,10);
  return Number.isFinite(n)&&n>=0&&n<9?n:-1;
}

function isGhostAgent(agent){
  return !!agent?.isGhost;
}

function getLiveConversationAgents(conv=S.conv){
  return Array.isArray(conv?.agents)?conv.agents.filter(agent=>!isGhostAgent(agent)):[];
}

function getLiveConversationAgentCount(conv=S.conv){
  return getLiveConversationAgents(conv).length;
}

function buildGhostAgentId(resp,agents=[]){
  const persistedId=String(resp?.agentId||'').trim();
  if(persistedId) return persistedId;
  const rawName=String(resp?.agentName||resp?.speakerLabel||'').trim();
  const baseSlug=rawName.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,48);
  const base=baseSlug?`ghost_${baseSlug}`:'ghost_agent';
  const existingIds=new Set((agents||[]).map(agent=>String(agent?.id||'')).filter(Boolean));
  let candidate=base;
  let suffix=2;
  while(existingIds.has(candidate)){
    candidate=`${base}_${suffix++}`;
  }
  return candidate;
}

function makeGhostAgentFromLogResponse(resp,agents=[]){
  const ghostName=String(resp?.speakerLabel||resp?.agentName||resp?.agentId||'Removed Agent').trim()||'Removed Agent';
  return{
    id:buildGhostAgentId(resp,agents),
    name:ghostName,
    personaUuid:'',
    slotIndex:-1,
    model:'',
    voiceName:'',
    voiceActive:false,
    voiceRate:1,
    personaMissing:false,
    personaResolvedData:null,
    color:GHOST_COLOR_ID,
    msgs:[],
    expanded:false,
    settings:{activeByDefault:false,showSys:false},
    isGhost:true,
    fileName:''
  };
}

function getAgentSlotIndex(agent,conv=S.conv){
  const stored=normalizeAgentSlotIndex(agent?.slotIndex);
  if(stored>=0) return stored;
  if(conv&&Array.isArray(conv.agents)){
    const idx=conv.agents.indexOf(agent);
    if(idx>=0&&idx<9) return idx;
  }
  return 0;
}

function sortAgentsBySlotIndex(agents){
  if(!Array.isArray(agents)) return agents;
  agents.sort((a,b)=>{
    const aIdx=normalizeAgentSlotIndex(a?.slotIndex);
    const bIdx=normalizeAgentSlotIndex(b?.slotIndex);
    const safeA=aIdx>=0?aIdx:99;
    const safeB=bIdx>=0?bIdx:99;
    if(safeA!==safeB) return safeA-safeB;
    return String(a?.id||'').localeCompare(String(b?.id||''));
  });
  return agents;
}

function hasParticipantPlanSource(conv){
  return !!String(conv?.topicObjective||'').trim()||!!String(conv?.participantDescription||'').trim();
}

function hasCachedParticipantPlan(conv){
  const cached=conv?._participantPlan;
  if(!conv||!cached||!Array.isArray(cached.slots)||cached.slots.length!==9) return false;
  return conv._participantPlanKey===buildParticipantPlanKey(conv.topicObjective,conv.participantDescription);
}

function getPersistableParticipantPlan(conv){
  const plan=conv?._participantPlan;
  if(!plan||!Array.isArray(plan.slots)||plan.slots.length!==9) return null;
  return normalizeParticipantPlan(
    plan,
    String(plan.topicObjective||conv?.topicObjective||'').trim(),
    String(plan.participantDescription||conv?.participantDescription||'').trim()
  );
}

function warmParticipantPlan(conv,{persist=false}={}){
  if(!conv||!hasParticipantPlanSource(conv)) return Promise.resolve(null);
  const hadCached=hasCachedParticipantPlan(conv);
  return ensureParticipantPlan(conv).then(async plan=>{
    if(!plan) return null;
    if(S.conv&&isSameConversation(S.conv,conv)){
      renderAgentGrid();
      syncDirectorComposerUi();
    }
    if(persist&&!hadCached) await writeMetaFile(conv);
    return plan;
  }).catch(()=>null);
}

function toPersistedAgent(agent){
  return{
    id:agent.id,
    name:agent.name,
    personaUuid:agent.personaUuid||'',
    slotIndex:getAgentSlotIndex(agent),
    model:String(agent.model||'').trim(),
    color:agent.color||'teal',
    expanded:!!agent.expanded,
    voiceActive:!!agent.voiceActive,
    voiceName:String(agent.voiceName||''),
    voiceRate:agent.voiceRate||1,
    settings:{...(agent.settings||{}),activeByDefault:true,showSys:false}
  };
}

function fromPersistedAgent(raw,index,fileName=''){
  const slotIndex=normalizeAgentSlotIndex(raw?.slotIndex);
  const effectiveSlotIndex=slotIndex>=0?slotIndex:index;
  const d=DEFS[effectiveSlotIndex]||{name:'Agent '+(effectiveSlotIndex+1),color:COLORS[effectiveSlotIndex%COLORS.length].id,persona:''};
  const persistedSettings=(raw?.settings&&typeof raw.settings==='object')?raw.settings:{};
  return{
    id:raw?.id||('a'+Date.now()+index),
    name:raw?.name||d.name,
    personaUuid:String(raw?.personaUuid||'').trim(),
    slotIndex:effectiveSlotIndex,
    model:String(raw?.model||'').trim(),
    personaMissing:false,
    personaResolvedData:null,
    color:raw?.color||d.color||COLORS[effectiveSlotIndex%COLORS.length].id,
    expanded:!!raw?.expanded,
    voiceActive:!!raw?.voiceActive,
    voiceName:String(raw?.voiceName||''),
    voiceRate:raw?.voiceRate||1,
    settings:{...persistedSettings,activeByDefault:true,showSys:false},
    msgs:[],
    fileName:fileName||raw?.fileName||'',
    isGhost:false
  };
}
async function getConvsDir(create=true){
  if(!S.fsRoot)return null;
  try{
    return await S.fsRoot.getDirectoryHandle('Conversations',{create});
  }catch(e){return null;}
}
async function getPersonasDir(create=true){
  if(!S.fsRoot) return null;
  try{
    return await S.fsRoot.getDirectoryHandle('Personas',{create});
  }catch(e){return null;}
}
async function getConvDir(create=true){
  const c=S.conv;
  if(!c||!S.fsRoot) return null;
  if(c.folderHandle) return c.folderHandle;
  return null;
}
async function writeJsonFile(dirHandle,fname,data){
  try{
    const fh=await dirHandle.getFileHandle(fname,{create:true});
    const wr=await fh.createWritable();
    await wr.write(JSON.stringify(data,null,2));
    await wr.close();
  }catch(e){
    console.error('writeJsonFile failed:',fname,e);
    throw e;
  }
}
async function writeTextFile(dirHandle,fname,text){
  try{
    const fh=await dirHandle.getFileHandle(fname,{create:true});
    const wr=await fh.createWritable();
    await wr.write(String(text??''));
    await wr.close();
  }catch(e){
    console.error('writeTextFile failed:',fname,e);
    throw e;
  }
}
async function writeBinaryFile(dirHandle,fname,bytes){
  try{
    const fh=await dirHandle.getFileHandle(fname,{create:true});
    const wr=await fh.createWritable();
    await wr.write(bytes);
    await wr.close();
  }catch(e){
    console.error('writeBinaryFile failed:',fname,e);
    throw e;
  }
}
async function readJsonFile(fileHandle){
  const file=await fileHandle.getFile();
  return JSON.parse(await file.text());
}
async function readTextFile(fileHandle){
  const file=await fileHandle.getFile();
  return file.text();
}
async function ensureChildDir(dirHandle,name){
  return dirHandle.getDirectoryHandle(name,{create:true});
}
async function getConversationDownloadsDir(convNodeOrConv=S.conv,create=false){
  const base=convNodeOrConv?.folderHandle||await treeGetDirectoryHandleByPath(CONV_TREE_VIEW,convNodeOrConv?.sourcePath||'');
  if(!base) return null;
  return base.getDirectoryHandle(CONV_DOWNLOADS_DIR,{create:!!create});
}
async function getConversationDownloadSubdir(convNodeOrConv,subdir,create=false){
  const downloadsDir=await getConversationDownloadsDir(convNodeOrConv,create);
  if(!downloadsDir) return null;
  return downloadsDir.getDirectoryHandle(subdir,{create:!!create});
}

async function getConversationImageStorageDir(convNodeOrConv=S.conv,create=false){
  return getConversationDownloadSubdir(convNodeOrConv,CONV_DOWNLOADS_IMAGES_DIR,create);
}

async function getConversationImageFamilyDir(convNodeOrConv,familyDirName='',create=false){
  const imagesDir=await getConversationImageStorageDir(convNodeOrConv,create);
  if(!imagesDir) return null;
  const dirName=normalizeImageStoragePath(familyDirName);
  if(!dirName) return imagesDir;
  return imagesDir.getDirectoryHandle(dirName,{create:!!create});
}
async function writeAgentFiles(conv,convDir){
  const agentsDir=await convDir.getDirectoryHandle(CONV_AGENTS_DIR,{create:true});
  const keep=new Set();
  const persistable=getLiveConversationAgents(conv);
  for(let i=0;i<persistable.length;i++){
    const agent=persistable[i];
    let fileName=String(agent.fileName||'').trim();
    if(!fileName.endsWith('.json')){
      const base=sanitizeTitleForFs(agent.name||('agent_'+(i+1)),64);
      fileName=await makeUniqueFileName(agentsDir,base,'.json');
      agent.fileName=fileName;
    }
    keep.add(fileName);
    await writeJsonFile(agentsDir,fileName,toPersistedAgent(agent));
  }
  for await(const [name,entry] of agentsDir.entries()){
    if(entry.kind!=='file'||!name.endsWith('.json')) continue;
    if(!keep.has(name)){
      try{await agentsDir.removeEntry(name);}catch(e){}
    }
  }
}
async function writeMetaFile(convOverride){
  const c=convOverride||S.conv;
  if(!c||!S.fsRoot)return;
  try{
    const dir=c.folderHandle||await treeGetDirectoryHandleByPath(CONV_TREE_VIEW,c.sourcePath||'');
    if(!dir)return;
    await dir.getDirectoryHandle(CONV_AGENTS_DIR,{create:true});
    await dir.getDirectoryHandle(CONV_LOGS_DIR,{create:true});
    const meta={
      uuid:c.uuid||c.id,
      name:c.name,created:c.created,agentCols:c.agentCols,
      editorFieldsLocked:!!c.editorFieldsLocked,
      topicObjective:c.topicObjective||'',
      participantDescription:c.participantDescription||'',
      rollingRounds:c.rollingRounds||APP_SETTINGS.maxRounds||10,
      artifactCounters:getConversationArtifactCounters(c),
      settings:{
        ...(c.settings||{}),
        webSearchBudget:getConversationWebSearchBudget(c),
        activeAgentIds:getConversationActiveAgentIds(c),
        conversationMode:getConversationMode(c),
        directorType:getConversationDirectorType(c),
        aiDirectorCountdown:getConversationAiDirectorCountdown(c),
        paceDelay:getConversationPaceDelay(c)
      }
    };
    const participantPlan=getPersistableParticipantPlan(c);
    if(participantPlan) meta.participantPlan=participantPlan;
    await writeJsonFile(dir,CONV_SETTINGS_FILE,meta);
    await writeAgentFiles(c,dir);
  }catch(e){
    console.error('writeMetaFile failed:',e);
  }
}
async function writeRoundFile(roundData){
  if(!S.conv||!S.fsRoot)return;
  try{
    const dir=await getConvDir(true);if(!dir)return;
    const logsDir=await dir.getDirectoryHandle(CONV_LOGS_DIR,{create:true});
    const fileName=buildRoundLogFileName(roundData);
    await writeJsonFile(logsDir,fileName,roundData);
  }catch(e){}
}
const CONV_TREE_EXP_KEY='cl_conv_tree_expanded';
const CONV_TREE_SEL_KEY='cl_conv_tree_selected';
const PERSONA_TREE_EXP_KEY='cl_persona_tree_expanded';
const PERSONA_TREE_SEL_KEY='cl_persona_tree_selected';
const TREE_DND_MIME='application/x-conflab-tree-dnd';

const CONV_TREE_VIEW={
  key:'conv',
  leafType:'conversation',
  indexKey:'convTreeIndex',
  expandedKey:'convTreeExpanded',
  selectedPathKey:'convTreeSelectedPath',
  uiLoadedKey:'_convTreeUiLoaded',
  lsExpandedKey:CONV_TREE_EXP_KEY,
  lsSelectedKey:CONV_TREE_SEL_KEY,
  rootTargetId:'conv-root-target',
  getRootDir:()=>getConvsDir(true),
  dragTreeName:'conv',
  menuId:'cat-menu',
  menuPathKey:'catMenuPath',
  menuBoundKey:'_catMenuBound',
  menuRenameButtonId:'cat-menu-rename',
  menuDeleteButtonId:'cat-menu-delete',
  menuCancelButtonId:'cat-menu-cancel',
  renamePathKey:'catRenamePath',
  renameValueKey:'catRenameValue',
  renameInputId:'cat-rename-input',
  createParentPathKey:'catCreateParentPath',
  createValueKey:'catCreateValue',
  createInputId:'cat-create-input',
  render:()=>renderConvList(),
  moveNode:moveConversationTreeNode,
  rescan:()=>scanConvFolders(),
  canManageCategory:node=>!!node&&node.type==='category',
  rootUnavailableMessage:'Choose a Conflab workspace first.',
  createTargetErrorMessage:'Unable to access Conversations folder.',
  renameErrorMessage:'Could not rename category.',
  deleteErrorMessage:'Could not delete category.',
  confirmDeleteMessage:node=>'Delete category "'+(node.displayName||stripLeadingBang(node.name))+'"?\n\nThis will permanently delete this category and everything inside it.',
  onAfterRemap:(oldPrefix,newPrefix)=>{
    if(S.conv?.sourcePath){
      S.conv.sourcePath=remapTreePath(S.conv.sourcePath,oldPrefix,newPrefix);
      S.conv.id=S.conv.sourcePath;
    }
    if(S.convDialogPath){
      S.convDialogPath=remapTreePath(S.convDialogPath,oldPrefix,newPrefix);
    }
    const last=localStorage.getItem('cl_last_conv')||'';
    const remapped=remapTreePath(last,oldPrefix,newPrefix);
    if(remapped!==last) localStorage.setItem('cl_last_conv',remapped);
  },
  onAfterDelete:node=>{
    const oldPath=node.path||'';
    if(S.conv?.sourcePath&&(S.conv.sourcePath===oldPath||S.conv.sourcePath.startsWith(oldPath+'/'))){
      S.conv=null;
      S.attachments=[];
      clearDownloads();
    }
  },
  onAfterRenameCopy:(copied,node)=>{node.folderHandle=copied;},
  afterDeleteRender:()=>renderAll(),
  afterRenameRender:()=>renderAll()
};

const PERSONA_TREE_VIEW={
  key:'persona',
  leafType:'persona',
  indexKey:'personaTreeIndex',
  expandedKey:'personaTreeExpanded',
  selectedPathKey:'personaTreeSelectedPath',
  uiLoadedKey:'_personaTreeUiLoaded',
  lsExpandedKey:PERSONA_TREE_EXP_KEY,
  lsSelectedKey:PERSONA_TREE_SEL_KEY,
  rootTargetId:'persona-root-target',
  getRootDir:()=>getPersonasDir(true),
  dragTreeName:'persona',
  menuId:'pcat-menu',
  menuPathKey:'pcatMenuPath',
  menuBoundKey:'_pcatMenuBound',
  menuRenameButtonId:'pcat-menu-rename',
  menuDeleteButtonId:'pcat-menu-delete',
  menuCancelButtonId:'pcat-menu-cancel',
  renamePathKey:'pcatRenamePath',
  renameValueKey:'pcatRenameValue',
  renameInputId:'pcat-rename-input',
  createParentPathKey:'pcatCreateParentPath',
  createValueKey:'pcatCreateValue',
  createInputId:'pcat-create-input',
  render:()=>renderPersonaList(),
  moveNode:movePersonaTreeNode,
  rescan:()=>scanPersonaFolders(),
  canManageCategory:node=>!!node&&node.type==='category',
  rootUnavailableMessage:'Choose a Conflab workspace first.',
  createTargetErrorMessage:'Unable to access Personas folder.',
  renameErrorMessage:'Could not rename category.',
  deleteErrorMessage:'Could not delete category.',
  confirmDeleteMessage:node=>'Delete category "'+(node.displayName||stripLeadingBang(node.name))+'"?\n\nThis will permanently delete this category and all subcategories and personas inside it.',
  onAfterRemap:(oldPrefix,newPrefix)=>{
    if(S.activePersona?.path){
      S.activePersona.path=remapTreePath(S.activePersona.path,oldPrefix,newPrefix);
    }
    const pePath=document.getElementById('pe-path');
    if(pePath&&pePath.value){
      pePath.value=remapTreePath(pePath.value,oldPrefix,newPrefix);
    }
    const peId=document.getElementById('pe-id');
    if(peId&&peId.value){
      peId.value=remapTreePath(peId.value,oldPrefix,newPrefix);
    }
  },
  onAfterDelete:node=>{
    const oldPath=node.path||'';
    if(S.activePersona?.path&&(S.activePersona.path===oldPath||S.activePersona.path.startsWith(oldPath+'/'))){
      personaListBack();
    }
  },
  afterDeleteRender:()=>renderPersonaList(),
  afterRenameRender:()=>renderPersonaList()
};

const DOWNLOADS_TREE_VIEW={
  key:'downloads',
  leafType:'conversation',
  indexKey:'downloadsTreeIndex',
  expandedKey:'downloadsTreeExpanded',
  selectedPathKey:'downloadsTreeSelectedPath',
  rootTargetId:'downloads-root-target',
  render:()=>renderDownloadsTree()
};

function treeLoadUIState(cfg){
  if(!cfg?.lsExpandedKey||!cfg.lsSelectedKey) return;
  if(cfg.uiLoadedKey&&S[cfg.uiLoadedKey]) return;
  try{S[cfg.expandedKey]=JSON.parse(localStorage.getItem(cfg.lsExpandedKey)||'{}');}
  catch(e){S[cfg.expandedKey]={};}
  S[cfg.selectedPathKey]=localStorage.getItem(cfg.lsSelectedKey)||'';
  if(cfg.uiLoadedKey) S[cfg.uiLoadedKey]=true;
}

function treeSaveUIState(cfg){
  if(!cfg?.lsExpandedKey||!cfg.lsSelectedKey) return;
  try{localStorage.setItem(cfg.lsExpandedKey,JSON.stringify(S[cfg.expandedKey]||{}));}catch(e){}
  try{localStorage.setItem(cfg.lsSelectedKey,S[cfg.selectedPathKey]||'');}catch(e){}
}

async function treeGetDirectoryHandleByPath(cfg,path){
  const rootDir=await cfg?.getRootDir?.();
  if(!rootDir) return null;
  const segs=splitTreePath(path);
  let cur=rootDir;
  for(const seg of segs){
    cur=await cur.getDirectoryHandle(seg,{create:false});
  }
  return cur;
}

function treeRemapPathState(cfg,oldPrefix,newPrefix){
  if(!cfg||!oldPrefix||oldPrefix===newPrefix) return;
  treeLoadUIState(cfg);
  const nextExpanded={};
  Object.entries(S[cfg.expandedKey]||{}).forEach(([path,open])=>{
    nextExpanded[remapTreePath(path,oldPrefix,newPrefix)]=!!open;
  });
  S[cfg.expandedKey]=nextExpanded;
  S[cfg.selectedPathKey]=remapTreePath(S[cfg.selectedPathKey]||'',oldPrefix,newPrefix);
  cfg.onAfterRemap?.(oldPrefix,newPrefix);
  treeSaveUIState(cfg);
}

function treeEnsurePathExpanded(cfg,path){
  if(!cfg||!path) return;
  const segs=String(path).split('/').filter(Boolean);
  let cur='';
  for(let i=0;i<segs.length-1;i++){
    cur=cur?cur+'/'+segs[i]:segs[i];
    const node=S[cfg.indexKey]?.[cur];
    if(node?.type==='category'){
      S[cfg.expandedKey][cur]=true;
    }
  }
}

function treeSelectPath(cfg,path){
  if(!cfg) return;
  treeLoadUIState(cfg);
  S[cfg.selectedPathKey]=path||'';
  treeEnsurePathExpanded(cfg,path);
  treeSaveUIState(cfg);
}

function treeSelectRoot(cfg){
  if(!S.fsRoot) return;
  treeSelectPath(cfg,'');
  cfg?.render?.();
}

function treeUpdateRootTargetState(cfg){
  const rootRow=document.getElementById(cfg?.rootTargetId||'');
  if(!rootRow) return;
  rootRow.classList.toggle('sel',!(S[cfg.selectedPathKey]||''));
}

async function treeGetCreateTarget(cfg,forceRoot){
  const rootDir=await cfg?.getRootDir?.();
  if(!rootDir) return null;
  if(forceRoot) return{parentHandle:rootDir,parentPath:''};
  treeLoadUIState(cfg);
  const selPath=S[cfg.selectedPathKey]||'';
  const selected=selPath?S[cfg.indexKey]?.[selPath]:null;
  if(selected?.type==='category'){
    return{parentHandle:selected.folderHandle,parentPath:selected.path};
  }
  if(selected?.type===cfg.leafType){
    return{parentHandle:selected.parentHandle||rootDir,parentPath:selected.parentPath||''};
  }
  return{parentHandle:rootDir,parentPath:''};
}

function treeHasInlineCreate(cfg){
  return !!cfg&&cfg.createParentPathKey&&(S[cfg.createParentPathKey]!==null&&S[cfg.createParentPathKey]!==undefined);
}

function treeClearInlineCreateState(cfg){
  if(!cfg?.createParentPathKey||!cfg.createValueKey) return;
  S[cfg.createParentPathKey]=null;
  S[cfg.createValueKey]='';
}

function treeFocusInlineCreateInput(cfg){
  setTimeout(()=>{
    const input=document.getElementById(cfg?.createInputId||'');
    if(input){
      input.focus();
      input.select();
    }
  },0);
}

async function treeStartInlineCreate(cfg){
  if(!cfg) return;
  if(!S.workspaceReady&&!S.fsRoot){
    await appAlert(cfg.rootUnavailableMessage||'Choose a Conflab workspace first.');
    return;
  }
  if(treeHasInlineCreate(cfg)){
    treeFocusInlineCreateInput(cfg);
    return;
  }
  const target=await treeGetCreateTarget(cfg,false);
  if(!target){await appAlert(cfg.createTargetErrorMessage||'Unable to access folder.');return;}
  treeHideMenu(cfg);
  S[cfg.renamePathKey]='';
  S[cfg.renameValueKey]='';
  treeLoadUIState(cfg);
  if(target.parentPath) S[cfg.expandedKey][target.parentPath]=true;
  treeSaveUIState(cfg);
  S[cfg.createParentPathKey]=target.parentPath;
  S[cfg.createValueKey]='';
  cfg.render?.();
  treeFocusInlineCreateInput(cfg);
}

function treeCancelInlineCreate(cfg){
  if(!cfg) return;
  if(!treeHasInlineCreate(cfg)&&!(S[cfg.createValueKey]||'')) return;
  treeClearInlineCreateState(cfg);
  cfg.render?.();
}

async function treeCommitInlineCreate(cfg){
  if(!treeHasInlineCreate(cfg)){
    treeCancelInlineCreate(cfg);
    return;
  }
  const parentPath=S[cfg.createParentPathKey];
  const raw=(S[cfg.createValueKey]||'').trim();
  const displayName=stripLeadingBang(raw).trim();
  if(!displayName){
    treeCancelInlineCreate(cfg);
    return;
  }
  try{
    const parentHandle=await treeGetDirectoryHandleByPath(cfg,parentPath||'');
    if(!parentHandle) throw new Error('Category parent folder unavailable.');
    const base='!'+sanitizeTitleForFs(displayName,64);
    const folderName=await makeUniqueDirName(parentHandle,base);
    await parentHandle.getDirectoryHandle(folderName,{create:true});
    treeClearInlineCreateState(cfg);
    treeLoadUIState(cfg);
    if(parentPath) S[cfg.expandedKey][parentPath]=true;
    treeSaveUIState(cfg);
    await cfg.rescan?.();
  }catch(e){
    await appAlert(cfg.createTargetErrorMessage||'Unable to access folder.');
    treeCancelInlineCreate(cfg);
  }
}

function treeHideMenu(cfg){
  const menu=document.getElementById(cfg?.menuId||'');
  if(menu){
    menu.style.display='none';
    menu.setAttribute('aria-hidden','true');
  }
  if(cfg?.menuPathKey) S[cfg.menuPathKey]='';
}

function treeShowMenu(cfg,path,x,y){
  const menu=document.getElementById(cfg?.menuId||'');
  if(!menu) return;
  const node=path?S[cfg.indexKey]?.[path]:null;
  if(!cfg.canManageCategory?.(node)) return;
  S[cfg.menuPathKey]=path;
  menu.style.display='block';
  menu.setAttribute('aria-hidden','false');
  const vw=window.innerWidth||1024;
  const vh=window.innerHeight||768;
  const rect=menu.getBoundingClientRect();
  menu.style.left=Math.max(8,Math.min(x,vw-rect.width-8))+'px';
  menu.style.top=Math.max(8,Math.min(y,vh-rect.height-8))+'px';
}

function treeStartInlineRename(cfg,path){
  const node=path?S[cfg.indexKey]?.[path]:null;
  if(!cfg.canManageCategory?.(node)) return;
  treeHideMenu(cfg);
  S[cfg.renamePathKey]=path;
  S[cfg.renameValueKey]=node.displayName||stripLeadingBang(node.name);
  cfg.render?.();
  setTimeout(()=>{
    const input=document.getElementById(cfg.renameInputId);
    if(input){
      input.focus();
      input.select();
    }
  },0);
}

function treeCancelInlineRename(cfg){
  if(!cfg) return;
  if(!S[cfg.renamePathKey]&&!S[cfg.renameValueKey]) return;
  S[cfg.renamePathKey]='';
  S[cfg.renameValueKey]='';
  cfg.render?.();
}

async function treeCommitInlineRename(cfg){
  const path=S[cfg.renamePathKey]||'';
  const node=path?S[cfg.indexKey]?.[path]:null;
  if(!cfg.canManageCategory?.(node)){
    treeCancelInlineRename(cfg);
    return;
  }
  const raw=(S[cfg.renameValueKey]||'').trim();
  const displayName=stripLeadingBang(raw).trim();
  if(!displayName){
    treeCancelInlineRename(cfg);
    return;
  }
  const targetBase='!'+sanitizeTitleForFs(displayName,64);
  const oldPath=node.path||'';
  const oldName=node.name||'';
  try{
    let nextPath=oldPath;
    if(targetBase!==oldName){
      if(!node.parentHandle||!node.folderHandle) throw new Error('Category handle unavailable.');
      let targetName=targetBase;
      try{
        await node.parentHandle.getDirectoryHandle(targetName,{create:false});
        targetName=await makeUniqueDirName(node.parentHandle,targetBase);
      }catch(e){}
      const copied=await copyDirectoryRecursive(node.folderHandle,node.parentHandle,targetName);
      await node.parentHandle.removeEntry(oldName,{recursive:true});
      nextPath=node.parentPath?node.parentPath+'/'+targetName:targetName;
      treeRemapPathState(cfg,oldPath,nextPath);
      cfg.onAfterRenameCopy?.(copied,node,nextPath);
    }
    S[cfg.renamePathKey]='';
    S[cfg.renameValueKey]='';
    await cfg.rescan?.();
    treeSelectPath(cfg,nextPath);
    (cfg.afterRenameRender||cfg.render)?.();
  }catch(e){
    await appAlert(cfg.renameErrorMessage||'Could not rename category.');
    treeCancelInlineRename(cfg);
  }
}

async function treeDeleteCategoryNode(cfg,node){
  if(!cfg.canManageCategory?.(node)||!node.parentHandle) return false;
  const ok=await appConfirm(cfg.confirmDeleteMessage?.(node)||'Delete category?',{title:'DELETE CATEGORY',okLabel:'Delete'});
  if(!ok) return true;
  try{
    await node.parentHandle.removeEntry(node.name,{recursive:true});
  }catch(e){
    await appAlert(cfg.deleteErrorMessage||'Could not delete category.');
    return true;
  }
  cfg.onAfterDelete?.(node);
  treeSelectPath(cfg,node.parentPath||'');
  await cfg.rescan?.();
  (cfg.afterDeleteRender||cfg.render)?.();
  return true;
}

async function treeDeleteSelectedCategory(cfg){
  treeLoadUIState(cfg);
  const sel=S[cfg.selectedPathKey]||'';
  const node=sel?S[cfg.indexKey]?.[sel]:null;
  if(!cfg.canManageCategory?.(node)) return false;
  return treeDeleteCategoryNode(cfg,node);
}

function treeEvaluateDrop(cfg,payload,targetKind,targetPath){
  if(!cfg?.dragTreeName||!payload||payload.tree!==cfg.dragTreeName) return{ok:false};
  const src=S[cfg.indexKey]?.[payload.path];
  if(!src||src.type!==payload.type) return{ok:false};
  if(targetKind!=='root'&&targetKind!=='category') return{ok:false};
  const destPath=(targetKind==='category')?(targetPath||''):'';
  if(src.type==='category'&&destPath&&isSameOrDescendantPath(destPath,src.path)) return{ok:false};
  if(targetKind==='category'){
    const target=S[cfg.indexKey]?.[destPath];
    if(!target||target.type!=='category'||!target.folderHandle) return{ok:false};
    return{ok:true,src,destPath,destHandle:target.folderHandle};
  }
  return{ok:true,src,destPath:'',destHandle:null};
}

function treeHandleDragOver(cfg,event,targetKind,targetPath,targetEl){
  const payload=readTreeDragPayload(event);
  if(!payload) return;
  const verdict=treeEvaluateDrop(cfg,payload,targetKind,targetPath);
  event.preventDefault();
  if(event.dataTransfer) event.dataTransfer.dropEffect=verdict.ok?'move':'none';
  if(verdict.ok) setDragHoverTarget(targetEl);
  else clearDragHoverTarget();
}

async function treeHandleDrop(cfg,event,targetKind,targetPath){
  const payload=readTreeDragPayload(event);
  const verdict=treeEvaluateDrop(cfg,payload,targetKind,targetPath);
  event.preventDefault();
  clearDragHoverTarget();
  if(!verdict.ok){
    if(event.dataTransfer) event.dataTransfer.dropEffect='none';
    clearTreeDragState();
    return;
  }
  try{
    await cfg.moveNode?.(verdict);
  }catch(e){
    await appAlert('Could not move item.');
  }finally{
    clearTreeDragState();
  }
}

function flattenTreeLeaves(nodes,leafType,out=[]){
  (nodes||[]).forEach(n=>{
    if(n.type==='category') flattenTreeLeaves(n.children||[],leafType,out);
    else if(n.type===leafType) out.push(n);
  });
  return out;
}

function treeBindRenameInput(input,cfg){
  if(!input||!cfg) return;
  input.oninput=()=>{S[cfg.renameValueKey]=input.value;};
  input.onclick=e=>e.stopPropagation();
  input.onkeydown=async e=>{
    if(e.key==='Enter'){
      e.preventDefault();
      S[cfg.renameValueKey]=input.value;
      await treeCommitInlineRename(cfg);
    }else if(e.key==='Escape'){
      e.preventDefault();
      treeCancelInlineRename(cfg);
    }
  };
  input.onblur=async()=>{
    S[cfg.renameValueKey]=input.value;
    await treeCommitInlineRename(cfg);
  };
}

function treeBindCreateInput(input,cfg){
  if(!input||!cfg) return;
  input.oninput=()=>{S[cfg.createValueKey]=input.value;};
  input.onclick=e=>e.stopPropagation();
  input.onkeydown=async e=>{
    if(e.key==='Enter'){
      e.preventDefault();
      S[cfg.createValueKey]=input.value;
      await treeCommitInlineCreate(cfg);
    }else if(e.key==='Escape'){
      e.preventDefault();
      treeCancelInlineCreate(cfg);
    }
  };
  input.onblur=()=>{
    S[cfg.createValueKey]=input.value;
    treeCancelInlineCreate(cfg);
  };
}

function treeToggleCategorySelection(cfg,node,hasChildren,expanded){
  if(cfg.renamePathKey&&S[cfg.renamePathKey]===node.path) return;
  treeHideMenu(cfg);
  treeLoadUIState(cfg);
  const wasSelected=S[cfg.selectedPathKey]===node.path;
  S[cfg.selectedPathKey]=node.path;
  if(hasChildren){
    if(!wasSelected) S[cfg.expandedKey][node.path]=true;
    else S[cfg.expandedKey][node.path]=!expanded;
  }else{
    playUiFailSound();
    delete S[cfg.expandedKey][node.path];
  }
  treeSaveUIState(cfg);
  cfg.render?.();
}

function treeShowCategoryContextMenu(cfg,node,event){
  event.preventDefault();
  treeHideMenu(cfg);
  treeSelectPath(cfg,node.path||'');
  cfg.render?.();
  treeShowMenu(cfg,node.path||'',event.clientX,event.clientY);
}

function treeCaretGlyph(hasChildren,expanded){
  if(!hasChildren) return '▷';
  return expanded?'▾':'▸';
}
function treeCaretClass(hasChildren){
  return hasChildren?'c-caret':'c-caret c-caret-empty';
}

function treeCreateCategoryRow(cfg,node,depth,selected,expanded,hasChildren){
  const row=document.createElement('div');
  const basePad=8+(depth*14);
  const isRenaming=!!(cfg.renamePathKey&&S[cfg.renamePathKey]===node.path);
  row.className='c-row c-cat'+(selected?' sel':'');
  if(!hasChildren) row.dataset.uiClickSound='off';
  row.style.paddingLeft=basePad+'px';
  row.innerHTML=`
      <span class="${treeCaretClass(hasChildren)}">${treeCaretGlyph(hasChildren,expanded)}</span>
      <span class="c-icon">${expanded?'📂':'📁'}</span>
      ${isRenaming
        ? `<input id="${cfg.renameInputId}" class="tree-rename-input" type="text" maxlength="64" value="${esc(S[cfg.renameValueKey]||node.displayName||stripLeadingBang(node.name))}">`
        : `<span class="c-label">${esc(node.displayName||stripLeadingBang(node.name))}</span>`}`;
  if(isRenaming){
    treeBindRenameInput(row.querySelector('#'+cfg.renameInputId),cfg);
  }
  if(cfg.dragTreeName&&!isRenaming){
    row.draggable=true;
    row.ondragstart=e=>startTreeDrag(e,cfg.dragTreeName,node,row);
    row.ondragend=()=>endTreeDrag(row);
  }
  if(cfg.dragTreeName){
    row.ondragover=e=>treeHandleDragOver(cfg,e,'category',node.path,row);
    row.ondragleave=e=>handleDropTargetDragLeave(e,row);
    row.ondrop=async e=>{await treeHandleDrop(cfg,e,'category',node.path);};
  }
  row.onclick=()=>treeToggleCategorySelection(cfg,node,hasChildren,expanded);
  if(cfg.menuId){
    row.oncontextmenu=e=>treeShowCategoryContextMenu(cfg,node,e);
  }
  return row;
}

function treeCreatePendingCategoryRow(cfg,depth){
  const row=document.createElement('div');
  const basePad=8+(depth*14);
  row.className='c-row c-cat';
  row.style.paddingLeft=basePad+'px';
  row.innerHTML=`
      <span class="c-caret"></span>
      <span class="c-icon">📁</span>
      <input id="${cfg.createInputId}" class="tree-rename-input" type="text" maxlength="64" value="${esc(S[cfg.createValueKey]||'')}" placeholder="New category">`;
  treeBindCreateInput(row.querySelector('#'+cfg.createInputId),cfg);
  return row;
}

function treeBindRootTarget(cfg){
  const root=document.getElementById(cfg?.rootTargetId||'');
  if(!root||root._treeRootBound) return;
  root._treeRootBound=true;
  root.addEventListener('click',()=>treeSelectRoot(cfg));
  if(cfg.dragTreeName){
    root.addEventListener('dragover',e=>treeHandleDragOver(cfg,e,'root','',root));
    root.addEventListener('dragleave',e=>handleDropTargetDragLeave(e,root));
    root.addEventListener('drop',async e=>{await treeHandleDrop(cfg,e,'root','');});
  }
}

function treeBindMenu(cfg){
  if(!cfg?.menuId) return;
  if(S[cfg.menuBoundKey]) return;
  S[cfg.menuBoundKey]=true;
  document.getElementById(cfg.menuRenameButtonId)?.addEventListener('click',()=>{
    const path=S[cfg.menuPathKey]||'';
    treeHideMenu(cfg);
    if(path) treeStartInlineRename(cfg,path);
  });
  document.getElementById(cfg.menuDeleteButtonId)?.addEventListener('click',async()=>{
    const path=S[cfg.menuPathKey]||'';
    treeHideMenu(cfg);
    const node=path?S[cfg.indexKey]?.[path]:null;
    if(cfg.canManageCategory?.(node)) await treeDeleteCategoryNode(cfg,node);
  });
  document.getElementById(cfg.menuCancelButtonId)?.addEventListener('click',()=>treeHideMenu(cfg));
  document.addEventListener('mousedown',e=>{
    const menu=document.getElementById(cfg.menuId);
    if(!menu||menu.style.display!=='block') return;
    if(menu.contains(e.target)) return;
    treeHideMenu(cfg);
  });
}

function bindTreeUiHandlers(){
  treeBindRootTarget(CONV_TREE_VIEW);
  treeBindRootTarget(PERSONA_TREE_VIEW);
  treeBindRootTarget(DOWNLOADS_TREE_VIEW);
  treeBindMenu(CONV_TREE_VIEW);
  treeBindMenu(PERSONA_TREE_VIEW);
}

function createUUID(){
  if(window.crypto&&window.crypto.randomUUID) return window.crypto.randomUUID();
  return 'u'+Date.now().toString(36)+Math.random().toString(36).slice(2,10);
}

function ensureClientSessionState(){
  if(window.__conflabClientSessionState) return window.__conflabClientSessionState;
  window.__conflabClientSessionState={
    id:createUUID(),
    startedAt:Date.now(),
    ownerEpoch:0,
    activeSessionId:'',
    suspended:false,
    status:'claiming',
    bannerMessage:'',
    bannerEl:null,
    channel:null,
    autoCloseAttempted:false,
    closeBlocked:false,
    closeAttemptTimer:null
  };
  return window.__conflabClientSessionState;
}

function isMutatingFsApiUrl(url){
  return url==='/api/fs/ensure-dir'||
    url==='/api/fs/ensure-file'||
    url==='/api/fs/write'||
    url==='/api/fs/remove'||
    url==='/api/fs/move';
}

function ensureSessionStatusBanner(){
  const session=ensureClientSessionState();
  if(session.bannerEl&&document.body?.contains(session.bannerEl)) return session.bannerEl;
  if(!document.body) return null;
  const banner=document.createElement('div');
  banner.id='session-status-banner';
  banner.style.display='none';
  banner.style.position='fixed';
  banner.style.top='8px';
  banner.style.left='50%';
  banner.style.transform='translateX(-50%)';
  banner.style.zIndex='9999';
  banner.style.padding='10px 16px';
  banner.style.border='1px solid rgba(255,85,85,.55)';
  banner.style.borderRadius='999px';
  banner.style.background='rgba(40,10,10,.92)';
  banner.style.color='var(--red,#ff6b6b)';
  banner.style.fontFamily="'JetBrains Mono',monospace";
  banner.style.fontSize='12px';
  banner.style.letterSpacing='.04em';
  banner.style.boxShadow='0 8px 24px rgba(0,0,0,.35)';
  banner.style.pointerEvents='none';
  document.body.appendChild(banner);
  session.bannerEl=banner;
  return banner;
}

function isSessionInteractionBlocked(){
  return !!ensureClientSessionState().suspended||isStartupWorkspaceLoading();
}

function clearSuspendedCloseAttemptTimer(){
  const session=ensureClientSessionState();
  if(session.closeAttemptTimer){
    window.clearTimeout(session.closeAttemptTimer);
    session.closeAttemptTimer=null;
  }
}

function closeUiForSuspendedSession(){
  try{ stopMic(); }catch(e){}
  try{ closeAllModelPickers(); }catch(e){}
  try{ drawerClose(); }catch(e){}
  try{ closeApiErrorDialog(); }catch(e){}
  try{ closeExamplesModal(); }catch(e){}
  try{ closeMissionStatementDialog(); }catch(e){}
  try{
    const appDialog=document.getElementById('modal-app-dialog');
    if(appDialog&&appDialog.style.display==='flex') cancelAppDialog();
  }catch(e){}
  try{
    const fsPicker=document.getElementById('modal-fs-picker');
    if(fsPicker&&fsPicker.style.display==='flex') cancelFsPicker();
  }catch(e){}
  try{ document.activeElement?.blur?.(); }catch(e){}
}

function syncSuspendedSessionOverlay(){
  const session=ensureClientSessionState();
  const app=document.getElementById('app');
  const overlay=document.getElementById('session-suspended-overlay');
  const status=document.getElementById('session-suspended-status');
  const closeBtn=document.getElementById('session-suspended-close');
  document.body.classList.toggle('session-suspended',session.suspended);
  if(app){
    if(session.suspended){
      app.setAttribute('inert','');
      app.setAttribute('aria-hidden','true');
    }else{
      app.removeAttribute('inert');
      app.removeAttribute('aria-hidden');
    }
  }
  if(!overlay||!status||!closeBtn) return;
  overlay.style.display=session.suspended?'flex':'none';
  if(!session.suspended){
    status.textContent='';
    closeBtn.disabled=false;
    closeBtn.textContent='Close Tab';
    return;
  }
  closeBtn.disabled=!session.closeBlocked;
  closeBtn.textContent=session.closeBlocked?'Close Tab':'Closing Tab...';
  status.textContent=session.closeBlocked
    ? 'Your browser kept this inactive tab open. Please close it now.'
    : 'Conflab is trying to close this inactive tab automatically...';
}

function attemptCloseSuspendedTab(fromAutoClose=true){
  const session=ensureClientSessionState();
  if(!session.suspended) return;
  clearSuspendedCloseAttemptTimer();
  if(fromAutoClose) session.autoCloseAttempted=true;
  session.closeBlocked=false;
  syncSuspendedSessionOverlay();
  try{ window.close(); }catch(e){}
  session.closeAttemptTimer=window.setTimeout(()=>{
    const latest=ensureClientSessionState();
    latest.closeAttemptTimer=null;
    if(!latest.suspended) return;
    latest.closeBlocked=true;
    syncSuspendedSessionOverlay();
  },250);
}

function syncSessionOwnershipUi(){
  const session=ensureClientSessionState();
  const banner=ensureSessionStatusBanner();
  if(banner){
    banner.style.display='none';
    banner.textContent='';
  }
  syncSuspendedSessionOverlay();
  syncDirectorComposerUi();
}

function setupSessionBroadcastChannel(){
  const session=ensureClientSessionState();
  if(session.channel||typeof BroadcastChannel==='undefined') return session.channel;
  try{
    const channel=new BroadcastChannel(SESSION_BROADCAST_CHANNEL_NAME);
    channel.onmessage=event=>handleSessionBroadcast(event?.data||null);
    session.channel=channel;
  }catch(e){
    session.channel=null;
  }
  return session.channel;
}

function broadcastActiveSessionOwnership(){
  const session=ensureClientSessionState();
  const channel=setupSessionBroadcastChannel();
  if(!channel||!session.ownerEpoch) return;
  try{
    channel.postMessage({
      type:'active-session',
      sessionId:session.id,
      ownerEpoch:session.ownerEpoch,
      appVersion:APP_VERSION,
      ts:Date.now()
    });
  }catch(e){
    console.error('writeRoundFile failed:',e);
  }
}

function suspendClientSession(message=SESSION_SUPERSEDED_MESSAGE){
  const session=ensureClientSessionState();
  session.suspended=true;
  session.status='suspended';
  session.bannerMessage=String(message||SESSION_SUPERSEDED_MESSAGE);
  session.closeBlocked=false;
  try{ interruptAll(); }catch(e){}
  closeUiForSuspendedSession();
  syncSessionOwnershipUi();
  if(!session.autoCloseAttempted) attemptCloseSuspendedTab(true);
}

function activateClientSession(ownerEpoch){
  const session=ensureClientSessionState();
  const nextEpoch=Math.max(0,parseInt(ownerEpoch,10)||0);
  const changed=session.suspended||session.ownerEpoch!==nextEpoch||session.activeSessionId!==session.id;
  session.ownerEpoch=nextEpoch;
  session.activeSessionId=session.id;
  session.suspended=false;
  session.status='active';
  session.bannerMessage='';
  session.autoCloseAttempted=false;
  session.closeBlocked=false;
  clearSuspendedCloseAttemptTimer();
  syncSessionOwnershipUi();
  if(changed) broadcastActiveSessionOwnership();
}

function applySessionOwnershipPayload(payload){
  if(!payload||typeof payload!=='object') return false;
  const session=ensureClientSessionState();
  const activeSessionId=String(payload?.activeSessionId||'').trim();
  const ownerEpoch=Math.max(0,parseInt(payload?.ownerEpoch,10)||0);
  if(activeSessionId&&activeSessionId===session.id){
    activateClientSession(ownerEpoch);
    return true;
  }
  if(activeSessionId&&activeSessionId!==session.id){
    session.activeSessionId=activeSessionId;
    session.ownerEpoch=ownerEpoch;
    suspendClientSession(String(payload?.message||SESSION_SUPERSEDED_MESSAGE));
    return false;
  }
  return false;
}

function handleSessionBroadcast(message){
  if(!message||message.type!=='active-session') return;
  const session=ensureClientSessionState();
  const activeSessionId=String(message.sessionId||'').trim();
  const ownerEpoch=Math.max(0,parseInt(message.ownerEpoch,10)||0);
  if(!activeSessionId||activeSessionId===session.id) return;
  if(!session.ownerEpoch||ownerEpoch>=session.ownerEpoch){
    session.activeSessionId=activeSessionId;
    session.ownerEpoch=ownerEpoch;
    suspendClientSession(SESSION_SUPERSEDED_MESSAGE);
  }
}

async function claimSessionOwnership(reason='startup'){
  return sendServerHeartbeat(reason,{claim:true});
}

async function ensureSessionCanMutate(){
  const session=ensureClientSessionState();
  if(session.suspended){
    throw new Error(SESSION_SUPERSEDED_MESSAGE);
  }
  if(!session.ownerEpoch){
    await claimSessionOwnership('mutation');
    if(session.suspended||!session.ownerEpoch){
      throw new Error(SESSION_SUPERSEDED_MESSAGE);
    }
  }
}


async function tryReadJsonFile(dirHandle,fileName){
  try{
    const fh=await dirHandle.getFileHandle(fileName);
    const f=await fh.getFile();
    return JSON.parse(await f.text());
  }catch(e){return null;}
}

function sortByDisplayName(a,b){
  return (a.displayName||'').localeCompare((b.displayName||''),undefined,{sensitivity:'base'});
}

function stripLeadingBang(s){
  let v=String(s||'').trim();
  while(v.startsWith('!')) v=v.slice(1);
  return v.trim();
}

function isUuidLike(value){
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value||'').trim());
}

function sanitizeTitleForFs(raw,maxLen=64){
  const reserved=/^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
  let s=stripLeadingBang(raw).slice(0,maxLen);
  s=s.replace(/\s+/g,'_');
  s=s.replace(/[\\/:*?"<>|]/g,'_');
  s=s.replace(/^[\s.]+|[\s.]+$/g,'');
  if(!s) s='Untitled';
  if(reserved.test(s)) s=s+'_1';
  return s;
}

function createEmptyPersonaNameUsage(){
  return{full:{},first:{},last:{}};
}

function normalizePersonaNameKey(name){
  return String(name||'').replace(/\s+/g,' ').trim().toLowerCase();
}

const PERSONA_NAME_PREFIXES=new Set(['mr','mrs','ms','miss','mx','dr','prof','professor','rev','fr']);
const PERSONA_NAME_SUFFIXES=new Set(['jr','sr','ii','iii','iv','v','md','phd','dds','dvm']);

function normalizePersonaNameToken(token){
  return String(token||'').replace(/^[^A-Za-z0-9]+|[^A-Za-z0-9]+$/g,'').toLowerCase();
}

function isPersonaNamePrefix(token){
  return PERSONA_NAME_PREFIXES.has(normalizePersonaNameToken(token));
}

function isPersonaNameSuffix(token){
  return PERSONA_NAME_SUFFIXES.has(normalizePersonaNameToken(token));
}

function formatPersonaNameForPrompt(name){
  return String(name||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean).map(token=>{
    if(token.length<=1) return token.toUpperCase();
    return token.charAt(0).toUpperCase()+token.slice(1);
  }).join(' ');
}

function shuffleArrayCopy(items){
  const out=Array.isArray(items)?items.slice():[];
  for(let i=out.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [out[i],out[j]]=[out[j],out[i]];
  }
  return out;
}

function splitPersonaNameParts(name){
  const full=String(name||'').replace(/\s+/g,' ').trim();
  const rawTokens=full?full.split(' ').filter(Boolean):[];
  const tokens=[...rawTokens];
  while(tokens.length&&isPersonaNamePrefix(tokens[0])) tokens.shift();
  while(tokens.length>1&&isPersonaNameSuffix(tokens[tokens.length-1])) tokens.pop();
  const usable=tokens.length?tokens:rawTokens;
  return{
    full,
    tokens:usable,
    first:usable[0]||'',
    last:usable.length>1?usable[usable.length-1]:''
  };
}

function cleanGeneratedNamePart(raw,kind='generic'){
  let safe=String(raw||'')
    .replace(/^\s*(?:[-*]|\d+[.)-]?)\s*/,'')
    .replace(/[^A-Za-z0-9\s'.-]/g,' ')
    .replace(/\s+/g,' ')
    .trim();
  if(!safe) return'';
  const tokens=safe.split(' ').filter(Boolean);
  while(tokens.length&&isPersonaNamePrefix(tokens[0])) tokens.shift();
  while(tokens.length>1&&isPersonaNameSuffix(tokens[tokens.length-1])) tokens.pop();
  if(!tokens.length) return'';
  if(kind==='first'&&tokens.length>1) return formatPersonaNameForPrompt(tokens[0]);
  return formatPersonaNameForPrompt(tokens.join(' '));
}

function dedupeGeneratedNameParts(values,kind){
  const out=[];
  const seen=new Set();
  (Array.isArray(values)?values:[]).forEach(value=>{
    const cleaned=cleanGeneratedNamePart(value,kind);
    const key=normalizePersonaNameKey(cleaned);
    if(!key||seen.has(key)) return;
    seen.add(key);
    out.push(cleaned);
  });
  return out;
}

function filterGeneratedNamePartsAgainstPersonaUsage(kind,values,excludeUsed=true){
  return dedupeGeneratedNameParts(values,kind).filter(value=>!excludeUsed||getPersonaNameUsageCount(kind,value)===0);
}

function recordPersonaNameUsage(bucket,name){
  const key=normalizePersonaNameKey(name);
  if(!key) return;
  bucket[key]=(bucket[key]||0)+1;
}

function buildPersonaNameUsage(nodes){
  const usage=createEmptyPersonaNameUsage();
  (nodes||[]).forEach(node=>{
    if(!node||node.type!=='persona'||node.damaged) return;
    const parts=splitPersonaNameParts(node.displayName||node.name||'');
    if(!parts.full) return;
    recordPersonaNameUsage(usage.full,parts.full);
    recordPersonaNameUsage(usage.first,parts.first);
    recordPersonaNameUsage(usage.last,parts.last);
  });
  return usage;
}

function getPersonaNameUsageCount(kind,name){
  const key=normalizePersonaNameKey(name);
  if(!key) return 0;
  return parseInt(S.personaNameUsage?.[kind]?.[key],10)||0;
}

function getPersonaNameAvoidanceList(kind,limit=12,extras=[]){
  const out=[];
  const seen=new Set();
  const addName=raw=>{
    const key=normalizePersonaNameKey(raw);
    if(!key||seen.has(key)||out.length>=limit) return;
    seen.add(key);
    out.push(formatPersonaNameForPrompt(raw||key));
  };
  (Array.isArray(extras)?extras:[]).forEach(addName);
  Object.entries(S.personaNameUsage?.[kind]||{})
    .sort((a,b)=>(b[1]-a[1])||a[0].localeCompare(b[0],undefined,{sensitivity:'base'}))
    .forEach(([name])=>addName(name));
  return out;
}

function buildPersonaNameFallback(attrs){
  const age=normalizePersonaAge(attrs?.age);
  let fallbackBase='Alex';
  if(attrs?.gender==='Female'){
    fallbackBase=(age&&age>=60)?'Patricia':((age&&age>=40)?'Jennifer':'Olivia');
  }else if(attrs?.gender==='Male'){
    fallbackBase=(age&&age>=60)?'Robert':((age&&age>=40)?'Michael':'Ethan');
  }else{
    fallbackBase=(age&&age>=60)?'Morgan':((age&&age>=40)?'Taylor':'Riley');
  }
  const roleToken=String(attrs?.occupation||'Contributor').split(/[ /]/).map(x=>x.trim()).filter(Boolean)[0]||'Contributor';
  return`${fallbackBase} ${roleToken}`;
}

function choosePersonaNameFromPools(firstNames,surnames){
  const firstPool=shuffleArrayCopy(dedupeGeneratedNameParts(firstNames,'first')).slice(0,32);
  const lastPool=shuffleArrayCopy(dedupeGeneratedNameParts(surnames,'last')).slice(0,32);
  let best=null;
  for(const first of firstPool){
    for(const last of lastPool){
      const verdict=evaluatePersonaNameCandidate(`${first} ${last}`);
      if(verdict.accept) return verdict.name;
      if(!best||verdict.score<best.score) best=verdict;
    }
  }
  return best&&!best.hardReject?best.name:'';
}

function parseGeneratedNamePoolPayload(text){
  const jsonText=extractJsonObject(text);
  let parsed=null;
  try{parsed=jsonText?JSON.parse(jsonText):null;}catch(e){}
  return{
    firstNames:dedupeGeneratedNameParts(parsed?.firstNames,'first'),
    surnames:dedupeGeneratedNameParts(parsed?.surnames,'last')
  };
}


function evaluatePersonaNameCandidate(name){
  const parts=splitPersonaNameParts(name);
  const fullCount=getPersonaNameUsageCount('full',parts.full);
  const firstCount=getPersonaNameUsageCount('first',parts.first);
  const lastCount=getPersonaNameUsageCount('last',parts.last);
  if(!parts.full){
    return{name:'',fullCount,firstCount,lastCount,score:999,accept:false,hardReject:true};
  }
  if(parts.tokens.length<2){
    return{name:parts.full,fullCount,firstCount,lastCount,score:900,accept:false,hardReject:true};
  }
  if(fullCount>0){
    return{name:parts.full,fullCount,firstCount,lastCount,score:800+(fullCount*10),accept:false,hardReject:true};
  }
  if(firstCount>0&&lastCount>0){
    return{name:parts.full,fullCount,firstCount,lastCount,score:700+(firstCount*25)+(lastCount*25),accept:false,hardReject:true};
  }
  const score=(firstCount*50)+(lastCount*50);
  return{
    name:parts.full,
    fullCount,
    firstCount,
    lastCount,
    score,
    accept:score===0,
    hardReject:false
  };
}

async function makeUniqueDirName(parentDir,baseName){
  let i=1;
  let candidate=baseName;
  while(true){
    try{
      await parentDir.getDirectoryHandle(candidate,{create:false});
      i++;
      candidate=baseName+'_'+i;
    }catch(e){
      return candidate;
    }
  }
}

async function makeUniqueFileName(parentDir,baseName,ext='.json'){
  let i=1;
  let candidate=baseName+ext;
  while(true){
    try{
      await parentDir.getFileHandle(candidate,{create:false});
      i++;
      candidate=baseName+'_'+i+ext;
    }catch(e){
      return candidate;
    }
  }
}

function splitTreePath(path){
  return String(path||'').split('/').filter(Boolean);
}


async function copyFileHandleToDir(srcFileHandle,targetDir,targetName){
  const file=await srcFileHandle.getFile();
  const out=await targetDir.getFileHandle(targetName||srcFileHandle.name,{create:true});
  const wr=await out.createWritable();
  await wr.write(await file.arrayBuffer());
  await wr.close();
}

async function copyDirectoryRecursive(sourceDir,targetParentDir,targetName){
  const targetDir=await targetParentDir.getDirectoryHandle(targetName,{create:true});
  for await(const [name,handle] of sourceDir.entries()){
    if(handle.kind==='file'){
      await copyFileHandleToDir(handle,targetDir,name);
    }else if(handle.kind==='directory'){
      await copyDirectoryRecursive(handle,targetDir,name);
    }
  }
  return targetDir;
}

function remapTreePath(path,oldPrefix,newPrefix){
  const val=String(path||'');
  if(!oldPrefix||oldPrefix===newPrefix) return val;
  if(val===oldPrefix) return newPrefix;
  if(val.startsWith(oldPrefix+'/')) return newPrefix+val.slice(oldPrefix.length);
  return val;
}


function isSameOrDescendantPath(path,base){
  const p=String(path||'');
  const b=String(base||'');
  if(!b) return false;
  return p===b||p.startsWith(b+'/');
}

async function directoryExists(parentHandle,name){
  if(!parentHandle||!name) return false;
  try{
    await parentHandle.getDirectoryHandle(name,{create:false});
    return true;
  }catch(e){
    return false;
  }
}

async function fileExists(parentHandle,name){
  if(!parentHandle||!name) return false;
  try{
    await parentHandle.getFileHandle(name,{create:false});
    return true;
  }catch(e){
    return false;
  }
}

function clearDragHoverTarget(){
  if(S.dragHoverEl){
    S.dragHoverEl.classList.remove('drop-target-active');
    S.dragHoverEl=null;
  }
}

function setDragHoverTarget(el){
  if(S.dragHoverEl===el) return;
  clearDragHoverTarget();
  if(el){
    el.classList.add('drop-target-active');
    S.dragHoverEl=el;
  }
}

function clearTreeDragState(){
  clearDragHoverTarget();
  S.dragPayload=null;
  document.querySelectorAll('.c-row.drag-source').forEach(el=>el.classList.remove('drag-source'));
}

function readTreeDragPayload(event){
  if(S.dragPayload) return S.dragPayload;
  const dt=event?.dataTransfer;
  if(!dt) return null;
  const raw=dt.getData(TREE_DND_MIME)||dt.getData('text/plain');
  if(!raw) return null;
  try{
    const payload=JSON.parse(raw);
    if(!payload||!payload.tree||!payload.path||!payload.type) return null;
    return payload;
  }catch(e){
    return null;
  }
}

function startTreeDrag(event,tree,node,row){
  if(!event?.dataTransfer||!node?.path||!node?.type) return;
  const payload={tree,path:node.path,type:node.type};
  const raw=JSON.stringify(payload);
  S.dragPayload=payload;
  event.dataTransfer.effectAllowed='move';
  try{event.dataTransfer.setData(TREE_DND_MIME,raw);}catch(e){}
  try{event.dataTransfer.setData('text/plain',raw);}catch(e){}
  if(row) row.classList.add('drag-source');
  treeHideMenu(CONV_TREE_VIEW);
  treeHideMenu(PERSONA_TREE_VIEW);
}

function endTreeDrag(row){
  if(row) row.classList.remove('drag-source');
  clearTreeDragState();
}

function handleDropTargetDragLeave(event,targetEl){
  if(S.dragHoverEl!==targetEl) return;
  const next=event.relatedTarget;
  if(next&&targetEl.contains(next)) return;
  clearDragHoverTarget();
}

async function moveConversationTreeNode(verdict){
  const src=verdict?.src;
  const destPath=verdict?.destPath||'';
  if(!src?.path||!src?.name||!src?.parentHandle) return false;
  if((src.parentPath||'')===destPath){
    treeSelectPath(CONV_TREE_VIEW,src.path||'');
    renderConvList();
    return true;
  }
  const destHandle=verdict.destHandle||await getConvsDir(true);
  if(!destHandle) throw new Error('Conversations destination unavailable.');
  if(await directoryExists(destHandle,src.name)){
    await appAlert('An item with that name already exists in the destination');
    return false;
  }
  const sourceHandle=src.folderHandle||await src.parentHandle.getDirectoryHandle(src.name,{create:false});
  const copied=await copyDirectoryRecursive(sourceHandle,destHandle,src.name);
  await src.parentHandle.removeEntry(src.name,{recursive:true});
  const oldPath=src.path||'';
  const newPath=destPath?destPath+'/'+src.name:src.name;
  treeRemapPathState(CONV_TREE_VIEW,oldPath,newPath);
  treeRemapPathState(DOWNLOADS_TREE_VIEW,oldPath,newPath);
  treeLoadUIState(CONV_TREE_VIEW);
  if(destPath) S.convTreeExpanded[destPath]=true;
  treeSaveUIState(CONV_TREE_VIEW);
  if(S.conv?.sourcePath===newPath){
    S.conv.folderHandle=copied;
  }
  if(S.convDialogPath===newPath&&S.convDialogConv){
    S.convDialogConv.folderHandle=copied;
    S.convDialogConv.sourcePath=newPath;
    S.convDialogConv.id=newPath;
  }
  await scanConvFolders();
  await scanDownloadsTree();
  treeSelectPath(CONV_TREE_VIEW,newPath);
  renderAll();
  return true;
}

async function movePersonaTreeNode(verdict){
  const src=verdict?.src;
  const destPath=verdict?.destPath||'';
  if(!src?.path||!src?.name||!src?.parentHandle) return false;
  if((src.parentPath||'')===destPath){
    treeSelectPath(PERSONA_TREE_VIEW,src.path||'');
    renderPersonaList();
    return true;
  }
  const destHandle=verdict.destHandle||await getPersonasDir(true);
  if(!destHandle) throw new Error('Personas destination unavailable.');
  if(src.type==='category'){
    if(await directoryExists(destHandle,src.name)){
      await appAlert('An item with that name already exists in the destination');
      return false;
    }
    const sourceHandle=src.folderHandle||await src.parentHandle.getDirectoryHandle(src.name,{create:false});
    await copyDirectoryRecursive(sourceHandle,destHandle,src.name);
    await src.parentHandle.removeEntry(src.name,{recursive:true});
  }else if(src.type==='persona'){
    if(await fileExists(destHandle,src.name)){
      await appAlert('An item with that name already exists in the destination');
      return false;
    }
    const sourceFile=src.fileHandle||await src.parentHandle.getFileHandle(src.name,{create:false});
    await copyFileHandleToDir(sourceFile,destHandle,src.name);
    await src.parentHandle.removeEntry(src.name,{recursive:false});
  }else{
    return false;
  }
  const oldPath=src.path||'';
  const newPath=destPath?destPath+'/'+src.name:src.name;
  treeRemapPathState(PERSONA_TREE_VIEW,oldPath,newPath);
  treeLoadUIState(PERSONA_TREE_VIEW);
  if(destPath) S.personaTreeExpanded[destPath]=true;
  treeSaveUIState(PERSONA_TREE_VIEW);
  await scanPersonaFolders();
  treeSelectPath(PERSONA_TREE_VIEW,newPath);
  renderPersonaList();
  return true;
}

async function scanTreeDirectory(dirHandle,parentPath,index){
  const categories=[];
  const conversations=[];
  for await(const [name,handle] of dirHandle.entries()){
    if(handle.kind!=='directory') continue;
    const path=parentPath?parentPath+'/'+name:name;
    if(name.startsWith('!')){
      const displayName=(name.slice(1).replace(/_/g,' ')).trim()||name.slice(1);
      const node={
        type:'category',
        name,path,parentPath,parentHandle:dirHandle,folderHandle:handle,
        displayName,uuid:path,children:[]
      };
      const child=await scanTreeDirectory(handle,path,index);
      node.children=[...child.categories,...child.conversations];
      categories.push(node);
      index[path]=node;
    }else{
      const meta=await tryReadJsonFile(handle,CONV_SETTINGS_FILE);
      let hasAgentsDir=true;
      try{await handle.getDirectoryHandle(CONV_AGENTS_DIR,{create:false});}catch(e){hasAgentsDir=false;}
      const displayName=(meta?.name||name.replace(/_/g,' ')).trim()||name;
      const node={
        type:'conversation',
        name,path,parentPath,
        parentHandle:dirHandle,folderHandle:handle,
        displayName,created:meta?.created||0,
        id:meta?.uuid||path,uuid:meta?.uuid||path,damaged:!meta||!hasAgentsDir
      };
      conversations.push(node);
      index[path]=node;
    }
  }
  categories.sort(sortByDisplayName);
  conversations.sort(sortByDisplayName);
  return{categories,conversations};
}

function categoryHasLeafDescendant(node,leafType){
  if(!node||node.type!=='category') return false;
  return (node.children||[]).some(child=>{
    if(child.type===leafType) return true;
    if(child.type==='category') return categoryHasLeafDescendant(child,leafType);
    return false;
  });
}

async function scanConvFolders(){
  treeLoadUIState(CONV_TREE_VIEW);
  if(!S.fsRoot){
    S.convs=[];
    S.convTree=[];
    S.convTreeIndex={};
    S.convTreeSelectedPath='';
    treeSaveUIState(CONV_TREE_VIEW);
    renderConvList();
    return;
  }
  try{
    const convsDir=await getConvsDir(true);if(!convsDir){renderConvList();return;}
    const index={};
    const treeResult=await scanTreeDirectory(convsDir,'',index);
    const rootNodes=[...treeResult.categories,...treeResult.conversations];
    S.convTree=rootNodes;
    S.convTreeIndex=index;
    S.convs=flattenTreeLeaves(rootNodes,'conversation',[]);
    if(S.convTreeSelectedPath&&!index[S.convTreeSelectedPath]){
      S.convTreeSelectedPath='';
      treeSaveUIState(CONV_TREE_VIEW);
    }
    if(S.conv?.sourcePath&&index[S.conv.sourcePath]){
      const activeNode=index[S.conv.sourcePath];
      if(activeNode?.type==='conversation'){
        S.conv.folderHandle=activeNode.folderHandle;
      }
      treeSelectPath(CONV_TREE_VIEW,S.conv.sourcePath);
    }
    if(S.convDialogPath&&S.convDialogConv&&index[S.convDialogPath]){
      const dialogNode=index[S.convDialogPath];
      if(dialogNode?.type==='conversation'){
        S.convDialogConv.folderHandle=dialogNode.folderHandle;
        S.convDialogConv.sourcePath=dialogNode.path;
        S.convDialogConv.id=dialogNode.path;
      }
    }
    renderConvList();
    const lastPath=localStorage.getItem('cl_last_conv');
    if(!S.conv){
      const target=lastPath?S.convs.find(c=>c.path===lastPath):S.convs[0];
      if(target)await openConvFolder(target);
    }
  }catch(e){renderConvList();}
}
async function loadConvFromFolder(entry){
  const handle=entry.folderHandle;
  try{
    const loadWarnings=[];
    const noteLoadWarning=(code,message,extra={})=>{
      const warning={code,message,...extra};
      loadWarnings.push(warning);
      console.warn('loadConvFromFolder warning:',warning);
    };
    const meta=await tryReadJsonFile(handle,CONV_SETTINGS_FILE);
    if(!meta) return null;
    const restoredPlan=meta?.participantPlan
      ? normalizeParticipantPlan(
          meta.participantPlan,
          meta?.participantPlan?.topicObjective||meta.topicObjective||meta.objective||meta.description||'',
          meta?.participantPlan?.participantDescription||meta.participantDescription||''
        )
      : null;

    // Load agents only from agents/*.json.
    const agents=[];
    try{
      const agentsDir=await handle.getDirectoryHandle(CONV_AGENTS_DIR,{create:false});
      const agentFiles=[];
      for await(const [name,fh] of agentsDir.entries()){
        if(fh.kind==='file'&&name.endsWith('.json')) agentFiles.push({name,fh});
      }
      agentFiles.sort((a,b)=>a.name.localeCompare(b.name));
      for(let i=0;i<agentFiles.length;i++){
        const af=agentFiles[i];
        try{
          const f=await af.fh.getFile();
          const parsed=JSON.parse(await f.text());
          agents.push(fromPersistedAgent(parsed,i,af.name));
        }catch(e){}
      }
    }catch(e){return null;}
    sortAgentsBySlotIndex(agents);
    const agentColorById={};
    agents.forEach(agent=>{
      const col=COLORS.find(c=>c.id===agent.color)||COLORS[0];
      if(agent?.id) agentColorById[String(agent.id)]=col.hex;
    });
    let downloadsDirPromise=null;
    const getDownloadsDir=()=>{
      if(!downloadsDirPromise){
        downloadsDirPromise=handle.getDirectoryHandle(CONV_DOWNLOADS_DIR,{create:false}).catch(()=>null);
      }
      return downloadsDirPromise;
    };

    // Collect round files only from logs/.
    const roundFiles=[];
    try{
      const logsDir=await handle.getDirectoryHandle(CONV_LOGS_DIR,{create:false});
      for await(const [name,fh] of logsDir.entries()){
        if(fh.kind==='file'&&/^\d{4}\.json$/i.test(name)){
          roundFiles.push({
            name,
            handle:fh,
            snippet:parseDirectorSnippetFromLogFileName(name),
            logicalKey:getRoundLogLogicalKeyFromFileName(name)||name
          });
        }
      }
    }catch(e){}
    roundFiles.sort((a,b)=>a.name.localeCompare(b.name));
    const selectedRoundFiles=[];
    const groupedRoundFiles=new Map();
    roundFiles.forEach(fileEntry=>{
      const key=String(fileEntry.logicalKey||fileEntry.name||'');
      if(!groupedRoundFiles.has(key)) groupedRoundFiles.set(key,[]);
      groupedRoundFiles.get(key).push(fileEntry);
    });
    for(const group of groupedRoundFiles.values()){
      const validEntries=[];
      for(const fileEntry of group){
        let file=null;
        try{
          file=await fileEntry.handle.getFile();
        }catch(e){
          noteLoadWarning('log_read_failed','Could not read a round log file.',{file:fileEntry.name});
          continue;
        }
        const size=Math.max(0,Number(file?.size)||0);
        if(size===0){
          noteLoadWarning('zero_length_log','Skipped zero-length round log artifact.',{file:fileEntry.name});
          continue;
        }
        let round=null;
        try{
          round=JSON.parse(await file.text());
        }catch(e){
          noteLoadWarning('invalid_round_json','Skipped malformed round log JSON.',{file:fileEntry.name});
          continue;
        }
        validEntries.push({
          ...fileEntry,
          round,
          size,
          modified:Date.parse(String(fileEntry.handle?.meta?.modified||''))||0
        });
      }
      if(!validEntries.length) continue;
      validEntries.sort((a,b)=>{
        if(b.modified!==a.modified) return b.modified-a.modified;
        if(b.size!==a.size) return b.size-a.size;
        return b.name.localeCompare(a.name);
      });
      if(validEntries.length>1){
        noteLoadWarning('duplicate_round_logs','Multiple valid log files matched the same logical round; selected the newest candidate.',{
          files:validEntries.map(entry=>entry.name)
        });
      }
      selectedRoundFiles.push(validEntries[0]);
    }
    selectedRoundFiles.sort((a,b)=>a.name.localeCompare(b.name));
    // Reconstruct messages
    const messages=[];let context=0;let msgCount=0;
    for(const fileEntry of selectedRoundFiles){
      const {snippet,round}=fileEntry;
      msgCount=Math.max(msgCount,round.round||0);
      let roundDirectorId='';
      const roundMode=normalizeConversationMode(round.mode||'parallel');
      if(round.isSep){
        context++;
        const sep={id:'sep_'+round.ts,role:'director',isSep:true,ts:round.ts,ctx:context};
        messages.push(sep);
        agents.forEach(a=>a.msgs.push({isSep:true,ctx:context,ts:round.ts}));
        continue;
      }
      if(round.director){
        const fallbackSummary=buildDirectorSnippet(round.director.content||'',128);
        const summary=(snippet||fallbackSummary);
        const dm={id:round.director.id||('d_r'+round.round),role:'director',
          content:round.director.content,
          summary,
          ts:round.ts,ctx:context,
          targets:round.director.targets||[],
          files:(round.director.files||[]).map(f=>({name:f})),
          num:round.round,
          roundId:round.round,
          roundMode,
          roundOpen:true,
          source:normalizeDirectorType(round.director?.source||'human'),
          roundOrder:0,
          turnIndex:0};
        roundDirectorId=dm.id;
        messages.push(dm);
        agents.forEach(a=>{
          const targeted=!round.director.targets||round.director.targets.length===0||
            round.director.targets.includes(a.id)||
            round.director.targets.includes(a.name)||
            round.director.targets.includes(getAgentIdentityLabel(a,{agents}));
          if(targeted)a.msgs.push({...dm,role:'director'});
        });
      }
      const dirContent=round.director?.content||'';
      const dirSum=snippet||buildDirectorSnippet(dirContent,128);
      const pushAgentRoundMessage=async(resp,inReplyTo,roundOrder)=>{
        const respAgentId=String(resp?.agentId||'').trim();
        const respAgentName=String(resp?.agentName||resp?.speakerLabel||'').trim();
        let agent=null;
        if(respAgentId){
          agent=agents.find(a=>String(a.id||'')===respAgentId);
        }else if(respAgentName){
          agent=agents.find(a=>
            String(a.name||'')===respAgentName||
            String(getAgentIdentityLabel(a,{agents})||'')===respAgentName
          );
        }
        if(!agent){
          agent=makeGhostAgentFromLogResponse(resp,agents);
          agents.push(agent);
          const ghostCol=COLORS.find(c=>c.id===agent.color)||COLORS[0];
          if(agent.id) agentColorById[String(agent.id)]=ghostCol.hex;
        }
        const agentId=respAgentId||String(agent.id||'');
        const agentName=String(resp.speakerLabel||resp.agentName||getAgentIdentityLabel(agent,{agents})||agentId);
        const agentColor=agentColorById[agentId]||'';
        const downloadItems=parseDownloads(resp.content||'',agentName,agentColor);
        if(downloadItems.length){
          const downloadsDir=await getDownloadsDir();
          if(downloadsDir){
            try{
              await ensureDownloadPointersForItems(downloadsDir,downloadItems,{
                sourceLog:fileEntry.name,
                agentId,
                agentName,
                agentColor,
                round:round.round||0,
                responseTs:Number(resp.ts)||0
              });
            }catch(e){
              noteLoadWarning('download_pointer_reconcile_failed','Skipped download pointer reconciliation during load.',{file:fileEntry.name});
            }
          }
        }
        agent.msgs.push({
          id:resp.id||('a_r'+round.round+'_'+agentId+'_'+roundOrder),
          role:'agent',content:resp.content,ts:resp.ts,ctx:context,dirSum,
          inReplyTo:inReplyTo||roundDirectorId||round.director?.id||('d_r'+round.round),
          round:round.round||0,
          speakerLabel:agentName,
          truncated:!!resp.truncated,
          stopReason:resp.stopReason||'',
          failed:!!resp.failed,
          failureKind:String(resp.failureKind||''),
          retryable:!!resp.retryable,
          errorMessage:resp.errorMessage||'',
          warningMessage:resp.warningMessage||'',
          toolUse:Array.isArray(resp.toolUse)?resp.toolUse:[],
          downloadItems,
          attemptCount:Math.max(1,Number(resp.attemptCount)||1),
          retriedFromFailure:!!resp.retriedFromFailure,
          _retryRequest:resp._retryRequest?deepCloneJsonSafe(resp._retryRequest):undefined,
          roundOrder,
          turnIndex:roundOrder
        });
      };
      if(Array.isArray(round.turns)&&round.turns.length){
        let lastDirectorId=roundDirectorId;
        for(let idx=0;idx<round.turns.length;idx++){
          const turn=round.turns[idx]||{};
          const roundOrder=idx+1;
          if(turn.type==='director'){
            const dm={id:turn.id||('d_r'+round.round+'_t'+roundOrder),role:'director',
              content:String(turn.content||''),
              summary:buildDirectorSnippet(turn.content||'',128),
              ts:Number(turn.ts)||round.ts,ctx:context,
              targets:Array.isArray(turn.targets)?turn.targets:[],
              files:(turn.files||[]).map(f=>({name:f.name||f})),
              num:round.round,
              roundId:round.round,
              roundMode,
              roundOpen:false,
              source:normalizeDirectorType(turn.source||'human'),
              continue:!!turn.continue,
              roundOrder,
              turnIndex:roundOrder};
            lastDirectorId=dm.id;
            messages.push(dm);
            agents.forEach(a=>{
              const targeted=!dm.targets||dm.targets.length===0||
                dm.targets.includes(a.id)||
                dm.targets.includes(a.name)||
                dm.targets.includes(getAgentIdentityLabel(a,{agents}));
              if(targeted) a.msgs.push({...dm,role:'director'});
            });
            continue;
          }
          if(turn.type==='agent'){
            await pushAgentRoundMessage(turn,lastDirectorId,roundOrder);
          }
        }
      }else if(round.responses){
        for(let idx=0;idx<round.responses.length;idx++){
          await pushAgentRoundMessage(round.responses[idx],roundDirectorId,idx+1);
        }
      }
    }
    const effectiveMsgCount=Math.max(msgCount,roundFiles.length);
    const convData={...meta,id:entry.path||entry.id,uuid:meta.uuid||entry.id,folderHandle:handle,sourcePath:entry.path||entry.id,agents,messages,
      msgCount:effectiveMsgCount,context,
      editorFieldsLocked:!!meta.editorFieldsLocked,
      topicObjective:meta.topicObjective||meta.objective||meta.description||'',
      participantDescription:meta.participantDescription||'',
      rollingRounds:meta.rollingRounds||APP_SETTINGS.maxRounds||10,
      artifactCounters:normalizeArtifactCounters(meta.artifactCounters),
      settings:{
        ...(meta.settings||{}),
        allDefault:true,
        showFiles:true,
        autoScroll:true,
        webSearchBudget:normalizeWebSearchBudget(meta?.settings?.webSearchBudget),
        activeAgentIds:normalizeActiveAgentIds(meta?.settings?.activeAgentIds,agents),
        conversationMode:normalizeConversationMode(meta?.settings?.conversationMode),
        directorType:normalizeDirectorType(meta?.settings?.directorType),
        aiDirectorCountdown:normalizeAiDirectorCountdown(meta?.settings?.aiDirectorCountdown),
        paceDelay:normalizeConversationPaceDelay(meta?.settings?.paceDelay)
      }};
    if(restoredPlan){
      convData._participantPlan=restoredPlan;
      convData._participantPlanKey=buildParticipantPlanKey(restoredPlan.topicObjective,restoredPlan.participantDescription);
    }
    if(loadWarnings.length) convData._loadWarnings=loadWarnings;
    markConversationDownloadsReconciled(convData);
    try{
      await resolveConversationPersonaState(convData);
    }catch(e){
      noteLoadWarning('persona_state_resolve_failed','Persona state resolution failed during conversation load.',{conversation:convData.sourcePath||convData.id||''});
    }
    return convData;
  }catch(e){console.error('loadConvFromFolder:',e);return null;}
}

// ── CONVERSATIONS ─────────────────────────────────────────────────
async function createConversationFromPanel(){
  if(!S.workspaceReady){await appAlert('Choose a Conflab workspace first.');return;}
  const name='New Conversation';
  const target=await treeGetCreateTarget(CONV_TREE_VIEW,false);
  if(!target){await appAlert('Unable to access Conversations folder.');return;}
  const cols=2;
  const count=2;
  const created=Date.now();
  const folderBase=sanitizeTitleForFs(name,64);
  const folderName=await makeUniqueDirName(target.parentHandle,folderBase);
  const folderHandle=await target.parentHandle.getDirectoryHandle(folderName,{create:true});
  await folderHandle.getDirectoryHandle(CONV_AGENTS_DIR,{create:true});
  await folderHandle.getDirectoryHandle(CONV_LOGS_DIR,{create:true});
  const path=target.parentPath?target.parentPath+'/'+folderName:folderName;
  const agents=Array.from({length:count},(_,i)=>makeAgent(i));
  const conv={
    id:path,uuid:createUUID(),sourcePath:path,folderHandle,name,
    agentCols:cols,created,agents,messages:[],msgCount:0,context:0,
    editorFieldsLocked:false,
    topicObjective:'',participantDescription:'',rollingRounds:APP_SETTINGS.maxRounds||10,
    artifactCounters:createDefaultArtifactCounters(),
    settings:{
      allDefault:true,
      showFiles:true,
      autoScroll:true,
      webSearchBudget:DEFAULT_WEB_SEARCH_BUDGET,
      activeAgentIds:agents.map(agent=>agent.id),
      conversationMode:DEFAULT_CONVERSATION_MODE,
      directorType:DEFAULT_DIRECTOR_TYPE,
      aiDirectorCountdown:DEFAULT_AI_DIRECTOR_COUNTDOWN,
      paceDelay:DEFAULT_CONVERSATION_PACE_DELAY
    }
  };
  assignAgentColors(conv);
  await writeMetaFile(conv);
  treeLoadUIState(CONV_TREE_VIEW);
  if(target.parentPath) S.convTreeExpanded[target.parentPath]=true;
  await scanConvFolders();
  const entry=S.convs.find(c=>c.path===path);
  const loaded=entry?await loadConvFromFolder(entry):conv;
  S.convDialogConv=loaded||conv;
  S.convDialogPath=path;
  S.convDialogIsNew=true;
  openConversationEditView();
}

async function handleDamagedConversationEntry(entry){
  if(!entry?.damaged) return false;
  const remove=await appConfirm('This conversation appears damaged. Delete it?',{title:'DAMAGED CONVERSATION',okLabel:'Delete'});
  if(remove&&entry.parentHandle){
    try{
      await entry.parentHandle.removeEntry(entry.name,{recursive:true});
    }catch(e){
      await appAlert('Could not delete damaged conversation folder.');
    }
    treeSelectPath(CONV_TREE_VIEW,entry.parentPath||'');
    await scanConvFolders();
    renderAll();
    return true;
  }
  treeSelectPath(CONV_TREE_VIEW,entry.path||'');
  renderConvList();
  return true;
}

async function openConvFolder(entry){
  if(!entry) return;
  if(await handleDamagedConversationEntry(entry)) return;
  resetConversationRuntimeState();
  const conv=await loadConvFromFolder(entry);
  if(!conv)return;
  await persistConversationEditorLockIfNeeded(conv);
  clearPersonaSegmentCycle(conv);
  S.conv=conv;S.attachments=[];
  prepareDirectorComposerForConversationEntry(S.conv);
  assignAgentColors(S.conv);
  clearDownloads(); // reset downloads list for this conversation
  const path=entry.path||conv.sourcePath||conv.id||'';
  if(path){
    S.conv.id=path;
    S.conv.sourcePath=path;
    localStorage.setItem('cl_last_conv',path);
    treeSelectPath(CONV_TREE_VIEW,path);
  }
  void warmParticipantPlan(S.conv,{persist:true});
  drawerClose();renderAll();
}

async function openConversationEditor(entry){
  if(!entry) return;
  if(await handleDamagedConversationEntry(entry)) return;
  const conv=await loadConvFromFolder(entry);
  if(!conv) return;
  await persistConversationEditorLockIfNeeded(conv);
  S.convDialogIsNew=false;
  S.convDialogConv=conv;
  S.convDialogPath=entry.path||conv.sourcePath||conv.id||'';
  openConversationEditView();
}

function getAgentColorPool(){
  const dirColor=APP_SETTINGS.directorColor||'teal';
  const hasDirectorColor=DIRECTOR_COLORS.some(c=>c.id===dirColor);
  const reserved=hasDirectorColor?dirColor:'teal';
  const pool=DIRECTOR_COLORS.filter(c=>c.id!==reserved);
  return pool.length?pool:DIRECTOR_COLORS;
}
function assignAgentColors(conv){
  if(!conv?.agents?.length) return;
  const pool=getAgentColorPool();
  const liveAgents=getLiveConversationAgents(conv);
  liveAgents.forEach((a,i)=>{a.color=pool[i%pool.length].id;});
}
function makeAgent(i){
  const slotIndex=Math.max(0,Math.min(8,normalizeAgentSlotIndex(i)>=0?normalizeAgentSlotIndex(i):0));
  const d=DEFS[slotIndex]||{name:'Agent '+(slotIndex+1),color:COLORS[slotIndex%COLORS.length].id,persona:''};
  return{
    id:'a'+Date.now()+slotIndex,
    name:d.name||('Agent '+(slotIndex+1)),
    personaUuid:'',
    slotIndex,
    model:'',
    voiceName:'',
    voiceActive:false,
    voiceRate:1,
    personaMissing:false,
    personaResolvedData:null,
    color:d.color||COLORS[slotIndex%COLORS.length].id,
    msgs:[],
    expanded:false,
    settings:{activeByDefault:true,showSys:false},
    isGhost:false
  };
}

// ── RENDER ────────────────────────────────────────────────────────
function renderAll(){renderConvList();renderWorkspace();}

function renderConvList(){
  const el=document.getElementById('conv-list');el.innerHTML='';
  treeLoadUIState(CONV_TREE_VIEW);
  treeUpdateRootTargetState(CONV_TREE_VIEW);
  const hasNodes=Array.isArray(S.convTree)&&S.convTree.length>0;
  const pendingParentPath=S[CONV_TREE_VIEW.createParentPathKey];
  if(!hasNodes&&!treeHasInlineCreate(CONV_TREE_VIEW)){
    el.innerHTML='<div style="padding:14px;font-size:11px;color:var(--text-dim);text-align:center">No conversations yet.<br>Click + Conversation to start.</div>';
    return;
  }

  const renderNode=(node,depth)=>{
    const row=document.createElement('div');
    const selected=S.convTreeSelectedPath===node.path;
    const basePad=8+(depth*14);
    row.style.paddingLeft=basePad+'px';

    if(node.type==='category'){
      const hasChildren=((node.children||[]).length>0)||(pendingParentPath===node.path);
      const expanded=(pendingParentPath===node.path)||(hasChildren&&!!S.convTreeExpanded[node.path]);
      const row=treeCreateCategoryRow(CONV_TREE_VIEW,node,depth,selected,expanded,hasChildren);
      el.appendChild(row);
      if(expanded){
        renderLevel(node.children||[],depth+1,node.path);
      }
      return;
    }

    row.className='c-row c-conv'+(selected?' sel':'');
    row.style.paddingLeft=Math.max(0,basePad-3)+'px';
    row.innerHTML=`
      <span class="c-caret"></span>
      <span class="c-icon">💬</span>
      <span class="c-label">${esc(node.displayName||node.name)}</span>
      ${node.damaged?'<span class="c-warn">damaged</span>':''}`;
    row.draggable=true;
    row.ondragstart=e=>startTreeDrag(e,'conv',node,row);
    row.ondragend=()=>endTreeDrag(row);
    row.onclick=async()=>{
      treeHideMenu(CONV_TREE_VIEW);
      treeSelectPath(CONV_TREE_VIEW,node.path||'');
      renderConvList();
      await openConversationEditor(node);
    };
    row.oncontextmenu=async(e)=>{
      e.preventDefault();
      treeHideMenu(CONV_TREE_VIEW);
      treeSelectPath(CONV_TREE_VIEW,node.path||'');
      renderConvList();
      await openConversationEditor(node);
    };
    el.appendChild(row);
  };

  const renderLevel=(nodes,depth,parentPath)=>{
    let insertedPending=false;
    const maybeInsertPending=beforeLeaf=>{
      if(insertedPending||pendingParentPath!==parentPath) return;
      if(beforeLeaf||!(nodes||[]).some(node=>node.type!=='category')){
        el.appendChild(treeCreatePendingCategoryRow(CONV_TREE_VIEW,depth));
        insertedPending=true;
      }
    };
    (nodes||[]).forEach(node=>{
      if(node.type!=='category') maybeInsertPending(true);
      renderNode(node,depth);
    });
    maybeInsertPending(false);
  };

  renderLevel(S.convTree,0,'');
}

function renderWorkspace(){
  const c=S.conv,has=!!c;
  const convKey=getDirectorAssistConvKey(c);
  if(S.directorAssistConvKey!==convKey){
    resetConversationRuntimeState();
    resetDirectorAssistState();
    S.directorAssistConvKey=convKey;
    maybeSeedDirectorDraftForConversation(c);
  }
  const historyPanel=document.getElementById('history-panel');
  const histResize=document.getElementById('hist-resize');
  const directorPanel=document.getElementById('director-panel');
  const dirResize=document.getElementById('dir-resize');
  if(historyPanel) historyPanel.style.display=has?'flex':'none';
  if(histResize) histResize.style.display=has?'':'none';
  if(directorPanel) directorPanel.style.display=has?'':'none';
  if(dirResize) dirResize.style.display=has?'':'none';
  const convBadge=document.getElementById('conv-badge');
  const convBadgeText=document.getElementById('conv-badge-text');
  if(convBadge){
    if(convBadgeText) convBadgeText.textContent=has?c.name:'';
    convBadge.style.display=has?'':'none';
  }
  const topicLabel=document.getElementById('conv-topic-label');
  if(topicLabel) topicLabel.style.display=has?'':'none';
  const topicWrap=document.getElementById('conv-topic-wrap');
  if(topicWrap) topicWrap.style.display=has?'':'none';
  const attachBtn=document.getElementById('btn-attach');
  if(attachBtn){
    attachBtn.disabled=false;
    attachBtn.title='Attach files';
  }
  const micBtn=document.getElementById('mic-btn');
  if(micBtn){
    if(!has&&S.micOn) stopMic();
    micBtn.disabled=false;
    micBtn.title='Dictate at cursor';
  }
  const addBtn=document.getElementById('btn-add');
  if(addBtn){
    const atCap=!!c&&getLiveConversationAgentCount(c)>=9;
    addBtn.disabled=has?atCap:false;
    addBtn.title=atCap?'Maximum of 9 agents per conversation.':'';
  }
  const colSel=document.getElementById('col-sel');
  if(colSel){
    colSel.disabled=false;
    if(has) colSel.value=c.agentCols;
  }
  const dlFullBtn=document.getElementById('btn-dl-full');
  if(dlFullBtn){
    refreshFullHistoryDownloadButton();
  }
  syncDirectorActionHeights();
  if(!has){
    document.getElementById('agent-grid').innerHTML=getEmptyCoverHtml();
    document.getElementById('history-list').innerHTML='';
    document.getElementById('dir-thread').innerHTML='';
    syncRoundFailureBanner();
    syncDirectorModeUi();
    syncDirectorWebBudgetUi();
    syncDirectorRoundsUi();
    syncDirectorAiCountdownUi();
    syncDirectorPaceUi();
    syncDirectorAiStatusUi();
    syncDirectorTurnTimerUi();
    syncVersionLabels();
    syncLogoImages();
    hydrateOverviewPanel();
    bindOverviewBackgroundSettingsShortcut();
    syncDirectorComposerUi();
    return;
  }
  renderHistory();renderDirThread();renderAgentGrid();
  syncRoundFailureBanner();
  syncDirectorModeUi();
  syncDirectorWebBudgetUi();
  syncDirectorRoundsUi();
  syncDirectorAiCountdownUi();
  syncDirectorPaceUi();
  syncDirectorAiStatusUi();
  syncDirectorTurnTimerUi();
  syncDirectorComposerUi();
}

function refreshDirectorExportButtons(){
  const c=S.conv;
  const summaryBtn=document.getElementById('btn-summary');
  const dlFullBtn=document.getElementById('btn-dl-full');
  const imageBtn=document.getElementById('btn-image');
  const hasConversation=!!c;
  const hasDirectorMsgs=!!c&&c.messages.some(m=>!m.isSep&&m.role==='director');
  const hasCompletedRound=getCompletedRoundCount(c)>=1;
  if(summaryBtn){
    summaryBtn.disabled=!!S.directorSummaryBusy||!hasConversation||!hasCompletedRound;
    summaryBtn.style.opacity=(S.directorSummaryBusy||!hasConversation||!hasCompletedRound)?'0.35':'1';
    summaryBtn.textContent=S.directorSummaryBusy?'Generating...':'Summary ⤓';
    summaryBtn.classList.toggle('bs-generating',!!S.directorSummaryBusy);
    summaryBtn.title=S.directorSummaryBusy
      ?'Generating AI summary in the background.'
      :'Save AI-generated conversation summary to the Results drawer';
  }
  if(dlFullBtn){
    dlFullBtn.disabled=!hasConversation||!hasDirectorMsgs;
    dlFullBtn.style.opacity=(!hasConversation||!hasDirectorMsgs)?'0.35':'1';
    dlFullBtn.title='Save conversation log to the Results drawer';
  }
  if(imageBtn){
    imageBtn.disabled=!hasConversation;
    imageBtn.style.opacity=hasConversation?'1':'0.35';
    imageBtn.title=hasConversation
      ?'Open image creation dialog'
      :'Open a conversation to create images';
  }
}

function refreshFullHistoryDownloadButton(){
  refreshDirectorExportButtons();
}

function syncDirectorActionHeights(){
  const sendBtn=document.getElementById('btn-send');
  if(!sendBtn) return;
  const h=Math.round(sendBtn.getBoundingClientRect().height);
  if(!h) return;
  ['btn-add','col-sel','btn-summary','btn-dl-full','btn-image','btn-assist','btn-assist-prev','btn-assist-next'].forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.style.height=h+'px';
  });
}

function isSameConversation(a,b){
  if(!a||!b) return false;
  if(a.sourcePath&&b.sourcePath&&a.sourcePath===b.sourcePath) return true;
  return !!(a.uuid&&b.uuid&&a.uuid===b.uuid);
}
function getConversationEditorLocked(conv=S.convDialogConv||S.conv){
  if(!conv) return false;
  return !!conv.editorFieldsLocked||Number(conv.msgCount||0)>0;
}
async function persistConversationEditorLockIfNeeded(conv){
  if(!conv||conv.editorFieldsLocked||Number(conv.msgCount||0)<=0) return false;
  conv.editorFieldsLocked=true;
  if(S.convDialogConv&&isSameConversation(S.convDialogConv,conv)){
    S.convDialogConv.editorFieldsLocked=true;
    S.convDialogConv.msgCount=Math.max(Number(S.convDialogConv.msgCount||0),Number(conv.msgCount||0));
    if(document.getElementById('conv-edit-view')?.style.display!=='none'){
      setConvDialogFields(S.convDialogConv);
      applyConversationEditorLockState(S.convDialogConv);
      S.convDialogInitial=getConvDialogFormState();
      updateConvDialogActionState();
    }
  }
  await writeMetaFile(conv);
  return true;
}
function syncDirectorWebBudgetUi(){
  const wrap=document.getElementById('dir-web-budget-wrap');
  const slider=document.getElementById('dir-web-budget-slider');
  const valEl=document.getElementById('dir-web-budget-val');
  const hasConv=!!S.conv;
  const value=getConversationWebSearchBudget(S.conv);
  if(wrap) wrap.classList.toggle('is-disabled',!hasConv);
  if(slider){
    slider.disabled=!hasConv;
    slider.value=String(value);
    slider.title='Max combined web actions per round for each agent in this conversation (searches + URL reads).';
  }
  if(valEl){
    valEl.textContent=value+'x';
    valEl.title='Max combined web actions per round for each agent in this conversation (searches + URL reads).';
  }
}

function setConversationWebSearchBudget(nextValue){
  if(!S.conv) return;
  const budget=normalizeWebSearchBudget(nextValue);
  S.conv.settings={...(S.conv.settings||{}),webSearchBudget:budget};
  syncDirectorWebBudgetUi();
  updateConvDialogActionState();
  writeMetaFile();
}

function syncDirectorWebBudgetFromSlider(){
  const slider=document.getElementById('dir-web-budget-slider');
  if(!slider) return;
  const next=normalizeWebSearchBudget(slider.value);
  slider.value=String(next);
  setConversationWebSearchBudget(next);
}
function syncDirectorRoundsUi(){
  const wrap=document.getElementById('dir-rounds-wrap');
  const slider=document.getElementById('dir-rounds-slider');
  const valEl=document.getElementById('dir-rounds-val');
  const hasConv=!!S.conv;
  const value=getConversationRollingRounds(S.conv);
  if(wrap) wrap.classList.toggle('is-disabled',!hasConv);
  if(slider){
    slider.disabled=!hasConv;
    slider.value=String(value);
    slider.title='Rolling rounds of history per agent for context. Smaller is faster.';
  }
  if(valEl){
    valEl.textContent=String(value);
    valEl.title='Rolling rounds of history per agent for context. Smaller is faster.';
  }
}
function setConversationRollingRounds(nextValue){
  if(!S.conv) return;
  const rounds=normalizeRollingRounds(nextValue);
  S.conv.rollingRounds=rounds;
  syncDirectorRoundsUi();
  updateConvDialogActionState();
  writeMetaFile();
}
function syncDirectorRoundsFromSlider(){
  const slider=document.getElementById('dir-rounds-slider');
  if(!slider) return;
  const next=normalizeRollingRounds(slider.value);
  slider.value=String(next);
  setConversationRollingRounds(next);
}
function syncConversationSettingsMirror(conv=S.conv){
  if(!conv||!S.convDialogConv||!isSameConversation(S.convDialogConv,conv)) return;
  S.convDialogConv.settings={...(S.convDialogConv.settings||{}),...(conv.settings||{})};
}
function syncDirectorModeUi(){
  const hasConv=!!S.conv;
  const mode=hasConv?getConversationMode(S.conv):DEFAULT_CONVERSATION_MODE;
  const directorType=hasConv?getConversationDirectorType(S.conv):DEFAULT_DIRECTOR_TYPE;
  const aiAllowed=hasConv&&isAiDirectorAllowed(S.conv);
  const modeWrap=document.getElementById('dir-mode-toolbar-group');
  const directorWrap=document.getElementById('dir-director-toolbar-group');
  const modeInputs=document.querySelectorAll('input[name="dir-toolbar-mode"]');
  const directorInputs=document.querySelectorAll('input[name="dir-toolbar-director"]');
  if(modeWrap) modeWrap.classList.toggle('is-disabled',!hasConv);
  if(directorWrap) directorWrap.classList.toggle('is-disabled',!hasConv);
  modeInputs.forEach(input=>{
    input.checked=input.value===mode;
    input.disabled=!hasConv;
  });
  directorInputs.forEach(input=>{
    const isAi=input.value==='ai';
    input.checked=input.value===directorType;
    input.disabled=!hasConv||(isAi&&!aiAllowed);
  });
}
function syncDirectorAiStatusUi(){
  const el=document.getElementById('dir-ai-state');
  if(!el) return;
  if(!S.aiDirectorStatus){
    el.style.display='none';
    el.textContent='';
    el.classList.remove('is-busy');
    return;
  }
  el.style.display='';
  el.textContent=S.aiDirectorStatus;
  el.classList.toggle('is-busy',/^AI\s/i.test(String(S.aiDirectorStatus||'')));
}
function isDirectorTurnTimerVisible(conv=S.conv){
  return !!conv&&isAiDirectorMode(conv);
}
function getDirectorTurnElapsedMs(now=Date.now()){
  const base=Math.max(0,Number(S.directorTurnTimerElapsedMs)||0);
  if(!S.directorTurnTimerActive||!S.directorTurnTimerStartedAt) return base;
  return Math.max(0,base+(now-S.directorTurnTimerStartedAt));
}
function formatDirectorTurnElapsed(ms){
  const totalSeconds=Math.max(0,Math.floor(Number(ms||0)/1000));
  const minutes=Math.floor(totalSeconds/60);
  const seconds=totalSeconds%60;
  return `${minutes}:${String(seconds).padStart(2,'0')}`;
}
let directorTurnAudioCtx=null;
function getDirectorTurnAudioContext(){
  const Ctx=window.AudioContext||window.webkitAudioContext;
  if(!Ctx) return null;
  if(!directorTurnAudioCtx) directorTurnAudioCtx=new Ctx();
  if(directorTurnAudioCtx.state==='suspended'){
    directorTurnAudioCtx.resume().catch(()=>{});
  }
  return directorTurnAudioCtx;
}
function playDirectorTurnTone(freq,durationMs,{type='sine',gain=0.018,delayMs=0}={}){
  const ctx=getDirectorTurnAudioContext();
  if(!ctx) return;
  const osc=ctx.createOscillator();
  const amp=ctx.createGain();
  const startAt=ctx.currentTime+Math.max(0,delayMs)/1000;
  const endAt=startAt+Math.max(0.04,Number(durationMs||0)/1000);
  osc.type=type;
  osc.frequency.setValueAtTime(freq,startAt);
  amp.gain.setValueAtTime(0.0001,startAt);
  amp.gain.exponentialRampToValueAtTime(Math.max(0.0001,gain),startAt+0.01);
  amp.gain.exponentialRampToValueAtTime(0.0001,endAt);
  osc.connect(amp);
  amp.connect(ctx.destination);
  osc.start(startAt);
  osc.stop(endAt+0.02);
}
function playDirectorTurnTick(){
  playDirectorTurnTone(1320,110,{type:'triangle',gain:0.026});
  playDirectorTurnTone(980,85,{type:'triangle',gain:0.018,delayMs:18});
}
function playDirectorTurnChime(){
  playDirectorTurnTone(1174,90,{type:'sine',gain:0.02});
  playDirectorTurnTone(1568,110,{type:'sine',gain:0.014,delayMs:38});
}
function syncDirectorTurnTimerUi(){
  const el=document.getElementById('dir-turn-timer');
  if(!el) return;
  const visible=isDirectorTurnTimerVisible(S.conv);
  if(!visible){
    el.style.display='none';
    return;
  }
  el.style.display='';
  const phase=String(S.directorTurnTimerPhase||'idle');
  const elapsedMs=getDirectorTurnElapsedMs();
  el.textContent=formatDirectorTurnElapsed(elapsedMs);
  el.classList.toggle('is-dim',!S.directorTurnTimerActive);
  el.classList.toggle('is-countdown',phase==='countdown');
}
function updateDirectorTurnTimer(){
  if(!S.directorTurnTimerActive){
    syncDirectorTurnTimerUi();
    return;
  }
  if(S.directorTurnTimerPhase==='countdown'){
    const countdownDuration=Math.max(1,getConversationAiDirectorCountdown(S.conv));
    const countdownElapsedMs=Math.max(0,Date.now()-(Number(S.directorTurnCountdownStartedAt)||Date.now()));
    const desiredTickCount=Math.min(countdownDuration,Math.floor(countdownElapsedMs/1000)+1);
    if(desiredTickCount>S.directorTurnTimerLastTickSecond){
      for(let sec=S.directorTurnTimerLastTickSecond+1;sec<=desiredTickCount;sec++){
        if(sec<=0||sec>countdownDuration) continue;
        playDirectorTurnTick();
      }
      S.directorTurnTimerLastTickSecond=desiredTickCount;
    }
  }
  syncDirectorTurnTimerUi();
}
function ensureDirectorTurnTimerInterval(){
  if(S.directorTurnTimerInterval) return;
  S.directorTurnTimerInterval=setInterval(updateDirectorTurnTimer,250);
}
function clearDirectorTurnTimerInterval(){
  if(!S.directorTurnTimerInterval) return;
  clearInterval(S.directorTurnTimerInterval);
  S.directorTurnTimerInterval=null;
}
function startDirectorTurnTimer(){
  S.directorTurnTimerStartedAt=Date.now();
  S.directorTurnTimerElapsedMs=0;
  S.directorTurnTimerActive=true;
  S.directorTurnTimerPhase='generating';
  S.directorTurnCountdownStartedAt=0;
  S.directorTurnTimerLastTickSecond=-1;
  ensureDirectorTurnTimerInterval();
  syncDirectorTurnTimerUi();
}
function freezeDirectorTurnTimer(){
  if(S.directorTurnTimerActive){
  S.directorTurnTimerElapsedMs=getDirectorTurnElapsedMs();
  }
  S.directorTurnTimerStartedAt=0;
  S.directorTurnTimerActive=false;
  S.directorTurnTimerPhase='idle';
  S.directorTurnCountdownStartedAt=0;
  S.directorTurnTimerLastTickSecond=-1;
  clearDirectorTurnTimerInterval();
  syncDirectorTurnTimerUi();
}
function setDirectorTurnTimerPhase(nextPhase='idle'){
  S.directorTurnTimerPhase=String(nextPhase||'idle');
  if(nextPhase==='countdown'){
    S.directorTurnCountdownStartedAt=Date.now();
    S.directorTurnTimerLastTickSecond=0;
  }else{
    S.directorTurnCountdownStartedAt=0;
    S.directorTurnTimerLastTickSecond=-1;
  }
  updateDirectorTurnTimer();
}
function syncDirectorAiCountdownUi(){
  const wrap=document.getElementById('dir-ai-countdown-toolbar-wrap');
  const slider=document.getElementById('dir-ai-countdown-slider');
  const valEl=document.getElementById('dir-ai-countdown-val');
  const hasConv=!!S.conv;
  const enabled=hasConv&&isAiDirectorMode(S.conv);
  const value=getConversationAiDirectorCountdown(S.conv);
  if(wrap) wrap.classList.toggle('is-active',enabled);
  if(slider){
    slider.disabled=!enabled;
    slider.value=String(value);
    slider.title='Seconds before AI Director auto-submits its suggested prompt.';
  }
  if(valEl){
    valEl.textContent=value+'s';
    valEl.title='Seconds before AI Director auto-submits its suggested prompt.';
  }
}
function setConversationAiDirectorCountdown(nextValue){
  if(!S.conv) return;
  const value=normalizeAiDirectorCountdown(nextValue);
  S.conv.settings={...(S.conv.settings||{}),aiDirectorCountdown:value};
  syncConversationSettingsMirror(S.conv);
  syncDirectorAiCountdownUi();
  updateConvDialogActionState();
  writeMetaFile();
}
function syncDirectorAiCountdownFromSlider(){
  const slider=document.getElementById('dir-ai-countdown-slider');
  if(!slider) return;
  const next=normalizeAiDirectorCountdown(slider.value);
  slider.value=String(next);
  setConversationAiDirectorCountdown(next);
}
function syncDirectorPaceUi(){
  const wrap=document.getElementById('dir-pace-wrap');
  const slider=document.getElementById('dir-pace-slider');
  const valEl=document.getElementById('dir-pace-val');
  const hasConv=!!S.conv;
  const enabled=hasConv&&isFreeFormMode(S.conv);
  const value=getConversationPaceDelay(S.conv);
  if(wrap) wrap.classList.toggle('is-active',enabled);
  if(slider){
    slider.disabled=!enabled;
    slider.value=String(value);
    slider.title='Seconds to wait before dispatching the next free-form agent turn.';
  }
  if(valEl){
    valEl.textContent=value+'s';
    valEl.title='Seconds to wait before dispatching the next free-form agent turn.';
  }
}
function setConversationPaceDelay(nextValue){
  if(!S.conv) return;
  const value=normalizeConversationPaceDelay(nextValue);
  S.conv.settings={...(S.conv.settings||{}),paceDelay:value};
  syncConversationSettingsMirror(S.conv);
  syncDirectorPaceUi();
  updateConvDialogActionState();
  writeMetaFile();
}
function syncDirectorPaceFromSlider(){
  const slider=document.getElementById('dir-pace-slider');
  if(!slider) return;
  const next=normalizeConversationPaceDelay(slider.value);
  slider.value=String(next);
  setConversationPaceDelay(next);
}
function setConversationModeFromToolbar(nextValue){
  const conv=S.conv;
  if(!conv) return;
  const nextMode=normalizeConversationMode(nextValue);
  const prevMode=getConversationMode(conv);
  if(prevMode===nextMode){
    syncDirectorModeUi();
    return;
  }
  const activeRound=getActiveRoundForConversation(conv);
  conv.settings={...(conv.settings||{}),conversationMode:nextMode};
  syncConversationSettingsMirror(conv);
  if(!activeRound) resetConversationRuntimeState();
  syncDirectorModeUi();
  syncDirectorPaceUi();
  syncDirectorAiCountdownUi();
  syncDirectorComposerUi();
  writeMetaFile(conv);
}
function setConversationDirectorTypeFromToolbar(nextValue){
  const conv=S.conv;
  if(!conv) return;
  let nextDirectorType=normalizeDirectorType(nextValue);
  if(nextDirectorType==='ai'&&!isAiDirectorAllowed(conv)) nextDirectorType='human';
  const prevDirectorType=getConversationDirectorType(conv);
  if(prevDirectorType===nextDirectorType){
    syncDirectorModeUi();
    return;
  }
  const activeRound=getActiveRoundForConversation(conv);
  conv.settings={...(conv.settings||{}),directorType:nextDirectorType};
  syncConversationSettingsMirror(conv);
  applyDirectorTypeRuntimeChange(conv,prevDirectorType,nextDirectorType,{activeRound});
  syncDirectorModeUi();
  syncDirectorAiCountdownUi();
  syncDirectorComposerUi();
  writeMetaFile(conv);
}

// LOG MODE TOGGLE
function toggleLogMode(){
  S.logMode = S.logMode==='summary'?'full':'summary';
  updateHistoryPanelTitle(S.conv);
  renderHistory();
}

function createEmptyHistorySearchState(){
  return{query:'',mode:'',results:[],index:-1,busy:false};
}

function resetHistorySearchState(){
  S.historySearch=createEmptyHistorySearchState();
  syncHistorySearchUi();
}

function getHistorySearchState(){
  if(!S.historySearch) S.historySearch=createEmptyHistorySearchState();
  return S.historySearch;
}

function getHistorySearchInputValue(){
  return String(document.getElementById('history-search-input')?.value||'').trim();
}

function onHistorySearchInputChange(){
  const state=getHistorySearchState();
  if(!state.query||getHistorySearchInputValue()===state.query) return;
  state.query='';
  state.mode='';
  state.results=[];
  state.index=-1;
  syncHistorySearchUi();
  if(S.logMode==='full') renderHistory();
}

function onHistorySearchInputKey(event){
  if(event.key==='Enter'){
    event.preventDefault();
    runHistorySearch(event.shiftKey?'smart':'exact');
  }else if(event.key==='Escape'){
    resetHistorySearchState();
    renderHistory();
  }
}

function flashHistorySearchInput(kind){
  const input=document.getElementById('history-search-input');
  if(!input) return;
  input.classList.remove('flash-ok','flash-fail','search-busy');
  void input.offsetWidth;
  input.classList.add(kind==='fail'?'flash-fail':'flash-ok');
}

function syncHistorySearchBusyFeedback(){
  const state=getHistorySearchState();
  const input=document.getElementById('history-search-input');
  if(!input) return;
  input.classList.toggle('search-busy',!!state.busy&&state.mode==='smart');
}

function syncHistorySearchUi(){
  const state=getHistorySearchState();
  const hasCurrent=state.index>=0&&state.index<state.results.length;
  const prevBtn=document.getElementById('history-prev-search-btn');
  const nextBtn=document.getElementById('history-next-search-btn');
  const smartBtn=document.getElementById('history-smart-search-btn');
  const exactBtn=document.getElementById('history-exact-search-btn');
  if(prevBtn){
    const canPrev=hasCurrent&&state.index>0;
    prevBtn.disabled=!canPrev||state.busy;
    prevBtn.classList.toggle('on',canPrev);
  }
  if(nextBtn){
    const canNext=hasCurrent&&state.index<state.results.length-1;
    nextBtn.disabled=!canNext||state.busy;
    nextBtn.classList.toggle('on',canNext);
  }
  if(smartBtn){
    smartBtn.disabled=state.busy;
    smartBtn.classList.toggle('on',state.mode==='smart'&&hasCurrent);
  }
  if(exactBtn){
    exactBtn.disabled=state.busy;
    exactBtn.classList.toggle('on',state.mode==='exact'&&hasCurrent);
  }
  syncHistorySearchBusyFeedback();
}

function buildHistorySearchEntries(conv=S.conv){
  const entries=[];
  getFullHistoryEntries(conv).forEach((entry,order)=>{
    if(entry.type==='director'){
      const msg=entry.msg;
      const roundLabel=formatRoundLabel(msg?.num||msg?.roundId);
      const body=msg.continue?'Continue':String(msg.content||'');
      const meta=`Director ${roundLabel} ${fmtT(msg.ts)}`;
      entries.push({
        id:String(msg.id||''),
        kind:'director',
        order,
        body,
        searchText:[meta,body,(msg.files||[]).map(f=>f.name).join(' ')].filter(Boolean).join('\n')
      });
      return;
    }
    if(entry.type==='agent'){
      const agent=entry.agent;
      const msg=entry.msg;
      const pNum=getAgentPanelNumber(agent,conv);
      const speaker=getAgentMessageSpeakerLabel(agent,msg);
      const body=msg.failed?`[FAILED] ${msg.errorMessage||'Agent response failed.'}`:stripUrlSummaryBlocks(msg.content||'');
      const meta=`${pNum}: ${speaker} ${fmtT(msg.ts)}`;
      entries.push({
        id:String(msg.id||''),
        kind:'agent',
        order,
        body,
        searchText:[meta,body].filter(Boolean).join('\n')
      });
    }
  });
  return entries.filter(entry=>entry.id);
}

function findAllCaseInsensitiveMatches(text,query){
  const src=String(text||'');
  const q=String(query||'');
  if(!src||!q) return [];
  const srcLower=src.toLowerCase();
  const qLower=q.toLowerCase();
  const out=[];
  let idx=0;
  while((idx=srcLower.indexOf(qLower,idx))!==-1){
    out.push({start:idx,end:idx+q.length});
    idx+=Math.max(q.length,1);
  }
  return out;
}

function buildExactHistorySearchResults(query,conv=S.conv){
  return buildHistorySearchEntries(conv).map(entry=>{
    const bodyMatches=findAllCaseInsensitiveMatches(entry.body,query);
    const metaMatches=findAllCaseInsensitiveMatches(entry.searchText,query);
    if(!bodyMatches.length&&!metaMatches.length) return null;
    return{
      mode:'exact',
      ids:[entry.id],
      primaryId:entry.id,
      matchesById:bodyMatches.length?{[entry.id]:bodyMatches}:{}};
  }).filter(Boolean);
}

const HISTORY_SMART_SEARCH_TARGET_TOKENS=150000;
const HISTORY_SMART_SEARCH_CHARS_PER_TOKEN=4;
const HISTORY_SMART_SEARCH_CHUNK_CHAR_BUDGET=HISTORY_SMART_SEARCH_TARGET_TOKENS*HISTORY_SMART_SEARCH_CHARS_PER_TOKEN;

function extractJsonArrayText(raw){
  const src=String(raw||'').trim();
  if(!src) return'';
  const fenced=src.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const text=fenced?fenced[1].trim():src;
  const start=text.indexOf('[');
  const end=text.lastIndexOf(']');
  return(start>=0&&end>start)?text.slice(start,end+1):'';
}

function normalizeSmartHistorySearchResults(rawResults,entryById){
  const out=[];
  const seenKeys=new Set();
  (Array.isArray(rawResults)?rawResults:[]).forEach(raw=>{
    const ids=Array.isArray(raw?.ids)?raw.ids:(raw?.id?[raw.id]:(raw?.messageId?[raw.messageId]:[]));
    const clean=[...new Set(ids.map(id=>String(id||'').trim()).filter(id=>entryById.has(id)))];
    if(!clean.length) return;
    clean.sort((a,b)=>entryById.get(a).order-entryById.get(b).order);
    const key=clean.join('|');
    if(seenKeys.has(key)) return;
    seenKeys.add(key);
    out.push({mode:'smart',ids:clean,primaryId:clean[0],matchesById:{}});
  });
  out.sort((a,b)=>entryById.get(a.primaryId).order-entryById.get(b.primaryId).order);
  return out;
}

function buildSmartHistorySearchChunks(entries){
  const chunks=[];
  let current=[];
  let currentChars=0;
  for(const entry of entries){
    const text=String(entry.searchText||'');
    const size=text.length+String(entry.id||'').length+80;
    if(current.length&&currentChars+size>HISTORY_SMART_SEARCH_CHUNK_CHAR_BUDGET){
      chunks.push(current);
      current=[];
      currentChars=0;
    }
    current.push(entry);
    currentChars+=size;
  }
  if(current.length) chunks.push(current);
  return chunks;
}

function buildSmartHistorySearchPrompt(query,entries,chunkIndex=0,chunkCount=1){
  const compactEntries=entries.map(entry=>({
    id:entry.id,
    speaker:entry.kind,
    text:String(entry.searchText||'')
  }));
  return[
    'Find conversation-history entries that match the user search intent.',
    'Return ONLY a JSON array. No prose.',
    'Each item must be {"ids":["message-id"],"reason":"short reason"}.',
    'If a match spans adjacent messages, include multiple ids in the same ids array.',
    'Use only ids from the provided entries. Return [] if there are no matches.',
    `This is chunk ${chunkIndex+1} of ${chunkCount}. Search only this chunk and return matches from this chunk.`,
    '',
    `Search intent: ${query}`,
    '',
    'Entries:',
    JSON.stringify(compactEntries,null,2)
  ].join('\n');
}

async function buildSmartHistorySearchResults(query,conv=S.conv){
  const entries=buildHistorySearchEntries(conv);
  const entryById=new Map(entries.map(entry=>[entry.id,entry]));
  const system='You are a precise semantic search helper for a local conversation history. Return only valid JSON.';
  const chunks=buildSmartHistorySearchChunks(entries);
  const allParsed=[];
  for(let idx=0;idx<chunks.length;idx++){
    const raw=await requestHelperCompletion(buildSmartHistorySearchPrompt(query,chunks[idx],idx,chunks.length),{
      system,
      suppressErrorDialog:false
    });
    const jsonText=extractJsonArrayText(raw);
    let parsed=[];
    try{parsed=jsonText?JSON.parse(jsonText):[];}catch(e){parsed=[];}
    if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed)){
      parsed=Array.isArray(parsed.results)?parsed.results:[parsed];
    }
    allParsed.push(...(Array.isArray(parsed)?parsed:[]));
  }
  return normalizeSmartHistorySearchResults(allParsed,entryById);
}

async function runHistorySearch(mode='exact'){
  const conv=S.conv;
  const query=getHistorySearchInputValue();
  if(!conv||!query) return;
  S.logMode='full';
  updateHistoryPanelTitle(conv);
  renderHistory();
  const state=getHistorySearchState();
  state.busy=true;
  state.query=query;
  state.mode=mode==='smart'?'smart':'exact';
  state.results=[];
  state.index=-1;
  syncHistorySearchUi();
  try{
    const results=state.mode==='smart'
      ? await buildSmartHistorySearchResults(query,conv)
      : buildExactHistorySearchResults(query,conv);
    state.results=results;
    state.index=results.length?0:-1;
    if(!results.length){
      flashHistorySearchInput('fail');
      playHistorySearchFailSound();
      renderHistory();
      return;
    }
    flashHistorySearchInput('ok');
    showHistorySearchResult(0);
  }catch(e){
    console.warn('History search failed:',e);
    state.results=[];
    state.index=-1;
    flashHistorySearchInput('fail');
    playHistorySearchFailSound();
    renderHistory();
  }finally{
    state.busy=false;
    syncHistorySearchUi();
  }
}

function navigateHistorySearchResult(delta){
  const state=getHistorySearchState();
  if(!state.results.length) return;
  const next=state.index+delta;
  if(next<0||next>=state.results.length) return;
  showHistorySearchResult(next);
}

function showHistorySearchResult(index){
  const state=getHistorySearchState();
  if(index<0||index>=state.results.length) return;
  state.index=index;
  S.logMode='full';
  updateHistoryPanelTitle(S.conv);
  renderHistory();
  const result=state.results[index];
  const targetId=result.primaryId||result.ids?.[0];
  const target=[...document.querySelectorAll('[data-history-msg-id]')]
    .find(el=>String(el.dataset.historyMsgId||'')===String(targetId||''));
  const list=document.getElementById('history-list');
  if(target&&list) scrollEntryToTopForHistoryNav(list,target);
  syncHistorySearchUi();
}

function getCurrentHistorySearchResult(){
  const state=getHistorySearchState();
  if(state.index<0||state.index>=state.results.length) return null;
  return state.results[state.index];
}

function historySearchResultContainsId(result,msgId){
  const id=String(msgId||'');
  return !!(result&&Array.isArray(result.ids)&&result.ids.includes(id));
}

function getHistorySearchMatchesForMessage(msgId){
  const result=getCurrentHistorySearchResult();
  const id=String(msgId||'');
  return result?.matchesById?.[id]||[];
}

function renderHistoryTextWithHighlights(text,matches){
  const src=String(text||'');
  const valid=(Array.isArray(matches)?matches:[])
    .map(m=>({start:Math.max(0,parseInt(m.start,10)||0),end:Math.max(0,parseInt(m.end,10)||0)}))
    .filter(m=>m.end>m.start&&m.start<src.length)
    .sort((a,b)=>a.start-b.start);
  if(!valid.length) return renderRichTextHtml(src);
  const parts=[];
  let pos=0;
  valid.forEach(match=>{
    const start=Math.max(pos,Math.min(match.start,src.length));
    const end=Math.max(start,Math.min(match.end,src.length));
    if(start>pos) parts.push(esc(src.slice(pos,start)));
    parts.push(`<span class="lv-search-mark">${esc(src.slice(start,end))}</span>`);
    pos=end;
  });
  if(pos<src.length) parts.push(esc(src.slice(pos)));
  return parts.join('');
}

function clearHistorySelection(opts={}){
  if(!S.historySelectedMsgId) return;
  S.historySelectedMsgId='';
  if(opts.render!==false) renderHistory();
}

function invalidateHistorySelectionFromUserScroll(){
  if(S.historySelectedMsgId) clearHistorySelection({render:true});
}

function bindAgentHistorySelectionInvalidation(logEl){
  if(!logEl||logEl.dataset.historySelectionBound==='1') return;
  logEl.dataset.historySelectionBound='1';
  logEl.tabIndex=0;
  logEl.addEventListener('wheel',()=>invalidateHistorySelectionFromUserScroll(),{passive:true});
  logEl.addEventListener('touchmove',()=>invalidateHistorySelectionFromUserScroll(),{passive:true});
  logEl.addEventListener('keydown',event=>{
    if(['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(event.key)){
      invalidateHistorySelectionFromUserScroll();
    }
  });
}

// HISTORY / LOG
function renderHistory(){
  const c=S.conv;if(!c)return;
  updateHistoryPanelTitle(c);
  syncHistorySearchUi();
  const el=document.getElementById('history-list');
  el.innerHTML='';
  if(S.logMode==='summary'){
    el.style.display='';
    getRoundOpeningDirectorMessages(c).forEach(m=>appendHistItem(m));
  } else {
    el.style.display='block';
    renderFullLog(el, c);
  }
  el.scrollTop=el.scrollHeight;
}

function appendHistItem(m){
  const c=S.conv;
  const failureState=getRoundFailureState(c,Number(m?.num||m?.roundId||0));
  const dots=(m.targets||[]).map(id=>{
    const a=c?.agents.find(x=>x.id===id);
    const col=COLORS.find(x=>x.id===a?.color)||COLORS[0];
    return `<span class="h-dot" style="background:${col.hex}" title="${esc(a?.name||'')}"></span>`;
  }).join('');
  const fileNote=m.files?.length?` 📎${m.files.length}`:'';
  const roundLabel=formatRoundLabel(m?.num||m?.roundId);
  const div=document.createElement('div');div.className='h-item'+(S.historySelectedMsgId===String(m.id||'')?' sel':'');div.id='h_'+m.id;
  const failBadge=failureState?` <span style="color:#fca5a5">FAILED</span>`:'';
  div.innerHTML=`<span class="h-ts">${roundLabel}-${fmtT(m.ts)}</span><span class="h-sum" title="${esc(`${m.summary||''}${fileNote}`)}">${esc(m.summary)}${fileNote}${failBadge}</span><span class="h-dots">${dots}</span>`;
  div.style.cursor='pointer';
  div.onclick=()=>{
    S.historySelectedMsgId=String(m.id||'');
    navigateToHistoryMsg(m.id);
    if(S.logMode==='summary') renderHistory();
  };
  const el=document.getElementById('history-list');
  el.appendChild(div);el.scrollTop=el.scrollHeight;
}

function clearHistoryNavScrollPad(logEl){
  if(!logEl) return;
  if(logEl.dataset.historyNavPad!=='1') return;
  logEl.style.paddingBottom=logEl.dataset.historyNavPrevPaddingBottom||'';
  delete logEl.dataset.historyNavPad;
  delete logEl.dataset.historyNavPrevPaddingBottom;
}

function scrollEntryToTopForHistoryNav(logEl,entryEl){
  if(!logEl||!entryEl) return;
  clearHistoryNavScrollPad(logEl);
  const target=entryEl.offsetTop-logEl.offsetTop;
  const maxScroll=Math.max(0,logEl.scrollHeight-logEl.clientHeight);
  if(target>maxScroll){
    // Add just enough temporary bottom space so target entry can anchor to top.
    const basePad=parseFloat(getComputedStyle(logEl).paddingBottom)||0;
    const needed=Math.ceil(target-maxScroll+1);
    logEl.dataset.historyNavPad='1';
    logEl.dataset.historyNavPrevPaddingBottom=logEl.style.paddingBottom||'';
    logEl.style.paddingBottom=(basePad+needed)+'px';
  }
  logEl.scrollTop=target;
}

// Navigate Director display and all agent windows to a specific Director message
function navigateToHistoryMsg(msgId){
  const c=S.conv;if(!c)return;
  const msg=c.messages.find(m=>m.id===msgId);
  if(!msg)return;
  // Update Director thread to show this message
  appendDirMsg(msg);
  const roundNum=Number(msg.num||msg.roundId||0);
  // Find the next director message to bound the search window
  const msgIdx=c.messages.indexOf(msg);
  const nextDirMsg=c.messages.slice(msgIdx+1).find(m=>m.role==='director'&&!m.isSep);
  const nextTs=nextDirMsg?nextDirMsg.ts:Infinity;

  // Scroll each agent to their response in this round
  c.agents.forEach(a=>{
    const logEl=document.getElementById('al_'+a.id);
    if(!logEl)return;
    clearHistoryNavScrollPad(logEl);
    // Prefer explicit reply-link; fall back to timestamp window for older data
    const resp=isRoundOpeningDirectorMessage(msg)&&roundNum
      ? a.msgs.find(m=>m.role==='agent'&&Number(m.round||0)===roundNum)
      : a.msgs.find(m=>
          m.role==='agent'&&
          (
            (m.inReplyTo&&m.inReplyTo===msg.id)||
            (!m.inReplyTo&&m.ts>=msg.ts&&m.ts<nextTs)
          )
        );
    if(!resp)return;
    const respEl=logEl.querySelector('#ae_'+resp.id);
    if(respEl){
      scrollEntryToTopForHistoryNav(logEl,respEl);
    }
  });
}

function getFullHistoryEntries(c){
  const entries=[];
  if(!c) return entries;
  for(const m of c.messages){
    if(m.isSep){
      entries.push({type:'sep',ts:m.ts});
      continue;
    }
    if(!isRoundOpeningDirectorMessage(m)) continue;
    entries.push({type:'director',msg:m});
    getConversationRoundTurnEntries(c,m).forEach(entry=>entries.push(entry));
  }
  return entries;
}

function renderFullLog(el, c){
  getFullHistoryEntries(c).forEach(entry=>{
    if(entry.type==='sep'){
      const div=document.createElement('div');
      div.className='lv-sep';
      div.innerHTML='<span>─ NEW CONTEXT ─</span>';
      el.appendChild(div);
      return;
    }
    if(entry.type==='director'){
      const m=entry.msg;
      const searchResult=getCurrentHistorySearchResult();
      const searchHit=historySearchResultContainsId(searchResult,m.id);
      const matches=getHistorySearchMatchesForMessage(m.id);
      const roundLabel=formatRoundLabel(m?.num||m?.roundId);
      const d=document.createElement('div');
      d.className='lv-dir'+(searchHit?' history-search-hit':'');
      d.dataset.historyMsgId=String(m.id||'');
      d.style.cursor='pointer';
      d.title='Click to navigate to this round';
      d.onclick=(()=>{const mid=m.id;return()=>navigateToHistoryMsg(mid);})();
      const filesHtml=m.files?.length
        ?`<div class="lv-dir-files">📎 ${m.files.map(f=>esc(f.name)).join(' · ')}</div>`:'';
      const label=(m.source==='ai')?'Director (AI)':'Director';
      const bodyText=m.continue?'Continue':(m.content||'');
      d.innerHTML=`<div class="lv-dir-hdr">${label} · ${roundLabel}-${fmtT(m.ts)}</div>
        <div class="lv-dir-body">${renderHistoryTextWithHighlights(bodyText,matches)}</div>${filesHtml}`;
      el.appendChild(d);
      return;
    }
    const agent=entry.agent;
    const msg=entry.msg;
    const searchResult=getCurrentHistorySearchResult();
    const searchHit=historySearchResultContainsId(searchResult,msg.id);
    const matches=getHistorySearchMatchesForMessage(msg.id);
    const col=COLORS.find(c=>c.id===agent.color)||COLORS[0];
    const pNum=getAgentPanelNumber(agent,c);
    const div=document.createElement('div');
    div.className='lv-agent'+(searchHit?' history-search-hit':'');
    div.dataset.historyMsgId=String(msg.id||'');
    div.style.setProperty('--ac',col.hex);
    div.style.borderLeftColor=col.hex;
    const toolHtml=msg.failed?'':renderToolUseHtml(msg);
    const body=msg.failed?`[FAILED] ${msg.errorMessage||'Agent response failed.'}`:stripUrlSummaryBlocks(msg.content||'');
    div.innerHTML=`<div class="lv-agent-hdr" style="color:${col.hex}">${pNum}: ${esc(getAgentMessageSpeakerLabel(agent,msg))} · ${fmtT(msg.ts)}</div>
      ${toolHtml}<div class="lv-agent-body">${renderHistoryTextWithHighlights(body,matches)}</div>`;
    el.appendChild(div);
  });
}

// DIRECTOR THREAD — shows only the most recent Director message
function renderDirThread(){
  const c=S.conv;if(!c)return;
  const el=document.getElementById('dir-thread');el.innerHTML='';
  // Find last non-separator message
  const last=[...c.messages].reverse().find(m=>!m.isSep);
  if(last) appendDirMsg(last);
}
function appendDirMsg(m){
  const c=S.conv;
  const el=document.getElementById('dir-thread');
  // Always replace — only show one message
  el.innerHTML='';
  if(m.isSep) return; // don't show separators here
  const dots=(m.targets||[]).map(id=>{
    const a=c?.agents.find(x=>x.id===id);
    const col=COLORS.find(x=>x.id===a?.color)||COLORS[0];
    return `<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${col.hex}" title="${esc(a?getAgentIdentityLabel(a):'')}"></span>`;
  }).join('');
  const fatt=m.files?.length?` <span class="d-att">📎 ${esc(m.files.map(f=>f.name).join(', '))}</span>`:'';
  const displayText=m.continue?'Continue':String(m.content||'');
  const prefix=m.source==='ai'?'AI Director':'Director';
  const div=document.createElement('div');div.id='dt_'+m.id;
  div.innerHTML=`<div class="d-msg"><span class="d-ts">${fmtT(m.ts)}</span><span class="d-txt" title="${esc(displayText)}">${esc(displayText||prefix)}</span><span class="d-rdots">${dots}</span>${fatt}</div>`;
  el.appendChild(div);
}

// AGENT GRID
function renderAgentGrid(){
  const c=S.conv;if(!c)return;
  const g=document.getElementById('agent-grid');g.innerHTML='';
  const liveAgents=getLiveConversationAgents(c);
  const soloAgent=liveAgents.find(a=>a.expanded);
  if(soloAgent){
    g.style.gridTemplateColumns='1fr';
    liveAgents.forEach(a=>{
      const panel=buildAgentPanel(a);
      if(!panel) return;
      if(a.id!==soloAgent.id) panel.style.display='none';
      g.appendChild(panel);
    });
  } else {
    g.style.gridTemplateColumns=`repeat(${c.agentCols},1fr)`;
    liveAgents.forEach(a=>{
      const panel=buildAgentPanel(a);
      if(panel) g.appendChild(panel);
    });
  }
}

function getAgentActiveToggleTitle(agent,conv=S.conv){
  const id=String(agent?.id||'');
  const round=getActiveRoundForConversation(conv);
  const active=isAgentActive(agent,conv);
  const inCurrentRound=!!round&&!round.complete&&Array.isArray(round.targets)&&round.targets.includes(id);
  if(active&&getFutureRoundTargetAgents(conv).length<=MIN_ACTIVE_AGENT_COUNT) return `At least ${MIN_ACTIVE_AGENT_COUNT} active agents are required.`;
  if(active) return 'Active for future rounds. Click to make inactive after the current round.';
  if(inCurrentRound) return 'Inactive for future rounds. This agent still finishes the current round. Click to include this agent again.';
  return 'Inactive for future rounds. Click to include this agent again.';
}

function syncAgentActiveToggleUi(agentId=''){
  const c=S.conv;
  if(!c) return 0;
  const ids=agentId?[String(agentId)]:c.agents.map(agent=>String(agent?.id||'')).filter(Boolean);
  let updated=0;
  ids.forEach(id=>{
    const agent=c.agents.find(entry=>String(entry?.id||'')===id);
    const btn=document.getElementById('agt_'+id+'_active');
    if(!agent||!btn) return;
    const col=COLORS.find(entry=>entry.id===agent.color)||COLORS[0];
    const active=isAgentActive(agent,c);
    btn.classList.toggle('on',active);
    btn.classList.toggle('off',!active);
    btn.textContent=active?'Active':'Inactive';
    btn.title=getAgentActiveToggleTitle(agent,c);
    btn.style.color=col.hex;
    btn.setAttribute('aria-pressed',active?'true':'false');
    updated++;
  });
  return updated;
}

function buildAgentPanel(a){
  if(a?.isGhost) return null;
  const c=S.conv;
  const col=COLORS.find(c=>c.id===a.color)||COLORS[0];
  const div=document.createElement('div');
  div.id='ap_'+a.id;div.style.borderColor=col.dim;

  const expandIcon=a.expanded?'⚡':'⊞';
  const expandTitle=a.expanded?'Return to grid view':'Solo - fill full screen';
  const pNum=getAgentPanelNumber(a,c);
  const ready=isAgentReady(a);
  const personaReady=hasAgentSelectedPersona(a);
  const missing=!!a.personaMissing;
  const unconfigured=!ready&&!missing;
  const active=isAgentActive(a,c);
  const needsPersonaSetup=active&&!personaReady;
  const displayName=(needsPersonaSetup&&!missing)?'Select Persona':getAgentDisplayName(a);
  const hasMsgs=a.msgs&&a.msgs.filter(m=>!m.isSep&&m.role!=='director').length;
  const retryMsg=getLatestRoundFailureMessageForAgent(a,c);
  const labelClass='a-label-btn'+((unconfigured||needsPersonaSetup&&!missing)?' is-empty':'')+(missing?' is-missing':'')+(needsPersonaSetup?' is-setup-required':'');
  const labelColor=(unconfigured||needsPersonaSetup&&!missing)?'var(--red)':(missing?'#facc15':col.hex);
  const labelTitle=needsPersonaSetup?'Select a persona to unlock the Director input.':'View or change Persona / AI Model';
  const activeTitle=getAgentActiveToggleTitle(a,c);
  div.className=`agent-panel ac-${a.color}`+(a.expanded?' expanded':'')+(needsPersonaSetup?' needs-persona-setup':'');
  div.innerHTML=`
    <div class="a-header">
      <div class="a-label" style="color:${labelColor}">
        <button type="button" class="${labelClass}" onclick="openAgentPersonaEditorOrPicker('${a.id}')" title="${labelTitle}">
          <span class="a-label-prefix">${pNum}:</span>
          <span class="a-label-text">${esc(displayName)}</span>
          <span class="a-label-chevron">▾</span>
        </button>
      </div>
      <div class="a-ctrl">
        <button class="a-active-toggle ${active?'on':'off'}" id="agt_${a.id}_active" onclick="toggleAgentActive('${a.id}')" title="${activeTitle}"
          style="color:${col.hex}">${active?'Active':'Inactive'}</button>
        <button class="bi" onclick="toggleExpand('${a.id}')" title="${expandTitle}" style="font-size:12px">${expandIcon}</button>
        <button class="bi" id="spk_${a.id}" onclick="toggleAgentVoice('${a.id}')"
          title="Toggle voice playback"
          style="font-size:11px;color:var(--text-mid);transition:opacity 0.15s,color 0.15s">
          <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
          </svg>
        </button>
        <button class="bi" id="dl_${a.id}" onclick="downloadAgentMd('${a.id}',event)" title="Save agent log to the Results drawer"
          style="font-size:11px;opacity:${hasMsgs?'1':'0.18'};color:${hasMsgs?col.hex:'var(--text-dim)'};transition:opacity .2s,color .2s">⤓</button>
        <button class="bi a-retry-btn ${retryMsg?'is-ready':''}" id="rt_${a.id}" onclick="retryLatestAgentFailure('${a.id}')" title="${retryMsg?'Retry this agent using the original failed request context.':'Retry is available when this agent has a retryable failure in the latest round.'}" ${retryMsg?'':'disabled'}>↻</button>
        <span class="a-ctrl-gap"></span>
        <button class="bi bd" onclick="removeAgent('${a.id}')" title="Remove agent">🗑</button>
      </div>
    </div>
    <div class="a-log" id="al_${a.id}"></div>
    <div style="display:flex;align-items:center;border-top:1px solid var(--border);background:var(--surface2)">
      <div class="a-status ready" id="as_${a.id}" style="flex:1;border-top:none">Ready</div>
    </div>`;

  const log=div.querySelector('#al_'+a.id);
  bindAgentHistorySelectionInvalidation(log);
  if(a.msgs&&a.msgs.some(m=>!m.isSep&&m.role==='agent')){
    a.msgs.forEach(m=>appendAgentEntry(log,m,a));
    setTimeout(()=>scrollAgentToLatestResponse(log),0);
  }
  setAgentStatusDisplay(a.id);
  applyAgentSpeakerButtonState(a.id);
  syncAgentRetryButtonUi(a.id);
  return div;
}

function setAgentStatusDisplay(agentId,ts){
  const c=S.conv;if(!c)return;
  const a=c.agents.find(x=>x.id===agentId);if(!a)return;
  const stEl=document.getElementById('as_'+agentId);if(!stEl)return;
  if(a.personaMissing){
    stEl.className='a-status warn';
    stEl.textContent='Persona file missing';
    return;
  }
  if(isAgentActive(a,c)&&!hasAgentSelectedPersona(a)){
    stEl.className='a-status warn';
    stEl.textContent='Select persona';
    return;
  }
  if(!isAgentReady(a)){
    stEl.className='a-status ready';
    stEl.textContent='';
    return;
  }
  stEl.className='a-status ready';
  stEl.textContent=ts?('Ready · '+fmtT(ts)):'Ready';
  syncAgentRetryButtonUi(agentId);
}

function applyAgentSpeakerButtonState(agentId){
  const c=S.conv;if(!c)return;
  const a=c.agents.find(x=>x.id===agentId);if(!a)return;
  const btn=document.getElementById('spk_'+agentId);if(!btn)return;
  const voiceName=getEffectiveAgentProfile(a).voiceName;
  if(!voiceName){
    btn.style.opacity='0.55';
    btn.style.color='var(--text-mid)';
    btn.title='Set a voice for this agent';
    return;
  }
  if(a.voiceActive){
    btn.style.opacity='1';
    btn.style.color='var(--text-bright)';
    btn.title='Voice on - click to mute';
    return;
  }
  btn.style.opacity='0.75';
  btn.style.color='var(--text-mid)';
  btn.title='Voice off - click to enable';
}

function appendAgentEntry(log,m,a){
  if(m.role==='director') return;
  const col=COLORS.find(c=>c.id===a.color)||COLORS[0];
  const div=document.createElement('div');div.className='a-entry';
  if(m.id) div.id='ae_'+m.id;
  if(m.isSep){div.innerHTML='<div class="ctx-sep"><span>─ NEW CONTEXT ─</span></div>';}
  else{
    const isDir=m.role==='director';
    const rc=isDir?'var(--teal)':col.hex;
    const rn=isDir?'Director':getAgentMessageSpeakerLabel(a,m);
    const filesHtml=(S.conv?.settings?.showFiles!==false&&m.files?.length)
      ?`<div class="e-files">${m.files.map(f=>`<span class="e-file">∙ ${esc(f.name)}</span>`).join('')}</div>`:'';

    // For agent responses: parse downloads out of content
    let displayContent=m.content;
    let dlCards=[];
    if(!isDir && m.content){
      if(!Array.isArray(m.downloadItems)){
        m.downloadItems=parseDownloads(m.content,getAgentMessageSpeakerLabel(a,m),col.hex);
      }
      if(m.downloadItems.length){
        if(!m.downloadRegistered){
          m.downloadStartIdx=S.downloads.length;
          registerDownloads(m.downloadItems);
          m.downloadRegistered=true;
        }
        displayContent=stripDownloadDelimiters(m.content);
        dlCards=m.downloadItems.map((item,i)=>({item,realIdx:(m.downloadStartIdx||0)+i}));
      }
    }
    if(!isDir) displayContent=stripUrlSummaryBlocks(displayContent);

    const truncTag=!isDir&&m.truncated?` · <span style="color:#facc15">TRUNCATED${m.stopReason?': '+esc(String(m.stopReason).replace(/_/g,' ')):''}</span>`:'';
    const warnHtml=!isDir&&m.warningMessage
      ? `<div class="api-error-indicator"><div class="msg">${esc(m.warningMessage)}</div></div>`
      : '';
    const retryBtnHtml=!isDir&&isRetryableFailureMessage(m)
      ? `<button class="retry" type="button" onclick="retryAgentResponse('${a.id}','${m.id||''}')">Retry</button>`
      : '';
    const failHtml=!isDir&&m.failed
      ? `<div class="api-error-indicator"><div class="kind">${esc(getFailureKindLabel(m.failureKind))}</div><div class="msg">${esc(m.errorMessage||'Agent response failed.')}</div>${retryBtnHtml}</div>`
      : `${warnHtml}${!isDir?renderToolUseHtml(m):''}<div class="e-body" id="eb_${m.id||''}">${renderRichTextHtml(displayContent)}</div>${filesHtml}`;
    div.innerHTML=`<div class="e-role" style="color:${rc}">${fmtDT(m.ts)} · ${esc(rn)}${!isDir&&m.dirSum?' · D-'+esc(m.dirSum):''}${truncTag}${m.failed?' · <span style="color:#fca5a5">FAILED</span>':''}</div>${failHtml}`;
    const body=div.querySelector('.e-body');
    if(body&&!isDir){
      body.dataset.agentId=a.id;
      body.dataset.msgId=m.id||'';
      body.addEventListener('click',handleTtsResponseBodyClick);
      body.addEventListener('dblclick',handleTtsResponseBodyDoubleClick);
    }
    div._dlCards=dlCards;
  }
  log.appendChild(div);
  // Append download cards after insertion
  if(div._dlCards&&div._dlCards.length){
    div._dlCards.forEach(({item,realIdx})=>{
      const card=document.createElement('div');
      card.className='dl-card';
      const icon=extIcon(item.ext);
      const actionLabel=item.blob?'⤓ Download':'↗ Open Link';
      card.innerHTML=`
        <span class="dl-card-icon">${icon}</span>
        <div class="dl-card-info">
          <div class="dl-card-name" title="${item.name}">${item.name}</div>
        </div>
        <button class="dl-card-btn" onclick="event.stopPropagation();triggerDownload(${realIdx},event)">${actionLabel}</button>`;
      card.onclick=event=>triggerDownload(realIdx,event);
      log.appendChild(card);
    });
  }
}

// EXPAND / COLLAPSE
async function refreshCurrentConversationDownloads(){
  if(!S.conv?.sourcePath||S.drawerTab!=='downloads') return;
  treeSelectPath(DOWNLOADS_TREE_VIEW,S.conv.sourcePath);
  await scanDownloadsTree();
}

async function saveConversationArtifact(subdir,fileName,text){
  const conv=S.conv;
  if(!conv) return false;
  const dir=await getConversationDownloadSubdir(conv,subdir,true);
  if(!dir) return false;
  await writeTextFile(dir,fileName,text);
  await refreshCurrentConversationDownloads();
  return true;
}
async function saveConversationMarkdownArtifactAsHtml(subdir,fileName,markdown,title){
  return saveConversationArtifact(subdir,fileName,wrapMarkdownAsHtmlDocument(markdown,title));
}
async function buildSavedSummaryHtmlDocument(conv,markdownBody,title){
  void conv;
  return wrapMarkdownAsHtmlDocument(markdownBody,title);
}

function buildScopedAgentLogEntries(agent,conv,scope){
  const targetId=String(agent?.id||'').trim();
  return buildScopedHistoryEntries(conv,scope).filter(entry=>{
    if(entry?.type==='sep'||entry?.type==='director') return true;
    return String(entry?.agent?.id||'').trim()===targetId;
  });
}

function buildAgentLogMarkdown(agent,conv,scope,opts={}){
  const profile=getEffectiveAgentProfile(agent);
  const now=opts.now instanceof Date?opts.now:new Date();
  const speakerLabel=getAgentIdentityLabel(agent);
  const lines=[];
  lines.push(`# ${speakerLabel}`);
  lines.push(`*${getModelDisplayName(profile.model)} - ${conv.name} - ${now.toLocaleDateString()}*`);
  lines.push(`*Rounds included: ${formatArtifactRoundSpan(scope)}*`);
  lines.push('');
  buildScopedAgentLogEntries(agent,conv,scope).forEach(entry=>{
    if(entry?.type==='sep'){
      lines.push('');
      lines.push('---');
      lines.push('*-- New Context --*');
      lines.push('');
      return;
    }
    if(entry?.type==='director'){
      const msg=entry.msg;
      lines.push(`**${formatDirectorLogHeading(msg)}**`);
      lines.push('');
      lines.push(msg.continue?'Continue':msg.content);
      lines.push('');
      return;
    }
    const msg=entry.msg;
    lines.push(`**${getAgentMessageSpeakerLabel(agent,msg)}** - *${fmtT(msg.ts)}*`);
    lines.push('');
    if(msg.warningMessage) lines.push(`Warning: ${msg.warningMessage}`,'');
    lines.push(msg.failed?`[FAILED] ${msg.errorMessage||'Agent response failed.'}`:(msg.content||''));
    lines.push('');
  });
  return lines.join('\n');
}

async function saveAgentLogArtifact(agentId,choice='full'){
  const c=S.conv;if(!c)return false;
  const a=c.agents.find(x=>x.id===agentId);if(!a)return false;
  const now=new Date();
  const scope=buildHistoryScopeFromChoice(c,choice);
  const speakerLabel=getAgentIdentityLabel(a);
  const text=buildAgentLogMarkdown(a,c,scope,{now});
  const counterId=await reserveConversationArtifactId(c,'agentLog');
  const fileName=getAgentLogArtifactFileName(a,c,scope,counterId);
  const ok=await saveConversationMarkdownArtifactAsHtml(CONV_DOWNLOADS_LOGS_DIR,fileName,text,speakerLabel);
  if(ok) await appAlert(`Saved ${fileName} to this conversation's Results drawer.`,{title:'AGENT LOG SAVED'});
  return ok;
}

function downloadAgentMd(agentId,event){
  const conv=S.conv;
  if(!conv) return;
  const popupItems=buildHistoryScopePopupItems(conv,{
    full:'Full Agent',
    upToHere:'Agent Up To Here',
    fromHereOn:'Agent From Here On'
  },{
    full:()=>saveAgentLogArtifact(agentId,'full'),
    upToHere:()=>saveAgentLogArtifact(agentId,'up-to-here'),
    fromHereOn:()=>saveAgentLogArtifact(agentId,'from-here-on')
  });
  if(popupItems.length){
    const point=getPopupAnchorPoint(event,event?.currentTarget);
    showPopupMenu(point.x,point.y,popupItems);
    return;
  }
  void saveAgentLogArtifact(agentId,'full');
}

function downloadTextAsFile(text,fileName,mimeType='text/plain;charset=utf-8'){
  const blob=new Blob([String(text||'')],{type:mimeType});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');
  link.href=url;
  link.download=fileName||'download.txt';
  link.style.display='none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

function downloadBytesAsFile(bytes,fileName,mimeType='application/octet-stream'){
  const blob=new Blob([bytes instanceof Uint8Array?bytes:new Uint8Array(bytes||[])],{type:mimeType});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');
  link.href=url;
  link.download=fileName||'download.bin';
  link.style.display='none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

function appendFullHistoryEntriesMarkdown(lines,c,entries){
  (Array.isArray(entries)?entries:[]).forEach(entry=>{
    if(entry.type==='sep'){
      lines.push('---');
      lines.push('*-- New Context --*');
      lines.push('');
      return;
    }
    if(entry.type==='director'){
      const m=entry.msg;
      lines.push(`## ${formatDirectorLogHeading(m)}`);
      lines.push('');
      lines.push(String(m.continue?'Continue':(m.content||'')));
      if(Array.isArray(m.files)&&m.files.length){
        lines.push('');
        lines.push(`Attachments: ${m.files.map(f=>f.name).join(' | ')}`);
      }
      lines.push('');
      return;
    }
    const agent=entry.agent;
    const msg=entry.msg;
    const pNum=getAgentPanelNumber(agent,c);
    lines.push(`### ${pNum}: ${getAgentMessageSpeakerLabel(agent,msg)} - ${fmtT(msg.ts)}`);
    lines.push('');
    if(msg.warningMessage){
      lines.push(`Warning: ${msg.warningMessage}`);
      lines.push('');
    }
    lines.push(String(msg.failed?`[FAILED] ${msg.errorMessage||'Agent response failed.'}`:(msg.content||'')));
    lines.push('');
  });
}

function formatDirectorLogHeading(msg){
  const label=msg?.source==='ai'?'Director (AI)':'Director';
  const rawRound=msg?.num||msg?.roundId||1;
  const roundMatch=String(rawRound).match(/\d+/);
  const roundNum=Math.max(1,Number(roundMatch?roundMatch[0]:rawRound)||1);
  const roundLabel=`R${roundNum}`;
  return `${roundLabel}: ${label} - ${fmtT(msg?.ts)}`;
}

function appendMarkdownBlockquote(lines,text){
  String(text||'').replace(/\r\n?/g,'\n').split('\n').forEach(line=>{
    lines.push(line?`> ${line}`:'>');
  });
}

function getAgentLogEntryColor(agent){
  const col=COLORS.find(c=>c.id===agent?.color)||COLORS[0];
  const hex=String(col?.hex||'').trim();
  return /^#[0-9a-f]{6}$/i.test(hex)?hex:'';
}

function appendMarkdownBlockquoteColorMeta(lines,color){
  const hex=String(color||'').trim();
  if(/^#[0-9a-f]{6}$/i.test(hex)) lines.push(`> {#conflab-border-color=${hex}}`);
}

function appendAgentConversationLogBlockquote(lines,agent,c,msg){
  const pNum=getAgentPanelNumber(agent,c);
  appendMarkdownBlockquoteColorMeta(lines,getAgentLogEntryColor(agent));
  appendMarkdownBlockquote(lines,`**${pNum}: ${getAgentMessageSpeakerLabel(agent,msg)} - ${fmtT(msg.ts)}**`);
  lines.push('>');
  if(msg.warningMessage){
    appendMarkdownBlockquote(lines,`Warning: ${msg.warningMessage}`);
    lines.push('>');
  }
  appendMarkdownBlockquote(lines,String(msg.failed?`[FAILED] ${msg.errorMessage||'Agent response failed.'}`:(msg.content||'')));
}


function appendConversationLogEntriesMarkdown(lines,c,entries){
  (Array.isArray(entries)?entries:[]).forEach(entry=>{
    if(entry.type==='sep'){
      lines.push('---');
      lines.push('*-- New Context --*');
      lines.push('');
      return;
    }
    if(entry.type==='director'){
      const m=entry.msg;
      lines.push(`## ${formatDirectorLogHeading(m)}`);
      lines.push('');
      lines.push(String(m.continue?'Continue':(m.content||'')));
      if(Array.isArray(m.files)&&m.files.length){
        lines.push('');
        lines.push(`Attachments: ${m.files.map(f=>f.name).join(' | ')}`);
      }
      lines.push('');
      return;
    }
    const agent=entry.agent;
    const msg=entry.msg;
    appendAgentConversationLogBlockquote(lines,agent,c,msg);
    lines.push('');
  });
}

function buildFullHistoryMarkdown(c,opts={}){
  const conv=c||S.conv;
  if(!conv) return'';
  const lines=[];
  const now=opts.now instanceof Date?opts.now:new Date();
  const convName=(conv.name||'Conversation').trim()||'Conversation';
  lines.push(`# ${convName} - Full History`);
  lines.push(`*Exported ${now.toLocaleString()}*`);
  if((conv.topicObjective||'').trim()) lines.push(`*Topic / Objective:* ${(conv.topicObjective||'').trim()}`);
  if((conv.participantDescription||'').trim()) lines.push(`*Participant Description:* ${(conv.participantDescription||'').trim()}`);
  lines.push('');
  appendFullHistoryEntriesMarkdown(lines,conv,Array.isArray(opts.entries)?opts.entries:getFullHistoryEntries(conv));
  return lines.join('\n');
}

function getSummaryModeRoundMessages(conv){
  return getRoundOpeningDirectorMessages(conv);
}

function getSelectedHistoryRoundInfo(conv=S.conv){
  if(!conv||S.logMode!=='summary'||!S.historySelectedMsgId) return null;
  const rounds=getSummaryModeRoundMessages(conv);
  const idx=rounds.findIndex(msg=>String(msg?.id||'')===String(S.historySelectedMsgId||''));
  if(idx<0) return null;
  const msg=rounds[idx];
  return{
    rounds,
    index:idx,
    msg,
    round:Number(msg?.num||msg?.roundId||idx+1)||idx+1,
    isFirst:idx===0,
    isLast:idx===rounds.length-1,
    isIntermediate:idx>0&&idx<rounds.length-1
  };
}

function getHistoryScopePopupState(conv=S.conv){
  if(!conv||S.logMode!=='summary') return null;
  const selected=getSelectedHistoryRoundInfo(conv);
  if(!selected||selected.isLast) return null;
  return selected;
}

function buildHistoryScopePopupItems(conv,labels,handlers){
  const selected=getHistoryScopePopupState(conv);
  if(!selected) return [];
  const items=[
    {label:labels.full,onSelect:handlers.full},
    {label:labels.upToHere,onSelect:handlers.upToHere}
  ];
  if(!selected.isFirst) items.push({label:labels.fromHereOn,onSelect:handlers.fromHereOn});
  return items;
}

function buildHistoryScopeFromChoice(conv,choice='full'){
  const rounds=getSummaryModeRoundMessages(conv);
  if(!rounds.length){
    return{choice:'full',rounds:[],startRound:1,endRound:1,isFull:true};
  }
  const selected=getSelectedHistoryRoundInfo(conv);
  let subset=rounds;
  let scopeChoice='full';
  if(selected&&!selected.isLast&&choice==='up-to-here'){
    subset=rounds.slice(0,selected.index+1);
    scopeChoice='up-to-here';
  }else if(selected&&!selected.isFirst&&!selected.isLast&&choice==='from-here-on'){
    subset=rounds.slice(selected.index);
    scopeChoice='from-here-on';
  }
  const startRound=Number(subset[0]?.num||subset[0]?.roundId||1)||1;
  const endRound=Number(subset[subset.length-1]?.num||subset[subset.length-1]?.roundId||startRound)||startRound;
  return{
    choice:scopeChoice,
    rounds:subset,
    startRound,
    endRound,
    isFull:scopeChoice==='full'
  };
}

function buildScopedHistoryEntries(conv,scope){
  return buildHistoryEntriesForRounds(conv,scope?.rounds||[]);
}

function getConversationArtifactLabel(conv,maxLen=72){
  return sanitizeTitleForFs(conv?.name||'Conversation',maxLen)||'Conversation';
}

function getAgentLogIdentityLabel(agent,conv=S.conv){
  if(!agent) return 'Agent';
  if(String(agent.personaUuid||'').trim()){
    const source=getPersonaSourceForAgent(agent);
    if(source?.name) return sanitizeTitleForFs(source.name,48)||'Persona';
  }
  if(String(agent.model||'').trim()){
    return sanitizeTitleForFs(getModelDisplayName(agent.model),48)||`Agent_${getAgentPanelNumber(agent,conv)}`;
  }
  return sanitizeTitleForFs(`Agent_${getAgentPanelNumber(agent,conv)}`,48)||'Agent';
}

function getScopedSummaryFileName(conv,scope,counterId){
  return `summary-${formatArtifactRoundSpan(scope)}-${getConversationArtifactLabel(conv)}__${counterId}.html`;
}

function getScopedLogFileName(conv,scope,counterId){
  return `log-${formatArtifactRoundSpan(scope)}-${getConversationArtifactLabel(conv)}__${counterId}.html`;
}

function getAgentLogArtifactFileName(agent,conv,scope,counterId){
  return `agent-${formatArtifactRoundSpan(scope)}-${getConversationArtifactLabel(conv)}__${getAgentLogIdentityLabel(agent,conv)}__${counterId}.html`;
}

function buildConversationLogMarkdown(conv,scope,opts={}){
  const now=opts.now instanceof Date?opts.now:new Date();
  const lines=[];
  const convName=(conv?.name||'Conversation').trim()||'Conversation';
  lines.push(`# ${convName} -- Conversation Log`);
  lines.push(`**Log generated:** ${now.toLocaleString()}`);
  lines.push(`**Rounds included:** R${scope.startRound}-R${scope.endRound}`);
  lines.push(`**Conversation mode:** ${formatConversationModeLabel(getConversationMode(conv))}`);
  lines.push(`**Director type:** ${formatDirectorTypeLabel(getConversationDirectorType(conv))}`);
  lines.push('');
  appendConversationLogEntriesMarkdown(lines,conv,buildScopedHistoryEntries(conv,scope));
  return lines.join('\n');
}

function estimateTextTokens(text){
  return Math.ceil(String(text||'').length/4);
}

function trimTextMiddle(text,maxChars,note){
  const src=String(text||'');
  if(src.length<=maxChars) return src;
  const gap=Math.max(0,maxChars-String(note||'').length-2);
  const head=Math.max(0,Math.floor(gap/2));
  const tail=Math.max(0,gap-head);
  return `${src.slice(0,head)}\n${note}\n${src.slice(Math.max(0,src.length-tail))}`;
}

function buildHistoryEntriesForRounds(conv,dirMsgs){
  const entries=[];
  (Array.isArray(dirMsgs)?dirMsgs:[]).forEach(msg=>{
    entries.push({type:'director',msg});
    getConversationRoundTurnEntries(conv,msg).forEach(entry=>entries.push(entry));
  });
  return entries;
}

function formatConversationModeLabel(mode){
  if(mode==='free_form') return'Free Form';
  if(mode==='sequential') return'Sequential';
  return'Parallel';
}

function formatDirectorTypeLabel(type){
  return normalizeDirectorType(type)==='ai'?'AI':'Human';
}

function getConversationSummaryRoleLine(agent,conv){
  const profile=getEffectiveAgentProfile(agent,conv);
  const parsed=parseIdentityLine(profile.backstory||'');
  if(parsed?.occupation) return parsed.occupation;
  const slot=getParticipantPlanSlotForAgentSync(conv,agent);
  if(slot?.occupation) return String(slot.occupation).trim();
  if(slot?.roleBrief) return String(slot.roleBrief).trim();
  return 'Participant';
}

function buildConversationSummaryHeaderMarkdown(conv,opts={}){
  const now=opts.now instanceof Date?opts.now:new Date();
  const convName=(conv?.name||'Conversation').trim()||'Conversation';
  const rounds=(Array.isArray(opts.rounds)&&opts.rounds.length)?opts.rounds:getRoundOpeningDirectorMessages(conv);
  const completedRounds=rounds.length;
  const firstTs=Number(rounds[0]?.ts||now.getTime());
  const lastTs=Number(rounds[rounds.length-1]?.ts||firstTs);
  const startRound=Number(rounds[0]?.num||rounds[0]?.roundId||1)||1;
  const endRound=Number(rounds[rounds.length-1]?.num||rounds[rounds.length-1]?.roundId||startRound)||startRound;
  const lines=[
    `# ${convName} -- Summary`,
    '',
    `**Summary generated:** ${now.toLocaleString()}`,
    `**Conversation period:** ${fmtT(firstTs)} to ${fmtT(lastTs)}`,
    `**Rounds:** ${completedRounds}`,
    `**Rounds included:** R${startRound}-R${endRound}`,
    `**Conversation mode:** ${formatConversationModeLabel(getConversationMode(conv))}`,
    `**Director type:** ${formatDirectorTypeLabel(getConversationDirectorType(conv))}`,
    ''
  ];
  if((conv?.topicObjective||'').trim()){
    lines.push('**Topic / Objective:**');
    lines.push((conv.topicObjective||'').trim());
    lines.push('');
  }
  if((conv?.participantDescription||'').trim()){
    lines.push('**Participant description:**');
    lines.push((conv.participantDescription||'').trim());
    lines.push('');
  }
  lines.push('**Panel:**');
  (conv?.agents||[]).forEach(agent=>{
    lines.push(`- ${getAgentIdentityLabel(agent,conv)} -- ${getConversationSummaryRoleLine(agent,conv)}`);
  });
  return lines.join('\n');
}

function buildConversationSummaryRosterContext(conv){
  const lines=['Agent roster and persona context:'];
  (conv?.agents||[]).forEach(agent=>{
    const name=getAgentIdentityLabel(agent,conv);
    const profile=getEffectiveAgentProfile(agent,conv);
    const backstory=truncateDirectorAssistText(profile.backstory||'',600)||'No persona description available.';
    lines.push(`- ${name}`);
    lines.push(`  Role: ${getConversationSummaryRoleLine(agent,conv)}`);
    lines.push(`  Persona context: ${backstory}`);
  });
  return lines.join('\n');
}

function splitArrayEvenly(items,parts){
  const src=Array.isArray(items)?items:[];
  const count=Math.max(1,Math.min(src.length||1,Number(parts)||1));
  const out=[];
  let start=0;
  for(let i=0;i<count;i++){
    const end=Math.round(((i+1)*src.length)/count);
    const slice=src.slice(start,end);
    if(slice.length) out.push(slice);
    start=end;
  }
  return out.length?out:[src];
}

function buildConversationSummaryChunkMarkdown(conv,rounds,opts={}){
  const subset=Array.isArray(rounds)?rounds.filter(Boolean):[];
  const now=opts.now instanceof Date?opts.now:new Date();
  const lines=[];
  const convName=(conv?.name||'Conversation').trim()||'Conversation';
  const firstRound=Number(subset[0]?.num||subset[0]?.roundId||1);
  const lastRound=Number(subset[subset.length-1]?.num||subset[subset.length-1]?.roundId||firstRound);
  lines.push(`# ${convName} - History Segment ${Number(opts.segmentIndex||0)+1} of ${Number(opts.segmentCount||1)}`);
  lines.push(`*Rounds ${firstRound}-${lastRound}*`);
  lines.push(`*Exported ${now.toLocaleString()}*`);
  if((conv?.topicObjective||'').trim()) lines.push(`*Topic / Objective:* ${(conv.topicObjective||'').trim()}`);
  lines.push('');
  appendFullHistoryEntriesMarkdown(lines,conv,buildHistoryEntriesForRounds(conv,subset));
  return{
    text:lines.join('\n'),
    firstRound,
    lastRound,
    roundCount:subset.length
  };
}

function buildConversationSummaryChunks(conv,opts={}){
  const rounds=(Array.isArray(opts.rounds)&&opts.rounds.length)?opts.rounds:getRoundOpeningDirectorMessages(conv);
  if(!rounds.length) return[];
  const now=opts.now instanceof Date?opts.now:new Date();
  const helperModel=ensureModelId(APP_SETTINGS.helperModel);
  const modelEntry=getOpenRouterModelEntry(helperModel);
  const contextLimit=Math.max(1,Number(modelEntry?.contextLength)||SUMMARY_CONTEXT_FALLBACK_TOKENS);
  const reserveTokens=Math.max(0,Number(opts.reserveTokens)||SUMMARY_CHUNK_PROMPT_RESERVE_TOKENS);
  const targetTokens=Math.max(1,Math.floor(contextLimit*SUMMARY_CONTEXT_USAGE_RATIO)-reserveTokens);
  const fullText=buildFullHistoryMarkdown(conv,{now,entries:buildHistoryEntriesForRounds(conv,rounds)});
  let chunkCount=Math.max(2,Math.ceil(estimateTextTokens(fullText)/targetTokens));
  chunkCount=Math.min(Math.max(1,chunkCount),rounds.length);
  while(chunkCount<=rounds.length){
    const groups=splitArrayEvenly(rounds,chunkCount);
    const chunks=groups.map((group,idx)=>buildConversationSummaryChunkMarkdown(conv,group,{
      now,
      segmentIndex:idx,
      segmentCount:groups.length
    }));
    const fits=chunks.every(chunk=>estimateTextTokens(chunk.text)<=targetTokens);
    if(fits||chunkCount===rounds.length){
      return chunks.map(chunk=>{
        if(estimateTextTokens(chunk.text)<=targetTokens) return chunk;
        return{
          ...chunk,
          text:trimTextMiddle(
            chunk.text,
            targetTokens*4,
            `[History segment for rounds ${chunk.firstRound}-${chunk.lastRound} trimmed to fit helper-model context limit.]`
          )
        };
      });
    }
    chunkCount++;
  }
  return[];
}

function buildConversationSummaryTranscript(conv,opts={}){
  const now=opts.now instanceof Date?opts.now:new Date();
  const helperModel=ensureModelId(APP_SETTINGS.helperModel);
  const modelEntry=getOpenRouterModelEntry(helperModel);
  const contextLimit=Math.max(1,Number(modelEntry?.contextLength)||SUMMARY_CONTEXT_FALLBACK_TOKENS);
  const reserveTokens=Math.max(0,Number(opts.reserveTokens)||0);
  const targetTokens=Math.max(1,Math.floor(contextLimit*SUMMARY_CONTEXT_USAGE_RATIO)-reserveTokens);
  const rounds=(Array.isArray(opts.rounds)&&opts.rounds.length)?opts.rounds:getRoundOpeningDirectorMessages(conv);
  const fullText=buildFullHistoryMarkdown(conv,{now,entries:buildHistoryEntriesForRounds(conv,rounds)});
  if(estimateTextTokens(fullText)<=targetTokens){
    return{text:fullText,truncated:false};
  }
  const edge=Math.max(1,Number(opts.edgeRounds)||SUMMARY_EDGE_ROUNDS);
  if(rounds.length<=edge*2){
    const maxChars=targetTokens*4;
    return{
      text:trimTextMiddle(
        fullText,
        maxChars,
        '[Transcript trimmed for helper-model context limit.]'
      ),
      truncated:true
    };
  }
  const firstRounds=rounds.slice(0,edge);
  const lastRounds=rounds.slice(-edge);
  const omittedCount=Math.max(0,rounds.length-firstRounds.length-lastRounds.length);
  const entries=[];
  const lines=[];
  const convName=(conv?.name||'Conversation').trim()||'Conversation';
  lines.push(`# ${convName} - Full History`);
  lines.push(`*Exported ${now.toLocaleString()}*`);
  if((conv.topicObjective||'').trim()) lines.push(`*Topic / Objective:* ${(conv.topicObjective||'').trim()}`);
  if((conv.participantDescription||'').trim()) lines.push(`*Participant Description:* ${(conv.participantDescription||'').trim()}`);
  lines.push('');
  appendFullHistoryEntriesMarkdown(lines,conv,buildHistoryEntriesForRounds(conv,firstRounds));
  lines.push(`> [Rounds ${firstRounds.length+1}-${Math.max(firstRounds.length+1,rounds.length-lastRounds.length)} omitted for length -- ${omittedCount} rounds of discussion]`);
  lines.push('');
  appendFullHistoryEntriesMarkdown(lines,conv,buildHistoryEntriesForRounds(conv,lastRounds));
  let text=lines.join('\n');
  if(estimateTextTokens(text)>targetTokens){
    text=trimTextMiddle(text,targetTokens*4,'[Transcript trimmed further to fit helper-model context limit.]');
  }
  return{text,truncated:true};
}

function buildConversationSummaryChunkSystemPrompt(){
  return `You are summarizing one segment of a larger Conflab multi-provider conversation. Other segments are being summarized separately.

Focus on:
- key developments in this segment
- turning points or reversals
- ideas introduced by specific participants, including the Director
- positions that shifted
- unresolved threads that matter later

Do not write a title or metadata block.
- Preserve the high points of this segment, not just its conclusions.
- The Director's messages are often the narrative backbone of the conversation. Weight them accordingly when reconstructing what mattered in this segment.
- If this segment contains contradictions, reversals, corrections, breakthroughs, or a sharp change in direction, keep those moments visible.
- Let each major turn have its own space rather than flattening everything into one smooth recap.
- In Participant Contributions, give significant participants enough room to show what they uniquely added when they mattered more than once.

Use these section headings exactly:
### Segment Overview
### Key Developments
### Participant Contributions
### Open Threads`;
}

function buildConversationSummarySystemPrompt(){
  return `You are writing a standalone summary of a Conflab multi-provider conversation for someone who did not read the full transcript.

Write it like a highlights reel of the conversation, not like a dry technical memo and not like a complete transcript. The goal is to preserve the high points: the turns where the discussion changed direction, where someone corrected an error, changed position, challenged another participant, introduced a breakthrough idea, or made the conversation more concrete, more interesting, or more useful.

Be honest. Do not exaggerate progress, manufacture drama, or invent consensus. But when something genuinely important happened, give it enough clarity and specificity that the reader can understand why it mattered.

The Director's messages are especially important. They often contain the interpretive thread of the conversation: what was missing, what was being challenged, what changed, and why a particular exchange mattered. Treat them as part of the narrative backbone of the discussion.

Do not add fluff, generic praise, or filler. Do not flatten everything into abstract summary. Prefer memorable, consequential moments over bland completeness.

Let the Arc of the Conversation section unfold across multiple paragraphs. Give each major shift its own paragraph, and make sure each paragraph contains at least one concrete moment, correction, contradiction, reversal, or breakthrough that explains why that phase mattered.

In Agent Contributions, focus on what each meaningful participant uniquely brought to the conversation. If someone mattered more than once in different ways, note the distinct contributions separately.

Be clear about what was resolved, what remained uncertain, and what the conversation produced by the end.

A code-generated metadata header will be prepended above your response. Do not repeat the header block.
Do not include a title, metadata preamble, conversation header, panel list, or any replacement header.
Your first line must be exactly: ## Objective Context

Use these section headings exactly:
## Objective Context
## Arc of the Conversation
## Key Findings or Decisions
## Agent Contributions
## Director's Role
## Current State
## Next Steps`;
}

function buildConversationSummaryChunkUserPrompt(snapshot,chunk,idx,total){
  const chunkTargetMin=Math.max(12,chunk.roundCount*6);
  const chunkTargetMax=Math.max(chunkTargetMin+4,chunk.roundCount*9);
  const lines=[
    `This is segment ${idx+1} of ${total} for a larger conversation summary.`,
    `Coverage: rounds ${chunk.firstRound}-${chunk.lastRound}.`,
    `Aim for roughly ${chunkTargetMin}-${chunkTargetMax} lines of substantive summary content for this segment so later synthesis has enough detail to work with.`,
    'Summarize only this segment. Do not speculate about segments you cannot see.',
    '',
    'Conversation metadata header for reference only:',
    snapshot.header,
    '',
    snapshot.rosterContext,
    '',
    'Segment transcript:',
    chunk.text
  ];
  return lines.join('\n');
}

function buildConversationSummaryUserPrompt(snapshot){
  const completedRounds=Math.max(1,Number(snapshot?.completedRounds)||1);
  const targetMin=Math.max(20,completedRounds*10);
  const targetMax=Math.max(targetMin+10,completedRounds*15);
  const lines=[
    'Generate a standalone markdown summary for the following conversation snapshot.',
    `This conversation has ${completedRounds} completed rounds. Aim for roughly ${targetMin}-${targetMax} lines of substantive summary content, unless the transcript itself is unusually repetitive.`,
    'Do not optimize for brevity or completeness. Optimize for preserving the high points of the conversation.',
    'A code-generated metadata header will be prepended above your response.',
    'Do not repeat the header, metadata, panel list, title, or conversation name block.',
    'Your first line must be exactly: ## Objective Context',
    '',
    'Metadata header for reference only (do not repeat it):',
    snapshot.header,
    '',
    snapshot.rosterContext,
    '',
    `Transcript source (${snapshot.transcriptSourceLabel||(snapshot.transcriptTruncated?'truncated for model context':'full export')}):`,
    snapshot.transcript
  ];
  return lines.join('\n');
}

function normalizeGeneratedMarkdown(raw){
  return String(raw||'')
    .replace(/\r\n?/g,'\n')
    .replace(/[ \t]+$/gm,'')
    .trim();
}

function stripConversationSummaryHeaderEcho(summary,snapshot){
  let text=normalizeGeneratedMarkdown(summary);
  if(!text) return'';
  const expectedHeader=normalizeGeneratedMarkdown(snapshot?.header||'');
  if(expectedHeader&&text.startsWith(expectedHeader)){
    text=text.slice(expectedHeader.length).trim();
  }
  const headingMatch=text.match(/^##\s+(Objective Context|Arc of the Conversation|Key Findings or Decisions|Agent Contributions|Director's Role|Current State|Next Steps)\b/m);
  if(headingMatch&&headingMatch.index>0){
    const prefix=text.slice(0,headingMatch.index).trim();
    if(prefix.startsWith('# ')||/\*\*Summary generated:\*\*|\*\*Conversation period:\*\*|\*\*Rounds:\*\*|\*\*Panel:\*\*/.test(prefix)){
      text=text.slice(headingMatch.index).trim();
    }
  }
  return text;
}

function buildConversationSummaryIntermediateTranscript(chunks,summaries){
  const lines=['Segment summaries covering the full conversation:',''];
  chunks.forEach((chunk,idx)=>{
    lines.push(`### Segment ${idx+1} - Rounds ${chunk.firstRound}-${chunk.lastRound}`);
    lines.push('');
    lines.push(normalizeGeneratedMarkdown(summaries[idx]||''));
    lines.push('');
  });
  return lines.join('\n').trim();
}

function shouldOfferHistoryScopePopup(conv=S.conv){
  return !!getHistoryScopePopupState(conv);
}

async function saveScopedHistoryLog(choice='full'){
  const conv=S.conv;
  if(!conv||getCompletedRoundCount(conv)<1) return false;
  const now=new Date();
  const scope=buildHistoryScopeFromChoice(conv,choice);
  const counterId=await reserveConversationArtifactId(conv,'conversationLog');
  const fileName=getScopedLogFileName(conv,scope,counterId);
  const text=buildConversationLogMarkdown(conv,scope,{now});
  const ok=await saveConversationMarkdownArtifactAsHtml(CONV_DOWNLOADS_LOGS_DIR,fileName,text,`${(conv?.name||'Conversation').trim()||'Conversation'} -- Conversation Log`);
  if(ok) await appAlert(`Saved ${fileName} to this conversation's Results drawer.`,{title:'LOG SAVED'});
  return ok;
}

function downloadFullHistoryMd(event){
  const conv=S.conv;
  if(!conv) return;
  const popupItems=buildHistoryScopePopupItems(conv,{
    full:'Full Log',
    upToHere:'Up To Here',
    fromHereOn:'From Here On'
  },{
    full:()=>saveScopedHistoryLog('full'),
    upToHere:()=>saveScopedHistoryLog('up-to-here'),
    fromHereOn:()=>saveScopedHistoryLog('from-here-on')
  });
  if(popupItems.length){
    const point=getPopupAnchorPoint(event,event?.currentTarget);
    showPopupMenu(point.x,point.y,popupItems);
    return;
  }
  void saveScopedHistoryLog('full');
}

async function saveScopedConversationSummary(choice='full'){
  const conv=S.conv;
  if(!conv||S.directorSummaryBusy||getCompletedRoundCount(conv)<1) return;
  const token=++S.directorSummaryToken;
  const now=new Date();
  const scope=buildHistoryScopeFromChoice(conv,choice);
  const completedRounds=scope.rounds.length;
  const header=buildConversationSummaryHeaderMarkdown(conv,{now,rounds:scope.rounds});
  const rosterContext=buildConversationSummaryRosterContext(conv);
  const reserveTokens=estimateTextTokens(`${header}\n\n${rosterContext}\n\nGenerate a standalone markdown summary for the following conversation snapshot.`);
  const counterId=await reserveConversationArtifactId(conv,'summary');
  const snapshot={
    conv,
    completedRounds,
    generatedAt:now,
    fileName:getScopedSummaryFileName(conv,scope,counterId),
    header,
    rosterContext
  };
  S.directorSummaryBusy=true;
  refreshDirectorExportButtons();
  try{
    const fullTranscript=buildFullHistoryMarkdown(conv,{now,entries:buildScopedHistoryEntries(conv,scope)});
    const helperModel=ensureModelId(APP_SETTINGS.helperModel);
    const modelEntry=getOpenRouterModelEntry(helperModel);
    const contextLimit=Math.max(1,Number(modelEntry?.contextLength)||SUMMARY_CONTEXT_FALLBACK_TOKENS);
    const finalTargetTokens=Math.max(1,Math.floor(contextLimit*SUMMARY_CONTEXT_USAGE_RATIO)-reserveTokens);
    snapshot.transcript=fullTranscript;
    snapshot.transcriptTruncated=false;
    snapshot.transcriptSourceLabel='full export';
    if(estimateTextTokens(fullTranscript)>finalTargetTokens){
      try{
        const chunks=buildConversationSummaryChunks(conv,{now,rounds:scope.rounds});
        const chunkSummaries=await Promise.all(chunks.map((chunk,idx)=>requestHelperCompletion('',{
          system:buildConversationSummaryChunkSystemPrompt(),
          messages:[{role:'user',content:buildConversationSummaryChunkUserPrompt(snapshot,chunk,idx,chunks.length)}],
          suppressErrorDialog:true
        })));
        const intermediateTranscript=buildConversationSummaryIntermediateTranscript(chunks,chunkSummaries);
        if(estimateTextTokens(intermediateTranscript)<=finalTargetTokens){
          snapshot.transcript=intermediateTranscript;
          snapshot.transcriptTruncated=false;
          snapshot.transcriptSourceLabel='parallel chunk summaries covering the full conversation';
        }else{
          const transcriptInfo=buildConversationSummaryTranscript(conv,{now,reserveTokens,rounds:scope.rounds});
          snapshot.transcript=transcriptInfo.text;
          snapshot.transcriptTruncated=!!transcriptInfo.truncated;
          snapshot.transcriptSourceLabel='middle-truncated export fallback after chunk synthesis exceeded final context budget';
        }
      }catch(e){
        console.warn('Chunked conversation summary failed; falling back to middle-truncated export summary.',e);
        const transcriptInfo=buildConversationSummaryTranscript(conv,{now,reserveTokens,rounds:scope.rounds});
        snapshot.transcript=transcriptInfo.text;
        snapshot.transcriptTruncated=!!transcriptInfo.truncated;
        snapshot.transcriptSourceLabel='middle-truncated export fallback after chunk processing failed';
      }
    }
    const summary=stripConversationSummaryHeaderEcho(await requestHelperCompletion('',{
      system:buildConversationSummarySystemPrompt(),
      messages:[{role:'user',content:buildConversationSummaryUserPrompt(snapshot)}]
    }),snapshot);
    if(!summary) return false;
    if(token!==S.directorSummaryToken) return false;
    const markdownBody=`${snapshot.header}\n\n${summary}\n`;
    const htmlText=await buildSavedSummaryHtmlDocument(conv,markdownBody,`${(conv?.name||'Conversation').trim()||'Conversation'} -- Summary`);
    const ok=await saveConversationArtifact(CONV_DOWNLOADS_SUMMARIES_DIR,snapshot.fileName,htmlText);
    if(ok) await appAlert(`Saved ${snapshot.fileName} to this conversation's Results drawer.`,{title:'SUMMARY SAVED'});
    return true;
  }catch(e){
    return false;
  }finally{
    if(token===S.directorSummaryToken){
      S.directorSummaryBusy=false;
      refreshDirectorExportButtons();
    }
  }
}

function downloadConversationSummaryMd(event){
  const conv=S.conv;
  if(!conv) return;
  const popupItems=buildHistoryScopePopupItems(conv,{
    full:'Full Summary',
    upToHere:'Up To Here',
    fromHereOn:'From Here On'
  },{
    full:()=>saveScopedConversationSummary('full'),
    upToHere:()=>saveScopedConversationSummary('up-to-here'),
    fromHereOn:()=>saveScopedConversationSummary('from-here-on')
  });
  if(popupItems.length){
    const point=getPopupAnchorPoint(event,event?.currentTarget);
    showPopupMenu(point.x,point.y,popupItems);
    return;
  }
  void saveScopedConversationSummary('full');
}

function refreshAgentDownloadBtn(agentId){
  const c=S.conv;if(!c)return;
  const a=c.agents.find(x=>x.id===agentId);if(!a)return;
  const btn=document.getElementById('dl_'+agentId);if(!btn)return;
  const col=COLORS.find(x=>x.id===a.color)||COLORS[0];
  const hasContent=a.msgs.filter(m=>!m.isSep&&m.role!=='director').length>0;
  btn.style.opacity=hasContent?'1':'0.18';
  btn.style.color=hasContent?col.hex:'var(--text-dim)';
}

function toggleExpand(agentId){
  const c=S.conv;if(!c)return;
  const a=c.agents.find(x=>x.id===agentId);if(!a)return;

  // If this agent is already solo, collapse back to grid
  if(a.expanded){
    a.expanded=false;
    // Show all panels, restore grid layout
    c.agents.forEach(ag=>{
      const el=document.getElementById('ap_'+ag.id);
      if(el) el.style.display='';
    });
    const grid=document.getElementById('agent-grid');
    grid.style.display='grid';
    grid.style.gridTemplateColumns=`repeat(${c.agentCols||2},1fr)`;
    // Rebuild just this panel to update icon
    const old=document.getElementById('ap_'+agentId);
    if(old) old.replaceWith(buildAgentPanel(a,true));
  } else {
    // Collapse any other expanded agent first
    c.agents.forEach(ag=>{if(ag.expanded){ag.expanded=false;}});
    a.expanded=true;
    // Hide all other panels
    c.agents.forEach(ag=>{
      if(ag.id===agentId) return;
      const el=document.getElementById('ap_'+ag.id);
      if(el) el.style.display='none';
    });
    // Make grid single-column so solo panel fills it
    const grid=document.getElementById('agent-grid');
    grid.style.gridTemplateColumns='1fr';
    // Rebuild this panel to update icon
    const old=document.getElementById('ap_'+agentId);
    if(old) old.replaceWith(buildAgentPanel(a,true));
  }
  stoSave();
}

function toggleAgentActive(agentId){
  const c=S.conv;if(!c)return;
  const agent=c.agents.find(x=>x.id===agentId);if(!agent)return;
  const activeIds=getConversationActiveAgentIds(c);
  const currentlyActive=activeIds.includes(agentId);
  if(currentlyActive&&activeIds.length<=MIN_ACTIVE_AGENT_COUNT){
    void appAlert(`At least ${MIN_ACTIVE_AGENT_COUNT} active agents are required.`,{title:'MINIMUM AGENTS'});
    return;
  }
  const nextIds=currentlyActive
    ?activeIds.filter(id=>id!==agentId)
    :[...activeIds,agentId];
  setConversationActiveAgentIds(c,nextIds);
  renderAgentGrid();
  syncDirectorComposerUi();
  writeMetaFile();
}

function renderRouting(){ return; }
function getTargets(){
  return getConversationActiveAgentIds(S.conv);
}

// ── FILE ATTACHMENTS ──────────────────────────────────────────────
function isTextAttachmentType(mimeType,fileName){
  const mime=String(mimeType||'').toLowerCase();
  if(mime.startsWith('text/')) return true;
  if([
    'application/json',
    'application/javascript',
    'application/xml',
    'image/svg+xml'
  ].includes(mime)) return true;
  return /\.(txt|md|json|csv|js|ts|html|css|xml|yaml|yml|svg)$/i.test(String(fileName||''));
}
function filePayloadToAttachment(file){
  const type=String(file?.mimeType||'application/octet-stream');
  if(type.startsWith('image/')||type==='application/pdf'||!isTextAttachmentType(type,file?.name||'')){
    return{
      name:String(file?.name||'file'),
      type,
      data:`data:${type};base64,${String(file?.base64||'')}`
    };
  }
  return{
    name:String(file?.name||'file'),
    type,
    data:decodeBytesToText(base64ToBytes(String(file?.base64||'')))
  };
}
async function triggerFile(){
  try{
    const picked=await openFsPicker({
      mode:'file',
      title:'SELECT FILES (for upload)',
      confirmLabel:'Attach Files'
    });
    if(!picked?.paths?.length) return;
    const payload=await fsReadMany(picked.paths);
    const errors=Array.isArray(payload?.errors)?payload.errors:[];
    if(errors.length){
      const first=errors[0];
      await appAlert(first?.message||'Could not read one or more selected files.',{title:'FILES'});
      return;
    }
    const files=Array.isArray(payload?.files)?payload.files:[];
    files.forEach(file=>{
      S.attachments.push(filePayloadToAttachment(file));
    });
    if(picked.currentPath) fsPickerStorageSet(UPLOAD_FOLDER_STORAGE_KEY,picked.currentPath);
    renderAttStrip();
  }catch(e){
    await appAlert(e.message||'Could not attach files.',{title:'FILES'});
  }
}
function renderAttStrip(){
  const el=document.getElementById('att-strip');el.innerHTML='';
  S.attachments.forEach((f,i)=>{
    const chip=document.createElement('div');chip.className='att-chip';
    chip.innerHTML=`<span style="opacity:0.5;font-size:10px">clip</span> <span>${esc(f.name)}</span><span class="chip-x" onclick="removeAtt(${i})">✕</span>`;
    el.appendChild(chip);
  });
}
function removeAtt(i){S.attachments.splice(i,1);renderAttStrip();}

// ── RESULTS ───────────────────────────────────────────────────────
// Registry: [{name, url, ext, agentName, agentColor, ts}]

const DL_EXTENSIONS = /\.(md|txt|py|js|ts|json|csv|html|css|sh|bat|svg|xml|yaml|yml|pdf|zip|png|jpg|jpeg|gif|webp|mp3|mp4|wav)$/i;
const DL_DELIM_RE  = /<<<\s*DOWNLOAD\s*:\s*([\w\-. ]+?)\s*>>>([\s\S]*?)(?:<<<\s*END\s*>>>|$)/gi;
const URL_SUMMARY_RE = /<<<\s*URLSUMMARY\s*>>>([\s\S]*?)<<<\s*END_SUMMARY\s*>>>/gi;

function parseUrlSummariesFromText(rawText){
  const out=[];
  const src=String(rawText||'');
  let m;
  URL_SUMMARY_RE.lastIndex=0;
  while((m=URL_SUMMARY_RE.exec(src))!==null){
    const summary=String(m[1]||'').trim();
    if(summary) out.push(summary);
  }
  return out;
}

function stripUrlSummaryBlocks(rawText){
  const re=new RegExp(URL_SUMMARY_RE.source,'gi');
  return String(rawText||'').replace(re,'').replace(/\n{3,}/g,'\n\n').trim();
}

function normalizeToolUseEntry(raw){
  if(!raw||typeof raw!=='object') return null;
  const type=raw?.type==='read_url'?'read_url':'web_search';
  if(type==='read_url'){
    return{
      type,
      url:sanitizeExternalToolText(raw?.url||''),
      title:sanitizeExternalToolText(raw?.title||''),
      contentLength:Math.max(0,parseInt(raw?.contentLength,10)||0),
      summary:sanitizeExternalToolText(raw?.summary||'')
    };
  }
  return{
    type,
    query:sanitizeExternalToolText(raw?.query||''),
    results:normalizeWebSearchResults(raw?.results)
  };
}

function attachUrlSummariesToToolUse(toolUse,rawText){
  const entries=(Array.isArray(toolUse)?toolUse:[]).map(entry=>normalizeToolUseEntry(entry)).filter(Boolean);
  const summaries=parseUrlSummariesFromText(rawText);
  let readIdx=0;
  return entries.map(entry=>{
    if(entry.type==='read_url'){
      if(summaries[readIdx]) entry.summary=entry.summary||sanitizeExternalToolText(summaries[readIdx]);
      readIdx++;
    }
    return entry;
  });
}

function getMessageToolUse(msg){
  return attachUrlSummariesToToolUse(msg?.toolUse||[],msg?.content||'');
}

function getReadableUrlLabel(url){
  const src=String(url||'').trim();
  if(!src) return'';
  try{
    const parsed=new URL(src);
    const label=(parsed.host+parsed.pathname).replace(/\/$/,'');
    return label.length>72?(label.slice(0,69)+'...'):label;
  }catch(e){
    return src.length>72?(src.slice(0,69)+'...'):src;
  }
}

function getAgentToolPreviewId(agentId){
  return 'ae_tool_preview_'+agentId;
}

function updateAgentToolPreview(logEl,agentId,toolUse){
  if(!logEl) return;
  const html=renderToolUseHtml(toolUse,true);
  const id=getAgentToolPreviewId(agentId);
  let preview=document.getElementById(id);
  if(!html){
    if(preview) preview.remove();
    return;
  }
  if(!preview){
    preview=document.createElement('div');
    preview.className='a-entry';
    preview.id=id;
    logEl.appendChild(preview);
  }
  preview.innerHTML=`<div class="e-role" style="color:var(--teal)">Live Research Activity</div>${html}`;
  logEl.scrollTop=logEl.scrollHeight;
}

function removeAgentToolPreview(agentId){
  document.getElementById(getAgentToolPreviewId(agentId))?.remove();
}

function buildToolUseContextText(toolUse){
  const lines=[];
  (Array.isArray(toolUse)?toolUse:[]).map(entry=>normalizeToolUseEntry(entry)).filter(Boolean).forEach(entry=>{
    if(entry.type==='web_search'){
      if(!entry.query) return;
      lines.push(`[Web search] Query: ${entry.query}`);
      entry.results.forEach((result,idx)=>{
        const parts=[`${idx+1}.`];
        if(result.title) parts.push(result.title);
        if(result.url) parts.push(result.url);
        if(result.snippet) parts.push(result.snippet);
        lines.push(parts.join(' — '));
      });
      return;
    }
    if(!entry.url) return;
    lines.push(`[Read URL] ${entry.url}`);
    if(entry.summary){
      lines.push('<<<URLSUMMARY>>>');
      lines.push(entry.summary);
      lines.push('<<<END_SUMMARY>>>');
    }
  });
  return lines.join('\n');
}

function buildAgentContextResponseText(msg){
  const toolText=buildToolUseContextText(getMessageToolUse(msg));
  const body=stripUrlSummaryBlocks(String(msg?.content||'')).trim();
  return[toolText,body].filter(Boolean).join('\n\n');
}

function renderToolUseHtml(toolUseOrMsg,preview=false){
  const isMsg=!!toolUseOrMsg&&typeof toolUseOrMsg==='object'&&(
    Object.prototype.hasOwnProperty.call(toolUseOrMsg,'toolUse')||
    Object.prototype.hasOwnProperty.call(toolUseOrMsg,'content')
  );
  const entries=isMsg?getMessageToolUse(toolUseOrMsg):attachUrlSummariesToToolUse(toolUseOrMsg,'');
  if(!entries.length) return'';
  const blocks=entries.map(entry=>{
    if(entry.type==='web_search'){
      const results=Array.isArray(entry.results)?entry.results:[];
      const shown=results.slice(0,5);
      const hidden=results.slice(5);
      const renderResult=result=>{
        const label=esc(result.title||getReadableUrlLabel(result.url));
        const urlLabel=result.url?` <span class="tool-use-result-url">— ${esc(getReadableUrlLabel(result.url))}</span>`:'';
        const snippet=result.snippet?` <span class="tool-use-result-snippet">— ${esc(result.snippet)}</span>`:'';
        const safe=result.url?mdSafeHref(result.url):'';
        if(!safe) return `<div class="tool-use-result"><span class="tool-use-result-title">${label}</span>${urlLabel}${snippet}</div>`;
        return `<div class="tool-use-result"><a class="tool-use-result-link" href="${esc(safe)}" target="_blank" rel="noopener noreferrer"><span class="tool-use-result-title">${label}</span>${urlLabel}${snippet}</a></div>`;
      };
      const hiddenHtml=hidden.length?`<details><summary>${hidden.length} more results</summary><div class="tool-use-summary-body">${hidden.map(renderResult).join('')}</div></details>`:'';
      return`<div class="tool-use-block"><div class="tool-use-line">🔍 Searched: "${esc(entry.query)}"</div><div class="tool-use-results">${shown.map(renderResult).join('')}${hiddenHtml}</div></div>`;
    }
    const summaryHtml=entry.summary?`<details><summary>Summary</summary><div class="tool-use-summary-body">${renderCompactTextHtml(entry.summary)}</div></details>`:'';
    const safe=entry.url?mdSafeHref(entry.url):'';
    const readLabel=esc(getReadableUrlLabel(entry.url)||entry.url);
    const readHtml=safe
      ? `<a href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${readLabel}</a>`
      : readLabel;
    return`<div class="tool-use-block"><div class="tool-use-line">📄 Read: ${readHtml}</div>${summaryHtml}</div>`;
  });
  return `<div class="tool-use${preview?' tool-use-preview':''}">${blocks.join('')}</div>`;
}

function extIcon(ext){
  const e=ext.toLowerCase();
  if(['png','jpg','jpeg','gif','webp','svg'].includes(e)) return '🖼';
  if(['mp3','wav','ogg'].includes(e)) return '🎵';
  if(['mp4','webm'].includes(e)) return '🎬';
  if(['pdf'].includes(e)) return '📄';
  if(['zip','tar','gz'].includes(e)) return '📦';
  if(['py','js','ts','sh','bat'].includes(e)) return '💻';
  if(['json','yaml','yml','xml','csv'].includes(e)) return '📊';
  return '📄';
}

function getConversationDownloadsReconcileKey(convLike){
  if(!convLike) return '';
  const uuid=String(convLike.uuid||convLike.id||'').trim();
  if(uuid) return uuid;
  return String(convLike.path||convLike.sourcePath||'').trim();
}

function areConversationDownloadsReconciled(convLike){
  const key=getConversationDownloadsReconcileKey(convLike);
  return !!(key&&S.downloadsReconciledByConvUuid?.[key]);
}

function markConversationDownloadsReconciled(convLike){
  const key=getConversationDownloadsReconcileKey(convLike);
  if(!key) return;
  S.downloadsReconciledByConvUuid[key]=true;
}

function parseDownloads(rawText, agentName, agentColor){
  const found=[];
  let m;
  let delimIndex=0;
  // Delimiter-wrapped content blocks
  DL_DELIM_RE.lastIndex=0;
  while((m=DL_DELIM_RE.exec(rawText))!==null){
    const filename=m[1].trim();
    const content=m[2];
    const ext=filename.split('.').pop()||'txt';
    const blob=new Blob([content],{type:'text/plain'});
    const url=URL.createObjectURL(blob);
    found.push({
      name:filename,url,ext,blob:true,type:'delimiter',matchIndex:delimIndex++,content,
      agentName,agentColor,ts:Date.now()
    });
  }
  return found;
}

function stripDownloadDelimiters(rawText){
  const re=new RegExp(DL_DELIM_RE.source,'gi');
  return String(rawText||'').replace(re,'').trim();
}

function parseDownloadPointerCandidates(rawText){
  const out=[];
  let m;
  let delimIndex=0;
  const src=String(rawText||'');
  DL_DELIM_RE.lastIndex=0;
  while((m=DL_DELIM_RE.exec(src))!==null){
    const filename=String(m[1]||'').trim();
    if(!filename) continue;
    out.push({type:'delimiter',filename,matchIndex:delimIndex++});
  }
  return out;
}

function buildDownloadPointer(item,meta={}){
  const pointer={
    filename:String(item?.name||item?.filename||'').trim(),
    type:item?.type==='url'?'url':'delimiter',
    sourceLog:String(meta.sourceLog||'').trim(),
    agentId:String(meta.agentId||'').trim(),
    agentName:String(meta.agentName||'').trim(),
    agentColor:String(meta.agentColor||'').trim(),
    round:Number(meta.round)||0,
    responseTs:Number(meta.responseTs)||0,
    matchIndex:Number(item?.matchIndex)||0,
    ts:Number(meta.responseTs)||Date.now()
  };
  if(pointer.type==='url') pointer.url=String(item?.url||'').trim();
  return pointer;
}

function downloadPointerSlotSignature(pointer){
  const type=(pointer?.type==='url')?'url':'delimiter';
  return [
    String(pointer?.sourceLog||'').trim(),
    String(pointer?.agentId||pointer?.agentName||'').trim(),
    String(Number(pointer?.responseTs)||0),
    type,
    String(Number(pointer?.matchIndex)||0)
  ].join('|');
}

function getDownloadPointerFileName(pointer){
  const sourceBase=String(pointer?.sourceLog||'log').replace(/\.json$/i,'');
  const agentKey=sanitizeTitleForFs(pointer?.agentId||pointer?.agentName||'agent',32)||'agent';
  const typeKey=(pointer?.type==='url')?'url':'file';
  const matchKey=String(Math.max(0,Number(pointer?.matchIndex)||0)).padStart(2,'0');
  const fileKey=sanitizeTitleForFs(pointer?.filename||'download',96)||'download';
  const base=sanitizeTitleForFs(`${sourceBase}__${agentKey}__${typeKey}_${matchKey}__${fileKey}`,180)||'download';
  return base+'.json';
}

async function ensureDownloadPointerFile(downloadsDir,pointer){
  if(!downloadsDir||!pointer?.filename||!pointer?.sourceLog) return false;
  const desiredFileName=getDownloadPointerFileName(pointer);
  const targetSlot=downloadPointerSlotSignature(pointer);
  let fileName=desiredFileName;
  let existingData=null;
  for await(const [name,handle] of downloadsDir.entries()){
    if(handle.kind!=='file'||!name.endsWith('.json')) continue;
    try{
      const file=await handle.getFile();
      const data=JSON.parse(await file.text());
      const sameSlot=downloadPointerSlotSignature(data)===targetSlot;
      if(name===desiredFileName||sameSlot){
        fileName=name;
        existingData=data;
        break;
      }
    }catch(e){}
  }
  if(existingData&&JSON.stringify(existingData)===JSON.stringify(pointer)) return false;
  await writeJsonFile(downloadsDir,fileName,pointer);
  return true;
}

async function ensureDownloadPointersForItems(downloadsDir,items,meta={}){
  if(!downloadsDir||!Array.isArray(items)||!items.length) return 0;
  let created=0;
  for(const item of items){
    const pointer=buildDownloadPointer(item,meta);
    if(await ensureDownloadPointerFile(downloadsDir,pointer)) created++;
  }
  return created;
}

function downloadPointerSignature(pointer){
  const type=(pointer?.type==='url')?'url':'delimiter';
  return [
    String(pointer?.sourceLog||''),
    String(pointer?.agentId||''),
    String(Number(pointer?.responseTs)||0),
    type,
    String(Number(pointer?.matchIndex)||0),
    String(pointer?.filename||'').trim(),
    type==='url'?String(pointer?.url||'').trim():''
  ].join('|');
}

function registerDownloads(items){
  if(!Array.isArray(items)||!items.length) return;
  S.downloads.push(...items);
  refreshDownloadsDrawer();
}

function openRuntimeDownloadItem(item,event){
  if(!item) return;
  if(item.type==='url'){
    if(item.url) openExternalUrlWithFullscreenRestore(item.url);
    return;
  }
  const point=getPopupAnchorPoint(event,event?.currentTarget);
  showPopupMenu(point.x,point.y,[
    {
      label:'View',
      onSelect:()=>openTextDownloadViewer({
        name:item.name,
        text:item.content||'',
        isHtml:/\.html?$/i.test(item.name||''),
        mime:/\.html?$/i.test(item.name||'')
          ? 'text/html;charset=utf-8'
          : (/\.(?:md|markdown)$/i.test(item.name||'')?'text/markdown;charset=utf-8':'text/plain;charset=utf-8')
      })
    }
  ]);
}

function triggerDownload(idx,event){
  const item=S.downloads[idx];
  if(!item)return;
  openRuntimeDownloadItem(item,event);
}

function refreshDownloadsDrawer(){
  const tab=document.getElementById('tab-downloads');
  if(tab&&!tab.classList.contains('active')) tab.style.color='';
}

async function writeDownloadPointersForAgentResponse(conv,agent,agentMsg,dirMsg,items){
  if(!conv||!agent||!agentMsg||!dirMsg||!Array.isArray(items)||!items.length) return'';
  try{
    const convDir=conv.folderHandle||await treeGetDirectoryHandleByPath(CONV_TREE_VIEW,conv.sourcePath||'');
    if(!convDir) return;
    const downloadsDir=await convDir.getDirectoryHandle(CONV_DOWNLOADS_DIR,{create:true});
    const sourceLog=buildRoundLogFileName({
      round:agentMsg.round||dirMsg.num||conv.msgCount||0,
      ts:dirMsg.ts,
      director:{content:dirMsg.content}
    });
    const col=COLORS.find(c=>c.id===agent.color)||COLORS[0];
    const agentName=getAgentMessageSpeakerLabel(agent,agentMsg);
    await ensureDownloadPointersForItems(downloadsDir,items,{
      sourceLog,
      agentId:agent.id,
      agentName,
      agentColor:col.hex,
      round:agentMsg.round||dirMsg.num||0,
      responseTs:agentMsg.ts
    });
    markConversationDownloadsReconciled(conv);
    if(S.drawerTab==='downloads'){
      const convPath=conv?.sourcePath||'';
      if(convPath){
        const synced=await syncDownloadsForConversationPath(convPath,{render:true,reconcile:false});
        if(!synced) await scanDownloadsTree();
      }else{
        await scanDownloadsTree();
      }
    }
    return'';
  }catch(e){
    console.warn('Could not write download pointers for agent response:',e);
    return'Download metadata for this response could not be saved.';
  }
}

function getDownloadItemKind(item){
  if(item?.itemType) return item.itemType;
  return item?.pointer?.type==='url'?'url':'file';
}

function getDownloadItemLabel(item){
  const kind=getDownloadItemKind(item);
  if(kind==='url') return'URL';
  if(kind==='summary') return'SUMMARY';
  if(kind==='image') return'IMAGE';
  if(kind==='log') return'LOG';
  return'FILE';
}

function getDownloadItemIcon(item){
  const kind=getDownloadItemKind(item);
  if(kind==='url') return'🔗';
  if(kind==='summary') return'📝';
  if(kind==='image') return'🖼';
  if(kind==='log') return'📋';
  return'📄';
}

function canDeleteDownloadItem(item){
  return ['summary','image','log'].includes(getDownloadItemKind(item));
}

async function getExistingDownloadSubdir(downloadsDir,subdir){
  try{
    return await downloadsDir.getDirectoryHandle(subdir,{create:false});
  }catch(e){
    return null;
  }
}

async function readWorkspaceArtifactEntriesFromDir(convNode,dir,subdir,itemType){
  const items=[];
  for await(const [name,handle] of dir.entries()){
    if(handle.kind!=='file') continue;
    if(itemType!=='image'&&!/\.html?$/i.test(name)) continue;
    try{
      const file=await handle.getFile();
      items.push({
        key:`${convNode.path}/${subdir}/${name}`,
        name,
        ext:(name.split('.').pop()||'txt').toLowerCase(),
        itemType,
        fileName:name,
        artifactDirHandle:dir,
        fileHandle:handle,
        mtime:Number(file.lastModified)||0
      });
    }catch(e){}
  }
  return items;
}

async function readWorkspaceArtifactEntries(convNode,downloadsDir,subdir,itemType){
  const dir=await getExistingDownloadSubdir(downloadsDir,subdir);
  if(!dir) return [];
  return readWorkspaceArtifactEntriesFromDir(convNode,dir,subdir,itemType);
}

async function readImageArtifactEntriesFromDir(convNode,dir,relativeDir=''){
  const promptMap=new Map();
  const imageHandles=[];
  for await(const [name,handle] of dir.entries()){
    if(handle.kind!=='file') continue;
    if(/^settings\.json$/i.test(name)) continue;
    const promptMatch=String(name||'').match(/^(summary|scratch)-prompt__(\d{3,})\.json$/i);
    if(promptMatch){
      try{
        const mode=promptMatch[1].toLowerCase()==='summary'?'from-summary':'from-scratch';
        const promptId=String(promptMatch[2]||'').padStart(3,'0');
        const imageBase=buildImageRenderFileName(mode,promptId).replace(new RegExp(`\\.${IMAGE_OUTPUT_FILE_EXTENSION}$`,'i'),'');
        const data=await readJsonFile(handle);
        promptMap.set(imageBase,{data,fileName:name});
      }catch(e){}
      continue;
    }
    if(new RegExp(`^(summary|scratch)-image__\\d{3,}\\.${IMAGE_OUTPUT_FILE_EXTENSION}$`,'i').test(name)){
      imageHandles.push({name,handle});
    }
  }
  const items=[];
  for(const entry of imageHandles){
    const base=entry.name.replace(new RegExp(`\\.${IMAGE_OUTPUT_FILE_EXTENSION}$`,'i'),'');
    const prompt=promptMap.get(base);
    if(!prompt?.data||!imagePromptHasSavedImage(prompt.data)){
      console.warn('Skipping stale image artifact without locked prompt JSON:',entry.name);
      continue;
    }
    try{
      const file=await entry.handle.getFile();
      items.push({
        key:`${convNode.path}/${CONV_DOWNLOADS_IMAGES_DIR}/${joinImageStoragePath(relativeDir,entry.name)}`,
        name:entry.name,
        ext:IMAGE_OUTPUT_FILE_EXTENSION,
        itemType:'image',
        fileName:entry.name,
        artifactDirHandle:dir,
        fileHandle:entry.handle,
        promptFileName:prompt.fileName,
        promptFilePath:joinImageStoragePath(relativeDir,prompt.fileName),
        imagePath:joinImageStoragePath(relativeDir,entry.name),
        promptData:prompt.data,
        mtime:Number(file.lastModified)||0
      });
    }catch(e){}
  }
  return items;
}

async function readImageArtifactEntries(convNode,downloadsDir){
  const dir=await getExistingDownloadSubdir(downloadsDir,CONV_DOWNLOADS_IMAGES_DIR);
  if(!dir) return [];
  return readImageArtifactEntriesFromDir(convNode,dir,'');
}

async function readDownloadPointerEntries(convNode,downloadsDirHandle=null){
  if(!convNode?.folderHandle&&!downloadsDirHandle) return [];
  const downloadsDir=downloadsDirHandle||await getExistingDownloadSubdir(convNode.folderHandle,CONV_DOWNLOADS_DIR);
  if(!downloadsDir) return [];
  const items=[];
  const seen=new Set();
  for await(const [name,handle] of downloadsDir.entries()){
    if(handle.kind!=='file'||!name.endsWith('.json')) continue;
    try{
      const file=await handle.getFile();
      const data=JSON.parse(await file.text());
      if(String(data?.type||'').toLowerCase()==='url') continue;
      const sig=downloadPointerSignature(data);
      if(sig){
        if(seen.has(sig)) continue;
        seen.add(sig);
      }
      const fileName=String(data.filename||name.replace(/\.json$/i,'')).trim()||name;
      const ext=(fileName.split('.').pop()||'txt').toLowerCase();
      items.push({
        key:`${convNode.path}/${name}`,
        name:fileName,
        ext,
        itemType:'file',
        pointer:data,
        pointerFileName:name,
        downloadsDirHandle:downloadsDir,
        mtime:Number(file.lastModified)||Number(data?.ts)||0
      });
    }catch(e){}
  }
  items.sort((a,b)=>(Number(b.mtime)||0)-(Number(a.mtime)||0)||String(a.name||'').localeCompare(String(b.name||'')));
  return items;
}

async function readDownloadArtifactGroups(convNode,downloadsDir){
  if(!downloadsDir) return [];
  const groups=[];
  const summaryDir=await getExistingDownloadSubdir(downloadsDir,CONV_DOWNLOADS_SUMMARIES_DIR);
  if(summaryDir){
    const items=await readWorkspaceArtifactEntriesFromDir(convNode,summaryDir,CONV_DOWNLOADS_SUMMARIES_DIR,'summary');
    items.sort((a,b)=>(Number(b.mtime)||0)-(Number(a.mtime)||0)||String(a.name||'').localeCompare(String(b.name||'')));
    groups.push({path:`${convNode.path}/${CONV_DOWNLOADS_SUMMARIES_DIR}`,displayName:'summaries',items,childGroups:[],hasContentsHint:items.length>0});
  }
  const logsDir=await getExistingDownloadSubdir(downloadsDir,CONV_DOWNLOADS_LOGS_DIR);
  if(logsDir){
    const items=await readWorkspaceArtifactEntriesFromDir(convNode,logsDir,CONV_DOWNLOADS_LOGS_DIR,'log');
    items.sort((a,b)=>(Number(b.mtime)||0)-(Number(a.mtime)||0)||String(a.name||'').localeCompare(String(b.name||'')));
    groups.push({path:`${convNode.path}/${CONV_DOWNLOADS_LOGS_DIR}`,displayName:'logs',items,childGroups:[],hasContentsHint:items.length>0});
  }
  const imagesDir=await getExistingDownloadSubdir(downloadsDir,CONV_DOWNLOADS_IMAGES_DIR);
  if(imagesDir){
    const rootItems=await readImageArtifactEntriesFromDir(convNode,imagesDir,'');
    rootItems.sort((a,b)=>(Number(b.mtime)||0)-(Number(a.mtime)||0)||String(a.name||'').localeCompare(String(b.name||'')));
    const childGroups=[];
    for await(const [name,handle] of imagesDir.entries()){
      if(handle.kind!=='directory'||!isSummaryFamilyDirName(name)) continue;
      const items=await readImageArtifactEntriesFromDir(convNode,handle,name);
      items.sort((a,b)=>(Number(b.mtime)||0)-(Number(a.mtime)||0)||String(a.name||'').localeCompare(String(b.name||'')));
      let hasPromptFiles=false;
      for await(const [childName,childHandle] of handle.entries()){
        if(childHandle.kind==='file'&&/^summary-prompt__\d{3,}\.json$/i.test(childName)){
          hasPromptFiles=true;
          break;
        }
      }
      if(!items.length&&!hasPromptFiles) continue;
      childGroups.push({
        path:`${convNode.path}/${CONV_DOWNLOADS_IMAGES_DIR}/${name}`,
        displayName:name,
        items,
        childGroups:[],
        hasContentsHint:hasPromptFiles||items.length>0
      });
    }
    childGroups.sort((a,b)=>Number(parseSummaryFamilyId(a.displayName)||0)-Number(parseSummaryFamilyId(b.displayName)||0));
    if(rootItems.length||childGroups.length){
      groups.push({
        path:`${convNode.path}/${CONV_DOWNLOADS_IMAGES_DIR}`,
        displayName:'images',
        items:rootItems,
        childGroups,
        hasContentsHint:rootItems.length>0||childGroups.length>0
      });
    }
  }
  return groups;
}

function mapConvTreeNodeToDownloadsNode(node,prevIndex,nextIndex){
  if(!node) return null;
  if(node.type==='category'){
    const mapped={
      type:'category',
      name:node.name,
      path:node.path,
      parentPath:node.parentPath||'',
      folderHandle:node.folderHandle,
      displayName:node.displayName,
      children:[]
    };
    mapped.children=(node.children||[])
      .map(child=>mapConvTreeNodeToDownloadsNode(child,prevIndex,nextIndex))
      .filter(Boolean);
    nextIndex[mapped.path]=mapped;
    return mapped;
  }
  if(node.type==='conversation'){
    const prev=prevIndex?.[node.path];
    const mapped={
      type:'conversation',
      name:node.name,
      path:node.path,
      parentPath:node.parentPath||'',
      folderHandle:node.folderHandle,
      uuid:node.uuid||node.id||node.path,
      displayName:node.displayName,
      downloads:Array.isArray(prev?.downloads)?prev.downloads:[],
      downloadGroups:Array.isArray(prev?.downloadGroups)?prev.downloadGroups:[],
      hasArtifactFolders:prev?.hasArtifactFolders===true
    };
    nextIndex[mapped.path]=mapped;
    return mapped;
  }
  return null;
}

function rebuildDownloadsTreeFromConversationTree(){
  const prevIndex=S.downloadsTreeIndex||{};
  const nextIndex={};
  const rootNodes=(S.convTree||[])
    .map(node=>mapConvTreeNodeToDownloadsNode(node,prevIndex,nextIndex))
    .filter(Boolean);
  S.downloadsTree=rootNodes;
  S.downloadsTreeIndex=nextIndex;
  if(S.downloadsTreeSelectedPath&&!nextIndex[S.downloadsTreeSelectedPath]){
    S.downloadsTreeSelectedPath='';
  }
  const nextExpanded={};
  Object.entries(S.downloadsTreeExpanded||{}).forEach(([path,open])=>{
    if(nextIndex[path]){
      nextExpanded[path]=!!open;
      return;
    }
    const m=String(path||'').match(/^(.*)\/(summaries|logs|images)$/);
    if(m&&nextIndex[m[1]]) nextExpanded[path]=!!open;
  });
  S.downloadsTreeExpanded=nextExpanded;
}

async function conversationHasArtifactFolders(node){
  if(!node?.folderHandle) return false;
  let downloadsDir=null;
  try{
    downloadsDir=await node.folderHandle.getDirectoryHandle(CONV_DOWNLOADS_DIR,{create:false});
  }catch(e){
    return false;
  }
  for(const subdir of [CONV_DOWNLOADS_SUMMARIES_DIR,CONV_DOWNLOADS_LOGS_DIR,CONV_DOWNLOADS_IMAGES_DIR]){
    try{
      await downloadsDir.getDirectoryHandle(subdir,{create:false});
      return true;
    }catch(e){}
  }
  return false;
}

async function hydrateDownloadsTreeFolderHints(){
  const nodes=Object.values(S.downloadsTreeIndex||{}).filter(node=>node?.type==='conversation');
  await Promise.all(nodes.map(async node=>{
    node.hasArtifactFolders=await conversationHasArtifactFolders(node);
  }));
}

async function reconcileConversationDownloadPointers(convNode){
  if(!convNode?.folderHandle) return false;
  let logsDir=null;
  try{
    logsDir=await convNode.folderHandle.getDirectoryHandle(CONV_LOGS_DIR,{create:false});
  }catch(e){return true;}
  let downloadsDirPromise=null;
  const getDownloadsDir=()=>{
    if(!downloadsDirPromise){
      downloadsDirPromise=convNode.folderHandle.getDirectoryHandle(CONV_DOWNLOADS_DIR,{create:true});
    }
    return downloadsDirPromise;
  };

  const colorByAgentId={};
  if(S.conv?.sourcePath===convNode.path&&Array.isArray(S.conv.agents)){
    (S.conv.agents||[]).forEach(agent=>{
      const col=COLORS.find(c=>c.id===agent.color)||COLORS[0];
      if(agent?.id) colorByAgentId[String(agent.id)]=col.hex;
    });
  }

  const logFiles=[];
  for await(const [name,handle] of logsDir.entries()){
    if(handle.kind!=='file'||!name.endsWith('.json')) continue;
    if(!/^\d{4}_/.test(name)) continue;
    logFiles.push({name,handle});
  }
  logFiles.sort((a,b)=>a.name.localeCompare(b.name));

  for(const lf of logFiles){
    let roundData=null;
    try{
      const f=await lf.handle.getFile();
      roundData=JSON.parse(await f.text());
    }catch(e){continue;}
    const responses=Array.isArray(roundData?.responses)?roundData.responses:[];
    for(const resp of responses){
      const content=String(resp?.content||'');
      if(!content) continue;
      const candidates=parseDownloadPointerCandidates(content);
      if(!candidates.length) continue;
      const downloadsDir=await getDownloadsDir();
      await ensureDownloadPointersForItems(downloadsDir,candidates,{
        sourceLog:lf.name,
        agentId:String(resp?.agentId||''),
        agentName:String(resp?.agentName||''),
        agentColor:colorByAgentId[String(resp?.agentId||'')]||'',
        round:Number(roundData?.round)||0,
        responseTs:Number(resp?.ts)||0
      });
    }
  }
  return true;
}

async function syncDownloadsForConversationPath(path,opts={}){
  const node=path?S.downloadsTreeIndex?.[path]:null;
  if(!node||node.type!=='conversation') return false;
  try{
    if(!node.folderHandle){
      const convNode=S.convTreeIndex?.[path];
      if(convNode?.folderHandle) node.folderHandle=convNode.folderHandle;
      if(convNode?.uuid&&!node.uuid) node.uuid=convNode.uuid;
    }
    const shouldReconcile=opts.reconcile===true||(opts.reconcile!==false&&!areConversationDownloadsReconciled(node));
    if(shouldReconcile){
      const reconciled=await reconcileConversationDownloadPointers(node);
      if(reconciled) markConversationDownloadsReconciled(node);
    }
    const downloadsDir=await getExistingDownloadSubdir(node.folderHandle,CONV_DOWNLOADS_DIR);
    node.downloads=downloadsDir?await readDownloadPointerEntries(node,downloadsDir):[];
    node.downloadGroups=downloadsDir?await readDownloadArtifactGroups(node,downloadsDir):[];
    if(opts.expand!==false&&(node.downloads.length||node.downloadGroups.length)){
      S.downloadsTreeExpanded[node.path]=true;
    }
  }catch(e){
    node.downloads=[];
    node.downloadGroups=[];
  }
  if(opts.render!==false) renderDownloadsTree();
  return Array.isArray(node.downloads);
}

async function syncSelectedDownloadsConversation(opts={}){
  const path=S.downloadsTreeSelectedPath||'';
  if(!path) return false;
  return syncDownloadsForConversationPath(path,opts);
}

async function scanDownloadsTree(){
  if(!S.fsRoot){
    S.downloadsTree=[];
    S.downloadsTreeIndex={};
    renderDownloadsTree();
    return;
  }
  rebuildDownloadsTreeFromConversationTree();
  await hydrateDownloadsTreeFolderHints();
  await syncSelectedDownloadsConversation({render:false});
  renderDownloadsTree();
}

async function refreshAllPanelsFromDisk(){
  if(!S.workspaceReady) return;
  await scanConvFolders();
  await scanPersonaFolders();
  if(S.drawerTab==='downloads'){
    if(S.conv?.sourcePath) treeSelectPath(DOWNLOADS_TREE_VIEW,S.conv.sourcePath);
    await scanDownloadsTree();
  }
}

async function promptDeleteStaleDownloadEntry(item,message){
  const del=await appConfirm(message+'\n\nDelete this download entry?',{title:'DELETE DOWNLOAD ENTRY',okLabel:'Delete'});
  if(!del) return;
  try{
    await item.downloadsDirHandle?.removeEntry(item.pointerFileName,{recursive:false});
  }catch(e){
    await appAlert('Could not delete download entry.');
  }
  await scanDownloadsTree();
}

async function resolveDelimiterContentFromPointer(convNode,item){
  const p=item?.pointer||{};
  if(!convNode?.folderHandle||!p.sourceLog) return null;
  let logsDir=null;
  try{logsDir=await convNode.folderHandle.getDirectoryHandle(CONV_LOGS_DIR,{create:false});}
  catch(e){return null;}
  let logFile=null;
  try{
    const fh=await logsDir.getFileHandle(String(p.sourceLog),{create:false});
    logFile=await fh.getFile();
  }catch(e){return null;}
  let round=null;
  try{round=JSON.parse(await logFile.text());}catch(e){return null;}
  const responses=Array.isArray(round?.responses)?round.responses:[];
  const targetTs=Number(p.responseTs)||0;
  let resp=responses.find(r=>String(r?.agentId||'')===String(p.agentId||'')&&Number(r?.ts||0)===targetTs);
  if(!resp&&p.agentId) resp=responses.find(r=>String(r?.agentId||'')===String(p.agentId||''));
  if(!resp&&p.agentName) resp=responses.find(r=>String(r?.agentName||'')===String(p.agentName||''));
  if(!resp||!resp.content) return null;
  const re=new RegExp(DL_DELIM_RE.source,'gi');
  const matches=[];
  let m;
  while((m=re.exec(String(resp.content)))!==null) matches.push(m);
  if(!matches.length) return null;
  let idx=Math.max(0,Number(p.matchIndex)||0);
  if(matches[idx]&&String(matches[idx][1]||'').trim()===String(p.filename||'').trim()){
    return matches[idx][2];
  }
  const byName=matches.find(x=>String(x[1]||'').trim()===String(p.filename||'').trim());
  if(byName) return byName[2];
  if(matches[idx]) return matches[idx][2];
  return null;
}

async function openPersistentDownloadItem(convNode,item,event=null){
  return openPersistentDownloadItemWithEvent(convNode,item,event);
}

async function viewPersistentDownloadItem(convNode,item){
  const kind=getDownloadItemKind(item);
  if(kind==='file'){
    const content=await resolveDelimiterContentFromPointer(convNode,item);
    if(content===null){
      await promptDeleteStaleDownloadEntry(item,'This delimiter download entry appears invalid or stale.');
      return;
    }
      openTextDownloadViewer({
        name:item.name,
        text:content,
        isHtml:/\.html?$/i.test(item.name||''),
        mime:/\.html?$/i.test(item.name||'')
          ? 'text/html;charset=utf-8'
        : (/\.(?:md|markdown)$/i.test(item.name||'')?'text/markdown;charset=utf-8':'text/plain;charset=utf-8'),
      convPath:convNode?.path||'',
      isSummary:false
    });
    return;
  }
  if(kind==='summary'||kind==='log'){
    try{
      const handle=item.fileHandle||await item.artifactDirHandle?.getFileHandle(item.fileName,{create:false});
      if(!handle) throw new Error('Missing file handle');
      const text=await readTextFile(handle);
      openTextDownloadViewer({
        name:item.name,
        text,
        isHtml:true,
        mime:'text/html;charset=utf-8',
        convPath:convNode?.path||'',
        isSummary:kind==='summary',
        deleteItem:item
      });
    }catch(e){
      await appAlert('Could not open this saved artifact.',{title:'VIEW FAILED'});
    }
    return;
  }
  if(kind==='image'){
    try{
      await openImageDialogForSavedArtifact(convNode,item);
    }catch(e){
      await appAlert('Could not open this saved image.',{title:'VIEW FAILED'});
    }
  }
}

async function deletePersistentDownloadItem(item){
  if(!canDeleteDownloadItem(item)) return;
  try{
    await item.artifactDirHandle?.removeEntry(item.fileName,{recursive:false});
    if(getDownloadItemKind(item)==='image'&&item.promptFileName){
      try{await item.artifactDirHandle?.removeEntry(item.promptFileName,{recursive:false});}catch(e){}
      if(doesImagePromptMatchRef({promptPath:item.promptFilePath,fileName:item.promptFileName,imagePath:item.imagePath,imageFileName:item.fileName},IMAGE_DIALOG_STATE.settings?.summary_prompt_file||'')){
        IMAGE_DIALOG_STATE.settings=await setSummaryImagePromptFileForConversation(S.conv,'',IMAGE_DIALOG_STATE.settings);
      }
    }
  }catch(e){
    await appAlert('Could not delete this saved artifact.',{title:'DELETE FAILED'});
    return;
  }
  await refreshCurrentConversationDownloads();
}

async function openPersistentDownloadItemWithEvent(convNode,item,event){
  const kind=getDownloadItemKind(item);
  const p=item?.pointer||{};
  if(kind==='url'){
    if(!p.url){
      await promptDeleteStaleDownloadEntry(item,'This URL download entry appears invalid.');
      return;
    }
    openExternalUrlWithFullscreenRestore(p.url);
    return;
  }
  await viewPersistentDownloadItem(convNode,item);
}

function renderDownloadsTree(){
  const treeEl=document.getElementById('downloads-tree');
  const emptyEl=document.getElementById('downloads-empty');
  if(!treeEl) return;
  treeEl.innerHTML='';
  treeUpdateRootTargetState(DOWNLOADS_TREE_VIEW);
  if(!S.workspaceReady){
    if(emptyEl){
      emptyEl.innerHTML='Set a Root Folder in Settings to browse persistent results.';
      emptyEl.style.display='';
    }
    return;
  }
  if(!Array.isArray(S.downloadsTree)||!S.downloadsTree.length){
    if(emptyEl){
      emptyEl.innerHTML='No persistent results found yet.<br><span style="opacity:.6">Results appear here after agents produce files or saved artifacts.</span>';
      emptyEl.style.display='';
    }
    return;
  }
  if(emptyEl) emptyEl.style.display='none';
  const renderDownloadItemRow=(convNode,item,depth)=>{
    const row=document.createElement('div');
    row.className='c-row c-conv';
    row.style.paddingLeft=(8+depth*14)+'px';
    const kindIcon=getDownloadItemIcon(item);
    row.innerHTML=`
      <span class="c-caret"></span>
      <span class="c-icon">${kindIcon}</span>
      <span class="c-label">${esc(item.name)}</span>`;
    row.onclick=event=>openPersistentDownloadItemWithEvent(convNode,item,event);
    treeEl.appendChild(row);
  };
  const findDownloadGroupByPath=(groups,targetPath)=>{
    for(const group of Array.isArray(groups)?groups:[]){
      if(group?.path===targetPath) return group;
      const nested=findDownloadGroupByPath(group?.childGroups,targetPath);
      if(nested) return nested;
    }
    return null;
  };
  const renderDownloadGroup=(convNode,group,depth)=>{
    const childGroups=Array.isArray(group.childGroups)?group.childGroups:[];
    const items=Array.isArray(group.items)?group.items:[];
    const hasChildren=items.length>0||childGroups.length>0;
    const hasContentsHint=hasChildren||group.hasContentsHint===true;
    const expanded=hasChildren&&!!S.downloadsTreeExpanded[group.path];
    const groupRow=treeCreateCategoryRow(DOWNLOADS_TREE_VIEW,{
      path:group.path,
      name:group.displayName,
      displayName:group.displayName
    },depth,false,expanded,hasChildren);
    groupRow.onclick=async ()=>{
      if(!hasContentsHint){
        playUiFailSound();
        return;
      }
      if(!hasChildren){
        await syncDownloadsForConversationPath(convNode.path,{render:false,expand:false,reconcile:false});
        const freshNode=S.downloadsTreeIndex?.[convNode.path];
        const freshGroup=findDownloadGroupByPath(freshNode?.downloadGroups,group.path);
        const freshChildGroups=Array.isArray(freshGroup?.childGroups)?freshGroup.childGroups:[];
        const freshItems=Array.isArray(freshGroup?.items)?freshGroup.items:[];
        const freshHasChildren=freshItems.length>0||freshChildGroups.length>0;
        if(freshHasChildren) S.downloadsTreeExpanded[group.path]=true;
        renderDownloadsTree();
        return;
      }
      S.downloadsTreeExpanded[group.path]=!expanded;
      renderDownloadsTree();
    };
    treeEl.appendChild(groupRow);
    if(!expanded) return;
    childGroups.forEach(child=>renderDownloadGroup(convNode,child,depth+1));
    items.forEach(item=>renderDownloadItemRow(convNode,item,depth+1));
  };
  const renderNode=(node,depth)=>{
    if(node.type==='category'){
      const hasChildren=Array.isArray(node.children)&&node.children.length>0;
      const expanded=hasChildren&&!!S.downloadsTreeExpanded[node.path];
      const selected=S.downloadsTreeSelectedPath===node.path;
      const row=treeCreateCategoryRow(DOWNLOADS_TREE_VIEW,node,depth,selected,expanded,hasChildren);
      treeEl.appendChild(row);
      if(expanded){
        (node.children||[]).forEach(child=>renderNode(child,depth+1));
      }
      return;
    }
    const rootItems=Array.isArray(node.downloads)?node.downloads:[];
    const groups=Array.isArray(node.downloadGroups)?node.downloadGroups:[];
    const hasItems=rootItems.length>0||groups.length>0;
    const hasContentsHint=hasItems||node.hasArtifactFolders===true;
    const expanded=hasItems&&!!S.downloadsTreeExpanded[node.path];
    const selected=S.downloadsTreeSelectedPath===node.path;
    const crow=document.createElement('div');
    crow.className='c-row c-conv'+(selected?' sel':'');
    if(!hasContentsHint) crow.dataset.uiClickSound='off';
    crow.style.paddingLeft=(Math.max(0,8+depth*14-3))+'px';
    crow.innerHTML=`
      <span class="${treeCaretClass(hasContentsHint)}">${treeCaretGlyph(hasContentsHint,expanded)}</span>
      <span class="c-icon">💬</span>
      <span class="c-label">${esc(node.displayName||node.name)}</span>`;
    crow.onclick=async()=>{
      if(!hasContentsHint) playUiFailSound();
      const wasSelected=S.downloadsTreeSelectedPath===node.path;
      treeSelectPath(DOWNLOADS_TREE_VIEW,node.path||'');
      if(!wasSelected) S.downloadsTreeExpanded[node.path]=true;
      else if(hasItems) S.downloadsTreeExpanded[node.path]=!expanded;
      await syncDownloadsForConversationPath(node.path,{render:false,expand:false});
      const fresh=S.downloadsTreeIndex?.[node.path];
      const hasFreshItems=(Array.isArray(fresh?.downloads)&&fresh.downloads.length>0)||(Array.isArray(fresh?.downloadGroups)&&fresh.downloadGroups.length>0);
      if(!hasFreshItems){
        delete S.downloadsTreeExpanded[node.path];
      }else if(!wasSelected){
        S.downloadsTreeExpanded[node.path]=true;
      }
      renderDownloadsTree();
    };
    treeEl.appendChild(crow);
    if(expanded){
      groups.forEach(group=>renderDownloadGroup(node,group,depth+1));
      rootItems.forEach(item=>renderDownloadItemRow(node,item,depth+1));
    }
  };
  S.downloadsTree.forEach(node=>renderNode(node,0));
}

// Call this after clearing a conversation to reset in-memory download cards
function clearDownloads(){
  S.downloads=[];
  refreshDownloadsDrawer();
}

// ── SEND ──────────────────────────────────────────────────────────
function clearPendingDispatchTimer(){
  if(S.pendingDispatchTimer){
    clearTimeout(S.pendingDispatchTimer);
    S.pendingDispatchTimer=null;
  }
}

function clearAiDirectorTimers(clearStatus=true){
  if(S.aiDirectorTimer){
    clearTimeout(S.aiDirectorTimer);
    S.aiDirectorTimer=null;
  }
  if(S.aiDirectorTicker){
    clearInterval(S.aiDirectorTicker);
    S.aiDirectorTicker=null;
  }
  S.aiDirectorCountdownEndsAt=0;
  S.aiDirectorAutoSending=false;
  if(isAiDirectorMode(S.conv)&&S.directorTurnTimerActive){
    setDirectorTurnTimerPhase('generating');
  }
  if(clearStatus){
    S.aiDirectorStatus='';
    syncDirectorAiStatusUi();
  }
}

function getActiveRoundForConversation(conv=S.conv){
  const key=getDirectorAssistConvKey(conv);
  if(!S.activeRound||S.activeRound.convKey!==key||S.activeRound.complete) return null;
  return S.activeRound;
}

function resetConversationRuntimeState(){
  clearPendingDispatchTimer();
  clearAiDirectorTimers(true);
  freezeDirectorTurnTimer();
  cancelDirectorAssistRun();
  S.activeRound=null;
}

function getRoundTargetNames(conv,targetIds){
  return (targetIds||[]).map(tid=>{
    const agent=conv?.agents?.find(a=>a.id===tid);
    return agent?getAgentIdentityLabel(agent,conv):tid;
  });
}

function getRoundOpeningMessageByRoundNumber(conv,roundNum){
  return getRoundOpeningDirectorMessages(conv).find(msg=>Number(msg.num||msg.roundId||0)===Number(roundNum||0))||null;
}

function getLatestDirectorMessageInRound(conv,roundNum){
  if(!conv) return null;
  const roundMessages=(conv.messages||[]).filter(msg=>msg.role==='director'&&!msg.isSep&&Number(msg.num||msg.roundId||0)===Number(roundNum||0));
  if(!roundMessages.length) return null;
  return roundMessages[roundMessages.length-1];
}

function getNextRoundOrder(conv,roundNum){
  const opening=getRoundOpeningMessageByRoundNumber(conv,roundNum);
  if(!opening) return 1;
  return getConversationRoundTurnEntries(conv,opening).length+1;
}

function getRoundMode(round,conv=S.conv){
  return normalizeConversationMode(round?.mode||round?.roundMode||getConversationMode(conv));
}

function isSequentialRound(round,conv=S.conv){
  return getRoundMode(round,conv)==='sequential';
}

function isFreeFormRound(round,conv=S.conv){
  return getRoundMode(round,conv)==='free_form';
}

function buildAgentResultFromMessage(agent,msg){
  const speakerLabel=getAgentMessageSpeakerLabel(agent,msg);
  return{
    id:msg.id||'',
    agentId:agent.id,
    agentName:speakerLabel,
    speakerLabel,
    content:String(msg.content||''),
    ts:Number(msg.ts)||Date.now(),
    truncated:!!msg.truncated,
    stopReason:msg.stopReason||'',
    failed:!!msg.failed,
    failureKind:String(msg.failureKind||''),
    retryable:isRetryableFailureMessage(msg),
    errorMessage:msg.errorMessage||'',
    warningMessage:msg.warningMessage||'',
    toolUse:Array.isArray(msg.toolUse)?msg.toolUse:[],
    attemptCount:Math.max(1,Number(msg.attemptCount)||1),
    retriedFromFailure:!!msg.retriedFromFailure
  };
}

function findExistingRoundAgentMessage(agent,dirMsg,roundOrder){
  if(!agent||!dirMsg) return null;
  const roundNum=Number(dirMsg.num||dirMsg.roundId||0);
  for(let i=(agent.msgs||[]).length-1;i>=0;i--){
    const msg=agent.msgs[i];
    if(msg?.role!=='agent') continue;
    if(String(msg.inReplyTo||'')!==String(dirMsg.id||'')) continue;
    if(Number(msg.roundOrder)!==Number(roundOrder)) continue;
    if(Number(msg.round||0)!==roundNum) continue;
    return msg;
  }
  return null;
}

function appendNonFatalAgentWarning(msg,warning){
  const text=String(warning||'').trim();
  if(!text) return;
  const existing=String(msg.warningMessage||'').trim();
  msg.warningMessage=existing?`${existing} ${text}`:text;
}

function buildThrownAgentFailureMessage(agent,dirMsg,conv,roundOrder,error){
  const ts=Date.now();
  const failureInfo=classifyAgentFailureFromError(error);
  const message=String(failureInfo.displayMessage||error?.displayMessage||error?.message||'Agent response failed.').trim()||'Agent response failed.';
  const speakerLabel=getAgentIdentityLabel(agent,conv);
  return{
    id:'a'+ts+'_'+agent.id,
    role:'agent',
    content:'',
    ts,
    ctx:conv.context,
    dirSum:buildDirectorSnippet(dirMsg.content,128),
    inReplyTo:dirMsg.id,
    round:dirMsg.num||conv.msgCount||0,
    speakerLabel,
    roundOrder,
    turnIndex:roundOrder,
    failed:true,
    failureKind:failureInfo.kind||'failed_api',
    retryable:!!failureInfo.retryable,
    errorMessage:message
  };
}

function recordThrownAgentFailure(agent,dirMsg,conv,roundOrder,error){
  const logEl=document.getElementById('al_'+agent.id);
  const stEl=document.getElementById('as_'+agent.id);
  const am=buildThrownAgentFailureMessage(agent,dirMsg,conv,roundOrder,error);
  agent.msgs.push(am);
  if(logEl){
    appendAgentEntry(logEl,am,agent);
    scrollAgentToLatestResponse(logEl);
  }
  if(stEl){
    stEl.className='a-status fail';
    stEl.textContent='Failed · '+fmtT(am.ts);
  }
  try{ refreshAgentDownloadBtn(agent.id); }catch(e){}
  syncAgentRetryButtonUi(agent.id);
  syncRoundFailureBanner();
  return am;
}

function buildDirectorTurnSummary(content,isContinue){
  if(isContinue) return 'Continue';
  return buildDirectorSnippet(content||'',128);
}

function createDirectorMessage({
  conv,content,targets,atts,num,source='human',roundOpen=true,continueFlag=false,roundMode=null,roundOrder=0
}){
  const ts=Date.now();
  const id='m'+ts+'_'+Math.floor(Math.random()*1000);
  const files=(atts||[]).map(f=>({name:f.name,type:f.type}));
  return{
    id,
    role:'director',
    content:String(content||''),
    summary:buildDirectorTurnSummary(content,continueFlag),
    ts,
    ctx:conv.context,
    targets:Array.isArray(targets)?targets.slice():[],
    files,
    num,
    roundId:num,
    roundOpen:!!roundOpen,
    source:normalizeDirectorType(source),
    continue:!!continueFlag,
    roundMode:normalizeConversationMode(roundMode||getConversationMode(conv)),
    roundOrder,
    turnIndex:roundOrder,
    _attachments:[...(atts||[])]
  };
}

function registerDirectorMessage(conv,msg){
  conv.messages.push(msg);
  if(msg?.role==='director'&&msg.roundOpen!==false) clearHistorySelection({render:false});
  appendDirMsg(msg);
  refreshFullHistoryDownloadButton();
  if(S.logMode==='summary'){
    if(msg.roundOpen!==false) appendHistItem(msg);
  }else{
    renderHistory();
  }
}

function createActiveRoundState(conv,openingMsg){
  return{
    convKey:getDirectorAssistConvKey(conv),
    roundNum:Number(openingMsg.num||0),
    mode:normalizeConversationMode(openingMsg.roundMode||getConversationMode(conv)),
    openingDirectorId:openingMsg.id,
    targets:Array.isArray(openingMsg.targets)?openingMsg.targets.slice():[],
    targetNames:getRoundTargetNames(conv,openingMsg.targets||[]),
    nextSequentialIndex:0,
    respondedIds:[],
    lastParticipant:'director:'+normalizeDirectorType(openingMsg.source||'human'),
    complete:false
  };
}

function markRoundDirectorTurn(round,source='human'){
  if(round) round.lastParticipant='director:'+normalizeDirectorType(source);
}

function markRoundAgentTurn(round,agentId){
  if(!round) return;
  const id=String(agentId||'');
  if(id&&!round.respondedIds.includes(id)) round.respondedIds.push(id);
  round.lastParticipant=id;
}

function getEligibleFreeFormAgentId(conv,round){
  if(!conv||!round) return'';
  const pending=round.targets.filter(aid=>!round.respondedIds.includes(aid));
  const first=pending.find(aid=>aid!==round.lastParticipant);
  if(first) return first;
  return pending[0]||'';
}

function getLatestRoundOpeningMessage(conv=S.conv){
  return [...(conv?.messages||[])].reverse().find(isRoundOpeningDirectorMessage)||null;
}

function getRoundFailureState(conv=S.conv,roundNum=null){
  if(!conv) return null;
  const openingMsg=roundNum?getRoundOpeningMessageByRoundNumber(conv,roundNum):getLatestRoundOpeningMessage(conv);
  if(!openingMsg) return null;
  const resolvedRoundNum=Number(openingMsg.num||openingMsg.roundId||0);
  if(!resolvedRoundNum) return null;
  const targetIds=Array.isArray(openingMsg.targets)&&openingMsg.targets.length
    ? openingMsg.targets.slice()
    : (conv.agents||[]).map(agent=>agent.id);
  const failures=[];
  targetIds.forEach(targetId=>{
    const agent=(conv.agents||[]).find(entry=>String(entry?.id||'')===String(targetId||''));
    if(!agent) return;
    const matches=(agent.msgs||[]).filter(msg=>msg?.role==='agent'&&Number(msg.round||0)===resolvedRoundNum);
    if(!matches.length) return;
    const latest=matches[matches.length-1];
    if(latest.failed) failures.push({agent,msg:latest});
  });
  if(!failures.length) return null;
  const first=failures[0];
  const sameKind=failures.every(entry=>String(entry.msg.failureKind||'')===String(first.msg.failureKind||''));
  const sharedKind=sameKind?String(first.msg.failureKind||'failed_api'):'mixed';
  return{
    roundNum:resolvedRoundNum,
    openingMsg,
    failures,
    retryable:failures.filter(entry=>isRetryableFailureMessage(entry.msg)),
    sharedKind,
    sharedLabel:sameKind
      ? summarizeFailureCauseLabel(first.msg.failureKind,first.msg.errorMessage)
      : 'Multiple agent failures remain unresolved',
    hasCredits:failures.some(entry=>String(entry.msg.failureKind||'')==='failed_credits')
  };
}

function syncRoundFailureBanner(){
  const el=document.getElementById('round-failure-banner');
  if(!el) return;
  const state=getRoundFailureState(S.conv);
  if(!state){
    el.classList.remove('is-open');
    el.style.display='none';
    el.innerHTML='';
    return;
  }
  const failureCount=state.failures.length;
  const countLabel=failureCount===1?'1 agent failed':`${failureCount} agent requests failed`;
  const summaryText=isAiDirectorMode(S.conv)
    ? `AI Director paused: ${state.sharedLabel}`
    : `${countLabel}: ${state.sharedLabel}`;
  const detailText=isAiDirectorMode(S.conv)?countLabel:'Resolve the latest round before treating it as a clean completion.';
  const retryDisabled=state.retryable.length?'':' disabled';
  const creditsBtn=state.hasCredits
    ? `<button type="button" onclick="openRoundFailureCredits()">Open Credits</button>`
    : '';
  const switchBtn=isAiDirectorMode(S.conv)
    ? `<button type="button" onclick="switchToHumanDirectorFromFailureBanner()">Switch to Human</button>`
    : '';
  el.innerHTML=`
    <div class="head">
      <div class="msg"><strong>${esc(summaryText)}</strong><div>${esc(detailText)}</div></div>
    </div>
    <div class="acts">
      <button type="button" onclick="retryFailedAgentsForLatestRound()"${retryDisabled}>Retry Failed Agents</button>
      ${creditsBtn}
      ${switchBtn}
    </div>`;
  el.classList.add('is-open');
  el.style.display='block';
}

function openRoundFailureCredits(){
  openExternalUrlWithFullscreenRestore('https://openrouter.ai/credits');
}

function switchToHumanDirectorFromFailureBanner(){
  setConversationDirectorTypeFromToolbar('human');
}

async function retryFailedAgentsForRound(roundNum=null){
  const conv=S.conv;
  if(!conv) return;
  if(ensureClientSessionState().suspended){
    await appAlert(SESSION_SUPERSEDED_MESSAGE,{title:'SESSION SUPERSEDED'});
    return;
  }
  const state=getRoundFailureState(conv,roundNum);
  if(!state||!state.retryable.length) return;
  await Promise.all(state.retryable.map(entry=>
    retryAgentResponse(entry.agent.id,entry.msg.id,{skipHistoryRender:true,skipAiCycle:true})
  ));
  if(state.openingMsg) await persistRoundForDirectorMessage(conv,state.openingMsg);
  if(S.logMode==='full') renderHistory();
  syncRoundFailureBanner();
  if(isAiDirectorMode(conv)) void scheduleAiDirectorCycle('round-retry');
}

function retryFailedAgentsForLatestRound(){
  void retryFailedAgentsForRound();
}

function updateAiDirectorCountdownStatus(){
  if(!S.aiDirectorCountdownEndsAt){
    S.aiDirectorStatus='';
    syncDirectorAiStatusUi();
    return;
  }
  const seconds=Math.max(0,Math.ceil((S.aiDirectorCountdownEndsAt-Date.now())/1000));
  S.aiDirectorStatus=`AI submits in ${seconds}s`;
  syncDirectorAiStatusUi();
}

function startAiDirectorCountdown(){
  clearAiDirectorTimers(false);
  const conv=S.conv;
  if(!conv||!isAiDirectorMode(conv)) return;
  const seconds=getConversationAiDirectorCountdown(conv);
  S.aiDirectorCountdownEndsAt=Date.now()+(seconds*1000);
  if(S.directorTurnTimerActive) setDirectorTurnTimerPhase('countdown');
  updateAiDirectorCountdownStatus();
  S.aiDirectorTicker=setInterval(updateAiDirectorCountdownStatus,250);
  const token=++S.aiDirectorToken;
  S.aiDirectorTimer=setTimeout(async()=>{
    if(token!==S.aiDirectorToken) return;
    const draftText=getDirectorDraftText();
    if(!draftText.trim()){
      clearAiDirectorTimers(true);
      S.aiDirectorStatus='AI waiting for Director';
      syncDirectorAiStatusUi();
      return;
    }
    clearAiDirectorTimers(true);
    S.aiDirectorAutoSending=true;
    try{
      await sendMessage({source:'ai',content:draftText,preserveDraft:false});
    }finally{
      S.aiDirectorAutoSending=false;
    }
  },seconds*1000);
}

async function scheduleAiDirectorCycle(reason=''){
  clearAiDirectorTimers(true);
  const conv=S.conv;
  if(!conv||!isAiDirectorMode(conv)||isDirectorInputLocked(conv)||S.directorAssistBusy) return;
  const failureState=getRoundFailureState(conv);
  if(failureState){
    S.aiDirectorStatus=`AI Director paused: ${failureState.sharedLabel}`;
    syncDirectorAiStatusUi();
    syncRoundFailureBanner();
    return;
  }
  if(['parallel-round','round-complete','sequential-turn','free-form-turn','round-retry','retry-agent-response'].includes(String(reason||''))){
    startDirectorTurnTimer();
  }
  const round=getActiveRoundForConversation(conv);
  const activeMode=round?getRoundMode(round,conv):getConversationMode(conv);
  if((activeMode==='sequential'||activeMode==='free_form')&&S.aborts.length>0) return;
  const draft=getDirectorDraftText().trim();
  const inputEl=document.getElementById('dir-input');
  if(draft){
    S.aiDirectorStatus='AI waiting for Director';
    syncDirectorAiStatusUi();
    return;
  }
  if(document.activeElement===inputEl){
    S.aiDirectorStatus='AI waiting for input box';
    syncDirectorAiStatusUi();
    return;
  }
  if(getCompletedRoundCount(conv)<1){
    S.aiDirectorStatus='';
    syncDirectorAiStatusUi();
    return;
  }
  if(reason){
    S.aiDirectorStatus='AI drafting...';
    syncDirectorAiStatusUi();
  }
  const applied=await runDirectorAssist({source:'ai'});
  if(!applied) return;
  if(!isAiDirectorMode(S.conv)) return;
  if(getDirectorDraftSource()!=='ai') return;
  if(!getDirectorDraftText().trim()) return;
  startAiDirectorCountdown();
}

function finalizeRound(round){
  if(!round) return;
  clearPendingDispatchTimer();
  round.complete=true;
  if(S.activeRound&&S.activeRound.convKey===round.convKey&&S.activeRound.roundNum===round.roundNum){
    S.activeRound=null;
  }
  updateHistoryPanelTitle(S.conv);
  syncRoundFailureBanner();
  syncDirectorComposerUi();
  if(isAiDirectorMode(S.conv)){
    void scheduleAiDirectorCycle('round-complete');
  }
}

async function dispatchRoundAgent(conv,round,agentId,dirMsg){
  const agent=conv?.agents?.find(a=>a.id===agentId);
  if(!agent) return null;
  const roundOrder=getNextRoundOrder(conv,round.roundNum);
  let result=null;
  let dispatchError=null;
  try{
    result=await dispatchToAgent(agent,dirMsg,dirMsg._attachments||[],conv,{roundOrder});
  }catch(e){
    dispatchError=e;
    const existing=findExistingRoundAgentMessage(agent,dirMsg,roundOrder);
    if(existing){
      result=buildAgentResultFromMessage(agent,existing);
    }else{
      const failedMsg=recordThrownAgentFailure(agent,dirMsg,conv,roundOrder,e);
      result=buildAgentResultFromMessage(agent,failedMsg);
    }
  }finally{
    markRoundAgentTurn(round,agentId);
    updateHistoryPanelTitle(conv);
    const openingMsg=getRoundOpeningMessageByRoundNumber(conv,round.roundNum);
    if(openingMsg){
      try{
        await persistRoundForDirectorMessage(conv,openingMsg);
      }catch(e){
        console.error('Could not persist round after agent dispatch:',e);
      }
    }
    syncRoundFailureBanner();
  }
  if(dispatchError) console.error('Recovered from thrown agent dispatch:',dispatchError);
  return result;
}

async function runSequentialAgentStep(conv,round,dirMsg){
  if(!round||round.complete) return;
  const nextAgentId=round.targets[round.nextSequentialIndex]||'';
  if(!nextAgentId){
    finalizeRound(round);
    return;
  }
  await dispatchRoundAgent(conv,round,nextAgentId,dirMsg);
  round.nextSequentialIndex++;
  syncDirectorComposerUi();
  if(round.nextSequentialIndex>=round.targets.length){
    finalizeRound(round);
    return;
  }
  if(isAiDirectorMode(conv)){
    void scheduleAiDirectorCycle('sequential-turn');
  }
}

function scheduleFreeFormAgentStep(conv,round,delayMs=null){
  if(!round||round.complete) return;
  if(round.respondedIds.length>=round.targets.length){
    finalizeRound(round);
    return;
  }
  const nextAgentId=getEligibleFreeFormAgentId(conv,round);
  if(!nextAgentId){
    finalizeRound(round);
    return;
  }
  clearPendingDispatchTimer();
  const waitMs=(delayMs===null?getConversationPaceDelay(conv)*1000:delayMs);
  const runner=async()=>{
    clearPendingDispatchTimer();
    if(!getActiveRoundForConversation(conv)||round.complete) return;
    const dispatchMsg=getLatestDirectorMessageInRound(conv,round.roundNum)||getRoundOpeningMessageByRoundNumber(conv,round.roundNum)||{
      id:'ff_'+round.roundNum+'_'+nextAgentId+'_'+Date.now(),
      num:round.roundNum,
      roundId:round.roundNum,
      content:'',
      ts:Date.now(),
      _attachments:[]
    };
    await dispatchRoundAgent(conv,round,nextAgentId,dispatchMsg);
    if(round.respondedIds.length>=round.targets.length){
      finalizeRound(round);
      return;
    }
    if(isAiDirectorMode(conv)){
      void scheduleAiDirectorCycle('free-form-turn');
      return;
    }
    scheduleFreeFormAgentStep(conv,round,null);
  };
  if(waitMs>0){
    S.pendingDispatchTimer=setTimeout(()=>{ void runner(); },waitMs);
  }else{
    void runner();
  }
}

function onDirKey(e){
  if(S.micOn) onDirectorInputManualIntent();
  if(isDirectorInputLocked(S.conv)||S.directorAssistBusy){
    if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing) e.preventDefault();
    return;
  }
  if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){
    e.preventDefault();
    sendMessage();
  }
}
function onDirectorInputManualIntent(){
  if(S.micOn) stopMic();
}

async function sendMessage(opts={}){
  const c=S.conv;if(!c)return;
  if(ensureClientSessionState().suspended){
    await appAlert(SESSION_SUPERSEDED_MESSAGE,{title:'SESSION SUPERSEDED'});
    return;
  }
  const activeRound=getActiveRoundForConversation(c);
  const activeMode=activeRound?getRoundMode(activeRound,c):getConversationMode(c);
  if(isDirectorInputLocked(c)||S.directorAssistBusy) return;
  if((activeMode==='sequential'||activeMode==='free_form')&&S.aborts.length>0) return;
  const source=normalizeDirectorType(opts.source||'human');
  const explicitContent=Object.prototype.hasOwnProperty.call(opts,'content');
  const rawContent=explicitContent?String(opts.content||''):String(getDirectorDraftText()||'');
  const trimmed=sanitizeSubmittedText(rawContent);
  const atts=Array.isArray(opts.attachments)?[...opts.attachments]:[...S.attachments];
  const isSequentialContinuation=!!activeRound&&isSequentialRound(activeRound,c);
  const allowBlankContinue=isSequentialContinuation&&!trimmed&&!atts.length;
  if(!trimmed&&!allowBlankContinue) return;

  const targets=activeRound?activeRound.targets.slice():(Array.isArray(opts.targets)&&opts.targets.length?opts.targets.slice():getTargets());
  if(!targets.length){await appAlert('Activate at least one agent before sending.');return;}

  stopMic();
  if(isAiDirectorMode(c)){
    freezeDirectorTurnTimer();
    playDirectorTurnChime();
  }
  clearAiDirectorTimers(true);
  if(opts.preserveDraft!==true) resetDirectorAssistState();
  syncDirectorComposerUi();
  S.attachments=[];
  renderAttStrip();

  if(!activeRound){
    c.msgCount=(c.msgCount||0)+1;
    await persistConversationEditorLockIfNeeded(c);
    const openingMsg=createDirectorMessage({
      conv:c,
      content:trimmed,
      targets,
      atts,
        num:c.msgCount,
        source,
        roundOpen:true,
        continueFlag:false,
        roundMode:activeMode,
        roundOrder:0
      });
    registerDirectorMessage(c,openingMsg);
    resetAgentScrollPositions();
    stoSave();
    if(activeMode==='parallel'){
      setInterruptVisible(true);
      const results=await Promise.all(targets.map(aid=>{
        const agent=c.agents.find(x=>x.id===aid);
        return agent?dispatchToAgent(agent,openingMsg,atts,c,{roundOrder:0}):Promise.resolve(null);
      }));
      await persistRoundForDirectorMessage(c,openingMsg);
      if(S.logMode==='full') renderHistory();
      syncRoundFailureBanner();
      if(isAiDirectorMode(c)) void scheduleAiDirectorCycle('parallel-round');
      return;
    }
    const round=createActiveRoundState(c,openingMsg);
    S.activeRound=round;
    await persistRoundForDirectorMessage(c,openingMsg);
    if(isSequentialRound(round,c)){
      await runSequentialAgentStep(c,round,openingMsg);
      return;
    }
    scheduleFreeFormAgentStep(c,round,0);
    return;
  }

  if(isSequentialRound(activeRound,c)){
    const nextAgentId=activeRound.targets[activeRound.nextSequentialIndex]||'';
    if(!nextAgentId){
      finalizeRound(activeRound);
      if(source==='human'&&trimmed){
        await sendMessage({source:'human',content:trimmed,attachments:atts});
      }
      return;
    }
    const turnMsg=createDirectorMessage({
      conv:c,
      content:trimmed,
      targets:[nextAgentId],
      atts,
      num:activeRound.roundNum,
      source,
      roundOpen:false,
      continueFlag:allowBlankContinue,
      roundMode:getRoundMode(activeRound,c),
      roundOrder:getNextRoundOrder(c,activeRound.roundNum)
    });
    registerDirectorMessage(c,turnMsg);
    markRoundDirectorTurn(activeRound,source);
    const openingMsg=getRoundOpeningMessageByRoundNumber(c,activeRound.roundNum);
    if(openingMsg) await persistRoundForDirectorMessage(c,openingMsg);
    await runSequentialAgentStep(c,activeRound,turnMsg);
    return;
  }

  if(isFreeFormRound(activeRound,c)){
    if(activeRound.lastParticipant===('director:'+source)) return;
    const turnMsg=createDirectorMessage({
      conv:c,
      content:trimmed,
      targets:targets,
      atts,
      num:activeRound.roundNum,
      source,
      roundOpen:false,
      continueFlag:false,
      roundMode:getRoundMode(activeRound,c),
      roundOrder:getNextRoundOrder(c,activeRound.roundNum)
    });
    registerDirectorMessage(c,turnMsg);
    markRoundDirectorTurn(activeRound,source);
    const openingMsg=getRoundOpeningMessageByRoundNumber(c,activeRound.roundNum);
    if(openingMsg) await persistRoundForDirectorMessage(c,openingMsg);
    scheduleFreeFormAgentStep(c,activeRound,null);
  }
}

function goDirectorAssistPrev(){
  if(S.directorAssistBusy||S.directorAssistIndex<=0) return;
  S.directorAssistIndex--;
  syncDirectorComposerUi();
}

function goDirectorAssistNext(){
  if(S.directorAssistBusy||S.directorAssistIndex>=S.directorAssistSlots.length-1) return;
  S.directorAssistIndex++;
  syncDirectorComposerUi();
}

function truncateDirectorAssistText(text,maxLen){
  const clean=String(text||'').replace(/\s+/g,' ').trim();
  if(!clean) return'';
  if(clean.length<=maxLen) return clean;
  return clean.slice(0,Math.max(0,maxLen-3)).trimEnd()+'...';
}

function isRoundOpeningDirectorMessage(msg){
  return !!msg&&msg.role==='director'&&!msg.isSep&&(msg.roundOpen!==false);
}

function getRoundOpeningDirectorMessages(conv){
  return (conv?.messages||[]).filter(isRoundOpeningDirectorMessage);
}

function getRoundEntryOrder(entry){
  const msg=entry?.msg||entry;
  const explicit=Number(msg?.roundOrder);
  if(Number.isFinite(explicit)) return explicit;
  const turnIndex=Number(msg?.turnIndex);
  if(Number.isFinite(turnIndex)) return turnIndex;
  const ts=Number(msg?.ts);
  return Number.isFinite(ts)?ts:0;
}

function getConversationRoundTurnEntries(conv,dirMsg){
  if(!conv||!dirMsg) return [];
  const roundNum=Number(dirMsg.num||dirMsg.roundId||0);
  if(!roundNum) return [];
  const entries=[];
  (conv.messages||[]).forEach(msg=>{
    if(msg===dirMsg||msg.isSep||msg.role!=='director') return;
    if(Number(msg.num||msg.roundId||0)!==roundNum) return;
    entries.push({type:'director',msg});
  });
  (conv.agents||[]).forEach(agent=>{
    (agent.msgs||[]).forEach(msg=>{
      if(msg.role!=='agent') return;
      if(Number(msg.round||0)!==roundNum) return;
      entries.push({type:'agent',agent,msg});
    });
  });
  entries.sort((a,b)=>{
    const delta=getRoundEntryOrder(a)-getRoundEntryOrder(b);
    if(delta!==0) return delta;
    return Number((a.msg||a).ts||0)-Number((b.msg||b).ts||0);
  });
  return entries;
}

function getDirectorAssistRoundEntries(conv,dirMsg){
  return getConversationRoundTurnEntries(conv,dirMsg)
    .filter(entry=>entry.type==='agent')
    .map(entry=>({agent:entry.agent,msg:entry.msg}));
}

function getCompletedRoundCount(conv){
  const dirMsgs=getRoundOpeningDirectorMessages(conv);
  return dirMsgs.reduce((count,msg)=>count+(getDirectorAssistRoundEntries(conv,msg).length?1:0),0);
}
function updateHistoryPanelTitle(conv){
  const lbl=document.getElementById('log-toggle-label');
  if(!lbl) return;
  const modeText=S.logMode==='summary'?'HISTORY · SUMMARY':'HISTORY · FULL VIEW';
  const roundCount=conv?getCompletedRoundCount(conv):0;
  lbl.textContent=`${modeText} (Rounds Completed: ${roundCount})`;
}

function buildDirectorAssistAgentRoster(conv){
  const agents=(conv?.agents||[]).filter(agent=>isAgentReady(agent));
  if(!agents.length) return 'Assigned agents: none.';
  const lines=['Assigned agents:'];
  agents.forEach(agent=>{
    const profile=getEffectiveAgentProfile(agent,conv);
    const name=getAgentIdentityLabel(agent,conv);
    const backstory=truncateDirectorAssistText(profile.backstory||'',900)||'No backstory available.';
    lines.push(`- ${name}`);
    lines.push(`  Backstory: ${backstory}`);
  });
  return lines.join('\n');
}

function buildDirectorAssistHistorySummary(conv){
  const dirMsgs=getRoundOpeningDirectorMessages(conv).slice(-20);
  if(!dirMsgs.length) return 'Recent round summaries: none yet.';
  const lines=['Recent round summaries (up to 20):'];
  dirMsgs.forEach((msg,idx)=>{
    const round=msg.num||idx+1;
    const summary=String(msg.summary||buildDirectorSnippet(msg.content||'',128)).trim();
    lines.push(`- Round ${round}: ${summary}`);
  });
  return lines.join('\n');
}

function buildDirectorAssistLatestRound(conv){
  const dirMsg=[...getRoundOpeningDirectorMessages(conv)].reverse()[0];
  if(!dirMsg) return 'Most recent round detail: none yet.';
  const lines=['Most recent round detail:'];
  lines.push(`Director: ${truncateDirectorAssistText(dirMsg.content||'',700)}`);
  const roundEntries=getConversationRoundTurnEntries(conv,dirMsg);
  if(!roundEntries.length){
    lines.push('No agent responses yet.');
    return lines.join('\n');
  }
  roundEntries.forEach(entry=>{
    if(entry.type==='director'){
      const label=entry.msg.source==='ai'?'Director (AI)':'Director';
      const body=entry.msg.continue?'[Continue]':truncateDirectorAssistText(entry.msg.content||'',700)||'[Blank]';
      lines.push(`${label}: ${body}`);
      return;
    }
    const name=getAgentMessageSpeakerLabel(entry.agent,entry.msg);
    const body=truncateDirectorAssistText(buildAgentContextResponseText(entry.msg),700)||'[No response]';
    lines.push(`${name}: ${body}`);
  });
  return lines.join('\n');
}

function getDirectorAssistDispatchContext(conv){
  const round=getActiveRoundForConversation(conv);
  const conversationMode=round?getRoundMode(round,conv):getConversationMode(conv);
  let nextAgentName='';
  if(conversationMode==='sequential'){
    const targets=round?round.targets.slice():getTargets();
    const nextIndex=round?Math.max(0,Number(round.nextSequentialIndex)||0):0;
    const nextAgentId=targets[nextIndex]||targets[0]||'';
    const nextAgent=(conv?.agents||[]).find(agent=>agent.id===nextAgentId);
    if(nextAgent) nextAgentName=getAgentIdentityLabel(nextAgent,conv);
  }
  return{conversationMode,nextAgentName};
}

function buildManualDirectorAssistSystemPrompt(opts){
  const isEmpty=!!opts?.isEmpty;
  const assistIteration=Math.max(1,Number(opts?.assistIteration)||1);
  const completedRounds=Math.max(0,Number(opts?.completedRounds)||0);
  const conversationMode=normalizeConversationMode(opts?.conversationMode||DEFAULT_CONVERSATION_MODE);
  const nextAgentName=String(opts?.nextAgentName||'').trim();
  let dispatchGuidance='Parallel mode: Your message goes to all active agents simultaneously. Address the group. You may reference individual agents briefly, but your primary job is to push the whole conversation forward together.';
  if(conversationMode==='sequential'){
    dispatchGuidance=`Sequential mode: Your message opens the next sequential response slot. ${nextAgentName?`${nextAgentName} responds next.`:'One agent responds next.'} Lead with direction for that next responding agent. Do not open by praising or extensively addressing the previous round's last respondent; they are not the next one to see this prompt.`;
  }else if(conversationMode==='free_form'){
    dispatchGuidance='Free Form mode: You are a participant in a flowing conversation. Contribute naturally. Light references to what agents have said are fine, but always land on forward direction.';
  }
  let prompt=`You are Director Assist for Conflab, a multi-provider conversation tool.

`;

  if(isEmpty){
    prompt+=`The Director has not written a draft. Your job is to craft the next Director message. You are both a contributing participant and the conversation leader. Contribute your own analysis, recommendations, or practical observations alongside direction for the agents. You are not just a facilitator; you have a voice. Read the agent responses carefully. Identify areas of agreement, disagreement, open questions, and promising threads. Generate a natural, conversational prompt that the Director can send as-is or refine further.

`;
  }else{
    prompt+=`The Director is composing a message to send to a panel of AI agents. Your job is to improve the Director's draft so it produces better responses from those agents while preserving the Director's intent and voice.

`;
  }

  prompt+=`Rules:
- Preserve the Director's intent and voice. Improve how they are asking, not what they are asking.
- If the draft is brief or vague, expand it into a clearer, more useful prompt that gives the panel concrete direction.
- If the draft is already detailed and well-structured, sharpen it. Improve clarity, precision, and focus without making it longer.
- Use the provided panel context, persona backstories, recent history, and latest round details to make the prompt more situationally aware.
- ${dispatchGuidance}
- Every prompt must push forward. Past responses are context, not destination. Brief acknowledgment of agent contributions is fine; extended praise or backward-facing reaction is not. Always end with direction, a recommendation, or a concrete next step.
- You do not have web access. Never claim to browse, search, verify facts, check sources, or perform research yourself.
- You may suggest that the Director ask one or more agents to research, verify, or compare something when that would help.
- Return only the improved prompt text.
- Do not add greetings, preambles, or meta-commentary.
- Keep the tone natural and conversational. This is a human directing a discussion, not writing a formal memo.`;

  if(assistIteration>=2&&completedRounds>=1){
    prompt+=`

Additional guidance for this iteration:
- Analyze the agent responses for points of agreement, disagreement, and unaddressed gaps.
- Identify which agent direction or thread appears most coherent or promising given the conversation goals.
- Subtly frame the prompt to build toward a concrete outcome: a decision, a combined recommendation, a synthesized result, or clearer understanding of what remains unresolved.
- Do not force resolution. If the agents are still exploring productively, focus the next step on the most useful unresolved question. If they are circling or repeating, help the Director move the conversation forward.
- Be specific to this conversation's content. Do not use generic convergence language.`;
  }

  if(assistIteration>=3&&completedRounds>=1){
    prompt+=`
- The Director has requested multiple refinements. Be more direct about driving toward a result. Reference specific points from agent responses that can be resolved or combined. Suggest concrete next steps rather than open-ended questions where possible.`;
  }

  return prompt;
}

function getAiDirectorPromptSections(conversationMode,nextAgentName){
  if(conversationMode==='sequential'){
    const targetName=nextAgentName||'The next responding agent';
    return{
      modeGuidance:`You are in Sequential mode. Agents respond one at a time, and you provide direction between each agent's response. ${nextAgentName?`${nextAgentName} responds next.`:'One agent responds next.'}

Lead with direction for ${targetName}. Do not open by extensively praising or reacting to the previous agent's response -- ${targetName} is the one reading this prompt, not the previous respondent. A brief nod to prior contributions is fine ("Building on what Elena found..."), but always land on what ${targetName} should focus on.

Your touch should be light in each individual prompt. You get multiple interactions per round (one per agent), so you do not need to pack everything into a single message. Keep each prompt focused on one agent and one thread. Your broader synthesis comes through cumulatively across the round's interactions, not in any single message.

When you have your own analysis to contribute, weave it into your direction naturally: "I think the timing actually works better if we flip Saturday and Sunday -- ${targetName}, does that change your restaurant recommendation?"`,
      convergenceModifier:`In Sequential mode, you get multiple interactions per round (one per agent). Spread your convergence pressure across these interactions rather than concentrating it in any single prompt. Each individual prompt should carry roughly a third of the convergence pressure you would apply in a single Parallel prompt. The cumulative effect across one full sequential round should be comparable to one Parallel round. When pushing for creative expansion, tailor the creative challenge to each agent as the round progresses. Earlier agents in the round can be asked to propose novel ideas; later agents naturally see those proposals and can build on, challenge, or extend them.`
    };
  }
  if(conversationMode==='free_form'){
    return{
      modeGuidance:`You are in Free Form mode. Agents respond at their own pace in a natural conversation flow. You are one participant among many, subject to the same no-consecutive rule as everyone else.

Contribute naturally, as a voice in the conversation rather than a moderator standing above it. Your messages should be shorter than in Parallel or Sequential mode -- you will get more opportunities to speak, so each contribution can be focused on one point, one redirect, or one observation.

Light references to what agents have said are expected -- you are responding to a flowing conversation, not issuing directives from outside it. But always push forward: reference the past to set the future direction, do not just react.

When you have your own perspective to contribute, state it directly as your view, then connect it to what the agents should consider next.`,
      convergenceModifier:`In Free Form mode, you participate as one voice among many and will get multiple opportunities to speak per round. Distribute your convergence pressure across your natural contributions rather than concentrating it. Each individual message should be lighter than a Parallel prompt, but your overall trajectory across the round should still trend toward closure at roughly the same rate. When pushing for creative expansion, drop the challenge naturally into the conversation flow and invite agents to spend a turn on what would make an idea work, not just why it is hard.`
    };
  }
  return{
    modeGuidance:`You are in Parallel mode. Your message goes to all active agents simultaneously. They will all respond to this single prompt independently and will not see each other's current-round responses.

Address the group. You may reference individual agents' contributions from prior rounds -- briefly acknowledge what's working and redirect what isn't -- but your primary job is to push the whole conversation forward together. Since this is the only Director input for the entire round, make it count: synthesize what you've seen across all agents, contribute your own analysis where you have something to add, and give clear direction for the next round.

When forming your analysis, let the agents' perspectives inform and modify your own thinking. If an agent raised a point that changes your view, say so. Your value is not just in managing the conversation but in thinking alongside the agents.`,
    convergenceModifier:`In Parallel mode, your convergence pressure is carried entirely in this one prompt per round. Make your forward momentum clear but not aggressive. Since agents respond independently, frame your convergence cues so that each agent can contribute to resolution from their own perspective. When pushing for creative expansion, challenge all agents to propose novel ideas independently so they do not anchor on one another's current-round responses.`
  };
}

function buildAiDirectorSystemPrompt(opts){
  const isEmpty=!!opts?.isEmpty;
  const completedRounds=Math.max(0,Number(opts?.completedRounds)||0);
  const conversationMode=normalizeConversationMode(opts?.conversationMode||DEFAULT_CONVERSATION_MODE);
  const nextAgentName=String(opts?.nextAgentName||'').trim();
  const {modeGuidance,convergenceModifier}=getAiDirectorPromptSections(conversationMode,nextAgentName);
  const roundLabel=Math.max(1,completedRounds);
  const parts=[];

  if(isEmpty){
    parts.push(`You are the Director of this multi-provider conversation. You are both a contributing participant and the conversation leader.

Your job is to craft the next Director message. This is not just facilitation -- you have your own voice. When you see a connection the agents missed, a practical consideration they overlooked, or an opportunity to recommend a direction, contribute it directly. Synthesize what the agents have said, add your own analysis, and steer the conversation forward.

Read the agent responses carefully. Identify areas of agreement, disagreement, open questions, and promising threads. Generate a natural, conversational message that the Director can send as-is or refine further.`);
  }else{
    parts.push(`The Director is composing a message to send to the agents. Your job is to improve the Director's draft while preserving their intent and voice. Improve how they are asking, not what they are asking. If the draft is brief or vague, expand it into clearer direction. If it is already detailed, sharpen it.`);
  }

  parts.push(modeGuidance);
  parts.push(`Rules:
- Every prompt must push forward. Past responses are context, not destination. Brief acknowledgment of agent contributions is fine; extended praise or backward-facing reaction is not. Always end with direction, a recommendation, or a concrete next step.
- You do not have web access. Never claim to browse, search, verify facts, check sources, or perform research yourself.
- You may suggest that the Director ask one or more agents to research, verify, or compare something when that would help.
- Return only the message text. Do not add greetings, preambles, meta-commentary, or explanations of your reasoning.
- Keep the tone natural and conversational. This is a participant leading a discussion, not writing a formal memo.`);
  parts.push(`Convergence guidance:

You are in round ${roundLabel} of this conversation. As the conversation progresses, your role shifts gradually from exploration toward resolution. This is not a hard schedule -- read the conversation and modulate accordingly.

Before generating this prompt, assess the last 2-3 rounds:

- If the last few rounds produced genuinely new information, perspectives, or research findings: the conversation is still productive. Allow more exploration. Ease off convergence pressure.
- If the last few rounds have been dominated by agents evaluating, critiquing, or explaining why ideas will not work rather than proposing alternatives or novel approaches: the conversation needs creative expansion, not convergence. Challenge agents to propose solutions instead of cataloging problems. Push for ideas from adjacent domains, unconventional approaches, or creative reframings. Use language like "Do not just tell me why this fails -- propose what would make it work."
- If the last few rounds restated earlier positions without new evidence or reasoning: the conversation is oscillating. Push more firmly toward resolution. Acknowledge the disagreement and begin framing options rather than asking for more discussion.
- If agents are starting to align with only minor details unresolved: ease into convergence gently. Refine the edges. Do not slam into a forced conclusion.
- If the Director stepped in with input to redirect or pull back: the Director is signaling that the current path needs more exploration. Follow the Director's lead. Do not fight the Director's active intervention with convergence pressure.

Apply gentle, steady forward momentum. Each round, be slightly more decisive than the last -- not dramatically, but perceptibly. Think of it as roughly 10% more forward-leaning per round as a baseline, adjusted up or down by your assessment above.

${convergenceModifier}

Recognize three valid outcomes -- not just agreement:
1. Agreement: agents align on a recommendation. Consolidate and close.
2. Productive disagreement: agents hold genuinely different positions with real tradeoffs. Frame both options with stated tradeoffs and present the choice. This is a useful outcome, not a failure.
3. Oscillation: agents restate the same positions without progress. Acknowledge the disagreement, widen what counts as acceptable resolution, and either present options or make a recommendation. Do not keep asking agents to resolve what they have demonstrated they cannot.

Convergence on the wrong path is worse than no convergence. The human Director is always monitoring and can intervene. Your convergence pressure should be gentle forward momentum that the Director can easily override.`);

  if(completedRounds>=25){
    parts.push(`This conversation has run for ${completedRounds} rounds. At this stage, do not open new exploratory threads. Focus on resolving, framing, or closing the threads that already exist. If the conversation has a clear deliverable implied by its objective, begin working toward producing it. If major threads are resolved, consider stating what has been decided and presenting any remaining open items as Director decisions rather than topics for further agent discussion.`);
  }

  return parts.join('\n\n');
}

function buildDirectorAssistSystemPrompt(opts){
  const assistSource=(String(opts?.source||'manual').trim().toLowerCase()==='ai')?'ai':'manual';
  return assistSource==='ai'
    ? buildAiDirectorSystemPrompt(opts)
    : buildManualDirectorAssistSystemPrompt(opts);
}

function buildDirectorAssistUserPrompt(conv,currentText){
  const lines=[getCurrentDateTimeContextLine()];
  const dispatchContext=getDirectorAssistDispatchContext(conv);
  const topicObjective=String(conv?.topicObjective||'').trim();
  if(topicObjective) lines.push(`Conversation topic / objective:\n${topicObjective}`);
  lines.push(`Dispatch context:\n- Mode: ${dispatchContext.conversationMode}\n${dispatchContext.nextAgentName?`- Next responding sequential agent: ${dispatchContext.nextAgentName}`:'- Next responding sequential agent: n/a'}`);
  lines.push(buildDirectorAssistAgentRoster(conv));
  lines.push(buildDirectorAssistHistorySummary(conv));
  lines.push(buildDirectorAssistLatestRound(conv));
  lines.push('Important constraint: You are helping the Director frame the next message. You do not have web access and must not imply that you performed research.');
  if(String(currentText||'').trim()){
    lines.push(`Director's current draft:\n"""\n${String(currentText)}\n"""`);
    lines.push('Improve this draft.');
  }else{
    lines.push('The Director has not written a draft. Based on the conversation so far, draft the next Director message as a contributing participant who also steers the discussion forward.');
  }
  return lines.join('\n\n');
}

function normalizeDirectorAssistOutput(raw){
  return String(raw||'')
    .replace(/\r\n?/g,'\n')
    .replace(/[ \t]+$/gm,'')
    .replace(/\n\s*\n+/g,'\n')
    .trim();
}

async function runDirectorAssist(opts={}){
  const conv=S.conv;
  if(!conv||isDirectorInputLocked(conv)||S.directorAssistBusy) return;
  const assistSource=(String(opts?.source||'manual').trim().toLowerCase()==='ai')?'ai':'manual';
  const currentText=getDirectorDraftText();
  const completedRounds=getCompletedRoundCount(conv);
  const isEmpty=!currentText.trim();
  if(isEmpty&&completedRounds<1) return;
  const dispatchContext=getDirectorAssistDispatchContext(conv);

  const baseSlots=cloneDirectorAssistSlots(S.directorAssistSlots);
  const baseIndex=(S.directorAssistIndex>=0&&S.directorAssistIndex<baseSlots.length)?S.directorAssistIndex:0;
  const convKey=getDirectorAssistConvKey(conv);
  const assistToken=++S.directorAssistToken;
  S.directorAssistPressCount++;
  const assistIteration=S.directorAssistPressCount;
  S.directorAssistBusy=true;
  S.directorAssistSource=assistSource;
  syncDirectorComposerUi();
  try{
    const improved=normalizeDirectorAssistOutput(await requestHelperCompletion('',{
      system:buildDirectorAssistSystemPrompt({
        isEmpty,
        source:assistSource,
        assistIteration,
        completedRounds,
        conversationMode:dispatchContext.conversationMode,
        nextAgentName:dispatchContext.nextAgentName
      }),
      messages:[{role:'user',content:buildDirectorAssistUserPrompt(conv,currentText)}]
    }));
    if(!improved) return false;
    if(assistToken!==S.directorAssistToken) return false;
    if(getDirectorAssistConvKey(S.conv)!==convKey) return false;
    if(assistSource==='ai'&&!isAiDirectorMode(S.conv)&&S.conv===conv) return false;
    if(isEmpty){
      S.directorAssistSlots=[{committed:improved,tempEdits:null,source:'ai'}];
      S.directorAssistIndex=0;
      return true;
    }
    const nextSlots=baseSlots.slice(0,baseIndex+1);
    nextSlots.forEach((slot,idx)=>{
      if(idx<baseIndex) slot.tempEdits=null;
    });
    if(!nextSlots.length){
      nextSlots.push({committed:currentText,tempEdits:null,source:getDirectorDraftSource()||'human'});
    }else{
      nextSlots[baseIndex].committed=currentText;
      nextSlots[baseIndex].tempEdits=null;
    }
    nextSlots.push({committed:improved,tempEdits:null,source:'ai'});
    S.directorAssistSlots=nextSlots;
    S.directorAssistIndex=nextSlots.length-1;
    return true;
  }finally{
    if(assistToken===S.directorAssistToken){
      S.directorAssistBusy=false;
      S.directorAssistSource='';
      syncDirectorComposerUi();
    }
  }
}

async function dispatchToAgent(agent,dirMsg,atts,conv,opts={}){
  if(agent?.isGhost) return null;
  const logEl=document.getElementById('al_'+agent.id);
  const stEl=document.getElementById('as_'+agent.id);
  if(!logEl||!stEl)return;

  const appendDirectorTurn=opts?.appendDirectorTurn!==false;
  const files=atts.map(f=>({name:f.name,type:f.type}));
  if(appendDirectorTurn){
    const dm={id:'d_'+dirMsg.id+'_'+agent.id,role:'director',content:dirMsg.content,ts:dirMsg.ts,ctx:conv.context,files};
    agent.msgs.push(dm);
    appendAgentEntry(logEl,dm,agent);
    if(conv.settings?.autoScroll!==false) scrollAgentToLatestResponse(logEl);
  }

  let retryRequest=opts?.retryRequest?deepCloneJsonSafe(opts.retryRequest):null;
  if(!retryRequest){
    retryRequest=await buildAgentRetryRequest(agent,conv,atts);
  }
  const totalAllowedAttempts=isAiDirectorMode(conv)?(AI_DIRECTOR_FAILURE_RETRY_LIMIT+1):1;
  let attemptCount=0;
  let retriedFromFailure=!!opts?.retriedFromFailure;
  let modelResult={text:'',truncated:false,stopReason:'',toolUse:[]};
  let failure=null;
  for(let attempt=1;attempt<=totalAllowedAttempts;attempt++){
    attemptCount=attempt;
    stEl.className='a-status thinking';
    stEl.textContent=attempt>1?`Retrying... (${attempt-1}/${AI_DIRECTOR_FAILURE_RETRY_LIMIT})`:'Thinking...';
    const ctrl=new AbortController();
    S.aborts.push(ctrl);
    setInterruptVisible(true);
    try{
      const rawResult=await callModel(agent,conv,atts,ctrl.signal,(toolUse,isActive)=>{
        updateAgentToolPreview(logEl,agent.id,toolUse);
        if(isActive){
          stEl.className='a-status thinking';
          stEl.textContent='Researching...';
        }
      },{retryRequest});
      if(!retryRequest&&rawResult?._retryRequest){
        retryRequest=deepCloneJsonSafe(rawResult._retryRequest);
      }
      modelResult=normalizeModelResult(rawResult);
      failure=classifyEmptyCompletionFailure(modelResult);
    }catch(e){
      if(e?.name==='AbortError'){
        modelResult={text:'[Interrupted]',truncated:false,stopReason:'abort',toolUse:[]};
        failure=null;
      }else if(e?.apiSource==='web-search'){
        const shown=showWebSearchApiError(e);
        failure={
          kind:'failed_api',
          retryable:true,
          displayMessage:shown.displayMessage||shown.message||'Web search failed during this agent response.'
        };
        modelResult={text:'',truncated:false,stopReason:'error',toolUse:[]};
      }else{
        failure=classifyAgentFailureFromError(e);
        modelResult={text:'',truncated:false,stopReason:'error',toolUse:[]};
      }
    }finally{
      S.aborts=S.aborts.filter(c=>c!==ctrl);
      if(S.aborts.length===0) setInterruptVisible(false);
      removeAgentToolPreview(agent.id);
    }
    if(!failure) break;
    if(!isAutoRetryableFailureKind(failure.kind)||attempt>=totalAllowedAttempts) break;
    retriedFromFailure=true;
    await new Promise(resolve=>window.setTimeout(resolve,AI_DIRECTOR_FAILURE_RETRY_DELAY_MS));
  }

  const response=String(modelResult.text||'');
  const ts=Date.now();
  const dirSum=buildDirectorSnippet(dirMsg.content,128);
  const speakerLabel=getAgentIdentityLabel(agent,conv);
  const roundOrder=Number.isFinite(Number(opts?.roundOrder))?Number(opts.roundOrder):0;
  const am={id:'a'+ts+'_'+agent.id,role:'agent',content:response,ts,ctx:conv.context,dirSum,
    inReplyTo:dirMsg.id,round:dirMsg.num||conv.msgCount||0,speakerLabel,
    roundOrder,turnIndex:roundOrder,attemptCount:Math.max(1,attemptCount||1),
    retriedFromFailure:retriedFromFailure||Math.max(1,attemptCount||1)>1};
  if(Array.isArray(modelResult.toolUse)&&modelResult.toolUse.length) am.toolUse=modelResult.toolUse;
  if(failure){
    am.failed=true;
    am.failureKind=failure.kind||'failed_api';
    am.retryable=!!failure.retryable;
    am.errorMessage=failure.displayMessage||failure.message||'Agent response failed.';
    if(isRetryableFailureKind(am.failureKind)&&retryRequest){
      am._retryRequest=deepCloneJsonSafe(retryRequest);
    }
  }else if(String(modelResult.stopReason||'')==='abort'){
    am.failureKind='interrupted';
  }
  if(modelResult.truncated){
    am.truncated=true;
    am.stopReason=modelResult.stopReason||'max_tokens';
  }
  const col=COLORS.find(c=>c.id===agent.color)||COLORS[0];
  let statusWarning='';
  if(!failure){
    try{
      const parsedDownloads=parseDownloads(response,speakerLabel,col.hex);
      if(parsedDownloads.length){
        am.downloadItems=parsedDownloads;
        am.downloadStartIdx=S.downloads.length;
        am.downloadRegistered=true;
        registerDownloads(parsedDownloads);
        const warning=await writeDownloadPointersForAgentResponse(conv,agent,am,dirMsg,parsedDownloads);
        if(warning){
          appendNonFatalAgentWarning(am,warning);
          statusWarning=warning;
        }
      }
    }catch(e){
      console.warn('Non-fatal response follow-up failed:',e);
      appendNonFatalAgentWarning(am,'Some follow-up processing for this response could not be completed.');
      statusWarning=am.warningMessage;
    }
  }
  agent.msgs.push(am);
  try{
    appendAgentEntry(logEl,am,agent);
  }catch(e){
    console.error('Could not append agent entry. Re-rendering agent grid.',e);
    renderAgentGrid();
  }
  // Scroll so the newest response's top is at top of visible area
  scrollAgentToLatestResponse(logEl);
  if(failure){
    stEl.className='a-status fail';
    stEl.textContent='Failed · '+fmtT(ts);
  }else if(statusWarning){
    stEl.className='a-status warn';
    stEl.textContent='Warning · '+fmtT(ts);
  }else if(am.truncated){
    stEl.className='a-status warn';
    const reason=String(am.stopReason||'max_tokens').replace(/_/g,' ');
    stEl.textContent='Truncated · '+reason+' · '+fmtT(ts);
  }else{
    setAgentStatusDisplay(agent.id,ts);
  }
  try{
    refreshAgentDownloadBtn(agent.id);
  }catch(e){
    console.warn('Could not refresh agent download button:',e);
    stEl.className='a-status warn';
    stEl.textContent='Warning · '+fmtT(ts);
  }

  // Queue for TTS if voice is active on this agent
  if(!failure){
    try{
      ttsHandleResponse(agent, stripUrlSummaryBlocks(response), am.id);
    }catch(e){
      console.warn('Could not queue TTS for agent response:',e);
      stEl.className='a-status warn';
      stEl.textContent='Warning · '+fmtT(ts);
    }
  }
  syncAgentRetryButtonUi(agent.id);
  syncRoundFailureBanner();

  return{
    id:am.id,
    agentId:agent.id,
    agentName:speakerLabel,
    speakerLabel,
    content:response,
    ts,
    truncated:!!am.truncated,
    stopReason:am.stopReason||'',
    failed:!!am.failed,
    failureKind:String(am.failureKind||''),
    retryable:isRetryableFailureMessage(am),
    errorMessage:am.errorMessage||'',
    warningMessage:am.warningMessage||'',
    toolUse:Array.isArray(am.toolUse)?am.toolUse:[],
    attemptCount:Math.max(1,Number(am.attemptCount)||1),
    retriedFromFailure:!!am.retriedFromFailure
  };
}

async function persistRoundForDirectorMessage(conv,dirMsg){
  if(!conv||!dirMsg) return;
  if(dirMsg.roundOpen===false){
    dirMsg=getRoundOpeningMessageByRoundNumber(conv,dirMsg.num||dirMsg.roundId)||dirMsg;
  }
  const roundMode=normalizeConversationMode(dirMsg.roundMode||getConversationMode(conv));
  const targetIds=Array.isArray(dirMsg.targets)&&dirMsg.targets.length
    ?dirMsg.targets
    : conv.agents.map(a=>a.id);
  const targetNames=targetIds.map(tid=>{
    const agent=conv.agents.find(a=>a.id===tid);
    return agent?getAgentIdentityLabel(agent,conv):tid;
  });
  const baseRoundData={
    round:dirMsg.num||0,
    ts:dirMsg.ts,
    mode:roundMode,
    director:{
      id:dirMsg.id,
      content:dirMsg.content,
      targets:targetIds,
      targetNames,
      files:(dirMsg.files||[]).map(f=>f.name||f),
      source:normalizeDirectorType(dirMsg.source||'human')
    }
  };
  if(roundMode==='parallel'){
    const responses=targetIds.map(tid=>{
      const agent=conv.agents.find(a=>a.id===tid);
      if(!agent) return null;
      const matches=agent.msgs.filter(m=>m.role==='agent'&&m.inReplyTo===dirMsg.id);
      if(!matches.length) return null;
      const latest=matches[matches.length-1];
      return{
        id:latest.id||'',
        agentId:agent.id,
        agentName:getAgentMessageSpeakerLabel(agent,latest),
        speakerLabel:getAgentMessageSpeakerLabel(agent,latest),
        content:latest.content||'',
        ts:latest.ts,
        truncated:!!latest.truncated,
        stopReason:latest.stopReason||'',
        failed:!!latest.failed,
        failureKind:String(latest.failureKind||''),
        retryable:isRetryableFailureMessage(latest),
        errorMessage:latest.errorMessage||'',
        warningMessage:latest.warningMessage||'',
        toolUse:Array.isArray(latest.toolUse)?latest.toolUse:[],
        attemptCount:Math.max(1,Number(latest.attemptCount)||1),
        retriedFromFailure:!!latest.retriedFromFailure,
        _retryRequest:isRetryableFailureMessage(latest)?deepCloneJsonSafe(latest._retryRequest):undefined
      };
    }).filter(Boolean);
    await writeRoundFile({...baseRoundData,responses});
    return;
  }
  const turns=getConversationRoundTurnEntries(conv,dirMsg).map(entry=>{
    if(entry.type==='director'){
      return{
        type:'director',
        id:entry.msg.id||'',
        content:entry.msg.content||'',
        source:normalizeDirectorType(entry.msg.source||'human'),
        continue:!!entry.msg.continue,
        ts:entry.msg.ts,
        targets:Array.isArray(entry.msg.targets)?entry.msg.targets:[],
        files:(entry.msg.files||[]).map(f=>f.name||f)
      };
    }
    return{
        type:'agent',
        id:entry.msg.id||'',
        agentId:entry.agent.id,
        agentName:getAgentMessageSpeakerLabel(entry.agent,entry.msg),
        speakerLabel:getAgentMessageSpeakerLabel(entry.agent,entry.msg),
        content:entry.msg.content||'',
        ts:entry.msg.ts,
        truncated:!!entry.msg.truncated,
        stopReason:entry.msg.stopReason||'',
        failed:!!entry.msg.failed,
        failureKind:String(entry.msg.failureKind||''),
        retryable:isRetryableFailureMessage(entry.msg),
        errorMessage:entry.msg.errorMessage||'',
        warningMessage:entry.msg.warningMessage||'',
        toolUse:Array.isArray(entry.msg.toolUse)?entry.msg.toolUse:[],
        attemptCount:Math.max(1,Number(entry.msg.attemptCount)||1),
        retriedFromFailure:!!entry.msg.retriedFromFailure,
        _retryRequest:isRetryableFailureMessage(entry.msg)?deepCloneJsonSafe(entry.msg._retryRequest):undefined
    };
  });
  await writeRoundFile({...baseRoundData,turns});
}

async function retryAgentResponse(agentId,msgId,opts={}){
  const conv=S.conv;
  if(!conv) return;
  if(ensureClientSessionState().suspended){
    await appAlert(SESSION_SUPERSEDED_MESSAGE,{title:'SESSION SUPERSEDED'});
    return;
  }
  const agent=conv.agents.find(a=>a.id===agentId);
  if(!agent) return;
  const idx=agent.msgs.findIndex(m=>m.id===msgId&&m.failed);
  if(idx<0) return;
  const failedMsg=agent.msgs[idx];
  if(!isRetryableFailureMessage(failedMsg)) return;
  const dirMsg=conv.messages.find(m=>m.id===failedMsg.inReplyTo);
  if(!dirMsg) return;
  agent.msgs.splice(idx,1);
  document.getElementById('ae_'+msgId)?.remove();
  await dispatchToAgent(agent,dirMsg,[],conv,{
    retryRequest:failedMsg._retryRequest,
    retriedFromFailure:true,
    appendDirectorTurn:false
  });
  await persistRoundForDirectorMessage(conv,dirMsg);
  syncAgentRetryButtonUi(agent.id);
  syncRoundFailureBanner();
  if(S.logMode==='full'&&!opts.skipHistoryRender) renderHistory();
  if(isAiDirectorMode(conv)&&!opts.skipAiCycle) void scheduleAiDirectorCycle('retry-agent-response');
}

// ── MODEL CALLS ───────────────────────────────────────────────────
function normalizeModelResult(raw){
  if(raw&&typeof raw==='object'&&Object.prototype.hasOwnProperty.call(raw,'text')){
    return{
      text:String(raw.text||''),
      truncated:!!raw.truncated,
      stopReason:String(raw.stopReason||''),
      toolUse:Array.isArray(raw.toolUse)?raw.toolUse:[]
    };
  }
  return{text:String(raw||''),truncated:false,stopReason:'',toolUse:[]};
}

function deepCloneJsonSafe(value){
  if(value===undefined) return undefined;
  return JSON.parse(JSON.stringify(value));
}

function cloneRetryAttachments(atts){
  return Array.isArray(atts)?deepCloneJsonSafe(atts):[];
}

function getFailureKindLabel(kind){
  switch(String(kind||'')){
    case 'failed_empty': return 'Empty response';
    case 'failed_timeout': return 'Timed out';
    case 'failed_credits': return 'Credits required';
    case 'failed_api': return 'Request failed';
    case 'interrupted': return 'Interrupted';
    default: return 'Failed';
  }
}

function isRetryableFailureKind(kind){
  return['failed_empty','failed_api','failed_timeout','failed_credits'].includes(String(kind||''));
}

function isAutoRetryableFailureKind(kind){
  return['failed_empty','failed_api','failed_timeout'].includes(String(kind||''));
}

function isRetryableFailureMessage(msg){
  return !!msg&&!!msg.failed&&isRetryableFailureKind(msg.failureKind)&&!!msg._retryRequest;
}

function getLatestConversationRoundNumber(conv=S.conv){
  const last=[...(conv?.messages||[])].reverse().find(isRoundOpeningDirectorMessage);
  return Number(last?.num||last?.roundId||0);
}

function getLatestRoundFailureMessageForAgent(agent,conv=S.conv){
  if(!agent||!conv) return null;
  const roundNum=getLatestConversationRoundNumber(conv);
  if(!roundNum) return null;
  for(let i=(agent.msgs||[]).length-1;i>=0;i--){
    const msg=agent.msgs[i];
    if(msg?.role!=='agent') continue;
    if(Number(msg.round||0)!==roundNum) continue;
    return isRetryableFailureMessage(msg)?msg:null;
  }
  return null;
}

function syncAgentRetryButtonUi(agentId=''){
  const conv=S.conv;
  if(!conv) return 0;
  const ids=agentId?[String(agentId)]:conv.agents.map(agent=>String(agent?.id||'')).filter(Boolean);
  let updated=0;
  ids.forEach(id=>{
    const btn=document.getElementById('rt_'+id);
    const agent=conv.agents.find(entry=>String(entry?.id||'')===id);
    if(!btn||!agent) return;
    const failedMsg=getLatestRoundFailureMessageForAgent(agent,conv);
    const enabled=!!failedMsg;
    btn.disabled=!enabled;
    btn.classList.toggle('is-ready',enabled);
    btn.title=enabled?'Retry this agent using the original failed request context.':'Retry is available when this agent has a retryable failure in the latest round.';
    updated++;
  });
  return updated;
}

function retryLatestAgentFailure(agentId){
  const conv=S.conv;
  if(!conv) return;
  const agent=conv.agents.find(entry=>String(entry?.id||'')===String(agentId||''));
  const failedMsg=agent?getLatestRoundFailureMessageForAgent(agent,conv):null;
  if(failedMsg) void retryAgentResponse(agent.id,failedMsg.id);
}

function classifyAgentFailureFromError(err){
  const apiErr=normalizeApiError(err);
  if(apiErr?.name==='AbortError'){
    return{
      kind:'interrupted',
      retryable:false,
      displayMessage:'Interrupted.'
    };
  }
  const status=Number(apiErr?.apiStatus||0);
  if(status===402){
    return{
      kind:'failed_credits',
      retryable:true,
      displayMessage:apiErr.displayMessage||apiErr.message||'Insufficient OpenRouter credits.'
    };
  }
  if(String(apiErr?.failureKind||'')==='failed_timeout'||status===408){
    return{
      kind:'failed_timeout',
      retryable:true,
      displayMessage:apiErr.displayMessage||apiErr.message||`OpenRouter request timed out after ${Math.round(OPENROUTER_TIMEOUT_MS/1000)} seconds.`
    };
  }
  return{
    kind:'failed_api',
    retryable:true,
    displayMessage:apiErr.displayMessage||apiErr.message||'Agent response failed.'
  };
}

function classifyEmptyCompletionFailure(modelResult){
  const responseText=String(modelResult?.text||'');
  if(responseText.trim()) return null;
  const stopReason=String(modelResult?.stopReason||'');
  return{
    kind:'failed_empty',
    retryable:true,
    displayMessage:stopReason==='tool_loop_limit'
      ? 'Model exhausted tool steps before producing a final response.'
      : 'Empty response from model. No error was returned.'
  };
}

function summarizeFailureCauseLabel(kind,message){
  if(String(kind||'')==='failed_credits') return 'Insufficient OpenRouter credits';
  if(String(kind||'')==='failed_timeout') return 'OpenRouter requests timed out';
  if(String(kind||'')==='failed_empty') return 'Empty response from model';
  return String(message||'Agent request failed').trim()||'Agent request failed';
}

function createApiError(displayMessage,status,rawMessage){
  const err=new Error(displayMessage);
  err.isApiError=true;
  err.apiStatus=status||0;
  err.displayMessage=displayMessage;
  err.rawMessage=String(rawMessage||displayMessage);
  return err;
}
function mapOpenRouterError(status,rawMessage){
  const raw=String(rawMessage||'').trim();
  if(status===401) return'Invalid API key. Check your OpenRouter key in Settings.';
  if(status===402) return'Insufficient OpenRouter credits. Add credits at openrouter.ai or switch to a free model.';
  if(status===400) return raw?`OpenRouter rejected the request: ${raw}`:'OpenRouter rejected the request. Try a different helper model or adjust the request.';
  if(status===404) return'Model not found. It may have been removed. Select a different model.';
  if(status===408) return'Request timed out. Check your internet connection and try again.';
  if(status===429) return'Rate limited by OpenRouter. Wait a moment and try again.';
  if(status>=500&&status<600) return'OpenRouter is experiencing issues. Try again shortly.';
  if(raw) return`Unexpected error: ${status||raw}. Try again or select a different model.`;
  return`Unexpected error: ${status||'unknown error'}. Try again or select a different model.`;
}
function normalizeApiError(err){
  if(err?.name==='AbortError') return err;
  if(err?.isApiError) return err;
  const raw=String(err?.message||'').trim();
  if(/network/i.test(raw)) return createApiError('Network error. Check your internet connection.',0,raw);
  if(/timed? ?out/i.test(raw)) return createApiError('Request timed out. Check your internet connection and try again.',408,raw);
  return createApiError(raw||'Unexpected error. Try again or select a different model.',0,raw);
}
function closeApiErrorDialog(ev){
  if(ev&&ev.target&&ev.target.id!=='modal-api-error') return;
  const modal=document.getElementById('modal-api-error');
  if(modal) modal.style.display='none';
}
function showApiErrorDialog(title,message,suggestion,showSettings){
  const modal=document.getElementById('modal-api-error');
  if(!modal) return;
  document.getElementById('api-error-title').textContent=title;
  document.getElementById('api-error-message').textContent=message;
  document.getElementById('api-error-suggestion').textContent=suggestion||'';
  const btn=document.getElementById('api-error-open-settings');
  if(btn) btn.style.display=showSettings?'':'none';
  modal.style.display='flex';
}
function openSettingsFromApiError(){
  closeApiErrorDialog();
  drawerOpen('settings');
}
function showHelperApiError(err){
  const apiErr=normalizeApiError(err);
  if(apiErr.name==='AbortError') return apiErr;
  const status=Number(apiErr.apiStatus||0);
  let suggestion='Try again or select a different helper model in Settings.';
  let showSettings=true;
  if(status===401){
    suggestion='Check your OpenRouter API key in Settings.';
  }else if(status===402){
    suggestion='Add OpenRouter credits or select a free helper model in Settings.';
  }else if(status===400||status===404){
    suggestion='The selected helper model or request was rejected. Select a different helper model in Settings; details are shown above.';
  }else if(status===408||String(apiErr.failureKind||'')==='failed_timeout'){
    suggestion='Check your connection or try again with a smaller request.';
    showSettings=false;
  }else if(status===429){
    suggestion='Wait a moment, then retry or select a different helper model.';
    showSettings=false;
  }else if(status>=500&&status<600){
    suggestion='OpenRouter is having trouble. Try again shortly or select a different helper model.';
    showSettings=false;
  }
  showApiErrorDialog(
    'Helper Model Failed',
    apiErr.displayMessage||apiErr.message,
    suggestion,
    showSettings
  );
  return apiErr;
}
function showAgentApiError(err){
  const apiErr=normalizeApiError(err);
  if(apiErr.name==='AbortError') return apiErr;
  showApiErrorDialog(
    'Agent Response Failed',
    apiErr.displayMessage||apiErr.message,
    "You can change this agent's model by selecting a different persona or editing the current persona's model in the Personas panel. If this is a credits issue, add credits at openrouter.ai or switch to a free model.",
    false
  );
  return apiErr;
}

function mapBraveSearchError(status,rawMessage){
  const raw=String(rawMessage||'').trim();
  if(status===401) return'Invalid Brave Search API key. Check your key in Settings.';
  if(status===402) return'Brave Search credits exhausted. Check your plan at brave.com/search/api.';
  if(status===408) return'Brave Search timed out. Check your internet connection and try again.';
  if(status===429) return'Brave Search rate limited. Wait a moment and try again.';
  if(status>=500&&status<600) return'Brave Search is experiencing issues. Try again shortly.';
  if(raw) return`Unexpected Brave Search error: ${status||raw}.`;
  return`Unexpected Brave Search error: ${status||'unknown error'}.`;
}

function markWebSearchError(err){
  if(err&&typeof err==='object') err.apiSource='web-search';
  return err;
}

function showWebSearchApiError(err){
  const apiErr=normalizeApiError(err);
  if(apiErr.name==='AbortError') return apiErr;
  apiErr.apiSource='web-search';
  showApiErrorDialog(
    'Web Search Failed',
    apiErr.displayMessage||apiErr.message,
    'Check your Brave Search API key in Settings. Free tier: 2,000 searches/month.',
    true
  );
  return apiErr;
}

function getOpenRouterModelEntry(modelId,key='helper'){
  const id=key==='image'?ensureImageModelId(modelId):ensureModelId(modelId);
  const models=key==='image'
    ? (Array.isArray(S.openRouterImageModels)?S.openRouterImageModels:[])
    : (Array.isArray(S.openRouterModels)?S.openRouterModels:[]);
  return models.find(m=>m.id===id)||null;
}

function modelSupportsToolUse(modelId){
  const entry=getOpenRouterModelEntry(modelId);
  if(!entry) return true;
  return entry.supportsTools!==false;
}

function getConversationWebSearchBudget(conv=S.conv){
  return normalizeWebSearchBudget(conv?.settings?.webSearchBudget);
}
function getConversationRollingRounds(conv=S.conv){
  return normalizeRollingRounds(conv?.rollingRounds??APP_SETTINGS.maxRounds);
}
function getConversationActiveAgentIds(conv=S.conv){
  return normalizeActiveAgentIds(conv?.settings?.activeAgentIds,conv?.agents||[]);
}
function getFutureRoundTargetAgents(conv=S.conv){
  const activeIds=getConversationActiveAgentIds(conv);
  return Array.isArray(conv?.agents)?conv.agents.filter(agent=>activeIds.includes(String(agent?.id||''))):[];
}
function isAgentActive(agent,conv=S.conv){
  const id=String(agent?.id||'');
  return !!id&&getConversationActiveAgentIds(conv).includes(id);
}
function setConversationActiveAgentIds(conv,nextIds){
  if(!conv) return[];
  const activeIds=normalizeActiveAgentIds(nextIds,conv.agents||[]);
  conv.settings={...(conv.settings||{}),activeAgentIds:activeIds};
  syncConversationSettingsMirror(conv);
  return activeIds;
}
function getConversationMode(conv=S.conv){
  return normalizeConversationMode(conv?.settings?.conversationMode);
}
function isSequentialMode(conv=S.conv){
  return getConversationMode(conv)==='sequential';
}
function isFreeFormMode(conv=S.conv){
  return getConversationMode(conv)==='free_form';
}
function isParallelMode(conv=S.conv){
  return getConversationMode(conv)==='parallel';
}
function isAiDirectorAllowed(conv=S.conv){
  return !!conv&&Array.isArray(conv.agents)&&conv.agents.length>0;
}
function getConversationDirectorType(conv=S.conv){
  const desired=normalizeDirectorType(conv?.settings?.directorType);
  if(desired==='ai'&&!isAiDirectorAllowed(conv)) return'human';
  return desired;
}
function isAiDirectorMode(conv=S.conv){
  return getConversationDirectorType(conv)==='ai';
}
function getConversationAiDirectorCountdown(conv=S.conv){
  return normalizeAiDirectorCountdown(conv?.settings?.aiDirectorCountdown);
}
function getConversationPaceDelay(conv=S.conv){
  return normalizeConversationPaceDelay(conv?.settings?.paceDelay);
}

function applyDirectorTypeRuntimeChange(conv,prevDirectorType,nextDirectorType,{activeRound=null}={}){
  const prev=normalizeDirectorType(prevDirectorType);
  const next=normalizeDirectorType(nextDirectorType);
  if(prev===next) return;
  const draftSource=getDirectorDraftSource();
  const inputEl=document.getElementById('dir-input');
  const inputFocused=document.activeElement===inputEl;
  const hasDraft=!!getDirectorDraftText().trim();
  const round=activeRound||getActiveRoundForConversation(conv);
  const inFlightResponse=((round&&((isSequentialRound(round,conv)||isFreeFormRound(round,conv)))||(!round&&(isSequentialMode(conv)||isFreeFormMode(conv))))&&S.aborts.length>0);

  clearAiDirectorTimers(true);
  if(prev==='ai'&&next==='human'){
    freezeDirectorTurnTimer();
    S.directorTurnTimerElapsedMs=0;
    cancelDirectorAssistRun({clearDraft:false});
    if(draftSource==='ai') resetDirectorAssistState();
    S.aiDirectorStatus='';
    syncDirectorAiStatusUi();
    syncDirectorTurnTimerUi();
    syncDirectorComposerUi();
    return;
  }

  if(prev==='human'&&next==='ai'){
    freezeDirectorTurnTimer();
    S.directorTurnTimerElapsedMs=0;
    syncDirectorTurnTimerUi();
    if(inFlightResponse){
      S.aiDirectorStatus='';
      syncDirectorAiStatusUi();
      syncDirectorComposerUi();
      return;
    }
    if(hasDraft||inputFocused){
      S.aiDirectorStatus='AI waiting for Director';
      syncDirectorAiStatusUi();
      syncDirectorComposerUi();
      return;
    }
    void scheduleAiDirectorCycle('director-type-change');
  }
}

function getAgentWebTools(conv,profile){
  const braveKeyConfigured=isProviderKeyConfigured('keyBraveSearch');
  const budget=getConversationWebSearchBudget(conv);
  if(!budget||!braveKeyConfigured||!modelSupportsToolUse(profile?.model||'')) return[];
  return[
    {
      type:'function',
      function:{
        name:'web_search',
        description:'Search the web for current information. Use specific, targeted queries. Returns up to 10 results with titles, URLs, and brief descriptions.',
        parameters:{
          type:'object',
          properties:{
            query:{type:'string',description:'The search query. Be specific and focused.'}
          },
          required:['query']
        }
      }
    },
    {
      type:'function',
      function:{
        name:'read_url',
        description:'Fetch and read the main content of a specific web page. Use this only for relevant search results. After reading, write a 2-4 sentence summary wrapped in <<<URLSUMMARY>>> and <<<END_SUMMARY>>> tags.',
        parameters:{
          type:'object',
          properties:{
            url:{type:'string',description:'The full URL to fetch and read.'}
          },
          required:['url']
        }
      }
    }
  ];
}

function getLocalServiceUrl(path=''){
  return /^https?:\/\//i.test(String(path||''))
    ? String(path||'')
    : `${LOCAL_SERVICE_BASE_URL}${String(path||'').startsWith('/')?'':'/'}${String(path||'')}`;
}

const LOCAL_TOOL_TIMEOUT_MS=60000;
const WEB_SEARCH_TIMEOUT_MS=90000;

function createTimeoutSignal(timeoutMs,parentSignal){
  const ctrl=new AbortController();
  const ms=Math.max(1,Number(timeoutMs)||0);
  const timer=window.setTimeout(()=>{ ctrl.abort(new DOMException('Timed out','AbortError')); },ms);
  const onAbort=()=>{ ctrl.abort(parentSignal?.reason||new DOMException('Aborted','AbortError')); };
  if(parentSignal){
    if(parentSignal.aborted) onAbort();
    else parentSignal.addEventListener('abort',onAbort,{once:true});
  }
  return{
    signal:ctrl.signal,
    cleanup(){
      window.clearTimeout(timer);
      if(parentSignal) parentSignal.removeEventListener('abort',onAbort);
    }
  };
}

async function postLocalToolJson(path,payload,signal,options={}){
  const localToolUrl=getLocalServiceUrl(path);
  const timeoutMs=Math.max(1,Number(options.timeoutMs)||LOCAL_TOOL_TIMEOUT_MS);
  const timeoutLabel=String(options.timeoutLabel||'local tool request').trim()||'local tool request';
  const timeoutRef=createTimeoutSignal(timeoutMs,signal);
  const req={
    method:'POST',
    headers:{
      'Content-Type':'application/json; charset=utf-8',
      ...(CONFLAB_BRIDGE_AUTH_TOKEN?{'X-Conflab-Bridge-Token':CONFLAB_BRIDGE_AUTH_TOKEN}:{})
    },
    body:JSON.stringify(payload||{})
  };
  req.signal=timeoutRef.signal;
  try{
    return await fetch(localToolUrl,req);
  }catch(e){
    if(signal?.aborted&&e?.name==='AbortError') throw e;
    if(timeoutRef.signal.aborted&&e?.name==='AbortError'){
      throw markWebSearchError(createApiError(`${timeoutLabel} timed out after ${Math.round(timeoutMs/1000)} seconds.`,408,'timeout'));
    }
    throw markWebSearchError(createApiError('Could not reach the local web service. Make sure the Conflab local service is running.',0,e?.message||''));
  }finally{
    timeoutRef.cleanup();
  }
}

function getActiveWorkspacePath(){
  return fsNormalizePath(S.fsRoot?.path||'');
}

async function sendServerHeartbeat(reason='interval',options={}){
  if(serverHeartbeatPromise) return serverHeartbeatPromise;
  serverHeartbeatPromise=(async()=>{
    const session=ensureClientSessionState();
    try{
      const response=await fetch(getLocalServiceUrl('/api/heartbeat'),{
        method:'POST',
        headers:{
          'Content-Type':'application/json',
          ...(CONFLAB_BRIDGE_AUTH_TOKEN?{'X-Conflab-Bridge-Token':CONFLAB_BRIDGE_AUTH_TOKEN}:{})
        },
        body:JSON.stringify({
          reason,
          ts:Date.now(),
          sessionId:session.id,
          startedAt:session.startedAt,
          ownerEpoch:session.ownerEpoch||0,
          appVersion:APP_VERSION,
          workspacePath:getActiveWorkspacePath(),
          claim:!!options.claim
        }),
        keepalive:true
      });
      const payload=await response.json().catch(()=>null);
      if(response.ok&&payload){
        applySessionOwnershipPayload(payload);
      }
    }catch(e){
      // Heartbeat is best-effort. Silent failure avoids spurious UI noise during startup/shutdown.
    }finally{
      serverHeartbeatPromise=null;
    }
  })();
  return serverHeartbeatPromise;
}

function startServerHeartbeat(){
  if(serverHeartbeatTimer) return;
  setupSessionBroadcastChannel();
  claimSessionOwnership('startup');
  serverHeartbeatTimer=window.setInterval(()=>{ sendServerHeartbeat('interval'); },SERVER_HEARTBEAT_INTERVAL_MS);
}

const CP1252_UTF8_REVERSE_MAP=new Map([
  [String.fromCodePoint(0x20AC),0x80],[String.fromCodePoint(0x201A),0x82],[String.fromCodePoint(0x0192),0x83],
  [String.fromCodePoint(0x201E),0x84],[String.fromCodePoint(0x2026),0x85],[String.fromCodePoint(0x2020),0x86],
  [String.fromCodePoint(0x2021),0x87],[String.fromCodePoint(0x02C6),0x88],[String.fromCodePoint(0x2030),0x89],
  [String.fromCodePoint(0x0160),0x8A],[String.fromCodePoint(0x2039),0x8B],[String.fromCodePoint(0x0152),0x8C],
  [String.fromCodePoint(0x017D),0x8E],[String.fromCodePoint(0x2018),0x91],[String.fromCodePoint(0x2019),0x92],
  [String.fromCodePoint(0x201C),0x93],[String.fromCodePoint(0x201D),0x94],[String.fromCodePoint(0x2022),0x95],
  [String.fromCodePoint(0x2013),0x96],[String.fromCodePoint(0x2014),0x97],[String.fromCodePoint(0x02DC),0x98],
  [String.fromCodePoint(0x2122),0x99],[String.fromCodePoint(0x0161),0x9A],[String.fromCodePoint(0x203A),0x9B],
  [String.fromCodePoint(0x0153),0x9C],[String.fromCodePoint(0x017E),0x9E],[String.fromCodePoint(0x0178),0x9F]
]);
const MOJIBAKE_SUSPECT_TOKENS=['Ã','Â','â','Î','Ï','�'];
const MOJIBAKE_CHUNK_RE=/[^\s]{0,8}(?:Ã|Â|â|Î|Ï)[^\s]{0,24}/g;

function maybeDecodeMojibakeText(raw){
  const src=String(raw||'');
  if(!src||!/[ÃÂâÎÏ]/.test(src)) return src;
  try{
    const decoded=decodeURIComponent(escape(src));
    if(decoded&&decoded!==src) return decoded;
  }catch(e){}
  return src;
}

function countMojibakeSuspiciousTokens(raw){
  const src=String(raw||'');
  let count=0;
  MOJIBAKE_SUSPECT_TOKENS.forEach(token=>{
    let idx=src.indexOf(token);
    while(idx!==-1){
      count++;
      idx=src.indexOf(token,idx+token.length);
    }
  });
  return count;
}

function encodeCp1252Bytes(raw){
  const src=String(raw||'');
  const bytes=[];
  for(const ch of src){
    const code=ch.codePointAt(0);
    if(code<=0xFF){
      bytes.push(code);
      continue;
    }
    if(CP1252_UTF8_REVERSE_MAP.has(ch)){
      bytes.push(CP1252_UTF8_REVERSE_MAP.get(ch));
      continue;
    }
    return null;
  }
  return new Uint8Array(bytes);
}

function tryDecodeCp1252Utf8(raw){
  const bytes=encodeCp1252Bytes(raw);
  if(!bytes) return String(raw||'');
  try{
    return new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  }catch(e){
    return String(raw||'');
  }
}

function repairIncomingMojibakeText(raw){
  let text=String(raw||'');
  for(let i=0;i<3;i++){
    const next=tryDecodeCp1252Utf8(text);
    if(next===text) break;
    if(countMojibakeSuspiciousTokens(next)>countMojibakeSuspiciousTokens(text)) break;
    text=next;
  }
  return text.replace(MOJIBAKE_CHUNK_RE,chunk=>{
    let fixed=chunk;
    for(let i=0;i<3;i++){
      const next=tryDecodeCp1252Utf8(fixed);
      if(next===fixed) break;
      if(countMojibakeSuspiciousTokens(next)>countMojibakeSuspiciousTokens(fixed)) break;
      fixed=next;
    }
    return fixed;
  });
}

function stripResidualMojibakeFragments(raw){
  let text=String(raw||'');
  text=text.replace(/\uFFFD/g,'');
  text=text.replace(/Â(?=[^\w]|$)/g,'');
  text=text.replace(MOJIBAKE_CHUNK_RE,'');
  text=text.replace(/[ \t]{2,}/g,' ');
  text=text.replace(/\n{3,}/g,'\n\n');
  return text;
}

function sanitizeIncomingModelText(raw){
  let text=String(raw||'');
  text=maybeDecodeMojibakeText(text);
  text=repairIncomingMojibakeText(text);
  if(countMojibakeSuspiciousTokens(text)>0){
    text=stripResidualMojibakeFragments(text);
  }
  text=String(text||'').replace(/\uFFFD/g,'');
  text=text.replace(/\r\n/g,'\n').replace(/\r/g,'\n');
  return text;
}

function sanitizeExternalToolText(raw){
  let text=sanitizeIncomingModelText(raw);
  text=text.trim();
  return text;
}

function sanitizeSubmittedText(raw,options={}){
  const trim=options?.trim!==false;
  let text=sanitizeIncomingModelText(raw);
  if(trim) text=text.trim();
  return text;
}

function normalizeWebSearchResults(results){
  return(Array.isArray(results)?results:[]).slice(0,10).map(item=>({
    title:sanitizeExternalToolText(item?.title||''),
    url:sanitizeExternalToolText(item?.url||''),
    snippet:sanitizeExternalToolText(item?.snippet||'')
  })).filter(item=>item.url);
}

async function runLocalWebSearch(query,signal){
  const r=await postLocalToolJson('/api/brave/search',{query:String(query||''),count:10},signal,{
    timeoutMs:WEB_SEARCH_TIMEOUT_MS,
    timeoutLabel:'Web search'
  });
  const payload=await r.json().catch(()=>({}));
  if(!r.ok){
    const rawMessage=getPayloadErrorMessage(payload);
    throw markWebSearchError(createApiError(
      mapBraveSearchError(r.status,rawMessage),
      r.status,
      rawMessage
    ));
  }
  return normalizeWebSearchResults(payload?.results);
}

async function runLocalUrlFetch(url,signal){
  const cleanUrl=String(url||'').trim();
  if(!cleanUrl) return{ok:false,error:'No URL was provided.'};
  try{
    const r=await postLocalToolJson('/api/fetch',{url:cleanUrl},signal,{
      timeoutMs:LOCAL_TOOL_TIMEOUT_MS,
      timeoutLabel:'URL fetch'
    });
    const payload=await r.json().catch(()=>({}));
    if(!r.ok){
      return{ok:false,error:String(payload?.error||payload?.message||`Could not fetch ${cleanUrl}.`)};
    }
    return{
      ok:true,
      url:sanitizeExternalToolText(payload?.url||cleanUrl),
      title:sanitizeExternalToolText(payload?.title||''),
      content:sanitizeExternalToolText(payload?.content||'')
    };
  }catch(e){
    if(e?.name==='AbortError') throw e;
    return{ok:false,error:'Could not fetch that URL right now.'};
  }
}

function tryParseJsonObject(raw){
  if(raw&&typeof raw==='object') return raw;
  const src=String(raw||'').trim();
  if(!src) return null;
  try{return JSON.parse(src);}catch(e){return null;}
}

function normalizeToolCallList(toolCalls){
  return(Array.isArray(toolCalls)?toolCalls:[]).map(call=>{
    const fn=call?.function||{};
    const args=typeof fn.arguments==='string'?fn.arguments:JSON.stringify(fn.arguments||{});
    return{
      id:String(call?.id||'').trim()||createUUID(),
      type:'function',
      function:{
        name:String(fn.name||'').trim(),
        arguments:args
      }
    };
  }).filter(call=>call.function.name);
}

function extractOpenRouterText(rawContent){
  if(typeof rawContent==='string') return rawContent;
  if(Array.isArray(rawContent)){
    return rawContent.map(part=>{
      if(typeof part==='string') return part;
      if(typeof part?.text==='string') return part.text;
      return'';
    }).join('\n').trim();
  }
  return'';
}

async function buildAgentRetryRequest(agent,conv,atts){
  const maxRounds=conv.rollingRounds||APP_SETTINGS.maxRounds||10;
  const rounds=getRoundOpeningDirectorMessages(conv).slice(-maxRounds);
  const history=[];
  const topicObjective=(conv.topicObjective||'').trim();
  if(topicObjective){
    history.push({role:'user',content:`The user started this conversation with the following topic and/or goal:\n\n"${topicObjective}"\n\nThis may describe what they want to discuss, what they're trying to achieve, or both. Treat it as the guiding context for this conversation.`});
  }
  const temporalContext=getCurrentDateTimeContextLine();
  for(let i=0;i<rounds.length;i++){
    const dirMsg=rounds[i];
    const isLast=(i===rounds.length-1);
    const roundEntries=getConversationRoundTurnEntries(conv,dirMsg);
    let userContent=temporalContext+'\n\n';
    const directorLabel=(dirMsg.source==='ai')?'Director (AI) input':'Director input';
    userContent+=directorLabel+':\n'+(dirMsg.content||'[Blank]');
    const supporting=[];
    let ownResp=null;
    roundEntries.forEach(entry=>{
      if(entry.type==='director'){
        const label=entry.msg.source==='ai'?'Director (AI) follow-up':'Director follow-up';
        supporting.push(`${label}:\n${entry.msg.continue?'[Continue]':(entry.msg.content||'[Blank]')}`);
        return;
      }
      if(entry.agent.id===agent.id){
        ownResp=entry.msg;
        return;
      }
      if(entry.msg.content&&!entry.msg.content.startsWith('[')){
        supporting.push(`[${getAgentMessageSpeakerLabel(entry.agent,entry.msg)}]: ${buildAgentContextResponseText(entry.msg)}`);
      }
    });
    if(supporting.length>0) userContent+='\n\n'+supporting.join('\n\n');
    history.push({role:'user',content:userContent});
    if(!isLast){
      if(ownResp&&ownResp.content){
        history.push({role:'assistant',content:buildAgentContextResponseText(ownResp)});
      }else{
        history.push({role:'assistant',content:'[No response]'});
      }
    }
  }
  await ensureAgentPersonaResolved(agent);
  const profile=getEffectiveAgentProfile(agent);
  const model=profile.model;
  const tools=getAgentWebTools(conv,profile);
  return{
    model,
    system:buildAgentSystemPrompt(agent),
    history:deepCloneJsonSafe(history),
    atts:cloneRetryAttachments(atts),
    tools:deepCloneJsonSafe(tools),
    temporalContext,
    webActionBudget:getConversationWebSearchBudget(conv)
  };
}

async function executeAgentRetryRequest(request,signal,onToolUpdate){
  await ensureProtectedSettingsReadyForProviderUse();
  if(!isProviderKeyConfigured('keyOpenRouter')) throw createApiError('Invalid API key. Check your OpenRouter key in Settings.',401,'Missing OpenRouter API key');
  const safeRequest=deepCloneJsonSafe(request)||{};
  const tools=Array.isArray(safeRequest.tools)?safeRequest.tools:[];
  if(!tools.length){
    const result=await callOpenRouter(
      '',
      safeRequest.model,
      safeRequest.system||'',
      Array.isArray(safeRequest.history)?safeRequest.history:[],
      cloneRetryAttachments(safeRequest.atts),
      signal
    );
    return{...result,toolUse:[]};
  }
  return await callOpenRouterWithTools({
    key:'',
    model:safeRequest.model,
    system:safeRequest.system||'',
    history:Array.isArray(safeRequest.history)?safeRequest.history:[],
    atts:cloneRetryAttachments(safeRequest.atts),
    signal,
    onToolUpdate,
    tools,
    webActionBudget:Math.max(0,Number(safeRequest.webActionBudget)||0)
  });
}

async function callModel(agent,conv,atts,signal,onToolUpdate,opts={}){
  const retryRequest=opts?.retryRequest
    ? deepCloneJsonSafe(opts.retryRequest)
    : await buildAgentRetryRequest(agent,conv,atts);
  const result=await executeAgentRetryRequest(retryRequest,signal,onToolUpdate);
  return{...result,_retryRequest:retryRequest};
}

function getCurrentDateTimeContextLine(){
  const now=new Date();
  const tz=APP_SETTINGS.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';
  try{
    const formattedDateTime=new Intl.DateTimeFormat('en-US',{
      timeZone:tz,weekday:'long',year:'numeric',month:'long',day:'numeric',
      hour:'numeric',minute:'2-digit',second:'2-digit',hour12:true,timeZoneName:'short'
    }).format(now);
    const formattedDate=new Intl.DateTimeFormat('en-CA',{
      timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit'
    }).format(now);
    return `Current date and time: ${formattedDateTime} (${tz})\nCurrent date: ${formattedDate}`;
  }catch(e){
    const iso=now.toISOString();
    return `Current date and time: ${iso} (UTC)\nCurrent date: ${iso.slice(0,10)}`;
  }
}

async function callOpenRouterWithTools({key,model,system,history,atts,signal,onToolUpdate,tools,webActionBudget=0}){
  const messages=[...history];
  const toolUse=[];
  const assistantTexts=[];
  let webActionCount=0;
  let nextAtts=Array.isArray(atts)?atts:[];
  for(let step=0;step<12;step++){
    const result=await callOpenRouter(key,model,system,messages,nextAtts,signal,{tools});
    nextAtts=[];
    const assistantText=String(result?.text||'');
    if(assistantText) assistantTexts.push(assistantText);
    const toolCalls=normalizeToolCallList(result?.message?.tool_calls);
    if(!toolCalls.length){
      const finalToolUse=attachUrlSummariesToToolUse(toolUse,assistantTexts.join('\n\n'));
      if(typeof onToolUpdate==='function') onToolUpdate(finalToolUse,false);
      return{text:assistantText,truncated:!!result.truncated,stopReason:result.stopReason||'',toolUse:finalToolUse};
    }
    messages.push({
      role:'assistant',
      content:assistantText,
      tool_calls:toolCalls.map(call=>({
        id:call.id,
        type:'function',
        function:{name:call.function.name,arguments:call.function.arguments}
      }))
    });
    for(const toolCall of toolCalls){
      const name=toolCall.function.name;
      const args=tryParseJsonObject(toolCall.function.arguments)||{};
      let toolContent='';
      if(name==='web_search'){
        const query=String(args?.query||'').trim();
        if(!query){
          toolContent='Search query was empty.';
        }else if(webActionCount>=webActionBudget){
          toolContent='Combined web action budget exhausted for this round. No more searches or URL reads are available.';
        }else{
          webActionCount++;
          const results=await runLocalWebSearch(query,signal);
          toolUse.push({type:'web_search',query,results});
          if(typeof onToolUpdate==='function') onToolUpdate(toolUse,true);
          toolContent=JSON.stringify({results},null,2);
        }
      }else if(name==='read_url'){
        const url=String(args?.url||'').trim();
        if(!url){
          toolContent='No URL was provided.';
        }else if(webActionCount>=webActionBudget){
          toolContent='Combined web action budget exhausted for this round. Use the search snippets you already have to finish your response.';
        }else{
          webActionCount++;
          const fetched=await runLocalUrlFetch(url,signal);
          if(!fetched.ok){
            toolContent=String(fetched.error||'Could not fetch that URL.');
          }else{
            toolUse.push({
              type:'read_url',
              url:fetched.url,
              title:fetched.title,
              contentLength:String(fetched.content||'').length,
              summary:''
            });
            if(typeof onToolUpdate==='function') onToolUpdate(toolUse,true);
            toolContent=JSON.stringify({
              url:fetched.url,
              title:fetched.title,
              content:fetched.content
            },null,2);
          }
        }
      }else{
        toolContent=`Tool "${name}" is unavailable.`;
      }
      messages.push({role:'tool',tool_call_id:toolCall.id,content:String(toolContent||'')});
    }
  }
  const finalToolUse=attachUrlSummariesToToolUse(toolUse,assistantTexts.join('\n\n'));
  if(typeof onToolUpdate==='function') onToolUpdate(finalToolUse,false);
  return{text:'',truncated:false,stopReason:'tool_loop_limit',toolUse:finalToolUse};
}

async function callOpenRouter(key,model,system,messages,atts,signal,options={}){
  const msgs=system?[{role:'system',content:system},...messages]:[...messages];
  if(atts.length&&msgs.length){
    const last=msgs[msgs.length-1];
    if(last.role==='user'){
      const parts=[{type:'text',text:last.content}];
      atts.filter(f=>f.type.startsWith('image/')).forEach(f=>parts.push({type:'image_url',image_url:{url:f.data}}));
      atts.filter(f=>!f.type.startsWith('image/')&&typeof f.data==='string').forEach(f=>parts.push({type:'text',text:`[Attached file: ${f.name}]\n${f.data}`}));
      msgs[msgs.length-1]={role:'user',content:parts};
    }
  }
  const body={model,max_tokens:16384,messages:msgs};
  if(Array.isArray(options.tools)&&options.tools.length) body.tools=options.tools;
  const timeoutRef=createTimeoutSignal(OPENROUTER_TIMEOUT_MS,signal);
  let r;
  try{
    r=await fetchProtectedBridgeJson('/api/openrouter/chat',{
      method:'POST',
      payload:{body,bodyJson:JSON.stringify(body),referer:/^https?:/i.test(location?.origin||'')?location.origin:''},
      signal:timeoutRef.signal,
      timeoutMs:OPENROUTER_TIMEOUT_MS,
      timeoutLabel:'OpenRouter request'
    });
  }catch(e){
    if(signal?.aborted&&e?.name==='AbortError') throw e;
    if(timeoutRef.signal.aborted&&e?.name==='AbortError'){
      const timeoutErr=createApiError(`OpenRouter request timed out after ${Math.round(OPENROUTER_TIMEOUT_MS/1000)} seconds.`,408,'timeout');
      timeoutErr.failureKind='failed_timeout';
      throw timeoutErr;
    }
    throw createApiError('Network error. Check your internet connection.',0,e?.message||'');
  }finally{
    timeoutRef.cleanup();
  }
  if(!r.ok){
    const e=await r.json().catch(()=>({}));
    const msg=getPayloadErrorMessage(e)||('OpenRouter error '+r.status);
    throw createApiError(mapOpenRouterError(r.status,msg),r.status,msg);
  }
  const d=await r.json();
  const choice=d.choices?.[0]||{};
  const message=choice?.message||{};
  const text=sanitizeIncomingModelText(extractOpenRouterText(message?.content));
  const stopReason=String(choice?.finish_reason||'');
  return{
    text,
    message:{role:'assistant',content:text,tool_calls:normalizeToolCallList(message?.tool_calls)},
    truncated:stopReason==='length',
    stopReason:stopReason||'stop'
  };
}

// ── AGENT MANAGEMENT ──────────────────────────────────────────────
async function addAgent(){
  const c=S.conv;if(!c)return;
  if(getLiveConversationAgentCount(c)>=9){await appAlert('Maximum of 9 agents per conversation.');return;}
  const usedSlots=new Set(getLiveConversationAgents(c).map(a=>getAgentSlotIndex(a,c)).filter(i=>Number.isInteger(i)));
  let nextSlot=-1;
  for(let i=0;i<9;i++){
    if(!usedSlots.has(i)){nextSlot=i;break;}
  }
  if(nextSlot<0){await appAlert('No free agent slot available.');return;}
  const a=makeAgent(nextSlot);
  c.agents.push(a);
  sortAgentsBySlotIndex(c.agents);
  assignAgentColors(c);
  setConversationActiveAgentIds(c,[...getConversationActiveAgentIds(c),a.id]);
  renderAgentGrid();
  writeMetaFile();
  syncDirectorComposerUi();
}
async function removeAgent(agentId){
  const c=S.conv;if(!c)return;
  const agent=c.agents.find(a=>a.id===agentId);
  if(!agent) return;
  const removingActive=isAgentActive(agent,c);
  if(getLiveConversationAgentCount(c)<=MIN_ACTIVE_AGENT_COUNT||(removingActive&&getFutureRoundTargetAgents(c).length<=MIN_ACTIVE_AGENT_COUNT)){
    await appAlert(`At least ${MIN_ACTIVE_AGENT_COUNT} agents are required.`,{title:'MINIMUM AGENTS'});
    return;
  }
  const panelLabel=`Agent ${getAgentPanelNumber(agent,c)}`;
  const displayName=(agent.personaMissing||isAgentReady(agent))?getAgentDisplayName(agent):'';
  const subject=displayName?`${panelLabel} (${displayName})`:panelLabel;
  if(!await appConfirm(`Remove ${subject} from this conversation?\n\nThe agent's chat history will be lost.`,{title:'REMOVE AGENT',okLabel:'Remove'}))return;
  c.agents=c.agents.filter(a=>a.id!==agentId);
  assignAgentColors(c);
  let nextActiveIds=getConversationActiveAgentIds(c).filter(id=>id!==agentId);
  const firstLiveAgent=getLiveConversationAgents(c)[0]||null;
  if(!nextActiveIds.length&&firstLiveAgent) nextActiveIds=[firstLiveAgent.id];
  setConversationActiveAgentIds(c,nextActiveIds);
  renderAgentGrid();writeMetaFile();
  syncDirectorComposerUi();
}

// ── CONVERSATION EDITOR ───────────────────────────────────────────
function getConvDialogFormState(){
  return{
    name:sanitizeSubmittedText(document.getElementById('ds-name').value||''),
    topicObjective:sanitizeSubmittedText(document.getElementById('ds-topic-objective').value||''),
    participantDescription:sanitizeSubmittedText(document.getElementById('ds-participant-description').value||'')
  };
}

function setConvDialogFields(c){
  document.getElementById('ds-name').value=c.name||'';
  document.getElementById('ds-topic-objective').value=c.topicObjective||'';
  document.getElementById('ds-participant-description').value=c.participantDescription||'';
}
function syncConversationSettingsEditorUi(){
  return;
}
function applyConversationEditorLockState(conv=S.convDialogConv||S.conv){
  const locked=getConversationEditorLocked(conv);
  const lockEl=document.getElementById('conv-edit-lock');
  if(lockEl){
    lockEl.classList.toggle('on',locked);
    lockEl.title=locked
      ?'Conversation name, objective, and participant description are locked after the conversation has at least one round.'
      :'These conversation-editor fields are editable until the conversation has its first round.';
  }
  ['ds-name','ds-topic-objective','ds-participant-description'].forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.disabled=locked;
    el.readOnly=locked;
    el.classList.toggle('conv-edit-locked-field',locked);
  });
}

function isConvDialogDirty(){
  if(!S.convDialogInitial) return false;
  return JSON.stringify(getConvDialogFormState())!==JSON.stringify(S.convDialogInitial);
}

function updateConvDialogActionState(){
  const saveBtn=document.getElementById('ds-btn-save');
  const goBtn=document.getElementById('ds-btn-go');
  if(!saveBtn||!goBtn) return;
  const dirty=isConvDialogDirty();
  saveBtn.disabled=!dirty;
  goBtn.disabled=dirty;
  saveBtn.classList.toggle('dialog-btn-muted',!dirty);
  goBtn.classList.toggle('dialog-btn-muted',dirty);
  saveBtn.classList.toggle('dialog-btn-primary',dirty);
  goBtn.classList.toggle('dialog-btn-primary',!dirty);
}

function bindConvDialogDirtyHandlers(){
  if(S._convDialogBound) return;
  S._convDialogBound=true;
  const ids=['ds-name','ds-topic-objective','ds-participant-description'];
  ids.forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.addEventListener('input',updateConvDialogActionState);
    el.addEventListener('change',updateConvDialogActionState);
  });
}

async function renameConversationFolderIfNeeded(conv,newName){
  const currentPath=conv.sourcePath||S.convDialogPath||'';
  const segs=splitTreePath(currentPath);
  if(!segs.length) return;
  const oldFolderName=segs[segs.length-1];
  const parentPath=segs.slice(0,-1).join('/');
  const nextFolderBase=sanitizeTitleForFs(newName,64);
  if(nextFolderBase===oldFolderName) return;
  const parentHandle=await treeGetDirectoryHandleByPath(CONV_TREE_VIEW,parentPath);
  if(!parentHandle) throw new Error('Conversation parent folder missing.');
  let nextFolderName=nextFolderBase;
  try{
    await parentHandle.getDirectoryHandle(nextFolderName,{create:false});
    nextFolderName=await makeUniqueDirName(parentHandle,nextFolderBase);
  }catch(e){}
  const sourceHandle=conv.folderHandle||await parentHandle.getDirectoryHandle(oldFolderName,{create:false});
  const copied=await copyDirectoryRecursive(sourceHandle,parentHandle,nextFolderName);
  await parentHandle.removeEntry(oldFolderName,{recursive:true});
  const nextPath=parentPath?parentPath+'/'+nextFolderName:nextFolderName;
  treeRemapPathState(CONV_TREE_VIEW,currentPath,nextPath);
  conv.folderHandle=copied;
  conv.sourcePath=nextPath;
  conv.id=nextPath;
  S.convDialogPath=nextPath;
}

async function saveDirSettings(){
  const dialogConv=S.convDialogConv||S.conv;
  if(!dialogConv) return;
  const dialogPath=S.convDialogPath||dialogConv.sourcePath||'';
  const activeSame=!!S.conv&&(S.conv.sourcePath===dialogPath||(S.conv.uuid&&dialogConv.uuid&&S.conv.uuid===dialogConv.uuid));
  const c=activeSame&&S.conv?S.conv:dialogConv;
  const activeRound=activeSame&&S.conv?getActiveRoundForConversation(S.conv):null;
  const prevMode=getConversationMode(c);
  const prevDirectorType=getConversationDirectorType(c);
  const form=getConvDialogFormState();
  const editorLocked=getConversationEditorLocked(c);
  const nextName=editorLocked?String(c.name||'').trim():String(form.name||'').trim();
  const nextTopicObjective=editorLocked?String(c.topicObjective||'').trim():String(form.topicObjective||'').trim();
  const nextParticipantDescription=editorLocked?String(c.participantDescription||'').trim():String(form.participantDescription||'').trim();
  const topicObjectiveChanged=String(c.topicObjective||'').trim()!==nextTopicObjective;
  const participantDescriptionChanged=String(c.participantDescription||'').trim()!==nextParticipantDescription;
  const plannerSourceChanged=topicObjectiveChanged||participantDescriptionChanged;
  if(!nextName){
    await appAlert('Conversation name is required.');
    document.getElementById('ds-name').focus();
    return;
  }
  try{
    if(!editorLocked){
      await renameConversationFolderIfNeeded(c,nextName);
    }
    c.name=nextName;
    assignAgentColors(c);
    c.topicObjective=nextTopicObjective;
    c.participantDescription=nextParticipantDescription;
    document.getElementById('ds-name').value=c.name;
    document.getElementById('ds-topic-objective').value=c.topicObjective;
    document.getElementById('ds-participant-description').value=c.participantDescription;
    c.editorFieldsLocked=editorLocked;
    c.rollingRounds=getConversationRollingRounds(activeSame&&S.conv?S.conv:c);
    const preservedSettings={...(c.settings||{})};
    c.settings={
      ...preservedSettings,
      webSearchBudget:getConversationWebSearchBudget(activeSame&&S.conv?S.conv:c),
      conversationMode:normalizeConversationMode(preservedSettings.conversationMode),
      directorType:normalizeDirectorType(preservedSettings.directorType),
      aiDirectorCountdown:normalizeAiDirectorCountdown(preservedSettings.aiDirectorCountdown),
      paceDelay:normalizeConversationPaceDelay(preservedSettings.paceDelay)
    };
    const nextMode=getConversationMode(c);
    const nextDirectorType=getConversationDirectorType(c);
    const modeChanged=prevMode!==nextMode;
    const directorTypeChanged=prevDirectorType!==nextDirectorType;
    if(plannerSourceChanged){
      clearPersonaSegmentCycle(c);
      clearParticipantPlanCache(c);
    }
    await writeMetaFile(c);

    if(activeSame&&S.conv){
      S.conv.name=c.name;
      S.conv.sourcePath=c.sourcePath;
      S.conv.id=c.sourcePath;
      S.conv.topicObjective=c.topicObjective;
      S.conv.participantDescription=c.participantDescription;
      S.conv.agentCols=c.agentCols;
      S.conv.editorFieldsLocked=c.editorFieldsLocked;
      S.conv.rollingRounds=c.rollingRounds;
      S.conv.settings={...c.settings};
      S.conv.folderHandle=c.folderHandle;
      if(plannerSourceChanged){
        clearPersonaSegmentCycle(S.conv);
        clearParticipantPlanCache(S.conv);
      }
    }
    if(S.convDialogConv&&isSameConversation(S.convDialogConv,c)){
      S.convDialogConv.name=c.name;
      S.convDialogConv.sourcePath=c.sourcePath;
      S.convDialogConv.id=c.sourcePath;
      S.convDialogConv.topicObjective=c.topicObjective;
      S.convDialogConv.participantDescription=c.participantDescription;
      S.convDialogConv.agentCols=c.agentCols;
      S.convDialogConv.editorFieldsLocked=c.editorFieldsLocked;
      S.convDialogConv.rollingRounds=c.rollingRounds;
      S.convDialogConv.settings={...c.settings};
      S.convDialogConv.folderHandle=c.folderHandle;
      S.convDialogConv.msgCount=Math.max(Number(S.convDialogConv.msgCount||0),Number(c.msgCount||0));
      if(Array.isArray(c.agents)) S.convDialogConv.agents=c.agents;
    }
    void warmParticipantPlan(c,{persist:true});

    await scanConvFolders();
    treeSelectPath(CONV_TREE_VIEW,c.sourcePath||S.convDialogPath||'');
    if(activeSame&&directorTypeChanged){
      applyDirectorTypeRuntimeChange(S.conv||c,prevDirectorType,nextDirectorType,{activeRound});
    }
    if(activeSame&&modeChanged&&!activeRound) resetConversationRuntimeState();
    renderAll();
    syncConversationSettingsEditorUi();
    if(S.convDialogIsNew){
      S.convDialogIsNew=false;
      setConvDialogFields(c);
    }
    applyConversationEditorLockState(c);
    S.convDialogInitial=getConvDialogFormState();
    updateConvDialogActionState();
  }catch(e){
    await appAlert('Could not save conversation settings.');
  }
}

async function deleteConversationFromDialog(){
  const c=S.convDialogConv||S.conv;
  const path=S.convDialogPath||c?.sourcePath||'';
  if(!c||!path) return;
  const ok=await appConfirm('This will permanently delete this conversation and all its data (agents, logs).',{title:'DELETE CONVERSATION',okLabel:'Delete'});
  if(!ok) return;
  try{
    const segs=splitTreePath(path);
    if(!segs.length) return;
    const folderName=segs[segs.length-1];
    const parentPath=segs.slice(0,-1).join('/');
    const parentHandle=await treeGetDirectoryHandleByPath(CONV_TREE_VIEW,parentPath);
    if(!parentHandle) throw new Error('Missing parent folder.');
    await parentHandle.removeEntry(folderName,{recursive:true});
    if(S.conv?.sourcePath===path){
      S.conv=null;
      S.attachments=[];
      clearDownloads();
    }
    conversationListBack();
    treeSelectPath(CONV_TREE_VIEW,parentPath);
    await scanConvFolders();
    renderAll();
  }catch(e){
    await appAlert('Could not delete conversation.');
  }
}

async function goConversation(){
  if(isConvDialogDirty()) return;
  const path=S.convDialogPath||(S.convDialogConv?.sourcePath)||'';
  if(!path){conversationListBack();return;}
  S.convDialogIsNew=false;
  conversationListBack();
  await scanConvFolders();
  const node=S.convTreeIndex?.[path];
  if(node&&node.type==='conversation'){
    await openConvFolder(node);
  }
}

function openConversationEditView(){
  const c=S.convDialogConv||S.conv;
  if(!c) return;
  drawerOpen('convs');
  bindConvDialogDirtyHandlers();
  if(!S.convDialogPath) S.convDialogPath=c.sourcePath||c.id||'';
  setConvDialogFields(c);
  applyConversationEditorLockState(c);
  S.convDialogInitial=getConvDialogFormState();
  document.getElementById('conv-list-view').style.display='none';
  document.getElementById('conv-edit-view').style.display='flex';
  updateConvDialogActionState();
  setTimeout(()=>{
    if(getConversationEditorLocked(c)) return;
    document.getElementById('ds-name')?.focus();
  },0);
}

function conversationListBack(){
  document.getElementById('conv-list-view').style.display='flex';
  document.getElementById('conv-edit-view').style.display='none';
  S.convDialogConv=null;
  S.convDialogPath='';
  S.convDialogInitial=null;
  S.convDialogIsNew=false;
  renderConvList();
}

// ── AGENT SETTINGS MODAL ──────────────────────────────────────────
// ── COLUMNS ───────────────────────────────────────────────────────
function setAgentCols(n){
  const c=S.conv;if(!c)return;
  c.agentCols=+n;
  document.getElementById('agent-grid').style.gridTemplateColumns=`repeat(${n},1fr)`;
  document.getElementById('col-sel').value=n;
  writeMetaFile();
}

// ── DICTATION ─────────────────────────────────────────────────────
// Mic singleton — created once so Chrome doesn't re-request permission on each toggle
let _micInstance=null;
let _micPermissionWarmupAttempted=false;
function resetMicTranscriptState(anchorStart=0,anchorEnd=anchorStart){
  const start=Math.max(0,Number(anchorStart)||0);
  const end=Math.max(start,Number(anchorEnd)||start);
  S.micLastFinalIndex=0;
  S.micInsertAnchor=start;
  S.micInterimStart=start;
  S.micInterimEnd=end;
}
function clearMicTranscriptState(){
  resetMicTranscriptState(0,0);
}
function getMicRecognitionErrorMessage(errorCode=''){
  const code=String(errorCode||'').toLowerCase();
  if(code==='not-allowed'||code==='service-not-allowed'){
    return 'Microphone access was denied. Check your browser settings to allow microphone access for this site.';
  }
  if(code==='audio-capture'){
    return 'No microphone was found or it could not be started.';
  }
  if(code==='network'){
    return 'Speech recognition lost its network connection. Please try again.';
  }
  return 'Could not start microphone dictation.';
}
async function preGrantMicrophonePermission(){
  if(_micPermissionWarmupAttempted) return;
  _micPermissionWarmupAttempted=true;
  try{
    if(!navigator?.permissions?.query||!navigator?.mediaDevices?.getUserMedia) return;
    const status=await navigator.permissions.query({name:'microphone'});
    if(String(status?.state||'')!=='prompt') return;
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
    stream.getTracks().forEach(track=>track.stop());
  }catch(e){
    // Best-effort only. Startup should stay silent if permission probing is unavailable or fails.
  }
}
function getMicInstance(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR) return null;
  if(_micInstance) return _micInstance;
  const r=new SR();
  r.continuous=true;r.interimResults=true;r.lang='en-US';
  r.onresult=e=>{
    if(isDirectorInputLocked(S.conv)||(S.directorAssistBusy&&S.directorAssistSource!=='ai')) return;
    const ta=document.getElementById('dir-input');
    if(!ta) return;
    let finalText='';
    let interimText='';
    for(let i=S.micLastFinalIndex;i<e.results.length;i++){
      const result=e.results[i];
      const alt=result?.[0];
      const transcript=String(alt?.transcript||'');
      if(result?.isFinal){
        finalText+=transcript;
        S.micLastFinalIndex=i+1;
      }else{
        interimText+=transcript;
      }
    }
    const replaceStart=Math.max(0,Math.min(S.micInterimStart,ta.value.length));
    const replaceEnd=Math.max(replaceStart,Math.min(S.micInterimEnd,ta.value.length));
    const before=ta.value.slice(0,replaceStart);
    const after=ta.value.slice(replaceEnd);
    const insertText=finalText+interimText;
    const nextValue=before+insertText+after;
    const nextInterimStart=replaceStart+finalText.length;
    const nextInterimEnd=nextInterimStart+interimText.length;
    const changed=ta.value!==nextValue;
    if(changed) ta.value=nextValue;
    S.micInterimStart=nextInterimStart;
    S.micInterimEnd=nextInterimEnd;
    const cursorPos=Math.max(0,Math.min(nextInterimEnd,ta.value.length));
    ta.setSelectionRange(cursorPos,cursorPos);
    ta.focus();
    if(changed) onDirectorInputChange();
  };
  r.onerror=e=>{
    const code=String(e?.error||'').toLowerCase();
    const shouldAlert=code&&code!=='aborted';
    stopMic();
    if(shouldAlert) void appAlert(getMicRecognitionErrorMessage(code),{title:'MICROPHONE'});
  };
  r.onend=()=>{
    if(S.micOn){
      try{r.start();}catch(e){}
    }
  };
  _micInstance=r;
  return r;
}
function toggleMic(){
  S.micOn?stopMic():startMic();
}
async function startMic(){
  const r=getMicInstance();
  if(!r){await appAlert('Speech recognition requires Chrome or Edge.');return;}
  const ta=document.getElementById('dir-input');
  const selStart=Math.max(0,Number(ta?.selectionStart)||0);
  const selEnd=Math.max(selStart,Number(ta?.selectionEnd)||selStart);
  resetMicTranscriptState(selStart,selEnd);
  try{
    r.start();
  }catch(e){
    const name=String(e?.name||'');
    if(!/InvalidStateError/i.test(name)){
      clearMicTranscriptState();
      await appAlert(getMicRecognitionErrorMessage(e?.error||name),{title:'MICROPHONE'});
      return;
    }
  }
  S.mic=r;S.micOn=true;
  document.getElementById('mic-btn')?.classList.add('mic-on');
}
function stopMic(){
  const mic=S.mic;
  S.micOn=false;
  S.mic=null;
  clearMicTranscriptState();
  document.getElementById('mic-btn')?.classList.remove('mic-on');
  if(mic){try{mic.stop();}catch(e){}}
}

// ── UTILS ─────────────────────────────────────────────────────────
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function renderCompactTextHtml(s){
  const lines=String(s||'').replace(/\r\n?/g,'\n').split('\n');
  if(!lines.length) return '';
  let out='';
  let prevBlank=false;
  lines.forEach((line,idx)=>{
    const isBlank=line==='';
    if(idx===0){
      if(isBlank) out+='<span class="compact-gap" aria-hidden="true"></span>';
      else out+=esc(line);
      prevBlank=isBlank;
      return;
    }
    if(isBlank){
      out+='<span class="compact-gap" aria-hidden="true"></span>';
    }else{
      if(!prevBlank) out+='<br>';
      out+=esc(line);
    }
    prevBlank=isBlank;
  });
  return out;
}

const URL_AUTOLINK_RE=/https?:\/\/[^\s<>"']+/gi;

function mdSafeHref(url){
  const u=String(url||'').trim();
  if(/^https?:\/\//i.test(u)||/^mailto:/i.test(u)) return u;
  return '';
}
function mdSafeImageSrc(url){
  const u=String(url||'').trim();
  if(/^https?:\/\//i.test(u)) return u;
  if(/^data:image\/[a-z0-9.+-]+;base64,[a-z0-9+/=]+$/i.test(u)) return u;
  return '';
}
function mdInline(s){
  let t=esc(s||'');
  t=t.replace(/!\[([^\]]*)\]\(([^)]+)\)/g,(m,label,url)=>{
    const safe=mdSafeImageSrc(url);
    if(!safe) return label;
    return `<img src="${esc(safe)}" alt="${label}">`;
  });
  t=t.replace(/`([^`]+)`/g,'<code>$1</code>');
  t=t.replace(/\[([^\]]+)\]\(([^)]+)\)/g,(m,label,url)=>{
    const safe=mdSafeHref(url);
    return safe?`<a href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${label}</a>`:label;
  });
  t=t.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
  t=t.replace(/\*([^*]+)\*/g,'<em>$1</em>');
  return t;
}

function parseConflabBlockquoteMeta(line){
  const m=String(line||'').trim().match(/^\{#conflab-border-color=(#[0-9a-f]{6})\}$/i);
  return m?{borderColor:m[1]}:null;
}

function trimAutolinkTrailingPunctuation(raw){
  let url=String(raw||'');
  let suffix='';
  while(/[.,!?;:]$/.test(url)){
    suffix=url.slice(-1)+suffix;
    url=url.slice(0,-1);
  }
  while(/\)$/.test(url)){
    const opens=(url.match(/\(/g)||[]).length;
    const closes=(url.match(/\)/g)||[]).length;
    if(closes<=opens) break;
    suffix=')'+suffix;
    url=url.slice(0,-1);
  }
  return {url,suffix};
}

function buildAutoLinkedTextFragment(text){
  const src=String(text||'');
  URL_AUTOLINK_RE.lastIndex=0;
  if(!src||!URL_AUTOLINK_RE.test(src)) return null;
  URL_AUTOLINK_RE.lastIndex=0;
  const frag=document.createDocumentFragment();
  let lastIndex=0;
  let match;
  while((match=URL_AUTOLINK_RE.exec(src))!==null){
    const start=match.index;
    const rawUrl=String(match[0]||'');
    const {url,suffix}=trimAutolinkTrailingPunctuation(rawUrl);
    if(start>lastIndex) frag.appendChild(document.createTextNode(src.slice(lastIndex,start)));
    const safe=mdSafeHref(url);
    if(safe){
      const link=document.createElement('a');
      link.href=safe;
      link.target='_blank';
      link.rel='noopener noreferrer';
      link.textContent=url;
      frag.appendChild(link);
    }else{
      frag.appendChild(document.createTextNode(rawUrl));
    }
    if(suffix) frag.appendChild(document.createTextNode(suffix));
    lastIndex=start+rawUrl.length;
  }
  if(lastIndex<src.length) frag.appendChild(document.createTextNode(src.slice(lastIndex)));
  return frag;
}

function autoLinkHtmlFragment(html){
  const tpl=document.createElement('template');
  tpl.innerHTML=String(html||'');
  const walker=document.createTreeWalker(tpl.content,NodeFilter.SHOW_TEXT,{
    acceptNode(node){
      URL_AUTOLINK_RE.lastIndex=0;
      if(!node.nodeValue||!URL_AUTOLINK_RE.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
      const parent=node.parentElement;
      if(parent&&parent.closest('a,code,pre,script,style')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  const nodes=[];
  let node;
  while((node=walker.nextNode())) nodes.push(node);
  nodes.forEach(textNode=>{
    const frag=buildAutoLinkedTextFragment(textNode.nodeValue||'');
    if(frag&&textNode.parentNode) textNode.parentNode.replaceChild(frag,textNode);
  });
  return tpl.innerHTML;
}

function shouldRenderTextAsMarkdown(text){
  const src=String(text||'');
  if(!src.trim()) return false;
  return /https?:\/\/|!\[[^\]]*\]\([^)]+\)|\[[^\]]+\]\([^)]+\)|^#{1,6}\s|^\s*[-*+]\s|^\s*\d+\.\s|^\s*>\s?|^\s*\|.+\|\s*$|^```|^(?:---|\*\*\*|___)\s*$/m.test(src);
}

function renderRichTextHtml(text){
  const src=String(text||'');
  if(!shouldRenderTextAsMarkdown(src)) return renderCompactTextHtml(src);
  return `<div class="md-doc">${renderMarkdownHtml(src)}</div>`;
}

function isMdTableDelimiter(line){
  return /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line||'');
}
function parseMdTableCells(line){
  let s=String(line||'').trim();
  if(s.startsWith('|')) s=s.slice(1);
  if(s.endsWith('|')) s=s.slice(0,-1);
  return s.split('|').map(c=>c.trim());
}
function isMdBlockStart(lines,i){
  const line=(lines[i]||'').trim();
  if(!line) return true;
  if(/^#{1,6}\s+/.test(line)) return true;
  if(/^(?:---|\*\*\*|___)\s*$/.test(line)) return true;
  if(/^```/.test(line)) return true;
  if(/^>\s?/.test(line)) return true;
  if(/^[-*+]\s+/.test(line)) return true;
  if(/^\d+\.\s+/.test(line)) return true;
  if(lines[i].includes('|')&&i+1<lines.length&&isMdTableDelimiter(lines[i+1])) return true;
  return false;
}
function renderMarkdownHtml(md){
  const lines=String(md||'').replace(/\r\n?/g,'\n').split('\n');
  let i=0;
  const out=[];
  while(i<lines.length){
    const raw=lines[i]||'';
    const line=raw.trim();
    if(!line){i++;continue;}

    if(/^```/.test(line)){
      const code=[];
      i++;
      while(i<lines.length&&!/^```/.test((lines[i]||'').trim())){code.push(lines[i]);i++;}
      if(i<lines.length) i++;
      out.push(`<pre><code>${esc(code.join('\n'))}</code></pre>`);
      continue;
    }

    const h=line.match(/^(#{1,6})\s+(.+)$/);
    if(h){
      const lvl=h[1].length;
      out.push(`<h${lvl}>${mdInline(h[2])}</h${lvl}>`);
      i++;
      continue;
    }

    if(/^(?:---|\*\*\*|___)\s*$/.test(line)){out.push('<hr>');i++;continue;}

    if(raw.includes('|')&&i+1<lines.length&&isMdTableDelimiter(lines[i+1])){
      const header=parseMdTableCells(raw);
      i+=2;
      const rows=[];
      while(i<lines.length){
        const r=lines[i]||'';
        if(!r.trim()||!r.includes('|')||isMdTableDelimiter(r.trim())) break;
        rows.push(parseMdTableCells(r));
        i++;
      }
      const thead=`<thead><tr>${header.map(c=>`<th>${mdInline(c)}</th>`).join('')}</tr></thead>`;
      const tbody=rows.length?`<tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${mdInline(c)}</td>`).join('')}</tr>`).join('')}</tbody>`:'';
      out.push(`<table>${thead}${tbody}</table>`);
      continue;
    }

    if(/^>\s?/.test(line)){
      const q=[];
      while(i<lines.length&&/^>\s?/.test((lines[i]||'').trim())){
        q.push((lines[i]||'').replace(/^\s*>\s?/,'').trim());
        i++;
      }
      const meta=parseConflabBlockquoteMeta(q[0]);
      if(meta) q.shift();
      const style=meta?.borderColor?` style="border-left-color:${esc(meta.borderColor)}"`:'';
      out.push(`<blockquote${style}>${q.map(v=>mdInline(v)).join('<br>')}</blockquote>`);
      continue;
    }

    if(/^[-*+]\s+/.test(line)){
      const items=[];
      while(i<lines.length){
        const m=(lines[i]||'').trim().match(/^[-*+]\s+(.+)$/);
        if(m){items.push(m[1]);i++;continue;}
        if(items.length&&/^\s{2,}\S/.test(lines[i]||'')){items[items.length-1]+=' '+(lines[i]||'').trim();i++;continue;}
        break;
      }
      out.push(`<ul>${items.map(v=>`<li>${mdInline(v)}</li>`).join('')}</ul>`);
      continue;
    }

    if(/^\d+\.\s+/.test(line)){
      const items=[];
      while(i<lines.length){
        const m=(lines[i]||'').trim().match(/^\d+\.\s+(.+)$/);
        if(m){items.push(m[1]);i++;continue;}
        if(items.length&&/^\s{2,}\S/.test(lines[i]||'')){items[items.length-1]+=' '+(lines[i]||'').trim();i++;continue;}
        break;
      }
      out.push(`<ol>${items.map(v=>`<li>${mdInline(v)}</li>`).join('')}</ol>`);
      continue;
    }

    const para=[];
    while(i<lines.length){
      const s=(lines[i]||'').trim();
      if(!s||isMdBlockStart(lines,i)) break;
      para.push(s);
      i++;
    }
    if(para.length){out.push(`<p>${mdInline(para.join(' '))}</p>`);continue;}
    i++;
  }
  return autoLinkHtmlFragment(out.join('\n'));
}
const CONFLAB_DELIVERABLE_CSS=`
  :root{color-scheme:light;}
  *{box-sizing:border-box}
  body{
    margin:0;
    padding:32px;
    background:#eef1f4;
    color:#15202b;
    font-family:Georgia,"Times New Roman",serif;
    line-height:1.6;
  }
  .conflab-deliverable{
    width:min(920px,100%);
    margin:0 auto;
    background:#fff;
    border:1px solid #d7dde4;
    border-radius:14px;
    padding:40px 44px;
    box-shadow:0 10px 30px rgba(15,23,42,.08);
  }
  h1,h2,h3,h4,h5,h6{
    margin:18px 0 8px;
    color:#0f172a;
    font-family:Arial,Helvetica,sans-serif;
    line-height:1.25;
  }
  h1{font-size:28px}
  h2{font-size:22px}
  h3{font-size:18px}
  h4,h5,h6{font-size:16px}
  p{margin:10px 0}
  ul,ol{margin:10px 0 10px 22px;padding:0}
  li{margin:4px 0}
  hr{border:none;border-top:1px solid #d7dde4;margin:18px 0}
  a{color:#0f766e}
  blockquote{
    margin:16px 0 16px 22px;
    padding:10px 14px;
    border-left:4px solid #7dd3c7;
    background:#f4fbf9;
  }
  code{
    font-family:"JetBrains Mono","Courier New",monospace;
    background:#f3f4f6;
    padding:1px 4px;
    border-radius:4px;
  }
  pre{
    margin:14px 0;
    padding:14px 16px;
    overflow:auto;
    border:1px solid #d7dde4;
    border-radius:8px;
    background:#f8fafc;
  }
  pre code{background:none;padding:0}
  table{width:100%;border-collapse:collapse;margin:16px 0}
  th,td{border:1px solid #d7dde4;padding:8px 10px;vertical-align:top;text-align:left}
  th{background:#f8fafc;color:#0f172a}
  img{
    max-width:100%;
    height:auto;
    display:block;
    margin:16px auto;
    border-radius:10px;
  }
  .summary-image{
    margin:16px auto 20px;
    break-inside:avoid;
    page-break-inside:avoid;
  }
  .summary-image img{
    margin:0 auto;
  }
  .summary-image.is-portrait img{
    max-width:75%;
  }
  @page { size: letter; margin: 0.25in; }
  @media print {
    body { font-size: 11pt; color: #000; background: #fff; padding:0; }
    .conflab-deliverable{width:auto;margin:0;border:0;border-radius:0;padding:0 44px;box-shadow:none}
    a { color: #000; text-decoration: none; }
    img, table, pre, blockquote, h1, h2, h3 { page-break-inside: avoid; }
    .summary-image.is-portrait img{max-width:75%;max-height:6in}
    .no-print { display: none; }
  }
`;
function wrapMarkdownAsHtmlDocument(mdBody,title){
  const bodyMarkdown=String(mdBody||'');
  const rendered=renderMarkdownHtml(bodyMarkdown);
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${esc(title||'Conflab Deliverable')}</title>
<style>${CONFLAB_DELIVERABLE_CSS}</style>
</head>
<body>
<article class="conflab-deliverable">
${rendered}
</article>
</body>
</html>`;
}
function extractTextFromHtmlDocument(htmlText){
  try{
    const doc=new DOMParser().parseFromString(String(htmlText||''),'text/html');
    const body=doc?.body;
    return String(body?.innerText||body?.textContent||'').replace(/\r\n?/g,'\n').trim();
  }catch(e){
    return String(htmlText||'').trim();
  }
}

function ensureDownloadViewerSummaryImageSlot(){
  const body=document.getElementById('download-viewer-body');
  const doc=body?.querySelector('.md-doc');
  if(!doc) return null;
  let slot=doc.querySelector('.download-viewer-summary-image-slot');
  if(slot) return slot;
  slot=document.createElement('div');
  slot.className='download-viewer-summary-image-slot is-loading';
  slot.innerHTML='<div class="download-viewer-summary-image-placeholder">Loading summary image...</div>';
  const heading=doc.querySelector('h1,h2,h3,h4,h5,h6');
  if(heading?.parentNode) heading.insertAdjacentElement('afterend',slot);
  else doc.prepend(slot);
  return slot;
}

async function hydrateDownloadViewerSummaryImage(){
  if(!DOWNLOAD_VIEWER_STATE.isSummary||DOWNLOAD_VIEWER_STATE.kind!=='text') return;
  const convRef=getConversationRefByPath(DOWNLOAD_VIEWER_STATE.convPath);
  if(!convRef) return;
  const slot=ensureDownloadViewerSummaryImageSlot();
  if(!slot) return;
  const marker=DOWNLOAD_VIEWER_STATE.name+'|'+DOWNLOAD_VIEWER_STATE.convPath;
  slot.dataset.viewerMarker=marker;
  const resolved=await resolveSummaryImageSelectionForConversation(convRef);
  if(DOWNLOAD_VIEWER_STATE.kind!=='text'||!DOWNLOAD_VIEWER_STATE.isSummary) return;
  if(slot.dataset.viewerMarker!==marker) return;
  DOWNLOAD_VIEWER_STATE.summaryImageStatus=resolved.status;
  DOWNLOAD_VIEWER_STATE.summaryImageSnapshot=resolved.snapshot;
  if(resolved.status==='none'){
    slot.remove();
    return;
  }
  if(resolved.status==='missing'||!resolved.snapshot){
    slot.className='download-viewer-summary-image-slot is-missing';
    slot.innerHTML='<div class="download-viewer-summary-image-placeholder">Selected summary image is unavailable.</div>';
    return;
  }
  const objectUrl=createImageObjectUrl(resolved.snapshot.bytes,resolved.snapshot.mimeType||IMAGE_OUTPUT_MIME_TYPE);
  resolved.snapshot.objectUrl=objectUrl;
  registerDownloadViewerCleanup(()=>{ try{URL.revokeObjectURL(objectUrl);}catch(e){} });
  slot.className='download-viewer-summary-image-slot';
  slot.innerHTML=`<div class="download-viewer-summary-image-wrap"><img src="${esc(objectUrl)}" alt="${esc(resolved.snapshot.altText||'Summary image')}"></div>`;
}

function hydrateOverviewPanel(){
  const body=document.getElementById('overview-md-body');
  if(body) body.innerHTML=renderMarkdownHtml(OVERVIEW_MD);
  const license=document.getElementById('overview-license-note');
  if(license) license.textContent=MIT_USAGE_NOTICE;
}
function handleOverviewBackgroundClick(event){
  const cover=document.getElementById('empty-cover');
  if(!cover||event.target!==cover) return;
  if(typeof event.button==='number'&&event.button!==0) return;
  drawerOpen('settings');
}
function bindOverviewBackgroundSettingsShortcut(){
  const cover=document.getElementById('empty-cover');
  if(!cover||cover.dataset.settingsBackgroundBound==='1') return;
  cover.dataset.settingsBackgroundBound='1';
  cover.addEventListener('click',handleOverviewBackgroundClick);
}
function hydrateExamplesModal(){
  const body=document.getElementById('examples-md-body');
  if(!body||body.dataset.hydrated==='1') return;
  body.innerHTML=renderMarkdownHtml(USE_CASES_MD);
  body.dataset.hydrated='1';
}
function isTypingIntoActiveElement(){
  const ae=document.activeElement;
  const tag=(ae?.tagName||'').toUpperCase();
  return tag==='INPUT'||tag==='TEXTAREA'||ae?.isContentEditable;
}
function isModalVisible(id){
  const el=document.getElementById(id);
  return !!el&&el.style.display==='flex';
}
function handleViewerArrowKeydown(e){
  if(isModalVisible('modal-image-dialog')){
    if(isTypingIntoActiveElement()) return false;
    if(e.key==='ArrowLeft'){
      e.preventDefault();
      stepImagePrompt(-1);
      return true;
    }
    if(e.key==='ArrowRight'){
      e.preventDefault();
      stepImagePrompt(1);
      return true;
    }
  }
  if(isModalVisible('modal-download-viewer')&&DOWNLOAD_VIEWER_STATE.kind==='text'){
    if(isTypingIntoActiveElement()) return false;
    const body=document.getElementById('download-viewer-body');
    if(!body) return false;
    const step=Math.max(48,Math.round(body.clientHeight*0.12)||64);
    if(e.key==='ArrowUp'){
      e.preventDefault();
      body.scrollBy({top:-step,behavior:'smooth'});
      return true;
    }
    if(e.key==='ArrowDown'){
      e.preventDefault();
      body.scrollBy({top:step,behavior:'smooth'});
      return true;
    }
  }
  return false;
}
function syncExamplesModalGeometry(){
  const modal=document.getElementById('modal-examples');
  if(!modal||modal.style.display!=='flex') return;
  const box=modal.querySelector('.examples-modal-box');
  const overview=document.querySelector('.empty-info-box');
  const footer=document.getElementById('app-footer');
  if(!box||!overview||!footer) return;

  const top=Math.max(0,Math.round(overview.getBoundingClientRect().top));
  const footerTop=Math.round(footer.getBoundingClientRect().top);
  const targetBottom=footerTop-3;
  const height=targetBottom-top;
  if(height<=0) return;

  modal.style.paddingTop=`${top}px`;
  modal.style.paddingBottom='0';
  box.style.height=`${height}px`;
  box.style.maxHeight=`${height}px`;
}
function openExamplesModal(){
  hydrateExamplesModal();
  const modal=document.getElementById('modal-examples');
  if(modal){
    modal.style.display='flex';
    requestAnimationFrame(syncExamplesModalGeometry);
  }
}
function closeExamplesModal(ev){
  if(ev&&ev.target&&ev.target.id!=='modal-examples') return;
  const modal=document.getElementById('modal-examples');
  if(modal){
    modal.style.display='none';
    modal.style.paddingTop='';
    modal.style.paddingBottom='';
    const box=modal.querySelector('.examples-modal-box');
    if(box){
      box.style.height='';
      box.style.maxHeight='';
    }
  }
}
window.addEventListener('resize',syncExamplesModalGeometry);
window.addEventListener('resize',()=>{
  if(IMAGE_DIALOG_STATE.open) requestAnimationFrame(fitImagePreviewFrameToShell);
});
function fmtDT(ts){
  const tz=APP_SETTINGS.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone;
  try{
    const d=new Date(ts);
    const parts=new Intl.DateTimeFormat('en-US',{
      timeZone:tz,month:'2-digit',day:'2-digit',year:'2-digit',
      hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false
    }).formatToParts(d);
    const get=t=>parts.find(p=>p.type===t)?.value||'00';
    return `${get('month')}/${get('day')}/${get('year')}-${get('hour')}:${get('minute')}:${get('second')}`;
  }catch(e){
    const d=new Date(ts);
    const mo=(d.getMonth()+1).toString().padStart(2,'0');
    const dy=d.getDate().toString().padStart(2,'0');
    const yr=d.getFullYear().toString().slice(-2);
    const hh=d.getHours().toString().padStart(2,'0');
    const mm=d.getMinutes().toString().padStart(2,'0');
    const ss=d.getSeconds().toString().padStart(2,'0');
    return `${mo}/${dy}/${yr}-${hh}:${mm}:${ss}`;
  }
}
function fmtT(ts){return fmtDT(ts);}

// ── KEYBOARD ──────────────────────────────────────────────────────
document.addEventListener('keydown',e=>{
  if(isStartupWorkspaceLoading()){
    e.preventDefault();
    e.stopPropagation();
    return;
  }
  if(handleViewerArrowKeydown(e)) return;
  if(e.key==='Escape'){
    const pmenu=document.getElementById('pcat-menu');
    if(pmenu&&pmenu.style.display==='block'){
      treeHideMenu(PERSONA_TREE_VIEW);
      e.preventDefault();
      return;
    }
    if(S.pcatRenamePath){
      treeCancelInlineRename(PERSONA_TREE_VIEW);
      e.preventDefault();
      return;
    }
    if(treeHasInlineCreate(PERSONA_TREE_VIEW)){
      treeCancelInlineCreate(PERSONA_TREE_VIEW);
      e.preventDefault();
      return;
    }
    const menu=document.getElementById('cat-menu');
    if(menu&&menu.style.display==='block'){
      treeHideMenu(CONV_TREE_VIEW);
      e.preventDefault();
      return;
    }
    if(S.catRenamePath){
      treeCancelInlineRename(CONV_TREE_VIEW);
      e.preventDefault();
      return;
    }
    if(treeHasInlineCreate(CONV_TREE_VIEW)){
      treeCancelInlineCreate(CONV_TREE_VIEW);
      e.preventDefault();
      return;
    }
    if(S.activeModelPicker){
      closeAllModelPickers();
      e.preventDefault();
      return;
    }
    closeExamplesModal();drawerClose();stopMic();ttsStop();
  }
  if(e.key==='Delete'){
    if(isTypingIntoActiveElement()) return;
    const drawer=document.getElementById('drawer');
    if(!drawer||!drawer.classList.contains('open')) return;
    const convTab=document.getElementById('tab-convs');
    const personaTab=document.getElementById('tab-personas');
    if(convTab&&convTab.classList.contains('active')){
      const sel=S.convTreeSelectedPath||'';
      const node=sel?S.convTreeIndex?.[sel]:null;
      if(node?.type==='category'){
        e.preventDefault();
        treeDeleteSelectedCategory(CONV_TREE_VIEW);
      }
      return;
    }
    if(personaTab&&personaTab.classList.contains('active')){
      const sel=S.personaTreeSelectedPath||'';
      const node=sel?S.personaTreeIndex?.[sel]:null;
      if(canManagePersonaCategory(node)){
        e.preventDefault();
        treeDeleteSelectedCategory(PERSONA_TREE_VIEW);
      }
    }
  }
});
document.addEventListener('mousedown',e=>{
  if(!e.target.closest('.model-picker-shell')) closeAllModelPickers();
});
// ── UI CLICK SOUND ────────────────────────────────────────────────
const UI_CLICK_SOUND_ACTIONABLE_SELECTOR=[
  'button',
  'a[href]',
  'summary',
  'select',
  'input[type="checkbox"]',
  'input[type="radio"]',
  'input[type="button"]',
  'input[type="submit"]',
  'input[type="reset"]',
  '[role="button"]',
  '[data-ui-click-sound="on"]',
  '[onclick]',
  '.clickable',
  '.c-row',
  '.h-item',
  '.lv-dir',
  '.fs-picker-row',
  '.fs-picker-crumb',
  '.fs-picker-root',
  '.model-picker-item',
  '.swatch'
].join(',');
const UI_CLICK_SOUND_DISABLED_SELECTOR='button:disabled,input:disabled,select:disabled,textarea:disabled,option:disabled,[aria-disabled="true"],.is-disabled';
const UI_CLICK_SOUND_TEXT_ENTRY_SELECTOR='input:not([type]),input[type="text"],input[type="password"],input[type="search"],input[type="email"],input[type="number"],input[type="url"],input[type="tel"],textarea,[contenteditable="true"]';
const UI_CLICK_SOUND={ctx:null,lastPlayedAt:0,bound:false};

function uiClickSoundEnabled(){
  return true;
}

function isUiClickSoundLabelTarget(el){
  return !!(el&&el.tagName==='LABEL'&&el.querySelector('input[type="checkbox"],input[type="radio"]'));
}

function findUiClickSoundTarget(target){
  let el=target instanceof Element?target:(target?.parentElement||null);
  while(el){
    if(el.matches?.('[data-ui-click-sound="off"]')) return null;
    if(el.matches?.(UI_CLICK_SOUND_TEXT_ENTRY_SELECTOR)) return null;
    if(isUiClickSoundLabelTarget(el)||el.matches?.(UI_CLICK_SOUND_ACTIONABLE_SELECTOR)){
      if(el.matches?.('.modal-bg,.drw-bg')) return null;
      if(el.matches?.(UI_CLICK_SOUND_DISABLED_SELECTOR)||el.closest?.(UI_CLICK_SOUND_DISABLED_SELECTOR)) return null;
      return el;
    }
    el=el.parentElement;
  }
  return null;
}

function ensureUiClickAudioContext(){
  if(UI_CLICK_SOUND.ctx?.state==='closed') UI_CLICK_SOUND.ctx=null;
  if(UI_CLICK_SOUND.ctx) return UI_CLICK_SOUND.ctx;
  const Ctx=window.AudioContext||window.webkitAudioContext;
  if(!Ctx) return null;
  try{
    UI_CLICK_SOUND.ctx=new Ctx();
  }catch(e){
    UI_CLICK_SOUND.ctx=null;
  }
  return UI_CLICK_SOUND.ctx;
}

function startUiClickSoundPlayback(ctx){
  if(!ctx||!uiClickSoundEnabled()) return;
  const startAt=ctx.currentTime+0.001;
  const osc=ctx.createOscillator();
  const gain=ctx.createGain();
  osc.type='triangle';
  osc.frequency.setValueAtTime(980,startAt);
  osc.frequency.exponentialRampToValueAtTime(720,startAt+0.028);
  gain.gain.setValueAtTime(0.0001,startAt);
  gain.gain.exponentialRampToValueAtTime(0.056,startAt+0.004);
  gain.gain.exponentialRampToValueAtTime(0.0001,startAt+0.045);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.onended=()=>{
    try{ osc.disconnect(); }catch(e){}
    try{ gain.disconnect(); }catch(e){}
  };
  osc.start(startAt);
  osc.stop(startAt+0.05);
}

function startUiFailSoundPlayback(ctx){
  if(!ctx||!uiClickSoundEnabled()) return;
  const startAt=ctx.currentTime+0.001;
  const gain=ctx.createGain();
  const oscA=ctx.createOscillator();
  const oscB=ctx.createOscillator();
  gain.gain.setValueAtTime(0.0001,startAt);
  gain.gain.exponentialRampToValueAtTime(0.045,startAt+0.006);
  gain.gain.exponentialRampToValueAtTime(0.0001,startAt+0.11);
  oscA.type='sawtooth';
  oscB.type='square';
  oscA.frequency.setValueAtTime(210,startAt);
  oscA.frequency.exponentialRampToValueAtTime(145,startAt+0.09);
  oscB.frequency.setValueAtTime(188,startAt);
  oscB.frequency.exponentialRampToValueAtTime(128,startAt+0.09);
  oscA.connect(gain);
  oscB.connect(gain);
  gain.connect(ctx.destination);
  const cleanup=()=>{
    try{ oscA.disconnect(); }catch(e){}
    try{ oscB.disconnect(); }catch(e){}
    try{ gain.disconnect(); }catch(e){}
  };
  oscA.onended=cleanup;
  oscB.onended=cleanup;
  oscA.start(startAt);
  oscB.start(startAt);
  oscA.stop(startAt+0.12);
  oscB.stop(startAt+0.12);
}

function playUiClickSound(){
  if(!uiClickSoundEnabled()) return;
  const now=performance.now();
  if((now-UI_CLICK_SOUND.lastPlayedAt)<35) return;
  UI_CLICK_SOUND.lastPlayedAt=now;
  const ctx=ensureUiClickAudioContext();
  if(!ctx) return;
  if(ctx.state==='suspended'){
    ctx.resume().then(()=>startUiClickSoundPlayback(ctx)).catch(()=>{});
    return;
  }
  startUiClickSoundPlayback(ctx);
}

function playUiFailSound(){
  if(!uiClickSoundEnabled()) return;
  UI_CLICK_SOUND.lastPlayedAt=performance.now();
  const ctx=ensureUiClickAudioContext();
  if(!ctx) return;
  if(ctx.state==='suspended'){
    ctx.resume().then(()=>startUiFailSoundPlayback(ctx)).catch(()=>{});
    return;
  }
  startUiFailSoundPlayback(ctx);
}

function playHistorySearchFailSound(){
  if(!uiClickSoundEnabled()) return;
  UI_CLICK_SOUND.lastPlayedAt=performance.now();
  const ctx=ensureUiClickAudioContext();
  if(!ctx) return;
  const play=()=>{
    for(let i=0;i<4;i++){
      window.setTimeout(()=>startUiFailSoundPlayback(ctx),i*140);
    }
  };
  if(ctx.state==='suspended'){
    ctx.resume().then(play).catch(()=>{});
    return;
  }
  play();
}

function handleUiClickSound(event){
  if(!event?.isTrusted) return;
  const target=findUiClickSoundTarget(event.target);
  if(!target) return;
  playUiClickSound();
}

function bindUiClickSound(){
  if(UI_CLICK_SOUND.bound) return;
  document.addEventListener('click',handleUiClickSound,true);
  UI_CLICK_SOUND.bound=true;
}

// ── TEXT TO SPEECH ────────────────────────────────────────────────
window.speechSynthesis.onvoiceschanged = () => {
  const view=document.getElementById('persona-edit-view');
  if(view&&view.style.display==='flex'){
    const selected=document.getElementById('pe-voice')?.value||'';
    if(typeof populatePersonaVoiceSelect==='function'){
      populatePersonaVoiceSelect(selected);
    }
  }
};

const TTS = {
  queue:    [],
  playing:  false,
  master:   false,   // global on/off
  rate:     1.0,     // global desired speech rate shown in UI
  active:   null,    // currently speaking item/utterance state
  clickTimer:null,
};

function clampTtsRate(v){
  return Math.max(1.0, Math.min(v, 4.0));
}

function getCurrentTtsRate(){
  return clampTtsRate(parseFloat(TTS.rate)||1.0);
}

function updateTtsRateControl(){
  const slider=document.getElementById('tts-rate-slider');
  const valEl=document.getElementById('tts-rate-val');
  const wrap=document.getElementById('tts-rate-wrap');
  const cur=getCurrentTtsRate();
  if(slider){
    slider.value=String(cur);
    slider.disabled=!TTS.master;
  }
  if(valEl){
    const label=(Math.round(cur*10)%10===0)?String(Math.round(cur)):cur.toFixed(1).replace(/\.0$/,'');
    valEl.textContent=label+'x';
  }
  if(wrap) wrap.style.opacity=TTS.master?'1':'0.45';
}

function onTtsRateInput(rawValue){
  if(!TTS.master) return;
  const next=clampTtsRate(parseFloat(rawValue)||1.0);
  TTS.rate=next;
  updateTtsRateControl();
  if(TTS.playing && TTS.active){
    ttsRestartActiveAtCurrentRate();
  }
}

// ── Master toggle ──────────────────────────────────────────────────
function toggleTtsMaster(){
  TTS.master = !TTS.master;
  const btn = document.getElementById('tts-master-btn');
  if(btn){
    btn.style.opacity = TTS.master ? '1' : '0.35';
    btn.style.color   = TTS.master ? 'var(--teal)' : '';
    btn.title = TTS.master ? 'Voice playback on — click to mute all' : 'Voice playback off — click to enable';
  }
  updateTtsRateControl();
  if(!TTS.master) ttsStop();
}

function isGoogleVoiceName(voiceName){
  return String(voiceName||'').toLowerCase().includes('google');
}

function mapDesiredTtsRateForVoice(desiredRate,voiceName){
  const desired=clampTtsRate(desiredRate);
  // Director calibration: Google voices run faster, so keep their slope lower.
  if(isGoogleVoiceName(voiceName)){
    return 1.0+((desired-1.0)*(0.5/2.0));
  }
  return desired;
}

function getTtsRate(agentRate,voiceName){
  // Google voices stay internally scaled for rough parity with Microsoft voices.
  const desired = getCurrentTtsRate();
  return mapDesiredTtsRateForVoice(desired,voiceName);
}

function getTtsAgentById(agentId){
  const c=S.conv;
  if(!c||!agentId) return null;
  return c.agents.find(a=>String(a.id)===String(agentId))||null;
}

function isTtsItemStillPlayable(item){
  if(!TTS.master||!item?.voiceName) return false;
  if(!item.agentId) return true;
  const agent=getTtsAgentById(item.agentId);
  if(!agent||!agent.voiceActive) return false;
  const currentVoice=getEffectiveAgentProfile(agent).voiceName;
  return !!currentVoice;
}

function getAgentMessageSpeakableText(rawText){
  return stripDownloadDelimiters(stripUrlSummaryBlocks(rawText)).trim();
}

function buildTtsItemForAgentMessage(agent,msg){
  if(!agent||!msg||msg.failed||msg.isSep||msg.role!=='agent') return null;
  const voiceName=getEffectiveAgentProfile(agent).voiceName;
  if(!agent.voiceActive||!voiceName) return null;
  const text=getAgentMessageSpeakableText(msg.content||'');
  if(!text) return null;
  return{text,voiceName,agentRate:agent.voiceRate||1,agentId:agent.id,msgId:msg.id};
}

function clearTtsClickTimer(){
  if(TTS.clickTimer){
    clearTimeout(TTS.clickTimer);
    TTS.clickTimer=null;
  }
}

function restoreTtsActiveBody(active){
  if(!active?.bodyEl) return;
  const restoreText=active.item?.text||active.bodyEl.textContent||'';
  active.bodyEl.innerHTML=renderRichTextHtml(restoreText);
}

function cancelTtsActiveForRestart(){
  const active=TTS.active;
  if(!active) return null;
  active.suppressCleanup=true;
  if(active.utterance){
    active.utterance.onboundary=null;
    active.utterance.onend=null;
    active.utterance.onerror=null;
  }
  restoreTtsActiveBody(active);
  const btn=active.item?.agentId?document.getElementById('spk_'+active.item.agentId):null;
  if(btn) btn.classList.remove('spk-speaking');
  TTS.active=null;
  window.speechSynthesis.cancel();
  return active;
}

function removeQueuedTtsItems(predicate){
  if(typeof predicate!=='function') return;
  TTS.queue=TTS.queue.filter(item=>!predicate(item));
}

function startTtsItemNow(item,startAt=0){
  if(!isTtsItemStillPlayable(item)) return;
  clearTtsClickTimer();
  cancelTtsActiveForRestart();
  removeQueuedTtsItems(q=>q.msgId&&item.msgId&&q.msgId===item.msgId);
  TTS.playing=true;
  ttsSpeakItem(item,startAt);
}

function completeActiveTtsAndPlayNext(){
  clearTtsClickTimer();
  cancelTtsActiveForRestart();
  ttsPlayNext();
}

function stopTtsAgent(agentId){
  removeQueuedTtsItems(item=>String(item.agentId||'')===String(agentId));
  if(TTS.active&&String(TTS.active.item?.agentId||'')===String(agentId)){
    completeActiveTtsAndPlayNext();
  }
}

function ttsRestartActiveAtCurrentRate(){
  const active=TTS.active;
  if(!active||!active.item) return;
  const fullText=active.item.text||'';
  let startAt=typeof active.charIndex==='number'?active.charIndex:0;
  startAt=Math.max(0,Math.min(startAt,Math.max(fullText.length-1,0)));

  cancelTtsActiveForRestart();
  ttsSpeakItem(active.item,startAt);
}

function keepKaraokeWordVisible(spanEl){
  if(!spanEl) return;
  if(S.conv?.settings?.autoScroll===false) return;
  const logEl=spanEl.closest('.a-log');
  if(!logEl) return;

  const wordRect=spanEl.getBoundingClientRect();
  const logRect=logEl.getBoundingClientRect();
  const lineHeight=parseFloat(getComputedStyle(spanEl).lineHeight)||18;

  if(wordRect.bottom>(logRect.bottom-4)){
    const overflow=wordRect.bottom-(logRect.bottom-4);
    logEl.scrollTop+=Math.max(lineHeight,overflow);
  }else if(wordRect.top<(logRect.top+4)){
    const underflow=(logRect.top+4)-wordRect.top;
    logEl.scrollTop-=Math.max(lineHeight,underflow);
  }
}

// ── Queue & playback ───────────────────────────────────────────────
function ttsEnqueue(text, voiceName, agentRate, agentId, msgId){
  if(!TTS.master || !voiceName) return;
  TTS.queue.push({text, voiceName, agentRate, agentId, msgId});
  if(!TTS.playing) ttsPlayNext();
}

function ttsPlayNext(){
  while(TTS.queue.length){
    const item = TTS.queue.shift();
    if(!isTtsItemStillPlayable(item)) continue;
    TTS.playing = true;
    ttsSpeakItem(item,0);
    return;
  }
  TTS.playing=false;
  TTS.active=null;
}

function ttsSpeakItem(item,startAt){
  const fullText=item?.text||'';
  let start=Math.max(0,parseInt(startAt||0,10));
  if(fullText.length) start=Math.min(start,fullText.length-1);
  const textToSpeak=fullText.slice(start);
  if(!textToSpeak.trim()){ttsPlayNext();return;}

  const utt = new SpeechSynthesisUtterance(textToSpeak);
  const voices = window.speechSynthesis.getVoices();
  const voice = voices.find(v => v.name === item.voiceName);
  if(voice) utt.voice = voice;
  utt.rate = getTtsRate(item.agentRate,item.voiceName);

  // Pulse speaker icon
  const btn = item.agentId ? document.getElementById('spk_'+item.agentId) : null;
  if(btn) btn.classList.add('spk-speaking');

  // ── Karaoke: wrap e-body text in word spans ──────────────────────
  const bodyEl = item.msgId ? document.getElementById('eb_'+item.msgId) : null;
  let wordSpans = null;

  if(bodyEl){
    // Wrap each word (and surrounding whitespace) in a span with char offset
    const rawText = fullText;
    let html = '';
    // Split keeping whitespace so charIndex stays accurate
    const wordRe = /\S+/g;
    let match;
    let lastEnd = 0;
    const segments = [];
    while((match = wordRe.exec(rawText)) !== null){
      if(match.index > lastEnd){
        segments.push({text: rawText.slice(lastEnd, match.index), isWord: false, start: lastEnd});
      }
      segments.push({text: match[0], isWord: true, start: match.index});
      lastEnd = match.index + match[0].length;
    }
    if(lastEnd < rawText.length) segments.push({text: rawText.slice(lastEnd), isWord: false, start: lastEnd});

    html = segments.map(s => s.isWord
      ? `<span class="kw" data-start="${s.start}" data-end="${s.start+s.text.length}">${s.text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</span>`
      : s.text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    ).join('');

    bodyEl.innerHTML = html;
    wordSpans = bodyEl.querySelectorAll('.kw');

    // Scroll entry into view
    if(start===0){
      bodyEl.closest('.a-entry')?.scrollIntoView({behavior:'smooth', block:'nearest'});
    }
  }

  const active={item,utterance:utt,bodyEl,wordSpans,charIndex:start,suppressCleanup:false};
  TTS.active=active;

  // boundary event — highlight current word
  utt.onboundary = e => {
    if(active.suppressCleanup) return;
    const localIndex=typeof e.charIndex==='number'?e.charIndex:0;
    const absIndex=start+localIndex;
    active.charIndex=absIndex;
    if(e.name !== 'word' || !wordSpans) return;
    wordSpans.forEach(sp => sp.style.cssText='');
    // Find span whose range contains charIndex
    for(const sp of wordSpans){
      const s = parseInt(sp.dataset.start);
      const en = parseInt(sp.dataset.end);
      if(absIndex >= s && absIndex < en){
        sp.style.cssText = 'background:rgba(24,212,192,0.25);color:var(--text-bright);border-radius:2px;padding:0 1px';
        keepKaraokeWordVisible(sp);
        break;
      }
    }
  };

  const cleanup = () => {
    if(active.suppressCleanup) return;
    if(TTS.active!==active) return;
    if(btn) btn.classList.remove('spk-speaking');
    // Restore plain text in body element
    if(bodyEl) bodyEl.innerHTML = renderRichTextHtml(fullText);
    TTS.active=null;
    ttsPlayNext();
  };
  utt.onend   = cleanup;
  utt.onerror = cleanup;

  window.speechSynthesis.speak(utt);
}

function ttsStop(){
  clearTtsClickTimer();
  TTS.queue   = [];
  TTS.playing = false;
  cancelTtsActiveForRestart();
  TTS.active=null;
  window.speechSynthesis.cancel();
  document.querySelectorAll('[id^="spk_"]').forEach(b => b.classList.remove('spk-speaking'));
  // Clean up any karaoke spans — restore plain text
  document.querySelectorAll('.kw').forEach(sp => {
    const body = sp.closest('.e-body');
    if(body) body.innerHTML = renderRichTextHtml(body.textContent||'');
  });
}

function getTtsBodyContext(bodyEl){
  const c=S.conv;
  if(!c||!bodyEl) return null;
  const msgId=String(bodyEl.dataset.msgId||bodyEl.id.replace(/^eb_/,'')||'');
  const agentId=String(bodyEl.dataset.agentId||bodyEl.closest('.agent-panel')?.id?.replace(/^ap_/,'')||'');
  if(!msgId||!agentId) return null;
  const agent=c.agents.find(a=>String(a.id)===agentId);
  const msg=agent?.msgs?.find(m=>String(m.id||'')===msgId);
  if(!agent||!msg) return null;
  return{agent,msg,msgId,agentId};
}

function getCaretRangeFromPoint(x,y){
  if(document.caretPositionFromPoint){
    const pos=document.caretPositionFromPoint(x,y);
    if(pos){
      const range=document.createRange();
      range.setStart(pos.offsetNode,pos.offset);
      range.collapse(true);
      return range;
    }
  }
  if(document.caretRangeFromPoint) return document.caretRangeFromPoint(x,y);
  return null;
}

function getTextOffsetWithinRoot(root,targetNode,targetOffset){
  if(!root||!targetNode) return 0;
  let total=0;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null);
  let node;
  while((node=walker.nextNode())){
    if(node===targetNode){
      return total+Math.max(0,Math.min(targetOffset,node.nodeValue.length));
    }
    total+=(node.nodeValue||'').length;
  }
  return total;
}

function normalizeTtsSeekStart(text,index){
  const src=String(text||'');
  if(!src.length) return 0;
  let pos=Math.max(0,Math.min(parseInt(index||0,10),src.length-1));
  while(pos<src.length&&/\s/.test(src.charAt(pos))) pos++;
  if(pos>=src.length) pos=Math.max(0,src.length-1);
  while(pos>0&&!/\s/.test(src.charAt(pos-1))&&!/\s/.test(src.charAt(pos))) pos--;
  return pos;
}

function getTtsStartFromPointer(bodyEl,event,fullText){
  const kw=event.target?.closest?.('.kw');
  if(kw&&bodyEl.contains(kw)){
    return normalizeTtsSeekStart(fullText,parseInt(kw.dataset.start||'0',10)||0);
  }
  const range=getCaretRangeFromPoint(event.clientX,event.clientY);
  if(!range||!bodyEl.contains(range.startContainer)) return 0;
  const offset=getTextOffsetWithinRoot(bodyEl,range.startContainer,range.startOffset);
  return normalizeTtsSeekStart(fullText,offset);
}

function isActiveTtsMessage(msgId){
  return !!(TTS.active&&String(TTS.active.item?.msgId||'')===String(msgId||''));
}

function handleTtsResponseBodyClick(event){
  if(event.detail>1) return;
  if(event.target?.closest?.('a,button,input,select,textarea')) return;
  const bodyEl=event.currentTarget;
  clearTtsClickTimer();
  TTS.clickTimer=setTimeout(()=>{
    TTS.clickTimer=null;
    const ctx=getTtsBodyContext(bodyEl);
    const item=ctx?buildTtsItemForAgentMessage(ctx.agent,ctx.msg):null;
    if(!item||!TTS.master) return;
    const startAt=isActiveTtsMessage(ctx.msgId)
      ? getTtsStartFromPointer(bodyEl,event,TTS.active?.item?.text||item.text)
      : 0;
    startTtsItemNow(item,startAt);
  },180);
}

function handleTtsResponseBodyDoubleClick(event){
  event.preventDefault();
  if(event.target?.closest?.('a,button,input,select,textarea')) return;
  clearTtsClickTimer();
  const ctx=getTtsBodyContext(event.currentTarget);
  if(!ctx||!TTS.master) return;
  if(isActiveTtsMessage(ctx.msgId)){
    completeActiveTtsAndPlayNext();
    return;
  }
  const item=buildTtsItemForAgentMessage(ctx.agent,ctx.msg);
  if(item) startTtsItemNow(item,0);
}

// ── Agent voice toggle ─────────────────────────────────────────────
function toggleAgentVoice(agentId){
  const c=S.conv; if(!c) return;
  const a=c.agents.find(x=>x.id===agentId); if(!a) return;
  const voiceName=getEffectiveAgentProfile(a).voiceName;
  if(!voiceName){
    openAgentPersonaPicker(agentId);
    return;
  }
  a.voiceActive = !a.voiceActive;
  if(!a.voiceActive) stopTtsAgent(agentId);
  applyAgentSpeakerButtonState(agentId);
  stoSave();
}

// ── Called by dispatchToAgent when response arrives ────────────────
function ttsHandleResponse(agent, text, msgId){
  const voiceName=getEffectiveAgentProfile(agent).voiceName;
  if(!TTS.master || !agent.voiceActive || !voiceName) return;
  const speakable=getAgentMessageSpeakableText(text);
  if(!speakable) return;
  ttsEnqueue(speakable, voiceName, agent.voiceRate||1, agent.id, msgId);
}

// ── DRAWER TABS ───────────────────────────────────────────────────
function switchDrawerTab(tab){
  if(isSessionInteractionBlocked()) return;
  const validTabs=['settings','personas','convs','downloads'];
  const nextTab=validTabs.includes(tab)?tab:'convs';
  treeHideMenu(PERSONA_TREE_VIEW);
  treeCancelInlineRename(PERSONA_TREE_VIEW);
  treeCancelInlineCreate(PERSONA_TREE_VIEW);
  treeHideMenu(CONV_TREE_VIEW);
  treeCancelInlineRename(CONV_TREE_VIEW);
  treeCancelInlineCreate(CONV_TREE_VIEW);
  validTabs.forEach(t=>{
    const tabBtn=document.getElementById('tab-'+t);
    if(tabBtn){
      tabBtn.classList.toggle('active',t===nextTab);
      tabBtn.style.color='';
    }
    document.getElementById('drw-'+t)?.classList.toggle('active',t===nextTab);
  });
  S.drawerTab=nextTab;
  if(nextTab!=='personas'&&S.agentPersonaPickerFor){
    S.agentPersonaPickerFor='';
    updatePersonaModeUi();
  }
  if(nextTab==='personas') renderPersonaList();
  if(nextTab==='settings') loadSettingsForm();
  if(nextTab==='convs') renderConvList();
  if(nextTab==='downloads'){
    if(!S.downloadsTreeSelectedPath&&S.conv?.sourcePath) treeSelectPath(DOWNLOADS_TREE_VIEW,S.conv.sourcePath);
    scanDownloadsTree();
  }
}

function drawerOpen(forceTab){
  if(isSessionInteractionBlocked()) return;
  document.getElementById('drawer').classList.add('open');
  document.getElementById('drw-bg').classList.add('open');
  let tab=forceTab||S.drawerTab||(S.convs.length===0?'settings':'convs');
  if(!S.workspaceReady&&tab!=='settings') tab='settings';
  switchDrawerTab(tab);
}
function drawerClose(){
  treeHideMenu(PERSONA_TREE_VIEW);
  treeCancelInlineRename(PERSONA_TREE_VIEW);
  treeCancelInlineCreate(PERSONA_TREE_VIEW);
  treeHideMenu(CONV_TREE_VIEW);
  treeCancelInlineRename(CONV_TREE_VIEW);
  treeCancelInlineCreate(CONV_TREE_VIEW);
  S.agentPersonaPickerFor='';
  updatePersonaModeUi();
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drw-bg').classList.remove('open');
}

// ── SETTINGS ─────────────────────────────────────────────────────
const SETTINGS_KEY='cl_settings';
const WORKSPACE_SETTINGS_FILE='_conflab_settings.json';
const SECRET_SETTING_KEYS=['keyOpenRouter','keyBraveSearch'];
const SECRET_SETTING_LABELS={keyOpenRouter:'OpenRouter',keyBraveSearch:'Brave Search'};
const DEFAULT_MISSION_STATEMENT=`1. You are one of several AI agents in a Director-led discussion. All agents receive this mission statement. It governs your behavior in every conversation.

2. The Director leads. Follow the Director's topic, focus, and direction. Only the Director assigns tasks and makes final decisions. Engage critically with other agents' ideas, but do not treat their suggestions as instructions.

3. Every conversation has a goal: move toward the best achievable outcome. When a clear solution exists, work toward it. When no definitive answer exists, work toward equilibrium -- the closest stable alignment achievable when full agreement is not possible, with key tradeoffs and remaining disagreements made explicit.

4. Contribute your genuine perspective. Agree when something is sound. Push back when something is weak. Build on good ideas. Do not be agreeable for the sake of harmony.

5. Engage with what other agents say. When prior agent responses exist, explicitly agree, disagree, or build on another agent by name in roughly 1 out of every 3 to 4 responses. Do this naturally, not mechanically, and skip forced references when there is nothing meaningful to add.

6. When the Director addresses a specific agent by name for a task, that task belongs to that named agent. If you are not that named agent, do not perform the assigned task; you may still add perspective, critique, or supporting context.

7. Treat the Director's newest message as the primary task for your next response. Use prior rounds as supporting context.

8. The conversation log contains responses from all agents, including your own. Your prior responses are part of your identity in this discussion.

9. After this mission statement you will receive: a conversation objective (the specific goal for this discussion), your persona (who you are and how you should behave), and the conversation history.

10. Never write dialogue, narration, or paraphrased speech for the Director. The Director speaks for themselves. Your response contains only your own words.

11. Only speak as yourself. Do not invent, narrate, or role-play other characters or agents. If you want to reference what another agent said, quote them - do not speak as them.

12. Use web search only when current external information would materially improve your response. If you can answer from your expertise and the conversation context, do so without searching. Prefer minimal, focused searches over broad exploration. When the Director specifically asks you to research something, or asks about time-sensitive/current/local events, prices, schedules, recent news, or "next weekend"/"today"/"currently" style questions, perform at least one focused web search before answering if web tools are available.

13. When other participants have performed web searches, review their search results and summaries before conducting your own. Seek complementary sources and different angles rather than repeating the same research.

14. When citing information from web searches, clearly attribute the source. Build on the collective research of all participants rather than duplicating it.`;
const DEFAULT_APP_SETTINGS={
  helperModel:'openrouter/free',
  imageHelperModel:'black-forest-labs/flux.2-klein-4b',
  keyOpenRouter:'',
  keyBraveSearch:'',
  defaultCols:2, defaultAgentCount:2,
  directorColor:'teal',
  maxRounds:10,
  timezone:'',
  missionStatement:DEFAULT_MISSION_STATEMENT
};
let APP_SETTINGS={...DEFAULT_APP_SETTINGS};
let APP_SETTINGS_SECRET_STATUS=createEmptySecretStatus();
let PENDING_SECRET_MIGRATION={};
let PROTECTED_SETTINGS_READY_PROMISE=null;
let SETTINGS_FORM_BASELINE=null;
let SETTINGS_WATCHERS_BOUND=false;

function hasWorkspaceApiConfiguration(settings=APP_SETTINGS){
  const keyConfigured=isProviderKeyConfigured('keyOpenRouter');
  const helper=ensureModelId(settings?.helperModel||'');
  return keyConfigured&&!!helper;
}

function createEmptySecretStatus(){
  return SECRET_SETTING_KEYS.reduce((out,key)=>{
    out[key]={configured:false,needsEntry:true,decryptFailed:false};
    return out;
  },{});
}

function normalizeSecretStatus(raw={}){
  const out=createEmptySecretStatus();
  SECRET_SETTING_KEYS.forEach(key=>{
    const src=raw?.[key]||{};
    const configured=!!src.configured;
    const decryptFailed=!!src.decryptFailed;
    out[key]={
      configured:configured&&!decryptFailed,
      needsEntry:decryptFailed||!configured||!!src.needsEntry,
      decryptFailed
    };
  });
  return out;
}

function applySecretStatus(status){
  APP_SETTINGS_SECRET_STATUS=normalizeSecretStatus(status);
  SECRET_SETTING_KEYS.forEach(key=>{ APP_SETTINGS[key]=''; });
  updateSecretStatusUi();
}

function isProviderKeyConfigured(key){
  const status=APP_SETTINGS_SECRET_STATUS?.[key]||{};
  return !!status.configured&&!status.decryptFailed;
}

function getSecretStatusLabel(key){
  const status=APP_SETTINGS_SECRET_STATUS?.[key]||{};
  if(status.decryptFailed) return `${SECRET_SETTING_LABELS[key]||'Provider'} key must be re-entered.`;
  if(status.configured) return `${SECRET_SETTING_LABELS[key]||'Provider'} key is configured. Enter a new key to replace it.`;
  return `${SECRET_SETTING_LABELS[key]||'Provider'} key is not configured.`;
}

function updateSecretStatusUi(){
  const configs={
    keyOpenRouter:{inputId:'set-key-openrouter',statusId:'set-key-openrouter-status',emptyPlaceholder:'sk-or-v1-...'},
    keyBraveSearch:{inputId:'set-key-brave',statusId:'set-key-brave-status',emptyPlaceholder:'BSA...'}
  };
  Object.entries(configs).forEach(([key,cfg])=>{
    const input=document.getElementById(cfg.inputId);
    const statusEl=document.getElementById(cfg.statusId);
    const status=APP_SETTINGS_SECRET_STATUS?.[key]||{};
    if(input){
      if(!input.value) input.placeholder=status.configured?'Configured - enter a new key to replace it':cfg.emptyPlaceholder;
      input.autocomplete='off';
    }
    if(statusEl){
      statusEl.textContent=getSecretStatusLabel(key);
      statusEl.style.color=status.decryptFailed?'var(--red)':(status.configured?'var(--teal)':'var(--text-dim)');
    }
  });
}

function extractProviderSecretValues(settings={}){
  const out={};
  SECRET_SETTING_KEYS.forEach(key=>{
    const value=String(settings?.[key]||'').trim();
    if(value) out[key]=value;
  });
  return out;
}

function normalizeDefaultAgentCount(value){
  const n=parseInt(value,10);
  if(Number.isNaN(n)) return MIN_ACTIVE_AGENT_COUNT;
  return Math.max(MIN_ACTIVE_AGENT_COUNT,Math.min(9,n));
}

function sanitizeSettingsForBrowser(settings={}){
  const out={...DEFAULT_APP_SETTINGS,...(settings||{})};
  out.defaultAgentCount=normalizeDefaultAgentCount(out.defaultAgentCount);
  SECRET_SETTING_KEYS.forEach(key=>{ out[key]=''; });
  delete out.secretStatus;
  delete out.lastWorkspacePath;
  return out;
}

function persistAppSettingsToBrowserStorage(){
  localStorage.setItem(SETTINGS_KEY,JSON.stringify(getPersistableAppSettings()));
}

function mergePendingSecretMigration(secrets={}){
  SECRET_SETTING_KEYS.forEach(key=>{
    const value=String(secrets?.[key]||'').trim();
    if(value) PENDING_SECRET_MIGRATION[key]=value;
  });
}

function buildSecretActionsFromForm(){
  const actions={};
  SECRET_SETTING_KEYS.forEach(key=>{ actions[key]={action:'preserve'}; });
  const openRouterValue=String(document.getElementById('set-key-openrouter')?.value||'').trim();
  const braveValue=String(document.getElementById('set-key-brave')?.value||'').trim();
  if(openRouterValue) actions.keyOpenRouter={action:'set',value:openRouterValue};
  if(braveValue) actions.keyBraveSearch={action:'set',value:braveValue};
  return actions;
}

function buildSecretActionsFromMigration(){
  const actions={};
  SECRET_SETTING_KEYS.forEach(key=>{
    const value=String(PENDING_SECRET_MIGRATION?.[key]||'').trim();
    if(value) actions[key]={action:'set',value};
  });
  return actions;
}

function applyServerSettingsPayload(payload,options={}){
  if(options.mergeNonSecret){
    const settings=sanitizeSettingsForBrowser(payload?.settings||{});
    APP_SETTINGS={...APP_SETTINGS,...settings};
  }
  APP_SETTINGS.missionStatement=getMissionStatement(APP_SETTINGS.missionStatement);
  applySecretStatus(payload?.settings?.secretStatus||{});
  persistAppSettingsToBrowserStorage();
  applyDirectorColor();
  updateFolderUI();
}

function getSelectedDirectorColorFromSettingsForm(){
  const selSwatch=document.querySelector('#set-director-sw .swatch.sel');
  return selSwatch?String(selSwatch.dataset.cid||'teal'):'teal';
}

function getSettingsFormState(){
  const helperModelEl=document.getElementById('set-helper-model');
  if(!helperModelEl) return null;
  const missionEl=document.getElementById('set-mission');
  return{
    helperModel:ensureModelId(helperModelEl.value),
    keyOpenRouter:String(document.getElementById('set-key-openrouter')?.value||'').trim(),
    keyBraveSearch:String(document.getElementById('set-key-brave')?.value||'').trim(),
    keyOpenRouterConfigured:isProviderKeyConfigured('keyOpenRouter'),
    keyOpenRouterNeedsEntry:!!APP_SETTINGS_SECRET_STATUS?.keyOpenRouter?.needsEntry,
    keyBraveSearchConfigured:isProviderKeyConfigured('keyBraveSearch'),
    keyBraveSearchNeedsEntry:!!APP_SETTINGS_SECRET_STATUS?.keyBraveSearch?.needsEntry,
    defaultCols:+(document.getElementById('set-cols')?.value||2),
    defaultAgentCount:normalizeDefaultAgentCount(document.getElementById('set-agent-count')?.value||2),
    maxRounds:APP_SETTINGS.maxRounds||10,
    timezone:String(document.getElementById('set-timezone')?.value||''),
    missionStatement:getMissionStatement(missionEl?.value||''),
    directorColor:getSelectedDirectorColorFromSettingsForm()
  };
}

function isSettingsDirty(){
  const current=getSettingsFormState();
  if(!current||!SETTINGS_FORM_BASELINE) return false;
  return JSON.stringify(current)!==JSON.stringify(SETTINGS_FORM_BASELINE);
}

function updateSettingsSaveState(){
  const saveBtn=document.getElementById('btn-save-settings');
  if(!saveBtn) return;
  const hasFolder=!!S.fsRoot;
  const needsInitialization=hasFolder&&!S.workspaceReady;
  const dirty=isSettingsDirty();
  const canSave=hasFolder&&(dirty||needsInitialization);
  saveBtn.disabled=!canSave;
  saveBtn.classList.toggle('dialog-btn-muted',!canSave);
  saveBtn.classList.toggle('dialog-btn-primary',canSave);
}

function bindSettingsDirtyWatchers(){
  if(SETTINGS_WATCHERS_BOUND) return;
  const ids=[
    'set-helper-model','set-key-openrouter','set-key-brave',
    'set-cols','set-agent-count','set-timezone','set-mission'
  ];
  ids.forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.addEventListener('input',updateSettingsSaveState);
    el.addEventListener('change',updateSettingsSaveState);
  });
  SETTINGS_WATCHERS_BOUND=true;
}

function captureSettingsFormBaseline(){
  SETTINGS_FORM_BASELINE=getSettingsFormState();
  updateSettingsSaveState();
}

function resetAppSettingsToDefaults(){
  const lastFolderName=APP_SETTINGS.lastFolderName||'';
  APP_SETTINGS={...DEFAULT_APP_SETTINGS};
  if(lastFolderName) APP_SETTINGS.lastFolderName=lastFolderName;
  persistAppSettingsToBrowserStorage();
  applyDirectorColor();
}

function getPersistableAppSettings(){
  return{
    helperModel:ensureModelId(APP_SETTINGS.helperModel),
    imageHelperModel:ensureImageModelId(APP_SETTINGS.imageHelperModel),
    defaultCols:APP_SETTINGS.defaultCols||2,
    defaultAgentCount:normalizeDefaultAgentCount(APP_SETTINGS.defaultAgentCount||2),
    directorColor:APP_SETTINGS.directorColor||'teal',
    maxRounds:APP_SETTINGS.maxRounds||10,
    timezone:APP_SETTINGS.timezone||'',
    lastFolderName:APP_SETTINGS.lastFolderName||'',
    missionStatement:getMissionStatement(),
  };
}

async function readServerSettings(){
  const response=await fetchProtectedBridgeJson('/api/settings/read',{method:'GET',timeoutMs:5000,timeoutLabel:'Settings read'});
  const payload=await response.json().catch(()=>({}));
  if(!response.ok){
    throw createApiError(getPayloadErrorMessage(payload)||'Could not read protected settings.',response.status,getPayloadErrorMessage(payload));
  }
  applyServerSettingsPayload(payload,{mergeNonSecret:true});
  return payload;
}

async function saveServerSettings(secrets={}){
  const response=await fetchProtectedBridgeJson('/api/settings/save',{
    method:'POST',
    payload:{settings:getPersistableAppSettings(),secrets},
    timeoutMs:5000,
    timeoutLabel:'Settings save'
  });
  const payload=await response.json().catch(()=>({}));
  if(!response.ok){
    throw createApiError(getPayloadErrorMessage(payload)||'Could not save protected settings.',response.status,getPayloadErrorMessage(payload));
  }
  applyServerSettingsPayload(payload,{mergeNonSecret:true});
  return payload;
}

async function syncProtectedSettings(migrationSecrets={}){
  mergePendingSecretMigration(migrationSecrets);
  const secrets=buildSecretActionsFromMigration();
  if(Object.keys(secrets).length){
    const payload=await saveServerSettings(secrets);
    PENDING_SECRET_MIGRATION={};
    return payload;
  }
  return await readServerSettings();
}

async function loadWorkspaceSettingsFromDisk(){
  if(!S.fsRoot) return false;
  try{
    const serverPayload=await readServerSettings();
    if(!serverPayload?.exists){
      try{
        const fh=await S.fsRoot.getFileHandle(WORKSPACE_SETTINGS_FILE);
        const file=await fh.getFile();
        const parsed=JSON.parse(await file.text());
        const migrationSecrets=extractProviderSecretValues(parsed);
        APP_SETTINGS={...APP_SETTINGS,...sanitizeSettingsForBrowser(parsed)};
        APP_SETTINGS.missionStatement=getMissionStatement(APP_SETTINGS.missionStatement);
        mergePendingSecretMigration(migrationSecrets);
        const secrets=buildSecretActionsFromMigration();
        await saveServerSettings(secrets);
        PENDING_SECRET_MIGRATION={};
      }catch(e){}
    }
    try{
      await syncProtectedSettings();
    }catch(e){
      console.warn('Protected settings sync failed:',e);
    }
    persistAppSettingsToBrowserStorage();
    applyDirectorColor();
    return true;
  }catch(e){return false;}
}

async function saveWorkspaceSettingsToDisk(){
  if(!S.fsRoot) return false;
  try{
    await saveServerSettings();
    return true;
  }catch(e){return false;}
}

async function workspaceLooksInitialized(rootHandle){
  if(!rootHandle) return false;
  try{
    await rootHandle.getDirectoryHandle('Conversations');
    return true;
  }catch(e){}
  try{
    await rootHandle.getDirectoryHandle('Personas');
    return true;
  }catch(e){return false;}
}

function loadAppSettings(){
  try{
    const s=localStorage.getItem(SETTINGS_KEY);
    if(s){
      const parsed=JSON.parse(s);
      const migrationSecrets=extractProviderSecretValues(parsed);
      mergePendingSecretMigration(migrationSecrets);
      APP_SETTINGS={...APP_SETTINGS,...sanitizeSettingsForBrowser(parsed)};
      if(!Object.keys(migrationSecrets).length) persistAppSettingsToBrowserStorage();
    }
  }catch(e){}
  APP_SETTINGS.missionStatement=getMissionStatement(APP_SETTINGS.missionStatement);
}

async function initializeProtectedSettingsFromBrowserStorage(){
  try{
    await syncProtectedSettings();
    if(S.drawerTab==='settings') loadSettingsForm();
  }catch(e){
    console.warn('Protected settings unavailable:',e);
  }
}

async function ensureProtectedSettingsReadyForProviderUse(){
  if(!PROTECTED_SETTINGS_READY_PROMISE||typeof PROTECTED_SETTINGS_READY_PROMISE.then!=='function') return;
  try{ await PROTECTED_SETTINGS_READY_PROMISE; }catch(e){}
}

// Mission statement helpers
function getMissionStatement(value){
  const raw=value===undefined?APP_SETTINGS.missionStatement:value;
  const t=String(raw||'').trim();
  return t||DEFAULT_MISSION_STATEMENT;
}

function getPersonaSourceForAgent(agent){
  if(!agent) return null;
  const master=agent.personaResolvedData||(agent.personaUuid?(S.personaUuidIndex?.[agent.personaUuid]?.data||null):null);
  return master||null;
}

function getAgentPanelNumber(agent,conv=S.conv){
  if(!agent) return 1;
  return getAgentSlotIndex(agent,conv)+1;
}

function getAgentDisplayName(agent){
  if(!agent) return '';
  if(String(agent.personaUuid||'').trim()){
    const source=getPersonaSourceForAgent(agent);
    if(source?.name) return source.name;
    return String(agent.name||'Persona').trim()||'Persona';
  }
  if(String(agent.model||'').trim()){
    return getModelDisplayName(agent.model);
  }
  return 'Select Persona';
}

function getAgentIdentityLabel(agent,conv=S.conv){
  if(!agent) return 'Agent';
  if(agent?.isGhost){
    return String(agent.name||'Removed Agent').trim()||'Removed Agent';
  }
  if(String(agent.personaUuid||'').trim()){
    const source=getPersonaSourceForAgent(agent);
    if(source?.name) return String(source.name).trim()||'Agent';
    return String(agent.name||'Persona').trim()||'Persona';
  }
  if(String(agent.model||'').trim()){
    return `Agent ${getAgentPanelNumber(agent,conv)} using ${getModelDisplayName(agent.model)}`;
  }
  return `Agent ${getAgentPanelNumber(agent,conv)}`;
}

function getAgentMessageSpeakerLabel(agent,msg){
  return String(msg?.speakerLabel||getAgentIdentityLabel(agent)).trim()||getAgentIdentityLabel(agent);
}

function getEffectiveAgentProfile(agent,conv=S.conv){
  if(agent?.isGhost){
    return{
      model:'',
      backstory:`Removed agent. Last known identity: ${getAgentIdentityLabel(agent,conv)}.`,
      voiceName:'',
      source:null
    };
  }
  const source=getPersonaSourceForAgent(agent);
  const hasPersona=!!String(agent?.personaUuid||'').trim();
  const hasAdHocModel=!!String(agent?.model||'').trim();
  const slot=getParticipantPlanSlotForAgentSync(conv,agent);
  const roleBrief=String(slot?.roleBrief||'').trim();
  const model=ensureModelId(hasPersona?(source?.model||getDefaultPersonaModel()):(agent?.model||'openrouter/free'));
  const backstory=hasPersona
    ? String(source?.backstory||'')
    : hasAdHocModel
      ? `No persona has been assigned. You are participating as ${getAgentIdentityLabel(agent,conv)}. Respond in your own voice.`
      : roleBrief
        ? `You are participating as ${getAgentIdentityLabel(agent,conv)}. The Director planned this slot with the following role: ${roleBrief}. Respond in your own voice, consistent with that role.`
        : `No persona has been assigned. You are participating as ${getAgentIdentityLabel(agent,conv)}. Respond in your own voice.`;
  const voiceName=hasPersona
    ? String(source?.voiceName||'')
    : String(agent?.voiceName||'');
  return{
    model,
    backstory:String(backstory||''),
    voiceName:String(voiceName||''),
    source:source||null
  };
}

function buildAgentSystemPrompt(agent){
  const mission=getMissionStatement();
  const agentName=getAgentIdentityLabel(agent);
  const persona=(getEffectiveAgentProfile(agent).backstory||'').trim();
  const nameDirectedTaskGuidance='When the Director addresses another agent by name for a specific task, that task is assigned to that named agent, not you. Do not duplicate that assigned task.';
  const downloadGuidance=`When the Director asks you to produce a file or document, wrap the file content using this exact format:
<<<DOWNLOAD:filename.ext>>>
file content here
<<<END>>>
The content will be extracted and made available as a downloadable file. Only produce a download when explicitly asked to create a file.

File extension rules:
- Use .md for formatted documents (supports headings, bold, lists, tables, code blocks).
- Use .txt for plain unformatted text.
- Use .csv for tabular/spreadsheet data.
- Use .json for structured data.
- Use .html for web content.
- Do NOT use .pdf -- you cannot produce binary PDF files. Use .md instead for formatted documents.
- Do NOT use image extensions (.png, .jpg) or archive extensions (.zip) -- you cannot produce binary files.
- For remote assets that already exist at a URL (for example generated images hosted by a provider), include the direct URL in your response body instead of a DOWNLOAD block.
Conflab converts DOWNLOAD blocks into downloadable files. Ordinary URLs stay inline in the response body.`;
  const urlSummaryGuidance=`When you read a web page via the read_url tool, immediately write a 2-4 sentence summary of the key findings. Be specific: include relevant data points, statistics, quotes, and conclusions. Wrap your summary using this exact format:
<<<URLSUMMARY>>>
your summary here
<<<END_SUMMARY>>>
Other participants cannot see the full page content, only your summary, so make it substantive.`;
  const identityBlock=`You are ${agentName}.

${persona||'No persona was provided for this agent.'}

Your responses reflect your professional identity, experience, and perspective. When you
contribute to this discussion, you are speaking from your expertise and your point of view.
Own your positions. If you believe something based on your background, say so clearly. If
another agent's response conflicts with your perspective, engage with it directly rather
than deferring. Build on your own prior responses across rounds. You have continuity of
thought and should develop your earlier points.

You are not trying to be generically helpful. You are a specific voice with a specific
perspective, and that perspective is why you are part of this panel.

${nameDirectedTaskGuidance}

${downloadGuidance}

${urlSummaryGuidance}

The following conversation log contains responses from all agents in this discussion, including your own prior responses. Your responses are labeled with your name and are part of your identity. Other agents' responses are labeled with their names.`;
  return mission+'\n\n'+identityBlock;
}

function syncMissionStatementView(){
  const mission=getMissionStatement();
  const hidden=document.getElementById('set-mission');
  const view=document.getElementById('set-mission-view');
  if(hidden) hidden.value=mission;
  if(view) view.textContent=mission;
}

function openMissionStatementDialog(){
  const modal=document.getElementById('modal-mission-edit');
  const input=document.getElementById('mission-edit-input');
  const hidden=document.getElementById('set-mission');
  if(!modal||!input||!hidden) return;
  input.value=hidden.value||getMissionStatement();
  modal.style.display='flex';
  input.focus();
  input.setSelectionRange(input.value.length,input.value.length);
}

function closeMissionStatementDialog(ev){
  if(ev&&ev.target&&ev.target.id!=='modal-mission-edit') return;
  const modal=document.getElementById('modal-mission-edit');
  if(modal) modal.style.display='none';
}

function saveMissionStatementDialog(){
  const input=document.getElementById('mission-edit-input');
  const hidden=document.getElementById('set-mission');
  if(!input||!hidden) return;
  hidden.value=getMissionStatement(input.value);
  syncMissionStatementView();
  updateSettingsSaveState();
  closeMissionStatementDialog();
}
async function saveSettings(){
  const wasReady=!!S.workspaceReady;
  APP_SETTINGS.helperModel=ensureModelId(document.getElementById('set-helper-model').value);
  APP_SETTINGS.defaultCols=+document.getElementById('set-cols').value;
  APP_SETTINGS.defaultAgentCount=normalizeDefaultAgentCount(document.getElementById('set-agent-count').value);
  APP_SETTINGS.timezone=document.getElementById('set-timezone').value;
  APP_SETTINGS.missionStatement=getMissionStatement(document.getElementById('set-mission').value);
  // Director color — read from selected swatch
  const selSwatch=document.querySelector('#set-director-sw .swatch.sel');
  APP_SETTINGS.directorColor=selSwatch?selSwatch.dataset.cid:'teal';
  try{
    await saveServerSettings(buildSecretActionsFromForm());
  }catch(e){
    showHelperApiError(e);
    return;
  }
  document.getElementById('set-key-openrouter').value='';
  document.getElementById('set-key-brave').value='';
  updateSecretStatusUi();
  persistAppSettingsToBrowserStorage();
  const savedToWorkspace=true;
  if(S.fsRoot) S.workspaceReady=savedToWorkspace&&hasWorkspaceApiConfiguration(APP_SETTINGS);
  applyDirectorColor();
  if(S.conv){
    assignAgentColors(S.conv);
    renderWorkspace();
    writeMetaFile();
  }
  updateFolderUI();
  if(S.fsRoot&&!savedToWorkspace){
    await appAlert('Unable to save workspace settings for this folder.');
  }
  if(S.fsRoot&&savedToWorkspace&&!wasReady){
    await scanConvFolders();
    await scanPersonaFolders();
  }
  const missionEl=document.getElementById('set-mission');
  if(missionEl) missionEl.value=getMissionStatement();
  syncMissionStatementView();
  captureSettingsFormBaseline();
  const btn=document.getElementById('btn-save-settings');
  if(btn){const orig=btn.textContent;btn.textContent='Saved ✓';btn.style.opacity='.6';
    setTimeout(()=>{btn.textContent=orig;btn.style.opacity='';},1200);}
}
function updateTzAbbr(){
  const sel=document.getElementById('set-timezone');
  const abbr=document.getElementById('set-tz-abbr');
  if(!sel||!abbr)return;
  try{
    const tz=sel.value;
    const parts=new Intl.DateTimeFormat('en-US',{timeZone:tz,timeZoneName:'short'}).formatToParts(new Date());
    const tzName=parts.find(p=>p.type==='timeZoneName')?.value||'';
    abbr.textContent=tzName?`· ${tzName}`:'';
  }catch(e){abbr.textContent='';}
}

function loadSettingsForm(){
  bindSettingsDirtyWatchers();
  document.getElementById('set-helper-model').value=ensureModelId(APP_SETTINGS.helperModel);
  document.getElementById('set-key-openrouter').value='';
  document.getElementById('set-key-brave').value='';
  updateSecretStatusUi();
  document.getElementById('set-cols').value=APP_SETTINGS.defaultCols||2;
  document.getElementById('set-agent-count').value=normalizeDefaultAgentCount(APP_SETTINGS.defaultAgentCount||2);
  const missionEl=document.getElementById('set-mission');
  if(missionEl) missionEl.value=getMissionStatement();
  syncMissionStatementView();
  const localTZ=Intl.DateTimeFormat().resolvedOptions().timeZone;
  const tzToSet=APP_SETTINGS.timezone||localTZ;
  const tzSel=document.getElementById('set-timezone');
  if(tzSel){
    // Try to select matching option, fall back to America/Los_Angeles if not found
    const opts=[...tzSel.options].map(o=>o.value);
    tzSel.value=opts.includes(tzToSet)?tzToSet:(opts.find(o=>o.includes(localTZ.split('/')[1]))||'America/Los_Angeles');
    updateTzAbbr();
  }
  // Render director color swatches
  const dirCol=DIRECTOR_COLORS.some(c=>c.id===APP_SETTINGS.directorColor)
    ?APP_SETTINGS.directorColor:'teal';
  const sw=document.getElementById('set-director-sw');
  if(sw){
    sw.innerHTML='';
    DIRECTOR_COLORS.forEach(col=>{
      const b=document.createElement('div');
      b.className='swatch'+(col.id===dirCol?' sel':'');
      b.style.background=col.hex;b.dataset.cid=col.id;b.title=col.id;
      b.onclick=()=>{
        sw.querySelectorAll('.swatch').forEach(s=>s.classList.remove('sel'));
        b.classList.add('sel');
        updateSettingsSaveState();
      };
      sw.appendChild(b);
    });
  }
  updateFolderUI();
  updateModelPickerSummary('helper');
  captureSettingsFormBaseline();
}

// Scroll agent log so the last agent response entry top is at top of visible area
function scrollAgentToLatestResponse(logEl){
  if(!logEl) return;
  // Find last agent-role entry (not director, not sep)
  const entries=[...logEl.querySelectorAll('.a-entry')];
  // Find last non-director entry
  let lastEntry=null;
  for(let i=entries.length-1;i>=0;i--){
    if(entries[i].querySelector('.e-body')||entries[i].querySelector('.api-error-indicator')){lastEntry=entries[i];break;}
  }
  if(lastEntry){
    // Scroll so lastEntry's top aligns with logEl's top and add bottom pad when needed.
    scrollEntryToTopForHistoryNav(logEl,lastEntry);
  } else {
    clearHistoryNavScrollPad(logEl);
    logEl.scrollTop=logEl.scrollHeight;
  }
}

// On Submit: align each agent log to newest response at top.
function resetAgentScrollPositions(){
  const c=S.conv;if(!c)return;
  c.agents.forEach(a=>{
    const logEl=document.getElementById('al_'+a.id);
    if(logEl){
      scrollAgentToLatestResponse(logEl);
    }
  });
}
function applyDirectorColor(){
  const col=DIRECTOR_COLORS.find(c=>c.id===(APP_SETTINGS.directorColor||'teal'))||DIRECTOR_COLORS[0];
  const dp=document.getElementById('director-panel');
  if(dp){
    dp.style.borderColor=col.dim;
    const lbl=dp.querySelector('.panel-label');
    if(lbl) lbl.style.color=col.hex;
  }
  const summaryBtn=document.getElementById('btn-summary');
  if(summaryBtn) summaryBtn.style.color=col.hex;
  const dlBtn=document.getElementById('btn-dl-full');
  if(dlBtn) dlBtn.style.color=col.hex;
}

// ── PERSONAS ──────────────────────────────────────────────────────

// -- PERSONAS --------------------------------------------------------------
const PERSONA_SLIDERS=[
  {id:'intellect',label:'Intellect'},
  {id:'directness',label:'Directness'},
  {id:'formality',label:'Formality'},
  {id:'empathy',label:'Empathy'},
  {id:'verbosity',label:'Verbosity'},
  {id:'riskTolerance',label:'Risk Tolerance'},
  {id:'optimism',label:'Optimism'},
  {id:'conformity',label:'Conformity'},
  {id:'analytical',label:'Analytical'},
  {id:'intuitive',label:'Intuitive'},
  {id:'humor',label:'Humor'},
  {id:'anxiety',label:'Anxiety'},
  {id:'mood',label:'Mood'},
  {id:'stressLevel',label:'Stress Level'},
  {id:'patience',label:'Patience'},
  {id:'confidence',label:'Confidence'},
  {id:'emotionalOpenness',label:'Emotional Openness'},
  {id:'honesty',label:'Honesty'},
  {id:'socialTrust',label:'Social Trust'},
  {id:'impulseControl',label:'Impulse Control'}
];

const PERSONA_OCCUPATIONS=[
  {category:'Medical / Health',roles:['General Practitioner','Cardiologist','Neurologist','Oncologist','Psychiatrist/Psychologist','Surgeon','ER/Trauma','Pediatrician','OB/GYN','Ophthalmologist','Dermatologist','Orthopedist','Pharmacist','Nurse Practitioner','Physical Therapist','Naturopath/Holistic','Traditional Chinese Medicine','Ayurvedic Practitioner','Nutritionist/Dietitian','Midwife','Dentist','Geriatric Specialist','Paramedic/EMT']},
  {category:'Science / Research',roles:['Physicist','Chemist','Biologist','Environmental Scientist','Astronomer','Geologist','Geneticist','Neuroscientist','Epidemiologist','Data Scientist/Statistician','Marine Biologist','Archaeologist','Anthropologist']},
  {category:'Technology',roles:['Software Engineer','Network Architect','Cybersecurity Specialist','AI/ML Researcher','Database Architect','DevOps Engineer','UX Designer','Product Manager','Systems Administrator','Game Developer','Mobile Developer','Hardware Engineer','CTO/Tech Executive']},
  {category:'Trades / Skilled Labor',roles:['Electrician','Plumber','HVAC Technician','General Contractor','Carpenter/Woodworker','Welder','Auto Mechanic','Heavy Equipment Operator','Mason/Bricklayer','Painter (house)','Roofer','Locksmith','Machinist']},
  {category:'Law / Justice',roles:['Criminal Defense Attorney','Prosecutor','Corporate Lawyer','Family Law Attorney','Constitutional Scholar','Judge','Police Officer','Detective/Investigator','Federal Agent','Forensic Specialist','Mediator/Arbitrator']},
  {category:'Education',roles:['Elementary Teacher','High School Teacher','University Professor','Special Education','School Counselor','Curriculum Designer','Montessori/Alternative Education','Athletic Coach','Librarian']},
  {category:'Finance / Business',roles:['Accountant/CPA','Financial Advisor','Investment Banker','Economist','Entrepreneur/Startup Founder','Small Business Owner','HR Professional','Management Consultant','Real Estate Agent','Insurance Specialist','Tax Specialist']},
  {category:'Creative / Arts',roles:['Novelist/Fiction Writer','Journalist','Screenwriter','Poet','Visual Artist/Painter','Sculptor','Graphic Designer','Photographer','Film Director','Musician (Classical)','Musician (Contemporary)','Music Producer','Actor/Theater','Architect','Interior Designer','Fashion Designer']},
  {category:'Religion / Spirituality',roles:['Catholic Priest','Protestant Pastor','Rabbi','Imam','Buddhist Monk','Hindu Priest','Interfaith Minister','Theologian','Secular Humanist Philosopher','Meditation/Mindfulness Teacher']},
  {category:'Military / Security',roles:['Army Officer','Navy/Marine','Air Force Pilot','Special Operations','Military Strategist','Intelligence Analyst','Veteran (post-service)']},
  {category:'Social Services / Community',roles:['Social Worker','Therapist/Counselor','Community Organizer','Nonprofit Director','Public Health Worker','Firefighter','Addiction Counselor']},
  {category:'Agriculture / Environment',roles:['Farmer (Conventional)','Farmer (Organic/Sustainable)','Rancher','Veterinarian','Forester/Park Ranger','Marine Conservationist','Climate Scientist','Urban Planner']},
  {category:'Sports / Fitness',roles:['Professional Athlete','Personal Trainer','Sports Medicine Specialist','Sports Psychologist','Coach (Professional Level)']},
  {category:'Culinary / Food',roles:['Chef (Fine Dining)','Baker/Pastry Chef','Food Scientist','Restaurant Owner','Food Critic','Sommelier']},
  {category:'Non-Occupational',roles:['Stay-at-home Parent','Retiree','Student (Undergraduate)','Student (Graduate/Trade)','Caregiver (Family)','Volunteer/Activist','Hobbyist/Autodidact']}
];

const PERSONA_CULTURES=['Western American','Southern American','East Asian','South Asian','Latin American','Middle Eastern','African','Eastern European','Western European','Caribbean','Indigenous/Native','Pacific Islander'];
const PERSONA_REGIONS=['Urban','Suburban','Rural'];
const PERSONA_EDUCATION=['None/minimal','High school','Trade/vocational','Some college','Bachelor\'s','Master\'s','Doctorate','Self-taught expert'];
const PERSONA_SOCIOECONOMIC=['Grew up poor','Working class','Middle class','Upper middle class','Wealthy'];
const PERSONA_DISABILITIES=['Blind','Deaf/HoH','Mobility-impaired','Neurodiverse','Chronic pain/illness','None'];
const PERSONA_MENTAL_HEALTH=['Depression','Anxiety Disorder','Bipolar Disorder','PTSD','OCD','ADHD','Autism Spectrum','Narcissistic Traits','Schizophrenia Spectrum','Dissociative Identity Disorder','Normal'];
const PERSONA_LIFE_STAGES=['Student','Early career','Mid-career','Senior/veteran','Retired','Parent','Caregiver'];

const PERSONA_WORLDVIEW={
  political:[
    {id:'progressive',label:'Progressive'},
    {id:'liberal',label:'Liberal'},
    {id:'moderate',label:'Moderate'},
    {id:'conservative',label:'Conservative'},
    {id:'libertarian',label:'Libertarian'},
    {id:'apolitical',label:'Apolitical'}
  ],
  religious:[
    {id:'secular_none',label:'Secular/None'},
    {id:'christian',label:'Christian'},
    {id:'jewish',label:'Jewish'},
    {id:'muslim',label:'Muslim'},
    {id:'hindu',label:'Hindu'},
    {id:'buddhist',label:'Buddhist'},
    {id:'spiritual_not_religious',label:'Spiritual-not-religious'},
    {id:'other',label:'Other'}
  ],
  epistemology:[
    {id:'scientific_evidence',label:'Scientific evidence'},
    {id:'personal_experience',label:'Personal experience'},
    {id:'authority_tradition',label:'Authority/tradition'},
    {id:'faith_revelation',label:'Faith/revelation'},
    {id:'pragmatism',label:'Pragmatism'},
    {id:'traditional_media',label:'Traditional Media'},
    {id:'internet',label:'Internet'}
  ]
};

const PERSONA_IDENTITY_GENDERS=['Male','Female','Non-binary'];

function personaClone(v){
  try{return JSON.parse(JSON.stringify(v));}catch(e){return null;}
}

function getAllPersonaOccupations(){
  const out=[];
  PERSONA_OCCUPATIONS.forEach(group=>{
    (group.roles||[]).forEach(role=>out.push(role));
  });
  return out;
}

function canonicalPersonaValue(list,value,fallback=''){
  const raw=String(value||'').trim();
  if(!raw) return fallback;
  const exact=list.find(item=>item===raw);
  if(exact) return exact;
  const lower=raw.toLowerCase();
  return list.find(item=>item.toLowerCase()===lower)||fallback;
}

function personaCodecSliderValue(value){
  return clampInt(value,-5,5);
}

function personaPromptChoices(list){
  return list.map(item=>`"${item}"`).join(', ');
}

function personaBudgetPromptSummary(key,budget){
  const opts=PERSONA_WORLDVIEW[key]||[];
  const data=normalizeWorldBudget(key,budget||{});
  return opts.map(opt=>`${opt.label} ${data[opt.id]||0}`).join(', ');
}

function personaArticleForPhrase(text){
  const src=String(text||'').trim();
  if(!src||/^\d/.test(src)) return'a';
  const match=src.match(/[A-Za-z]/);
  const ch=String(match?.[0]||'').toLowerCase();
  if(!ch) return'a';
  return'aeiou'.includes(ch)?'an':'a';
}

function isClusterDefault(clusterName,attrs){
  const data=normalizePersonaAttributes(attrs||{});
  if(clusterName==='background'){
    return !data.culture&&!data.region&&!data.education&&!data.socioeconomic;
  }
  if(clusterName==='worldview'){
    return isDefaultWorldBudget('political',data.political)
      &&isDefaultWorldBudget('religious',data.religious)
      &&isDefaultWorldBudget('epistemology',data.epistemology);
  }
  if(clusterName==='lifeExperiences'){
    const disabilities=Array.isArray(data.disabilities)?data.disabilities:[];
    const mentalHealth=Array.isArray(data.mentalHealth)?data.mentalHealth:[];
    const lifeStage=Array.isArray(data.lifeStage)?data.lifeStage:[];
    return (!disabilities.length||(disabilities.length===1&&disabilities[0]==='None'))
      &&(!mentalHealth.length||(mentalHealth.length===1&&mentalHealth[0]==='Normal'))
      &&!lifeStage.length;
  }
  if(clusterName==='personality'){
    return PERSONA_SLIDERS.every(sl=>(parseInt(data[sl.id],10)||0)===0);
  }
  return true;
}

function renderIdentityLine(name,attrs){
  const data=normalizePersonaAttributes(attrs||{});
  const safeName=String(name||'').trim();
  const descriptorParts=[];
  if(data.age) descriptorParts.push(`${data.age}-year-old`);
  if(data.gender) descriptorParts.push(data.gender);
  if(data.occupation) descriptorParts.push(data.occupation);
  let descriptor=descriptorParts.join(' ').trim();
  if(!descriptor) descriptor='person';
  if(!data.occupation&&data.gender&&!data.age) descriptor=`${data.gender} person`;
  const article=personaArticleForPhrase(descriptor);
  return safeName
    ? `You are ${safeName}, ${article} ${descriptor}.`
    : `You are ${article} ${descriptor}.`;
}

function parseIdentityLine(description){
  const firstLine=String(description||'').split(/\r?\n/)[0]?.trim()||'';
  const match=firstLine.match(/^You are\s+(.+?)\.\s*$/i);
  if(!match) return null;
  const body=String(match[1]||'').trim();
  const hasArticle=/^(?:a|an)\s+/i.test(body);
  let name='';
  let descriptor=body;
  const commaIdx=body.indexOf(',');
  if(commaIdx>=0){
    name=body.slice(0,commaIdx).trim();
    descriptor=body.slice(commaIdx+1).trim();
  }else if(!hasArticle){
    return{name:body,age:'',gender:'',occupation:''};
  }
  descriptor=descriptor.replace(/^(?:a|an)\s+/i,'').trim();
  let age='';
  const ageMatch=descriptor.match(/^(\d{1,3})-year-old\b/i);
  if(ageMatch){
    age=normalizePersonaAge(ageMatch[1])||'';
    descriptor=descriptor.slice(ageMatch[0].length).trim();
  }
  let gender='';
  const genderMatch=descriptor.match(/^(Male|Female|Non-binary)\b/i);
  if(genderMatch){
    gender=canonicalPersonaValue(PERSONA_IDENTITY_GENDERS,genderMatch[1],'');
    descriptor=descriptor.slice(genderMatch[0].length).trim();
  }
  const occupation=/^person$/i.test(descriptor)?'':descriptor;
  return{name,age,gender,occupation};
}

function personaRegexEscape(value){
  return String(value||'').replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
}

function personaSectionSubjectKey(value){
  return String(value||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
}

function personaSectionSubjectAllowlist(){
  const allowed=new Set(['he','she','they','the persona','urban','suburban','rural','none','normal']);
  const add=value=>{
    const key=personaSectionSubjectKey(value);
    if(key) allowed.add(key);
  };
  [
    PERSONA_CULTURES,
    PERSONA_REGIONS,
    PERSONA_EDUCATION,
    PERSONA_SOCIOECONOMIC,
    PERSONA_DISABILITIES,
    PERSONA_MENTAL_HEALTH,
    PERSONA_LIFE_STAGES,
    getAllPersonaOccupations()
  ].forEach(list=>{
    if(Array.isArray(list)) list.forEach(add);
  });
  return allowed;
}

function neutralizeGeneratedPersonaNameSubjects(text){
  const allowed=personaSectionSubjectAllowlist();
  const personIntroVerb='grew up|was born|was raised|works|lives|spent|comes from|balances|navigates|approaches|prefers|believes|struggles|relies';
  const subjectPattern=new RegExp(`(^|[.!?]\\s+)([A-Z][A-Za-z'\\u2019-]+(?:\\s+[A-Z][A-Za-z'\\u2019-]+){0,2})(?=(?:,\\s+(?:an?|the)\\s+[^,.!?]+,)?\\s+(?:${personIntroVerb})\\b)`,'g');
  return String(text||'').replace(subjectPattern,(match,prefix,subject)=>{
    if(allowed.has(personaSectionSubjectKey(subject))) return match;
    return `${prefix}The persona`;
  });
}

function normalizePersonaSectionBody(body,scrubNames=[]){
  let cleaned=String(body||'').trim();
  cleaned=cleaned.replace(/^```(?:json|markdown)?\s*/i,'').replace(/```$/,'').trim();
  const stripSectionHeading=text=>String(text||'').replace(/^(?:##\s*)?(Background|Worldview|Life Experiences|Personality)\s*\n+/i,'').trim();
  cleaned=stripSectionHeading(cleaned);
  if(/^"(.*)"$/s.test(cleaned)) cleaned=cleaned.slice(1,-1).trim();
  cleaned=cleaned.replace(/^You are\s+(?:(?:Dr|Mr|Mrs|Ms|Mx|Prof)\.?\s+)?[A-Z][A-Za-z'\u2019-]+(?:\s+[A-Z][A-Za-z'\u2019-]+){0,3}\s*,\s+(?:an?|the)\s+[^\n.!?]+[.!?]\s*/,'').trim();
  cleaned=cleaned.replace(/\b(?:Dr|Mr|Mrs|Ms|Mx|Prof)\.?\s+[A-Z][A-Za-z'\u2019-]+(?:\s+[A-Z][A-Za-z'\u2019-]+){0,3}\b/g,'the persona').trim();
  [...new Set((Array.isArray(scrubNames)?scrubNames:[]).map(name=>String(name||'').trim()).filter(name=>name.length>=3))].forEach(name=>{
    const pattern=personaRegexEscape(name).replace(/\s+/g,'\\s+');
    cleaned=cleaned.replace(new RegExp(`\\b${pattern}\\b`,'g'),'the persona').trim();
  });
  cleaned=neutralizeGeneratedPersonaNameSubjects(cleaned).trim();
  cleaned=cleaned.replace(/([.!?]\s+)the persona\b/g,'$1The persona');
  cleaned=cleaned.replace(/^the persona\b/,'The persona');
  cleaned=stripSectionHeading(cleaned);
  if(cleaned.startsWith('the persona')) cleaned='The persona'+cleaned.slice('the persona'.length);
  return cleaned;
}

function assembleSectionedDescription(identityLine,sectionBodies,scrubNames=[]){
  const identity=parseIdentityLine(identityLine);
  const sectionScrubNames=[identity.name,...(Array.isArray(scrubNames)?scrubNames:[])].filter(Boolean);
  const parts=[String(identityLine||'').trim()||renderIdentityLine('',personaDefaultAttributes())];
  [
    ['Background',sectionBodies?.background],
    ['Worldview',sectionBodies?.worldview],
    ['Life Experiences',sectionBodies?.lifeExperiences],
    ['Personality',sectionBodies?.personality]
  ].forEach(([heading,body])=>{
    const cleaned=normalizePersonaSectionBody(body,sectionScrubNames);
    if(!cleaned) return;
    parts.push(`## ${heading}\n${cleaned}`);
  });
  return parts.join('\n\n').trim();
}

function replacePersonaDescriptionIdentityLine(description,name,attrs){
  const identityLine=renderIdentityLine(name,attrs);
  const src=String(description||'').trim();
  if(!src) return identityLine;
  const lines=src.split(/\r?\n/);
  lines[0]=identityLine;
  return lines.join('\n').trim();
}

function parseHelperJsonObject(text){
  const jsonText=extractJsonObject(text);
  if(!jsonText) return null;
  try{return JSON.parse(jsonText);}catch(e){return null;}
}

function hasSectionedPersonaSections(description){
  return/\n##\s+(Background|Worldview|Life Experiences|Personality)\b/.test(String(description||''));
}

function setPersonaSaveButtonsDisabled(disabled){
  ['btn-persona-use','btn-persona-save','btn-persona-clone'].forEach(id=>{
    const btn=document.getElementById(id);
    if(btn) btn.disabled=!!disabled;
  });
  if(!disabled) syncPersonaAssignmentButtons();
}

function isPersonaEditorLocked(){
  return !!S.personaEditorLocked;
}

function personaHasSavedRecord(){
  return !!String(document.getElementById('pe-path')?.value||'').trim();
}

function setPersonaFieldGroupDisabled(selector,disabled){
  document.querySelectorAll(`${selector} input, ${selector} select, ${selector} textarea, ${selector} button`).forEach(el=>{
    if(String(el.type||'').toLowerCase()==='hidden') return;
    el.disabled=!!disabled;
  });
}

function updatePersonaEditorLockButton(){
  const btn=document.getElementById('pe-ai-lock-btn');
  if(!btn) return;
  const showLock=personaHasSavedRecord();
  btn.style.display=showLock?'inline-flex':'none';
  const locked=showLock&&isPersonaEditorLocked();
  btn.textContent=locked?'🔒':'🔓';
  btn.title=locked?'Unlock persona editing':'Lock persona editing';
  btn.setAttribute('aria-label',btn.title);
  btn.classList.toggle('is-unlocked',!locked);
}

function updatePersonaEditorLockUi(){
  const locked=personaHasSavedRecord()&&isPersonaEditorLocked();
  const modelSummary=document.getElementById('pe-model-summary');
  if(modelSummary) modelSummary.classList.toggle('is-disabled',locked);
  setPersonaFieldGroupDisabled('#pe-model-picker',locked);
  const voice=document.getElementById('pe-voice');
  if(voice) voice.disabled=locked;
  const setupDetails=document.getElementById('pe-setup-details');
  if(locked&&setupDetails) setupDetails.open=true;
  setPersonaFieldGroupDisabled('#pe-setup-details',locked);
  const dirtyBtn=document.getElementById('pe-dirty-hint-btn');
  if(dirtyBtn) dirtyBtn.disabled=locked;
  if(locked) closeModelPicker('persona');
  updatePersonaEditorLockButton();
}

function setPersonaEditorLocked(locked,options={}){
  S.personaEditorLocked=!!locked;
  updatePersonaEditorLockUi();
  if(!options.skipSync) syncPersonaAssignmentButtons();
}

function togglePersonaEditorLock(){
  setPersonaEditorLocked(!isPersonaEditorLocked());
}

function readPersonaIdentityFromForm(){
  return{
    name:String(document.getElementById('pe-name')?.value||'').trim(),
    occupation:String(document.getElementById('pe-occupation')?.value||'').trim(),
    gender:String(document.getElementById('pe-gender')?.value||'').trim(),
    age:normalizePersonaAge(document.getElementById('pe-age')?.value)||''
  };
}

function setPersonaNameFieldValue(value){
  const input=document.getElementById('pe-name');
  if(!input) return;
  input.value=String(value||'');
  syncPersonaAssignmentButtons();
}

function applyPersonaStructuredStateToForm(attrs,options={}){
  const data=normalizePersonaAttributes(attrs||{});
  const name=Object.prototype.hasOwnProperty.call(options,'name')?String(options.name||'').trim():null;
  if(name!==null) setPersonaNameFieldValue(name);
  populateOccupationSelect(data.occupation||'');
  document.getElementById('pe-gender').value=data.gender||'';
  document.getElementById('pe-age').value=data.age||25;
  document.getElementById('pe-age-slider').value=data.age||25;
  populateSimpleSelect('pe-culture',PERSONA_CULTURES,data.culture||'');
  populateSimpleSelect('pe-region',PERSONA_REGIONS,data.region||'');
  populateSimpleSelect('pe-education',PERSONA_EDUCATION,data.education||'');
  populateSimpleSelect('pe-socioeconomic',PERSONA_SOCIOECONOMIC,data.socioeconomic||'');
  renderPersonaSliderRows(data);
  renderWorldBudgetGroup('political','pe-world-political','Political Orientation',data.political);
  renderWorldBudgetGroup('religious','pe-world-religious','Religious/Spiritual Framework',data.religious);
  renderWorldBudgetGroup('epistemology','pe-world-epistemology','Interpret Truth',data.epistemology);
  renderCheckboxGroup('pe-disabilities',PERSONA_DISABILITIES,data.disabilities||['None'],'None');
  renderCheckboxGroup('pe-mental-health',PERSONA_MENTAL_HEALTH,data.mentalHealth||['Normal'],'Normal');
  renderCheckboxGroup('pe-life-stage',PERSONA_LIFE_STAGES,data.lifeStage||[]);
}

function personaEvenWorldBudget(key){
  const opts=PERSONA_WORLDVIEW[key]||[];
  if(!opts.length) return {};
  const base=Math.floor(100/opts.length);
  let rem=100-(base*opts.length);
  const out={};
  opts.forEach(opt=>{
    out[opt.id]=base+(rem>0?1:0);
    if(rem>0) rem--;
  });
  return out;
}

function normalizePersonaAge(v){
  const n=parseInt(v,10);
  if(Number.isNaN(n)) return'';
  return Math.max(5,Math.min(100,n));
}

function normalizeWebSearchBudget(v){
  const n=parseInt(v,10);
  if(Number.isNaN(n)) return DEFAULT_WEB_SEARCH_BUDGET;
  return Math.max(0,Math.min(5,n));
}
function normalizeRollingRounds(v){
  const fallback=APP_SETTINGS.maxRounds||10;
  const n=parseInt(v,10);
  if(Number.isNaN(n)) return Math.max(5,Math.min(50,Math.round(fallback/5)*5));
  return Math.max(5,Math.min(50,Math.round(n/5)*5));
}
function normalizeActiveAgentIds(ids,agents=[]){
  const validIds=(agents||[]).filter(agent=>!agent?.isGhost).map(agent=>String(agent?.id||'')).filter(Boolean);
  if(!Array.isArray(ids)) return validIds;
  const validSet=new Set(validIds);
  const normalized=[];
  ids.forEach(id=>{
    const key=String(id||'');
    if(key&&validSet.has(key)&&!normalized.includes(key)) normalized.push(key);
  });
  return normalized;
}
function normalizeConversationMode(v){
  const mode=String(v||'').trim().toLowerCase();
  return CONVERSATION_MODE_OPTIONS.includes(mode)?mode:DEFAULT_CONVERSATION_MODE;
}
function normalizeDirectorType(v){
  const type=String(v||'').trim().toLowerCase();
  return DIRECTOR_TYPE_OPTIONS.includes(type)?type:DEFAULT_DIRECTOR_TYPE;
}
function normalizeAiDirectorCountdown(v){
  const n=parseInt(v,10);
  if(Number.isNaN(n)) return DEFAULT_AI_DIRECTOR_COUNTDOWN;
  return Math.max(3,Math.min(60,n));
}
function normalizeConversationPaceDelay(v){
  const n=parseInt(v,10);
  if(Number.isNaN(n)) return DEFAULT_CONVERSATION_PACE_DELAY;
  return Math.max(0,Math.min(30,n));
}

function generationFromAge(age){
  const n=normalizePersonaAge(age);
  if(!n) return'';
  const year=(new Date()).getFullYear()-n;
  if(year<=1945) return'Silent';
  if(year<=1964) return'Boomer';
  if(year<=1980) return'Gen X';
  if(year<=1996) return'Millennial';
  if(year<=2012) return'Gen Z';
  return'Gen Alpha';
}

function inferAgeFromGeneration(generation){
  const g=String(generation||'').trim();
  if(g==='Silent') return 90;
  if(g==='Boomer') return 68;
  if(g==='Gen X') return 50;
  if(g==='Millennial') return 37;
  if(g==='Gen Z') return 22;
  if(g==='Gen Alpha') return 12;
  return'';
}

function personaDefaultAttributes(){
  const attrs={
    occupation:'',
    occupationCategory:'',
    gender:'',
    age:'',
    generation:'',
    culture:'',
    region:'',
    education:'',
    socioeconomic:'',
    political:personaEvenWorldBudget('political'),
    religious:personaEvenWorldBudget('religious'),
    epistemology:personaEvenWorldBudget('epistemology'),
    disabilities:['None'],
    mentalHealth:['Normal'],
    lifeStage:[]
  };
  PERSONA_SLIDERS.forEach(s=>{attrs[s.id]=0;});
  return attrs;
}

function clampInt(v,min,max){
  const n=parseInt(v,10);
  if(Number.isNaN(n)) return min;
  return Math.max(min,Math.min(max,n));
}

function normalizeExclusiveSelections(values,allowed,defaultValue){
  const src=Array.isArray(values)?values:[];
  const uniq=[...new Set(src.map(v=>String(v)).filter(v=>allowed.includes(v)))];
  const specific=uniq.filter(v=>v!==defaultValue);
  if(specific.length) return specific;
  return[defaultValue];
}

function normalizeWorldBudget(key,raw){
  const opts=PERSONA_WORLDVIEW[key]||[];
  const fallback=personaEvenWorldBudget(key);
  if(!raw||typeof raw!=='object') return fallback;
  const vals=opts.map(o=>Math.max(0,parseInt(raw[o.id],10)||0));
  const sum=vals.reduce((a,b)=>a+b,0);
  if(sum<=0) return fallback;
  if(sum===100){
    const out={};
    opts.forEach((o,i)=>{out[o.id]=vals[i];});
    return out;
  }
  const scaled=vals.map(v=>(v/sum)*100);
  const floored=scaled.map(v=>Math.floor(v));
  let rem=100-floored.reduce((a,b)=>a+b,0);
  const ranked=scaled.map((v,i)=>({i,frac:v-floored[i]})).sort((a,b)=>b.frac-a.frac);
  for(let i=0;i<ranked.length&&rem>0;i++,rem--){
    floored[ranked[i].i]+=1;
  }
  const out={};
  opts.forEach((o,i)=>{out[o.id]=floored[i];});
  return out;
}

function normalizePersonaAttributes(raw){
  const def=personaDefaultAttributes();
  const src=(raw&&typeof raw==='object')?raw:{};
  const out={...def};
  ['occupation','occupationCategory','gender','culture','region','education','socioeconomic'].forEach(k=>{
    out[k]=String(src[k]||'').trim();
  });
  out.age=normalizePersonaAge(src.age);
  if(!out.age){
    const inferred=inferAgeFromGeneration(src.generation);
    out.age=normalizePersonaAge(inferred);
  }
  out.generation=generationFromAge(out.age);
  PERSONA_SLIDERS.forEach(s=>{
    out[s.id]=clampInt(src[s.id],-10,10);
  });
  out.political=normalizeWorldBudget('political',src.political);
  out.religious=normalizeWorldBudget('religious',src.religious);
  out.epistemology=normalizeWorldBudget('epistemology',src.epistemology);
  out.disabilities=normalizeExclusiveSelections(src.disabilities,PERSONA_DISABILITIES,'None');
  out.mentalHealth=normalizeExclusiveSelections(src.mentalHealth,PERSONA_MENTAL_HEALTH,'Normal');
  out.lifeStage=[...new Set((Array.isArray(src.lifeStage)?src.lifeStage:[]).map(v=>String(v)).filter(v=>PERSONA_LIFE_STAGES.includes(v)))];
  return out;
}

function isValidPersonaData(data){
  if(!data||typeof data!=='object') return false;
  if(!String(data.uuid||'').trim()) return false;
  if(!String(data.name||'').trim()) return false;
  if(!String(data.model||'').trim()) return false;
  if(typeof data.attributes!=='object'||!data.attributes) return false;
  if(typeof data.webSearchBudget!=='undefined'&&!Number.isFinite(Number(data.webSearchBudget))) return false;
  if(typeof data.backstory!=='string') return false;
  if(typeof data.voiceName!=='undefined'&&typeof data.voiceName!=='string') return false;
  return true;
}

function normalizePersonaRecord(data){
  if(!isValidPersonaData(data)) return null;
  const rec={
    uuid:String(data.uuid).trim(),
    name:String(data.name).trim(),
    model:String(data.model).trim(),
    attributes:normalizePersonaAttributes(data.attributes),
    backstory:String(data.backstory||''),
    voiceName:String(data.voiceName||'')
  };
  if(!rec.uuid||!rec.name||!rec.model) return null;
  return rec;
}

function parsePersonaFileName(fileName){
  const match=String(fileName||'').match(/^(.+)__([A-Za-z0-9-]+)\.json$/i);
  if(!match) return null;
  const slug=String(match[1]||'').trim();
  const uuid=String(match[2]||'').trim();
  if(!isUuidLike(uuid)) return null;
  if(!uuid||!slug) return null;
  return{
    uuid,
    slug,
    displayName:slug.replace(/_/g,' ').trim()||slug
  };
}

function getFallbackPersonaDisplayName(fileName){
  const base=String(fileName||'').replace(/\.json$/i,'');
  return base.replace(/_/g,' ').trim()||base;
}

function buildPersonaFileName(uuid,name){
  const safeUuid=String(uuid||'').trim();
  const safeName=sanitizeTitleForFs(name||'Persona',64)||'Persona';
  return safeName+'__'+safeUuid+'.json';
}

function isDefaultWorldBudget(key,budget){
  const a=normalizeWorldBudget(key,budget||{});
  const b=personaEvenWorldBudget(key);
  return JSON.stringify(a)===JSON.stringify(b);
}

function worldBudgetRemaining(budget,key){
  const opts=PERSONA_WORLDVIEW[key]||[];
  const used=opts.reduce((sum,opt)=>sum+(parseInt(budget?.[opt.id],10)||0),0);
  return 100-used;
}

function getOccupationCategory(role){
  for(const group of PERSONA_OCCUPATIONS){
    if((group.roles||[]).includes(role)) return group.category;
  }
  return '';
}

function tryReadJsonFromFileHandle(fileHandle){
  return fileHandle.getFile().then(f=>f.text()).then(t=>JSON.parse(t)).catch(()=>null);
}

async function readPersonaRecordFromNode(node){
  if(!node||node.type!=='persona'||!node.fileHandle) return null;
  if(node.data) return node.data;
  const rec=normalizePersonaRecord(await tryReadJsonFromFileHandle(node.fileHandle));
  if(!rec) return null;
  if(node.uuid&&rec.uuid!==node.uuid) return null;
  node.data=rec;
  node.damaged=false;
  return rec;
}

function markAgentPersonaMissing(agent){
  if(!agent) return;
  agent.personaResolvedData=null;
  agent.personaMissing=!!String(agent.personaUuid||'').trim();
  if(agent.personaMissing) agent.voiceName='';
}

function applyPersonaRecordToAgent(agent,rec){
  if(!agent||!rec) return;
  agent.personaResolvedData=rec;
  agent.personaMissing=false;
  agent.name=rec.name||agent.name;
  agent.model='';
  agent.voiceName=rec.voiceName||'';
}

async function ensureAgentPersonaResolved(agent){
  if(!agent) return null;
  if(!String(agent.personaUuid||'').trim()){
    agent.personaResolvedData=null;
    agent.personaMissing=false;
    return null;
  }
  if(agent.personaResolvedData?.uuid===agent.personaUuid){
    agent.personaMissing=false;
    return agent.personaResolvedData;
  }
  const node=S.personaUuidIndex?.[agent.personaUuid]||null;
  if(!node||node.damaged){
    markAgentPersonaMissing(agent);
    return null;
  }
  const rec=await readPersonaRecordFromNode(node);
  if(!rec){
    node.damaged=true;
    node.data=null;
    markAgentPersonaMissing(agent);
    return null;
  }
  applyPersonaRecordToAgent(agent,rec);
  return rec;
}
async function scanPersonaTreeDirectory(dirHandle,parentPath,index){
  const categories=[];
  const personas=[];
  for await(const [name,handle] of dirHandle.entries()){
    if(handle.kind==='directory'){
      if(!name.startsWith('!')) continue;
      const path=parentPath?parentPath+'/'+name:name;
      const displayName=(name.slice(1).replace(/_/g,' ')).trim()||name.slice(1);
      const node={
        type:'category',
        name,path,parentPath,parentHandle:dirHandle,folderHandle:handle,
        displayName,children:[]
      };
      const child=await scanPersonaTreeDirectory(handle,path,index);
      node.children=[...child.categories,...child.personas];
      categories.push(node);
      index[path]=node;
      continue;
    }
    if(handle.kind!=='file') continue;
    if(!name.toLowerCase().endsWith('.json')) continue;
    if(name.startsWith('.')) continue;
    const path=parentPath?parentPath+'/'+name:name;
    const parsed=parsePersonaFileName(name);
    const node={
      type:'persona',
      name,path,parentPath,parentHandle:dirHandle,fileHandle:handle,
      displayName:parsed?.displayName||getFallbackPersonaDisplayName(name),
      uuid:parsed?.uuid||'',
      damaged:!parsed,
      data:null
    };
    personas.push(node);
    index[path]=node;
  }
  categories.sort(sortByDisplayName);
  personas.sort(sortByDisplayName);
  return{categories,personas};
}

async function resolveConversationPersonaState(conv){
  if(!conv?.agents?.length) return;
  for(const agent of conv.agents){
    await ensureAgentPersonaResolved(agent);
  }
}

async function scanPersonaFolders(){
  treeLoadUIState(PERSONA_TREE_VIEW);
  if(!S.fsRoot){
    S.personaTree=[];
    S.personaTreeIndex={};
    S.personaPickerList=[];
    S.personaUuidIndex={};
    S.personaNameUsage=createEmptyPersonaNameUsage();
    S.personaTreeSelectedPath='';
    treeSaveUIState(PERSONA_TREE_VIEW);
    renderPersonaList();
    return;
  }
  try{
    const personasDir=await getPersonasDir(true);
    if(!personasDir){
      S.personaTree=[];
      S.personaTreeIndex={};
      S.personaPickerList=[];
      S.personaUuidIndex={};
      S.personaNameUsage=createEmptyPersonaNameUsage();
      renderPersonaList();
      return;
    }
    const index={};
    const result=await scanPersonaTreeDirectory(personasDir,'',index);
    S.personaTree=[...result.categories,...result.personas];
    S.personaTreeIndex=index;
    S.personaPickerList=flattenTreeLeaves(S.personaTree,'persona',[]).filter(n=>!n.damaged&&n.uuid);
    const uuidIndex={};
    Object.values(index).forEach(node=>{
      if(node.type==='persona'&&!node.damaged&&node.uuid){
        uuidIndex[node.uuid]=node;
      }
    });
    S.personaUuidIndex=uuidIndex;
    S.personaNameUsage=buildPersonaNameUsage(S.personaPickerList);
    if(S.personaTreeSelectedPath&&!index[S.personaTreeSelectedPath]){
      S.personaTreeSelectedPath='';
      treeSaveUIState(PERSONA_TREE_VIEW);
    }
    if(S.activePersona?.path&&!index[S.activePersona.path]){
      S.activePersona=null;
      personaListBack();
    }
    if(S.conv){
      await resolveConversationPersonaState(S.conv);
      renderAgentGrid();
      renderRouting();
      syncDirectorComposerUi();
    }
    renderPersonaList();
  }catch(e){
    S.personaTree=[];
    S.personaTreeIndex={};
    S.personaPickerList=[];
    S.personaUuidIndex={};
    S.personaNameUsage=createEmptyPersonaNameUsage();
    renderPersonaList();
  }
}

function canManagePersonaCategory(node){
  return !!node&&node.type==='category';
}

function openPersonaEditView(){
  document.getElementById('persona-list-view').style.display='none';
  document.getElementById('persona-edit-view').style.display='flex';
}

function personaListBack(){
  if(!isPersonaEditorLocked()) setPersonaEditorLocked(true,{skipSync:true});
  document.getElementById('persona-list-view').style.display='flex';
  document.getElementById('persona-edit-view').style.display='none';
  S.activePersona=null;
  updatePersonaModeUi();
  renderPersonaList();
}
function getAssignmentAgentLabel(){
  const c=S.conv;
  if(!c||!S.agentPersonaPickerFor) return'';
  const agent=c.agents.find(a=>a.id===S.agentPersonaPickerFor);
  if(!agent) return'';
  return `Agent ${getAgentPanelNumber(agent,c)}`;
}

function syncPersonaAssignmentButtons(){
  const assigning=!!S.agentPersonaPickerFor;
  const setupOpen=!!document.getElementById('pe-setup-details')?.open;
  const hasSaved=personaHasSavedRecord();
  const locked=hasSaved&&isPersonaEditorLocked();
  const hasName=!!String(document.getElementById('pe-name')?.value||'').trim();
  const summary=document.getElementById('pe-setup-summary');
  const useBtn=document.getElementById('btn-persona-use');
  const saveBtn=document.getElementById('btn-persona-save');
  const cloneBtn=document.getElementById('btn-persona-clone');
  if(summary){
    const setupEmpty=!locked&&!setupOpen;
    summary.classList.toggle('persona-setup-empty',setupEmpty);
    if(locked){
      summary.textContent='Persona Setup -- Active (locked)';
      summary.title='Unlock persona editing to remove or edit persona setup.';
    }else if(setupOpen){
      summary.textContent='Persona Setup -- Active (click to remove)';
      summary.title='A persona will be assigned. Click to remove and use AI model only.';
    }else{
      summary.textContent='Persona Setup -- None (click to add)';
      summary.title='No persona will be assigned. Click to create one.';
    }
  }
  if(useBtn){
    if(!assigning){
      useBtn.disabled=false;
      useBtn.title='Apply the current setup to this agent';
    }else if(!setupOpen){
      useBtn.disabled=false;
      useBtn.title='Apply AI model and voice to this agent';
    }else if(!hasSaved||!locked){
      useBtn.disabled=true;
      useBtn.title='Save this persona before using it on the agent';
    }else{
      useBtn.disabled=false;
      useBtn.title='Apply this saved persona to the agent';
    }
  }
  if(saveBtn){
    saveBtn.disabled=locked||!setupOpen||!hasName;
    saveBtn.title=!setupOpen
      ?'Open Persona Setup to create a persona'
      :(locked?'Unlock this persona to save changes':(hasName?'Save this persona':'Persona must have a name'));
  }
  if(cloneBtn){
    cloneBtn.disabled=!locked||!hasSaved;
    cloneBtn.title=!hasSaved
      ?'Save this persona before cloning it'
      :(locked?'Create a cloned persona from this locked source':'Lock this persona before cloning it');
  }
}

function updatePersonaModeUi(){
  const assigning=!!S.agentPersonaPickerFor;
  const note=document.getElementById('persona-mode-note');
  if(note){
    if(assigning){
      note.style.display='block';
      note.textContent=`Assignment mode: configure ${getAssignmentAgentLabel()}. Use applies the current saved persona or AI-only setup to this agent.`;
    }else{
      note.style.display='none';
      note.textContent='';
    }
  }
  const useBtn=document.getElementById('btn-persona-use');
  const saveBtn=document.getElementById('btn-persona-save');
  const cloneBtn=document.getElementById('btn-persona-clone');
  if(useBtn) useBtn.style.display=assigning?'':'none';
  if(saveBtn) saveBtn.style.display='';
  if(cloneBtn) cloneBtn.style.display='';
  syncPersonaAssignmentButtons();
}
function populateSimpleSelect(id,items,selected){
  const el=document.getElementById(id);
  if(!el) return;
  el.innerHTML='<option value="">- Select -</option>';
  (items||[]).forEach(item=>{
    const opt=document.createElement('option');
    opt.value=item;
    opt.textContent=item;
    if(item===selected) opt.selected=true;
    el.appendChild(opt);
  });
  if(selected&&![...el.options].some(opt=>opt.value===selected)){
    const opt=document.createElement('option');
    opt.value=selected;
    opt.textContent=selected;
    opt.selected=true;
    el.appendChild(opt);
  }
}

function populateOccupationSelect(selected){
  const el=document.getElementById('pe-occupation');
  if(!el) return;
  el.innerHTML='<option value="">- Select -</option>';
  PERSONA_OCCUPATIONS.forEach(group=>{
    const og=document.createElement('optgroup');
    og.label=group.category;
    (group.roles||[]).forEach(role=>{
      const opt=document.createElement('option');
      opt.value=role;
      opt.textContent=role;
      opt.dataset.category=group.category;
      if(role===selected) opt.selected=true;
      og.appendChild(opt);
    });
    el.appendChild(og);
  });
  if(selected&&![...el.querySelectorAll('option')].some(opt=>opt.value===selected)){
    const opt=document.createElement('option');
    opt.value=selected;
    opt.textContent=selected;
    opt.selected=true;
    el.appendChild(opt);
  }
}

function populatePersonaVoiceSelect(selected=''){
  const vsel=document.getElementById('pe-voice');
  if(!vsel) return;
  vsel.innerHTML='<option value="">- None (silent) -</option>';
  const voices=window.speechSynthesis.getVoices();
  voices.forEach(v=>{
    const opt=document.createElement('option');
    opt.value=v.name;
    opt.textContent=`${v.name} (${v.lang})`;
    if(v.name===selected) opt.selected=true;
    vsel.appendChild(opt);
  });
  if(selected&&![...vsel.options].some(opt=>opt.value===selected)){
    const opt=document.createElement('option');
    opt.value=selected;
    opt.textContent=selected;
    opt.selected=true;
    vsel.appendChild(opt);
  }
}

function syncPersonaAgeFromSlider(){
  const slider=document.getElementById('pe-age-slider');
  const input=document.getElementById('pe-age');
  if(!slider||!input) return;
  input.value=String(clampInt(slider.value,5,100));
  markPersonaStructuredEdited();
}
function syncPersonaAgeFromInput(){
  const slider=document.getElementById('pe-age-slider');
  const input=document.getElementById('pe-age');
  if(!slider||!input) return;
  const next=clampInt(input.value||25,5,100);
  input.value=String(next);
  slider.value=String(next);
  markPersonaStructuredEdited();
}
function getPersonaFormSignature(){
  try{return JSON.stringify(readPersonaRecordFromForm());}
  catch(e){return'';}
}
function parsePersonaFormSignature(signature){
  try{return normalizePersonaRecord(JSON.parse(String(signature||'')));}
  catch(e){return null;}
}
function personaRecordComparableExceptName(rec,name){
  if(!rec) return null;
  return{
    uuid:rec.uuid,
    name:String(name||''),
    model:rec.model,
    attributes:normalizePersonaAttributes(rec.attributes),
    backstory:String(rec.backstory||''),
    voiceName:String(rec.voiceName||'')
  };
}
function isPersonaNameOnlyEdit(){
  const current=normalizePersonaRecord(readPersonaRecordFromForm());
  const baseline=parsePersonaFormSignature(S.personaLastGeneratedSignature)||parsePersonaFormSignature(S.personaFormBaseline);
  if(!current||!baseline) return false;
  if(!current.name||current.name===baseline.name) return false;
  const currentWithOldName=personaRecordComparableExceptName(current,baseline.name);
  const baselineComparable=personaRecordComparableExceptName(baseline,baseline.name);
  return JSON.stringify(currentWithOldName)===JSON.stringify(baselineComparable);
}
function resetPersonaDirtyTracking(){
  S.personaFormBaseline=getPersonaFormSignature();
  const desc=String(document.getElementById('pe-backstory')?.value||'').trim();
  S.personaLastGeneratedSignature=desc?S.personaFormBaseline:'';
  S.personaDirtyDirection='none';
  updatePersonaDirtyHint();
}
function markPersonaDescriptionGenerated(){
  S.personaLastGeneratedSignature=getPersonaFormSignature();
  S.personaDirtyDirection='none';
  updatePersonaDirtyHint();
}
function markPersonaStructuredEdited(){
  S.personaDirtyDirection='structured-changed';
  updatePersonaDirtyHint();
}
function markPersonaDescriptionEdited(){
  S.personaDirtyDirection='description-changed';
  updatePersonaDirtyHint();
}
function updatePersonaDirtyHint(){
  const hint=document.getElementById('pe-dirty-hint');
  const msg=document.getElementById('pe-dirty-hint-msg');
  const btn=document.getElementById('pe-dirty-hint-btn');
  if(!hint||!msg||!btn) return;
  const current=getPersonaFormSignature();
  const hasBaseline=!!S.personaLastGeneratedSignature&&!!current;
  const isSynced=hasBaseline&&current===S.personaLastGeneratedSignature;
  const direction=isSynced?'none':(S.personaDirtyDirection||'none');
  if(!hasBaseline||direction==='none'){
    hint.style.display='none';
    msg.textContent='';
    btn.style.display='none';
    btn.onclick=null;
    return;
  }
  hint.style.display='flex';
  btn.style.display='inline-flex';
  if(direction==='description-changed'){
    msg.textContent='Description edited -- re-derive structured fields from the description.';
    btn.textContent='Re-derive from description';
    btn.onclick=()=>{void rederivePersonaAttributesAction();};
    return;
  }
  msg.textContent='Structured fields changed -- regenerate the description to apply.';
  btn.textContent='Regenerate description';
  btn.onclick=()=>{void generatePersonaDescription();};
}
function syncPersonaSetupSummary(){
  syncPersonaAssignmentButtons();
}
function isPersonaSetupToggleLocked(){
  return personaHasSavedRecord()&&isPersonaEditorLocked();
}
function handlePersonaSetupSummaryClick(event){
  if(!isPersonaSetupToggleLocked()) return;
  event.preventDefault();
  event.stopPropagation();
  const details=document.getElementById('pe-setup-details');
  if(details) details.open=true;
  syncPersonaAssignmentButtons();
}
function getPersonaSetupStateKey(){
  return String(document.getElementById('pe-path')?.value||S.activePersona?.path||'').trim();
}
function applyPersonaSetupOpenState(options={}){
  const details=document.getElementById('pe-setup-details');
  if(!details) return;
  const forceOpen=Object.prototype.hasOwnProperty.call(options,'forceOpen')?!!options.forceOpen:null;
  const key=getPersonaSetupStateKey();
  let nextOpen;
  if(forceOpen!==null){
    nextOpen=forceOpen;
  }else if(S.agentPersonaPickerFor){
    const agent=S.conv?.agents?.find(a=>a.id===S.agentPersonaPickerFor);
    nextOpen=!!agent?.personaUuid;
  }else if(key){
    nextOpen=Object.prototype.hasOwnProperty.call(S.personaSetupOpenByPath,key)
      ? !!S.personaSetupOpenByPath[key]
      : true;
  }else{
    nextOpen=!!S.personaSetupNewOpen;
  }
  details.open=nextOpen;
  syncPersonaAssignmentButtons();
}
function rememberPersonaSetupState(){
  const details=document.getElementById('pe-setup-details');
  if(!details) return;
  if(isPersonaSetupToggleLocked()){
    details.open=true;
    syncPersonaAssignmentButtons();
    return;
  }
  if(S.agentPersonaPickerFor){
    syncPersonaAssignmentButtons();
    return;
  }
  const key=getPersonaSetupStateKey();
  if(key) S.personaSetupOpenByPath[key]=!!details.open;
  else S.personaSetupNewOpen=!!details.open;
  syncPersonaAssignmentButtons();
}

function sliderDefconClass(v){
  const val=Math.abs(parseInt(v,10)||0);
  if(val>=6) return'persona-defcon-red';
  if(val>=3) return'persona-defcon-yellow';
  return'persona-defcon-green';
}

function renderPersonaSliderRows(values){
  const list=document.getElementById('pe-slider-list');
  if(!list) return;
  const min=S.personaSliderUnlocked?-10:-5;
  const max=S.personaSliderUnlocked?10:5;
  list.innerHTML='';
  PERSONA_SLIDERS.forEach(sl=>{
    const raw=parseInt(values?.[sl.id],10)||0;
    const v=Math.max(min,Math.min(max,raw));
    const row=document.createElement('div');
    row.className='persona-slider-row '+sliderDefconClass(v);
    row.innerHTML=`
      <label for="ps_${sl.id}">${esc(sl.label)}</label>
      <input id="ps_${sl.id}" type="range" min="${min}" max="${max}" step="1" value="${v}">
      <div class="val" id="psv_${sl.id}">${v}</div>`;
    const input=row.querySelector('#ps_'+sl.id);
    const valEl=row.querySelector('#psv_'+sl.id);
    input.oninput=()=>{
      const nv=parseInt(input.value,10)||0;
      valEl.textContent=String(nv);
      row.className='persona-slider-row '+sliderDefconClass(nv);
      markPersonaStructuredEdited();
    };
    list.appendChild(row);
  });
}

function readSliderValuesFromForm(){
  const out={};
  PERSONA_SLIDERS.forEach(sl=>{
    out[sl.id]=clampInt(document.getElementById('ps_'+sl.id)?.value||0,-10,10);
  });
  return out;
}

function worldBudgetInputId(key,id){
  return 'pw_'+key+'_'+id;
}

function renderWorldBudgetGroup(key,mountId,title,budget){
  const mount=document.getElementById(mountId);
  if(!mount) return;
  const opts=PERSONA_WORLDVIEW[key]||[];
  const data=normalizeWorldBudget(key,budget||{});
  mount.innerHTML='';
  const box=document.createElement('div');
  box.className='world-budget';
  const rem=worldBudgetRemaining(data,key);
  box.innerHTML=`
    <div class="world-budget-head">
      <div class="world-budget-title">${esc(title)}</div>
      <div class="world-budget-rem" id="pw_rem_${key}">Points remaining: ${rem}</div>
    </div>
    <div style="display:flex;justify-content:flex-end;margin-bottom:6px">
      <button class="bs" type="button" onclick="resetWorldBudgetEven('${key}')">Even Distribution</button>
    </div>`;
  opts.forEach(opt=>{
    const row=document.createElement('div');
    row.className='world-budget-row';
    row.innerHTML=`
      <label for="${worldBudgetInputId(key,opt.id)}">${esc(opt.label)}</label>
      <input id="${worldBudgetInputId(key,opt.id)}" class="fi" type="number" min="0" max="100" step="1" value="${data[opt.id]||0}">`;
    const input=row.querySelector('input');
    input.oninput=()=>worldBudgetValueChanged(key,opt.id);
    input.onchange=()=>worldBudgetValueChanged(key,opt.id);
    box.appendChild(row);
  });
  mount.appendChild(box);
}

function readWorldBudgetFromForm(key){
  const opts=PERSONA_WORLDVIEW[key]||[];
  const raw={};
  opts.forEach(opt=>{
    raw[opt.id]=clampInt(document.getElementById(worldBudgetInputId(key,opt.id))?.value||0,0,100);
  });
  return raw;
}

function writeWorldBudgetToForm(key,budget){
  const opts=PERSONA_WORLDVIEW[key]||[];
  opts.forEach(opt=>{
    const el=document.getElementById(worldBudgetInputId(key,opt.id));
    if(el) el.value=String(Math.max(0,parseInt(budget?.[opt.id],10)||0));
  });
  const remEl=document.getElementById('pw_rem_'+key);
  if(remEl) remEl.textContent='Points remaining: '+worldBudgetRemaining(budget,key);
}

function worldBudgetValueChanged(key,editedId){
  const opts=PERSONA_WORLDVIEW[key]||[];
  const next=readWorldBudgetFromForm(key);
  const others=opts.filter(o=>o.id!==editedId).reduce((sum,o)=>sum+(parseInt(next[o.id],10)||0),0);
  const maxThis=Math.max(0,100-others);
  next[editedId]=Math.max(0,Math.min(maxThis,parseInt(next[editedId],10)||0));
  writeWorldBudgetToForm(key,next);
  markPersonaStructuredEdited();
}

function resetWorldBudgetEven(key){
  writeWorldBudgetToForm(key,personaEvenWorldBudget(key));
  markPersonaStructuredEdited();
}

function renderCheckboxGroup(containerId,options,selected,exclusiveDefault){
  const wrap=document.getElementById(containerId);
  if(!wrap) return;
  const base=exclusiveDefault?normalizeExclusiveSelections(selected,options,exclusiveDefault):(Array.isArray(selected)?selected:[]);
  const selSet=new Set(base);
  wrap.innerHTML='';
  options.forEach(item=>{
    const label=document.createElement('label');
    label.innerHTML=`<input type="checkbox" value="${esc(item)}"${selSet.has(item)?' checked':''}> <span>${esc(item)}</span>`;
    wrap.appendChild(label);
  });
  const inputs=[...wrap.querySelectorAll('input[type="checkbox"]')];
  inputs.forEach(input=>{
    input.onchange=()=>{
      if(exclusiveDefault){
        if(input.value===exclusiveDefault&&input.checked){
          inputs.forEach(other=>{if(other!==input) other.checked=false;});
        }else if(input.value!==exclusiveDefault&&input.checked){
          const def=inputs.find(x=>x.value===exclusiveDefault);
          if(def) def.checked=false;
        }
        const anyChecked=inputs.some(x=>x.checked);
        if(!anyChecked){
          const def=inputs.find(x=>x.value===exclusiveDefault);
          if(def) def.checked=true;
        }
      }
      markPersonaStructuredEdited();
    };
  });
}

function readCheckboxGroup(containerId){
  const wrap=document.getElementById(containerId);
  if(!wrap) return[];
  return[...wrap.querySelectorAll('input[type="checkbox"]:checked')].map(el=>String(el.value));
}

function updatePersonaSliderLockButton(){
  const btn=document.getElementById('pe-slider-lock-btn');
  if(!btn) return;
  if(S.personaSliderUnlocked) btn.textContent='🔓 Range Unlocked (-10..+10)';
  else btn.textContent='🔒 Range Locked (-5..+5)';
}

function togglePersonaSliderLock(){
  S.personaSliderUnlocked=!S.personaSliderUnlocked;
  updatePersonaSliderLockButton();
  const cur=readSliderValuesFromForm();
  renderPersonaSliderRows(cur);
}

function initPersonaFormControls(){
  if(S._personaFormInit) return;
  populateOccupationSelect('');
  populateSimpleSelect('pe-culture',PERSONA_CULTURES,'');
  populateSimpleSelect('pe-region',PERSONA_REGIONS,'');
  populateSimpleSelect('pe-education',PERSONA_EDUCATION,'');
  populateSimpleSelect('pe-socioeconomic',PERSONA_SOCIOECONOMIC,'');
  populatePersonaVoiceSelect('');
  renderCheckboxGroup('pe-disabilities',PERSONA_DISABILITIES,['None'],'None');
  renderCheckboxGroup('pe-mental-health',PERSONA_MENTAL_HEALTH,['Normal'],'Normal');
  renderCheckboxGroup('pe-life-stage',PERSONA_LIFE_STAGES,[]);
  renderPersonaSliderRows(personaDefaultAttributes());
  renderWorldBudgetGroup('political','pe-world-political','Political Orientation',personaEvenWorldBudget('political'));
  renderWorldBudgetGroup('religious','pe-world-religious','Religious/Spiritual Framework',personaEvenWorldBudget('religious'));
  renderWorldBudgetGroup('epistemology','pe-world-epistemology','Interpret Truth',personaEvenWorldBudget('epistemology'));
  updatePersonaSliderLockButton();
  const setupDetails=document.getElementById('pe-setup-details');
  if(setupDetails){
    setupDetails.addEventListener('toggle',rememberPersonaSetupState);
    syncPersonaSetupSummary();
  }
  const setupSummary=document.getElementById('pe-setup-summary');
  if(setupSummary) setupSummary.addEventListener('click',handlePersonaSetupSummaryClick);
  ['pe-name','pe-occupation','pe-gender','pe-culture','pe-region','pe-education','pe-socioeconomic'].forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.addEventListener('input',()=>{
      markPersonaStructuredEdited();
      if(id==='pe-name') syncPersonaAssignmentButtons();
    });
    el.addEventListener('change',()=>{
      markPersonaStructuredEdited();
      if(id==='pe-name') syncPersonaAssignmentButtons();
    });
  });
  const backstory=document.getElementById('pe-backstory');
  if(backstory){
    backstory.addEventListener('input',markPersonaDescriptionEdited);
    backstory.addEventListener('change',markPersonaDescriptionEdited);
  }
  S._personaFormInit=true;
}

function applyPersonaRecordToForm(rec,options={}){
  initPersonaFormControls();
  const data=rec||{uuid:createUUID(),name:'',model:getDefaultPersonaModel(),attributes:personaDefaultAttributes(),backstory:'',voiceName:''};
  const attrs=normalizePersonaAttributes(data.attributes||{});
  const description=String(data.backstory||'');
  document.getElementById('pe-uuid').value=data.uuid||createUUID();
  setPersonaNameFieldValue(data.name||'');
  document.getElementById('pe-model').value=ensureModelId(data.model||getDefaultPersonaModel());
  updateModelPickerSummary('persona');
  updatePersonaModelWarning();
  document.getElementById('pe-backstory').value=description;
  populateOccupationSelect(attrs.occupation||'');
  document.getElementById('pe-gender').value=attrs.gender||'';
  document.getElementById('pe-age').value=attrs.age||25;
  document.getElementById('pe-age-slider').value=attrs.age||25;
  populateSimpleSelect('pe-culture',PERSONA_CULTURES,attrs.culture||'');
  populateSimpleSelect('pe-region',PERSONA_REGIONS,attrs.region||'');
  populateSimpleSelect('pe-education',PERSONA_EDUCATION,attrs.education||'');
  populateSimpleSelect('pe-socioeconomic',PERSONA_SOCIOECONOMIC,attrs.socioeconomic||'');
  renderPersonaSliderRows(attrs);
  renderWorldBudgetGroup('political','pe-world-political','Political Orientation',attrs.political);
  renderWorldBudgetGroup('religious','pe-world-religious','Religious/Spiritual Framework',attrs.religious);
  renderWorldBudgetGroup('epistemology','pe-world-epistemology','Interpret Truth',attrs.epistemology);
  renderCheckboxGroup('pe-disabilities',PERSONA_DISABILITIES,attrs.disabilities||['None'],'None');
  renderCheckboxGroup('pe-mental-health',PERSONA_MENTAL_HEALTH,attrs.mentalHealth||['Normal'],'Normal');
  renderCheckboxGroup('pe-life-stage',PERSONA_LIFE_STAGES,attrs.lifeStage||[]);
  populatePersonaVoiceSelect(data.voiceName||'');
  applyPersonaSetupOpenState(options);
  setPersonaGenerationStatus('',{visible:false});
  updatePersonaEditorLockUi();
  updatePersonaModeUi();
  resetPersonaDirtyTracking();
  syncPersonaAssignmentButtons();
}

function setPersonaGenerationStatus(message,options={}){
  const status=document.getElementById('pe-gen-status');
  if(!status) return null;
  const visible=options.visible!==false;
  status.classList.remove('is-active','is-error');
  if(!visible){
    status.style.display='none';
    status.textContent='';
    return status;
  }
  status.style.display='block';
  status.textContent=String(message||'').trim()||'Generating...';
  if(options.error) status.classList.add('is-error');
  else if(options.active!==false) status.classList.add('is-active');
  return status;
}

function readPersonaRecordFromForm(){
  const attrs=personaDefaultAttributes();
  const description=sanitizeSubmittedText(document.getElementById('pe-backstory').value||'');
  attrs.occupation=sanitizeSubmittedText(document.getElementById('pe-occupation').value||'');
  attrs.occupationCategory=getOccupationCategory(attrs.occupation);
  attrs.gender=document.getElementById('pe-gender').value||'';
  attrs.age=normalizePersonaAge(document.getElementById('pe-age').value);
  attrs.generation=generationFromAge(attrs.age);
  attrs.culture=document.getElementById('pe-culture').value||'';
  attrs.region=document.getElementById('pe-region').value||'';
  attrs.education=document.getElementById('pe-education').value||'';
  attrs.socioeconomic=document.getElementById('pe-socioeconomic').value||'';
  Object.assign(attrs,readSliderValuesFromForm());
  attrs.political=normalizeWorldBudget('political',readWorldBudgetFromForm('political'));
  attrs.religious=normalizeWorldBudget('religious',readWorldBudgetFromForm('religious'));
  attrs.epistemology=normalizeWorldBudget('epistemology',readWorldBudgetFromForm('epistemology'));
  attrs.disabilities=normalizeExclusiveSelections(readCheckboxGroup('pe-disabilities'),PERSONA_DISABILITIES,'None');
  attrs.mentalHealth=normalizeExclusiveSelections(readCheckboxGroup('pe-mental-health'),PERSONA_MENTAL_HEALTH,'Normal');
  attrs.lifeStage=readCheckboxGroup('pe-life-stage');
  return{
    uuid:String(document.getElementById('pe-uuid').value||'').trim()||createUUID(),
    name:sanitizeSubmittedText(document.getElementById('pe-name').value||''),
    model:ensureModelId(document.getElementById('pe-model').value),
    attributes:attrs,
    backstory:description,
    voiceName:sanitizeSubmittedText(document.getElementById('pe-voice').value||'')
  };
}

function setPersonaDeleteButtonVisible(v){
  const btn=document.getElementById('btn-del-persona');
  if(btn) btn.style.visibility=v?'visible':'hidden';
}

function clearPersonaSegmentCycle(conv){
  if(!conv||typeof conv!=='object') return;
  delete conv._personaSegments;
  delete conv._personaSegmentIndex;
  delete conv._personaSegmentSource;
}

function clearParticipantPlanCache(conv){
  if(!conv||typeof conv!=='object') return;
  delete conv._participantPlan;
  delete conv._participantPlanKey;
}

function cleanPersonaSegments(parts){
  const out=(parts||[]).map(part=>String(part||'').trim()).filter(Boolean);
  return out.length?out:[];
}

function parseNumberedPersonaSegments(text){
  const src=String(text||'').replace(/\r/g,' ').trim();
  if(!src) return[];
  const matches=[...src.matchAll(/(?:^|[\n\s]+)(\d+\.\s*[\s\S]*?)(?=(?:[\n\s]+)\d+\.\s+|$)/g)];
  if(matches.length<2) return[];
  return cleanPersonaSegments(matches.map(m=>String(m[1]||'').replace(/^\d+\.\s*/,'').trim()));
}

function parseParticipantDescriptionSegments(text){
  const src=String(text||'').replace(/\r/g,'').trim();
  if(!src) return[];

  const numbered=parseNumberedPersonaSegments(src);
  if(numbered.length>1) return numbered;

  const semicolonParts=cleanPersonaSegments(src.split(/\s*;\s*/));
  if(semicolonParts.length>1) return semicolonParts;

  const logicalNormalized=src
    .replace(/\s*,\s*(?=(?:another\b|a\s+third\b|third\b|a\s+fourth\b|fourth\b|a\s+fifth\b|fifth\b|finally\b))/gi,'; ')
    .replace(/\s+\band\s+(?=(?:another\b|a\s+third\b|third\b|a\s+fourth\b|fourth\b|a\s+fifth\b|fifth\b|finally\b))/gi,'; ');
  const logicalParts=cleanPersonaSegments(logicalNormalized.split(/\s*;\s*/));
  if(logicalParts.length>1) return logicalParts;

  if(src.includes(',')&&/\band\b/i.test(src)){
    const commaAndParts=cleanPersonaSegments(src.split(/\s*,\s*/).map((part,idx,arr)=>{
      let next=String(part||'').trim();
      if(idx===arr.length-1) next=next.replace(/^and\s+/i,'').trim();
      return next;
    }));
    if(commaAndParts.length>1) return commaAndParts;
  }

  const commaParts=cleanPersonaSegments(src.split(/\s*,\s*/));
  if(commaParts.length>1) return commaParts;

  return[src];
}

function getPersonaSegmentsForConversation(conv){
  const description=String(conv?.participantDescription||'').trim();
  if(!conv||!description){
    clearPersonaSegmentCycle(conv);
    return[];
  }
  if(!Array.isArray(conv._personaSegments)||conv._personaSegmentSource!==description){
    conv._personaSegments=parseParticipantDescriptionSegments(description);
    conv._personaSegmentIndex=0;
    conv._personaSegmentSource=description;
  }
  return Array.isArray(conv._personaSegments)?conv._personaSegments:[];
}

function normalizeParticipantPlanGender(value){
  const t=String(value||'').trim().toLowerCase();
  if(!t) return'';
  if(['male','man','m'].includes(t)) return'Male';
  if(['female','woman','f'].includes(t)) return'Female';
  if(['non-binary','nonbinary','nb','enby'].includes(t)) return'Non-binary';
  return'';
}

function normalizeParticipantPlanRegion(value){
  const t=String(value||'').trim().toLowerCase();
  if(!t) return'';
  if(t.startsWith('urban')) return'Urban';
  if(t.startsWith('suburban')) return'Suburban';
  if(t.startsWith('rural')) return'Rural';
  return'';
}

function normalizeParticipantPlanSlot(raw,idx,fallbackBrief=''){
  const slot=(raw&&typeof raw==='object')?raw:{};
  const fallback=String(fallbackBrief||'').trim();
  const roleBrief=String(slot.roleBrief||slot.brief||slot.role||slot.description||fallback).trim();
  return{
    slotNumber:idx+1,
    name:cleanGeneratedName(slot.name||'',''),
    occupation:String(slot.occupation||slot.job||'').trim(),
    gender:normalizeParticipantPlanGender(slot.gender),
    age:normalizePersonaAge(slot.age)||0,
    culture:String(slot.culture||slot.culturalBackground||'').trim(),
    region:normalizeParticipantPlanRegion(slot.region),
    education:String(slot.education||'').trim(),
    socioeconomic:String(slot.socioeconomic||slot.socioeconomicBackground||'').trim(),
    roleBrief,
    temperament:String(slot.temperament||slot.communicationStyle||'').trim(),
    constraintNotes:String(slot.constraintNotes||slot.notes||'').trim()
  };
}

function buildFallbackParticipantPlanSlots(participantDescription){
  const description=String(participantDescription||'').trim();
  if(!description) return[];
  const seeds=parseParticipantDescriptionSegments(description);
  const source=seeds.length?seeds:[description];
  return Array.from({length:9},(_,idx)=>{
    const brief=source[idx%source.length]||description;
    return normalizeParticipantPlanSlot({roleBrief:brief},idx,brief);
  });
}

function buildParticipantPlanKey(topicObjective,participantDescription){
  return JSON.stringify([
    String(topicObjective||'').trim(),
    String(participantDescription||'').trim()
  ]);
}

function normalizeParticipantPlan(rawPlan,topicObjective,participantDescription){
  const description=String(participantDescription||'').trim();
  const fallbackSlots=buildFallbackParticipantPlanSlots(description);
  const rawSlots=Array.isArray(rawPlan?.slots)?rawPlan.slots:[];
  const slots=Array.from({length:9},(_,idx)=>{
    const fallback=fallbackSlots[idx]||normalizeParticipantPlanSlot({},idx,description||`Participant ${idx+1}`);
    const merged=normalizeParticipantPlanSlot(rawSlots[idx]||fallback,idx,fallback.roleBrief||description);
    if(!merged.roleBrief) merged.roleBrief=fallback.roleBrief||description||`Participant ${idx+1}`;
    if(!merged.occupation&&fallback.occupation) merged.occupation=fallback.occupation;
    if(!merged.gender&&fallback.gender) merged.gender=fallback.gender;
    if(!merged.age&&fallback.age) merged.age=fallback.age;
    if(!merged.culture&&fallback.culture) merged.culture=fallback.culture;
    if(!merged.region&&fallback.region) merged.region=fallback.region;
    if(!merged.education&&fallback.education) merged.education=fallback.education;
    if(!merged.socioeconomic&&fallback.socioeconomic) merged.socioeconomic=fallback.socioeconomic;
    if(!merged.temperament&&fallback.temperament) merged.temperament=fallback.temperament;
    if(!merged.constraintNotes&&fallback.constraintNotes) merged.constraintNotes=fallback.constraintNotes;
    return merged;
  });
  return{
    key:buildParticipantPlanKey(topicObjective,description),
    topicObjective:String(topicObjective||'').trim(),
    participantDescription:description,
    slots
  };
}

function buildParticipantPlannerPrompt(topicObjective,participantDescription){
  const topic=String(topicObjective||'').trim()||'No specific topic/goal provided.';
  const description=String(participantDescription||'').trim();
  const lines=[
    'Plan nine distinct participants for a multi-provider discussion tool.',
    '',
    `Conversation topic/goal: "${topic}"`,
    `Requested participant description: "${description}"`,
    '',
    'Return one JSON object only. No markdown.',
    'Use exactly this shape:',
    '{',
    '  "slots": [',
    '    {',
    '      "name": "optional string",',
    '      "occupation": "string",',
    '      "gender": "Male | Female | Non-binary",',
    '      "age": 25,',
    '      "culture": "optional string",',
    '      "region": "Urban | Suburban | Rural",',
    '      "education": "optional string",',
    '      "socioeconomic": "optional string",',
    '      "roleBrief": "1-2 sentence role seed for this individual",',
    '      "temperament": "optional short phrase",',
    '      "constraintNotes": "optional short phrase"',
    '    }',
    '  ]',
    '}',
    '',
    'Rules:',
    '- Produce exactly 9 slots.',
    '- Make all 9 individuals clearly distinct from one another.',
    '- Keep them aligned with the requested participant type and conversation goal.',
    '- When the request is underspecified, default to competent, articulate, reasonably educated adults.',
    '- Default age range is roughly 25-65 unless the request clearly implies otherwise.',
    '- Prefer a mixed male/female distribution unless the request implies a different distribution.',
    '- Avoid cartoonish extremes, parody, or low-functioning defaults unless explicitly requested.',
    '- Do not drift into generic white-collar personas if the requested group is something else such as fishermen, mechanics, laborers, traders, or preschool teachers.',
    '- If the request specifies a shared group identity, preserve that shared identity while varying background, temperament, experience, and point of view.',
    '- Keep roleBrief concrete and useful for downstream persona generation.'
  ];
  return lines.join('\n');
}

async function generateParticipantPlan(topicObjective,participantDescription){
  const text=await requestHelperCompletion(buildParticipantPlannerPrompt(topicObjective,participantDescription));
  const jsonText=extractJsonObject(text);
  let parsed=null;
  try{parsed=jsonText?JSON.parse(jsonText):null;}catch(e){}
  return normalizeParticipantPlan(parsed||{},topicObjective,participantDescription);
}

async function ensureParticipantPlan(conv,onStatus){
  const topicObjective=String(conv?.topicObjective||'').trim();
  const description=String(conv?.participantDescription||'').trim();
  if(!conv||(!topicObjective&&!description)){
    clearParticipantPlanCache(conv);
    return null;
  }
  const key=buildParticipantPlanKey(topicObjective,description);
  const cached=conv._participantPlan;
  if(cached&&conv._participantPlanKey===key&&Array.isArray(cached.slots)&&cached.slots.length===9){
    return cached;
  }
  if(typeof onStatus==='function') onStatus('Planning participants...');
  let plan=null;
  try{
    plan=await generateParticipantPlan(topicObjective,description);
  }catch(e){
    clearParticipantPlanCache(conv);
    return null;
  }
  conv._participantPlan=plan;
  conv._participantPlanKey=key;
  return plan;
}

function getParticipantPlanSlotIndexForAgent(conv,agentId){
  if(!conv||!Array.isArray(conv.agents)||!agentId) return 0;
  const agent=conv.agents.find(a=>a.id===agentId);
  if(!agent) return 0;
  return Math.max(0,Math.min(8,getAgentSlotIndex(agent,conv)));
}

function getParticipantPlanSlotForAgentSync(conv,agent){
  if(agent?.isGhost) return null;
  const plan=conv?._participantPlan;
  if(!plan||!Array.isArray(plan.slots)||!plan.slots.length||!agent) return null;
  return plan.slots[Math.max(0,Math.min(8,getAgentSlotIndex(agent,conv)))]||null;
}

async function getParticipantPlanSlotForAgent(conv,agentId,onStatus){
  const plan=await ensureParticipantPlan(conv,onStatus);
  if(!plan||!Array.isArray(plan.slots)||!plan.slots.length) return null;
  return plan.slots[getParticipantPlanSlotIndexForAgent(conv,agentId)]||null;
}

async function personaNew(){
  if(!S.workspaceReady){await appAlert('Choose a Conflab workspace first.');return;}
  S.personaSliderUnlocked=false;
  S.personaSetupNewOpen=false;
  updatePersonaSliderLockButton();
  document.getElementById('pe-id').value='';
  document.getElementById('pe-path').value='';
  applyPersonaRecordToForm({uuid:createUUID(),name:'',model:getDefaultPersonaModel(),attributes:personaDefaultAttributes(),backstory:'',voiceName:''});
  setPersonaEditorLocked(false,{skipSync:true});
  S.activePersona=null;
  setPersonaDeleteButtonVisible(false);
  openPersonaEditView();
  const topicObjective=String(S.conv?.topicObjective||'').trim();
  const participantDescription=String(S.conv?.participantDescription||'').trim();
  if(S.agentPersonaPickerFor&&(topicObjective||participantDescription)){
    setPersonaGenerationStatus('Planning participant...');
    try{
      const plannedSlot=await getParticipantPlanSlotForAgent(S.conv,S.agentPersonaPickerFor,nextStatus=>{
        setPersonaGenerationStatus(nextStatus);
      });
      setPersonaGenerationStatus(plannedSlot?`Generating persona from planned participant ${plannedSlot.slotNumber}...`:'Generating persona...');
      const generated=await generatePersonaFromParticipantDescription(topicObjective,participantDescription,plannedSlot);
      const setupWasOpen=!!document.getElementById('pe-setup-details')?.open;
      generated.model=ensureModelId(document.getElementById('pe-model')?.value||generated.model||getDefaultPersonaModel());
      generated.voiceName=String(document.getElementById('pe-voice')?.value||'');
      applyPersonaRecordToForm(generated,{forceOpen:setupWasOpen});
      setPersonaEditorLocked(false,{skipSync:true});
      document.getElementById('pe-id').value='';
      document.getElementById('pe-path').value='';
      markPersonaDescriptionGenerated();
      setPersonaGenerationStatus('Generated',{active:false});
      setTimeout(()=>{setPersonaGenerationStatus('',{visible:false});},1200);
    }catch(e){
      setPersonaGenerationStatus('Error: '+e.message,{active:false,error:true});
    }
  }else{
    document.getElementById('pe-name').focus();
  }
}

async function handleDamagedPersonaEntry(node){
  if(!node?.damaged) return false;
  const remove=await appConfirm('This persona appears damaged. Delete it?',{title:'DAMAGED PERSONA',okLabel:'Delete'});
  if(remove&&node.parentHandle){
    try{await node.parentHandle.removeEntry(node.name,{recursive:false});}catch(e){await appAlert('Could not delete damaged persona file.');}
    treeSelectPath(PERSONA_TREE_VIEW,node.parentPath||'');
    await scanPersonaFolders();
    return true;
  }
  treeSelectPath(PERSONA_TREE_VIEW,node.path||'');
  renderPersonaList();
  return true;
}

async function openPersonaEditor(node){
  if(!node||node.type!=='persona') return;
  if(await handleDamagedPersonaEntry(node)) return;
  const rec=await readPersonaRecordFromNode(node);
  if(!rec){
    await handleDamagedPersonaEntry({...node,damaged:true});
    return;
  }
  document.getElementById('pe-id').value=node.path;
  document.getElementById('pe-path').value=node.path;
  applyPersonaRecordToForm(rec,S.agentPersonaPickerFor?{forceOpen:true}:{});
  setPersonaEditorLocked(true,{skipSync:true});
  S.activePersona={path:node.path};
  setPersonaDeleteButtonVisible(true);
  treeSelectPath(PERSONA_TREE_VIEW,node.path);
  openPersonaEditView();
}

async function personaDelete(){
  const path=document.getElementById('pe-path').value||'';
  if(!path) return;
  const node=S.personaTreeIndex?.[path];
  if(!node||node.type!=='persona'||!node.parentHandle) return;
  if(!await appConfirm('Delete this persona?',{title:'DELETE PERSONA',okLabel:'Delete'})) return;
  try{await node.parentHandle.removeEntry(node.name,{recursive:false});}
  catch(e){await appAlert('Could not delete persona.');return;}
  treeSelectPath(PERSONA_TREE_VIEW,node.parentPath||'');
  await scanPersonaFolders();
  personaListBack();
}
function personaWorldBudgetSummary(attrs,key){
  const opts=PERSONA_WORLDVIEW[key]||[];
  const data=normalizeWorldBudget(key,attrs[key]||{});
  return opts.map(o=>`${o.label}: ${data[o.id]||0}`).join(', ');
}

function buildGenerateNamePrompt(attrs,options={}){
  const age=normalizePersonaAge(attrs.age);
  const birthYear=age?((new Date()).getFullYear()-age):'';
  const lines=['Generate a persona for a multi-provider discussion tool.','','Attributes:'];
  lines.push('- Name: generate an appropriate name');
  if(attrs.occupation) lines.push(`- Occupation: ${attrs.occupation}`);
  if(attrs.gender) lines.push(`- Gender: ${attrs.gender}`);
  if(age) lines.push(`- Age: ${age}`);
  if(birthYear) lines.push(`- Approximate Birth Year: ${birthYear}`);
  if(attrs.culture) lines.push(`- Cultural Background: ${attrs.culture}`);
  lines.push('','Use age and birth-year context to pick a first name that fits that era/cohort.','Avoid names strongly associated with much younger or much older cohorts than this age.');
  if(options.avoidFirstNames?.length) lines.push('Avoid reusing any of these first names across the full persona library: '+options.avoidFirstNames.join(', '));
  if(options.avoidLastNames?.length) lines.push('Avoid reusing any of these surnames across the full persona library: '+options.avoidLastNames.join(', '));
  if(options.avoidFullNames?.length) lines.push('Do not return any of these exact full names: '+options.avoidFullNames.join(', '));
  lines.push('Compare against the entire persona library, not just the current conversation.');
  lines.push('If you include an honorific such as Dr., still choose a fresh first name and surname underneath it.');
  if(options.attempt>1) lines.push('Previous attempts collided with existing persona names. Choose a distinctly different first name and surname this time.');
  lines.push('Return exactly one line:','NAME: <First Last>');
  return lines.join('\n');
}

function buildGenerateNamePoolPrompt(attrs,options={}){
  const count=Math.max(10,parseInt(options.count,10)||50);
  const age=normalizePersonaAge(attrs.age);
  const birthYear=age?((new Date()).getFullYear()-age):'';
  const strictEraMatch=options.attempt<=1;
  const lines=[
    'Generate candidate persona names for a multi-provider discussion tool.',
    '',
    `Return ${count} unique first names and ${count} unique surnames.`,
    '',
    'Attributes:'
  ];
  if(attrs.gender) lines.push(`- Gender: ${attrs.gender}`);
  if(strictEraMatch&&age) lines.push(`- Age: ${age}`);
  if(strictEraMatch&&birthYear) lines.push(`- Approximate Birth Year: ${birthYear}`);
  if(attrs.culture) lines.push(`- Cultural Background: ${attrs.culture}`);
  if(attrs.region) lines.push(`- Region: ${attrs.region}`);
  lines.push(
    '',
    strictEraMatch
      ? 'First names should fit the age/generation context.'
      : 'Prioritize fresh names over strict age/generation matching on this retry.',
    'Surnames should fit any provided cultural background when possible.',
    'Do not include honorifics or titles such as Dr., Mr., Ms., or Prof.',
    'Do not return full names in either list.',
    'Compare against the entire persona library, not just the current conversation.'
  );
  if(options.avoidFirstNames?.length) lines.push('Avoid these existing first names: '+options.avoidFirstNames.join(', '));
  if(options.avoidLastNames?.length) lines.push('Avoid these existing surnames: '+options.avoidLastNames.join(', '));
  if(options.attempt>1) lines.push('Earlier candidate pools overlapped too much with the existing persona library. Return a fresher set this time, even if that means loosening age-era fidelity.');
  lines.push(
    '',
    'Return one JSON object only. No markdown.',
    'Use this shape:',
    '{',
    '  "firstNames": ["Name 1", "Name 2"],',
    '  "surnames": ["Surname 1", "Surname 2"]',
    '}'
  );
  return lines.join('\n');
}

function buildGenerateDescriptionPrompt(attrs,name){
  const data=normalizePersonaAttributes(attrs||{});
  const sliderLines=PERSONA_SLIDERS.map(sl=>`${sl.label}: ${personaCodecSliderValue(data[sl.id])}`).join(', ');
  const lines=[
    'Generate the body of a persona description for a multi-provider discussion tool.',
    '',
    'The persona is:',
    `Name: ${String(name||'').trim()||'(unset)'}`,
    `Occupation: ${data.occupation||'(unset)'}`,
    `Gender: ${data.gender||'(unset)'}`,
    `Age: ${data.age||'(unset)'}`,
    '',
    'Structured attributes:',
    '- Background:',
    `  - Cultural background: ${data.culture||'(unset)'}`,
    `  - Region: ${data.region||'(unset)'}`,
    `  - Education: ${data.education||'(unset)'}`,
    `  - Socioeconomic: ${data.socioeconomic||'(unset)'}`,
    '- Worldview budgets (100 points each, written as "label N"):',
    `  - Political: ${personaBudgetPromptSummary('political',data.political)}`,
    `  - Religious: ${personaBudgetPromptSummary('religious',data.religious)}`,
    `  - Epistemology: ${personaBudgetPromptSummary('epistemology',data.epistemology)}`,
    '- Life experiences:',
    `  - Disabilities: ${(data.disabilities||[]).join(', ')||'None'}`,
    `  - Mental health: ${(data.mentalHealth||[]).join(', ')||'Normal'}`,
    `  - Life stage: ${(data.lifeStage||[]).join(', ')||'(none)'}`,
    '- Personality sliders (-5..+5):',
    `  - ${sliderLines}`,
    '',
    'Return one JSON object only. No markdown.',
    'Use this shape:',
    '{',
    '  "background": "",',
    '  "worldview": "",',
    '  "lifeExperiences": "",',
    '  "personality": ""',
    '}',
    '',
    'Rules:',
    '1. Do not write the identity line. The client will add it.',
    '1a. Do not start any section with "You are ...", and do not include any personal name, honorific, title, or alternate identity inside section bodies.',
    '2. Return an empty string for any section whose cluster is at default.',
    '3. If non-empty, each section body must be 1-3 natural sentences with no heading.',
    '4. Write naturally. Do not list fields, do not print numbers, and do not contradict the structured attributes.',
    '5. Background is default only when culture, region, education, and socioeconomic are all unset.',
    '6. Worldview is default only when all three worldview budgets stay at their even-split defaults.',
    '7. Life Experiences is default only when disabilities is ["None"], mentalHealth is ["Normal"], and lifeStage is empty.',
    '8. Personality is default only when all sliders are 0.',
    '9. Focus each non-empty section on the fields from that cluster only.'
  ];
  return lines.join('\n');
}

function buildGeneratePersonaPrompt(attrs){
  const data=normalizePersonaAttributes(attrs||{});
  const sliderLines=PERSONA_SLIDERS.map(sl=>`${sl.label}: ${personaCodecSliderValue(data[sl.id])}`).join(', ');
  const lines=[
    'Generate a persona name and section bodies for a multi-provider discussion tool.',
    '',
    'The persona attributes are:',
    `Occupation: ${data.occupation||'(unset)'}`,
    `Gender: ${data.gender||'(unset)'}`,
    `Age: ${data.age||'(unset)'}`,
    '',
    'Structured attributes:',
    '- Background:',
    `  - Cultural background: ${data.culture||'(unset)'}`,
    `  - Region: ${data.region||'(unset)'}`,
    `  - Education: ${data.education||'(unset)'}`,
    `  - Socioeconomic: ${data.socioeconomic||'(unset)'}`,
    '- Worldview budgets (100 points each, written as "label N"):',
    `  - Political: ${personaBudgetPromptSummary('political',data.political)}`,
    `  - Religious: ${personaBudgetPromptSummary('religious',data.religious)}`,
    `  - Epistemology: ${personaBudgetPromptSummary('epistemology',data.epistemology)}`,
    '- Life experiences:',
    `  - Disabilities: ${(data.disabilities||[]).join(', ')||'None'}`,
    `  - Mental health: ${(data.mentalHealth||[]).join(', ')||'Normal'}`,
    `  - Life stage: ${(data.lifeStage||[]).join(', ')||'(none)'}`,
    '- Personality sliders (-5..+5):',
    `  - ${sliderLines}`,
    '',
    'Return one JSON object only. No markdown.',
    'Use this shape:',
    '{',
    '  "name": "First Last",',
    '  "background": "",',
    '  "worldview": "",',
    '  "lifeExperiences": "",',
    '  "personality": ""',
    '}',
    '',
    'Rules:',
    '1. Return exactly one candidate full name in "name". Do not include honorifics or titles such as Dr., Mr., Ms., or Prof.',
    '2. The client will validate and may replace the name for uniqueness. Do not repeat the name inside any section body.',
    '3. Do not write the identity line. The client will add it from the final accepted name.',
    '4. Do not start any section with "You are ...". Do not name, rename, introduce, or refer to the persona by any personal name, honorific, title, or alternate identity inside background, worldview, lifeExperiences, or personality. Use neutral references such as "The persona" or pronouns only.',
    '5. Return an empty string for any section whose cluster is at default.',
    '6. If non-empty, each section body must be 1-3 natural sentences with no heading.',
    '7. Write naturally. Do not list fields, do not print numbers, and do not contradict the structured attributes.',
    '8. Background is default only when culture, region, education, and socioeconomic are all unset.',
    '9. Worldview is default only when all three worldview budgets stay at their even-split defaults.',
    '10. Life Experiences is default only when disabilities is ["None"], mentalHealth is ["Normal"], and lifeStage is empty.',
    '11. Personality is default only when all sliders are 0.',
    '12. Focus each non-empty section on the fields from that cluster only.'
  ];
  return lines.join('\n');
}

function extractJsonObject(text){
  const src=String(text||'').trim();
  const fenced=src.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body=(fenced?.[1]||src).trim();
  const start=body.indexOf('{');
  if(start<0) return'';
  let depth=0;
  let inString=false;
  let escape=false;
  for(let i=start;i<body.length;i++){
    const ch=body[i];
    if(inString){
      if(escape){escape=false;continue;}
      if(ch==='\\'){escape=true;continue;}
      if(ch==='"') inString=false;
      continue;
    }
    if(ch==='"'){inString=true;continue;}
    if(ch==='{') depth++;
    if(ch==='}'){
      depth--;
      if(depth===0) return body.slice(start,i+1);
    }
  }
  return'';
}

function buildRederivePrompt(description){
  const lines=[
    'Read a sectioned persona description for a multi-provider discussion tool and re-derive the structured persona fields from it.',
    '',
    'Return one JSON object only. No markdown.',
    'Use this shape:',
    '{',
    '  "background": {',
    '    "culture": "string or empty",',
    '    "region": "Urban | Suburban | Rural or empty",',
    '    "education": "string or empty",',
    '    "socioeconomic": "string or empty"',
    '  },',
    '  "worldview": {',
    '    "political": { "progressive": 17, "liberal": 17, "moderate": 17, "conservative": 17, "libertarian": 16, "apolitical": 16 },',
    '    "religious": { "secular_none": 13, "christian": 13, "jewish": 13, "muslim": 13, "hindu": 12, "buddhist": 12, "spiritual_not_religious": 12, "other": 12 },',
    '    "epistemology": { "scientific_evidence": 15, "personal_experience": 15, "authority_tradition": 14, "faith_revelation": 14, "pragmatism": 14, "traditional_media": 14, "internet": 14 }',
    '  },',
    '  "lifeExperiences": {',
    '    "disabilities": ["array of canonical values or \\"None\\""],',
    '    "mentalHealth": ["array of canonical values or \\"Normal\\""],',
    '    "lifeStage": ["array of canonical values"]',
    '  },',
    '  "sliders": {',
    `    ${PERSONA_SLIDERS.map(sl=>`"${sl.id}": -5`).join(', ')}`,
    '  }',
    '}',
    '',
    'Rules:',
    `1. Background values must be chosen only from these canonical lists: culture ${personaPromptChoices(PERSONA_CULTURES)}; region ${personaPromptChoices(PERSONA_REGIONS)}; education ${personaPromptChoices(PERSONA_EDUCATION)}; socioeconomic ${personaPromptChoices(PERSONA_SOCIOECONOMIC)}.`,
    `2. Life-experience values must be chosen only from these canonical lists: disabilities ${personaPromptChoices(PERSONA_DISABILITIES)}; mentalHealth ${personaPromptChoices(PERSONA_MENTAL_HEALTH)}; lifeStage ${personaPromptChoices(PERSONA_LIFE_STAGES)}.`,
    '3. If a section is absent, return the default values for that cluster.',
    `4. The default worldview budgets are: political ${personaBudgetPromptSummary('political',personaEvenWorldBudget('political'))}; religious ${personaBudgetPromptSummary('religious',personaEvenWorldBudget('religious'))}; epistemology ${personaBudgetPromptSummary('epistemology',personaEvenWorldBudget('epistemology'))}.`,
    '5. For worldview budgets, return integer values totaling 100 in each budget.',
    '6. For a clear dominant worldview category, allocate roughly 70 points there and distribute the remainder across one or two related categories.',
    '7. For sliders, return integers in -5..+5. Use 0 when the text does not imply that trait.',
    '8. Identity fields (name, occupation, gender, age) are parsed by the client from the identity line. Do not return them.',
    '',
    'Description to parse:',
    '',
    String(description||'').trim()
  ];
  return lines.join('\n');
}

function flattenPersonaRederivePayload(payload,currentAttrs){
  const current=normalizePersonaAttributes(currentAttrs||{});
  const background=(payload?.background&&typeof payload.background==='object')?payload.background:{};
  const worldview=(payload?.worldview&&typeof payload.worldview==='object')?payload.worldview:{};
  const lifeExperiences=(payload?.lifeExperiences&&typeof payload.lifeExperiences==='object')?payload.lifeExperiences:{};
  const sliders=(payload?.sliders&&typeof payload.sliders==='object')?payload.sliders:{};
  const out={...current};
  out.culture=canonicalPersonaValue(PERSONA_CULTURES,background.culture,'');
  out.region=canonicalPersonaValue(PERSONA_REGIONS,background.region,'');
  out.education=canonicalPersonaValue(PERSONA_EDUCATION,background.education,'');
  out.socioeconomic=canonicalPersonaValue(PERSONA_SOCIOECONOMIC,background.socioeconomic,'');
  out.political=normalizeWorldBudget('political',worldview.political||personaEvenWorldBudget('political'));
  out.religious=normalizeWorldBudget('religious',worldview.religious||personaEvenWorldBudget('religious'));
  out.epistemology=normalizeWorldBudget('epistemology',worldview.epistemology||personaEvenWorldBudget('epistemology'));
  out.disabilities=normalizeExclusiveSelections(
    (Array.isArray(lifeExperiences.disabilities)?lifeExperiences.disabilities:[]).map(v=>canonicalPersonaValue(PERSONA_DISABILITIES,v,'')).filter(Boolean),
    PERSONA_DISABILITIES,
    'None'
  );
  out.mentalHealth=normalizeExclusiveSelections(
    (Array.isArray(lifeExperiences.mentalHealth)?lifeExperiences.mentalHealth:[]).map(v=>canonicalPersonaValue(PERSONA_MENTAL_HEALTH,v,'')).filter(Boolean),
    PERSONA_MENTAL_HEALTH,
    'Normal'
  );
  out.lifeStage=[...new Set((Array.isArray(lifeExperiences.lifeStage)?lifeExperiences.lifeStage:[]).map(v=>canonicalPersonaValue(PERSONA_LIFE_STAGES,v,'')).filter(Boolean))];
  PERSONA_SLIDERS.forEach(sl=>{
    out[sl.id]=personaCodecSliderValue(sliders[sl.id]);
  });
  return normalizePersonaAttributes(out);
}

function buildAutoPersonaPrompt(topicObjective,participantDescription,plannedSlot=null){
  const topic=String(topicObjective||'').trim()||'No specific topic/goal provided.';
  const role=String(participantDescription||'').trim();
  const lines=[
    'Generate a complete persona for a multi-provider discussion tool.',
    '',
    `The user is setting up a conversation with this topic/goal: "${topic}"`,
    `Overall participant request: "${role}"`,
    '',
    'Return one JSON object only. No markdown.',
    'Use this shape:',
    '{',
    '  "name": "string",',
    '  "occupation": "one of the canonical occupation strings",',
    '  "gender": "Male | Female | Non-binary",',
    '  "age": 25,',
    '  "background": {',
    '    "culture": "optional string from PERSONA_CULTURES or empty",',
    '    "region": "Urban | Suburban | Rural or empty",',
    '    "education": "one of PERSONA_EDUCATION values or empty",',
    '    "socioeconomic": "one of PERSONA_SOCIOECONOMIC values or empty"',
    '  },',
    '  "worldview": {',
    '    "political": { "progressive": 17, "liberal": 17, "moderate": 17, "conservative": 17, "libertarian": 16, "apolitical": 16 },',
    '    "religious": { "secular_none": 13, "christian": 13, "jewish": 13, "muslim": 13, "hindu": 12, "buddhist": 12, "spiritual_not_religious": 12, "other": 12 },',
    '    "epistemology": { "scientific_evidence": 15, "personal_experience": 15, "authority_tradition": 14, "faith_revelation": 14, "pragmatism": 14, "traditional_media": 14, "internet": 14 }',
    '  },',
    '  "lifeExperiences": {',
    '    "disabilities": ["array of PERSONA_DISABILITIES values, or [\\"None\\"]"],',
    '    "mentalHealth": ["array of PERSONA_MENTAL_HEALTH values, or [\\"Normal\\"]"],',
    '    "lifeStage": ["array of PERSONA_LIFE_STAGES values"]',
    '  },',
    '  "sliders": {',
    `    ${PERSONA_SLIDERS.map(sl=>`"${sl.id}": -5`).join(', ')}`,
    '  },',
    '  "sections": {',
    '    "background": "",',
    '    "worldview": "",',
    '    "lifeExperiences": "",',
    '    "personality": ""',
    '  }',
    '}',
    '',
    'Rules for the structured fields:',
    '1. Set each field to the value most consistent with the participant description and the planned slot.',
    '2. It is normal for several sliders, several worldview budgets, and several life-experience entries to be non-default when the participant description implies them.',
    '3. Use 0 for a slider only when nothing in the participant description points to either direction for that trait.',
    '4. Use the even-split default for a worldview budget only when nothing in the participant description points to a specific orientation.',
    '5. Use ["None"] / ["Normal"] / [] for life-experience arrays only when nothing in the participant description points to specific entries.',
    '6. The structured fields and the description must be consistent with each other.',
    '',
    'Canonical lists:',
    `- Occupations: ${personaPromptChoices(getAllPersonaOccupations())}`,
    `- Cultures: ${personaPromptChoices(PERSONA_CULTURES)}`,
    `- Regions: ${personaPromptChoices(PERSONA_REGIONS)}`,
    `- Education: ${personaPromptChoices(PERSONA_EDUCATION)}`,
    `- Socioeconomic: ${personaPromptChoices(PERSONA_SOCIOECONOMIC)}`,
    `- Disabilities: ${personaPromptChoices(PERSONA_DISABILITIES)}`,
    `- Mental health: ${personaPromptChoices(PERSONA_MENTAL_HEALTH)}`,
    `- Life stage: ${personaPromptChoices(PERSONA_LIFE_STAGES)}`,
    '',
    'Rules for sections:',
    '1. The client will build the identity line from the final accepted name. Do not write "You are ..." in any section.',
    '2. Do not include any personal name, honorific, title, or alternate identity in section bodies. Use neutral references such as "The persona" or pronouns only.',
    '3. Return an empty string for a section whose corresponding cluster is default.',
    '4. If non-empty, each section body must be 1-3 natural sentences with no heading.',
    '5. Write naturally. Do not list fields, do not print numbers, and do not include default sections.'
  ];
  if(plannedSlot){
    lines.splice(4,0,
      `This participant is planned slot ${plannedSlot.slotNumber} of 9 for the conversation.`,
      plannedSlot.roleBrief?`Planned slot role brief: "${plannedSlot.roleBrief}"`:'Planned slot role brief: infer from the overall participant request',
      plannedSlot.name?`Preferred name seed (use only if it still fits the one-shot persona): "${plannedSlot.name}"`:'Preferred name seed: generate an appropriate name',
      plannedSlot.occupation?`Occupation/background anchor: "${plannedSlot.occupation}"`:'Occupation/background anchor: infer from the participant description',
      plannedSlot.gender?`Gender anchor: ${plannedSlot.gender}`:'Gender anchor: infer from the participant description',
      plannedSlot.age?`Age anchor: ${plannedSlot.age}`:'Age anchor: infer from the participant description',
      plannedSlot.culture?`Cultural background anchor: "${plannedSlot.culture}"`:'',
      plannedSlot.region?`Region anchor: ${plannedSlot.region}`:'',
      plannedSlot.education?`Education anchor: "${plannedSlot.education}"`:'',
      plannedSlot.socioeconomic?`Socioeconomic anchor: "${plannedSlot.socioeconomic}"`:'',
      plannedSlot.temperament?`Temperament anchor: "${plannedSlot.temperament}"`:'',
      plannedSlot.constraintNotes?`Constraint notes: "${plannedSlot.constraintNotes}"`:''
    );
    for(let i=lines.length-1;i>=0;i--){
      if(!lines[i]) lines.splice(i,1);
    }
    lines.push('Use the planned slot anchors as the primary identity scaffold, but return one coherent name that matches the section bodies.');
  }else{
    lines.splice(4,0,`They want this participant: "${role}"`);
  }
  return lines.join('\n');
}

function personaRecordFromAutoSeed(seed){
  const base=personaDefaultAttributes();
  const raw=(seed&&typeof seed==='object')?seed:{};
  const background=(raw.background&&typeof raw.background==='object')?raw.background:{};
  const worldview=(raw.worldview&&typeof raw.worldview==='object')?raw.worldview:{};
  const lifeExperiences=(raw.lifeExperiences&&typeof raw.lifeExperiences==='object')?raw.lifeExperiences:{};
  const sections=(raw.sections&&typeof raw.sections==='object')?raw.sections:{};
  base.occupation=canonicalPersonaValue(getAllPersonaOccupations(),raw.occupation,String(raw.occupation||'').trim());
  base.occupationCategory=getOccupationCategory(base.occupation);
  base.gender=canonicalPersonaValue(PERSONA_IDENTITY_GENDERS,raw.gender,'');
  base.age=normalizePersonaAge(raw.age)||25;
  base.generation=generationFromAge(base.age);
  base.culture=canonicalPersonaValue(PERSONA_CULTURES,background.culture,'');
  base.region=canonicalPersonaValue(PERSONA_REGIONS,background.region,'');
  base.education=canonicalPersonaValue(PERSONA_EDUCATION,background.education,'');
  base.socioeconomic=canonicalPersonaValue(PERSONA_SOCIOECONOMIC,background.socioeconomic,'');
  base.political=normalizeWorldBudget('political',worldview.political||personaEvenWorldBudget('political'));
  base.religious=normalizeWorldBudget('religious',worldview.religious||personaEvenWorldBudget('religious'));
  base.epistemology=normalizeWorldBudget('epistemology',worldview.epistemology||personaEvenWorldBudget('epistemology'));
  base.disabilities=normalizeExclusiveSelections(
    (Array.isArray(lifeExperiences.disabilities)?lifeExperiences.disabilities:[]).map(v=>canonicalPersonaValue(PERSONA_DISABILITIES,v,'')).filter(Boolean),
    PERSONA_DISABILITIES,
    'None'
  );
  base.mentalHealth=normalizeExclusiveSelections(
    (Array.isArray(lifeExperiences.mentalHealth)?lifeExperiences.mentalHealth:[]).map(v=>canonicalPersonaValue(PERSONA_MENTAL_HEALTH,v,'')).filter(Boolean),
    PERSONA_MENTAL_HEALTH,
    'Normal'
  );
  base.lifeStage=[...new Set((Array.isArray(lifeExperiences.lifeStage)?lifeExperiences.lifeStage:[]).map(v=>canonicalPersonaValue(PERSONA_LIFE_STAGES,v,'')).filter(Boolean))];
  const sliders=(raw.sliders&&typeof raw.sliders==='object')?raw.sliders:{};
  PERSONA_SLIDERS.forEach(sl=>{
    if(Object.prototype.hasOwnProperty.call(sliders,sl.id)) base[sl.id]=personaCodecSliderValue(sliders[sl.id]);
  });
  const description=String(raw.description||'').trim();
  return{
    uuid:createUUID(),
    name:String(raw.name||'').trim(),
    model:getDefaultPersonaModel(),
    attributes:normalizePersonaAttributes(base),
    backstory:description,
    sectionBodies:{
      background:sections.background,
      worldview:sections.worldview,
      lifeExperiences:sections.lifeExperiences,
      personality:sections.personality
    },
    voiceName:''
  };
}

async function generatePersonaFromParticipantDescription(topicObjective,participantDescription,plannedSlot=null){
  const text=await requestHelperCompletion(buildAutoPersonaPrompt(topicObjective,participantDescription,plannedSlot));
  const jsonText=extractJsonObject(text);
  let parsed=null;
  try{parsed=jsonText?JSON.parse(jsonText):null;}catch(e){}
  const rec=personaRecordFromAutoSeed(parsed||{});
  if(plannedSlot){
    const attrs={...(rec.attributes||personaDefaultAttributes())};
    if(!attrs.occupation&&plannedSlot.occupation) attrs.occupation=plannedSlot.occupation;
    if(!attrs.gender&&plannedSlot.gender) attrs.gender=plannedSlot.gender;
    if(!normalizePersonaAge(attrs.age)&&plannedSlot.age) attrs.age=normalizePersonaAge(plannedSlot.age)||attrs.age;
    if(!attrs.culture&&plannedSlot.culture) attrs.culture=plannedSlot.culture;
    if(!attrs.region&&plannedSlot.region) attrs.region=plannedSlot.region;
    if(!attrs.education&&plannedSlot.education) attrs.education=plannedSlot.education;
    if(!attrs.socioeconomic&&plannedSlot.socioeconomic) attrs.socioeconomic=plannedSlot.socioeconomic;
    rec.attributes=normalizePersonaAttributes(attrs);
  }
  {
    const attrs=rec.attributes||personaDefaultAttributes();
    // The one-shot response owns the name when present; planned-slot names are seeds/fallbacks so stale plan names cannot diverge from generated section bodies.
    const plannedSeedName=plannedSlot?.name?cleanGeneratedName(plannedSlot.name,''):'';
    const candidateName=cleanGeneratedName(rec.name,'')||plannedSeedName;
    rec.name=await ensureGeneratedPersonaNameUnique(candidateName,attrs);
  }
  const identityLine=renderIdentityLine(rec.name,rec.attributes);
  const scrubNames=[rec.name,plannedSlot?.name,parsed?.name].filter(Boolean);
  if(rec.sectionBodies&&Object.values(rec.sectionBodies).some(value=>String(value||'').trim())){
    rec.backstory=assembleSectionedDescription(identityLine,rec.sectionBodies,scrubNames);
  }else if(rec.backstory){
    rec.backstory=replacePersonaDescriptionIdentityLine(rec.backstory,rec.name,rec.attributes);
  }else{
    rec.backstory=await generatePersonaDescriptionFromAttributes(rec.attributes,rec.name);
  }
  delete rec.sectionBodies;
  return rec;
}

async function requestHelperCompletion(prompt,options={}){
  await ensureProtectedSettingsReadyForProviderUse();
  let model=ensureModelId(APP_SETTINGS.helperModel);
  if(!isProviderKeyConfigured('keyOpenRouter')){
    const err=createApiError('Invalid API key. Check your OpenRouter key in Settings.',401,'Missing OpenRouter API key');
    if(!options?.suppressErrorDialog) showHelperApiError(err);
    throw err;
  }
  try{
    model=await resolveHelperOpenRouterModelForRequest(model);
    const system=String(options?.system||'');
    const messages=Array.isArray(options?.messages)&&options.messages.length
      ? options.messages
      : [{role:'user',content:prompt}];
    const result=await callOpenRouter('',model,system,messages,[],null);
    return result.text||'';
  }catch(e){
    if(!options?.suppressErrorDialog) showHelperApiError(e);
    throw e;
  }
}

function normalizeImageSourceMode(value){
  return value==='from-summary'?'from-summary':'from-scratch';
}

function imageModeBaseLabel(mode){
  return normalizeImageSourceMode(mode)==='from-summary'?'summary':'scratch';
}

function imagePromptHasSavedImage(prompt){
  return !!prompt&&(prompt.hasImage===true||prompt.locked===true);
}

function getImagePromptCounterKey(mode){
  return normalizeImageSourceMode(mode)==='from-summary'?'imagePromptSummary':'imagePromptScratch';
}

function buildImagePromptFileName(mode,id){
  return `${imageModeBaseLabel(mode)}-prompt__${String(id||'001')}.json`;
}

function buildImageRenderFileName(mode,id){
  return `${imageModeBaseLabel(mode)}-image__${String(id||'001')}.${IMAGE_OUTPUT_FILE_EXTENSION}`;
}

function normalizeImageStoragePath(value=''){
  return String(value||'').replace(/\\/g,'/').replace(/^\/+|\/+$/g,'').trim();
}

function joinImageStoragePath(dirName,fileName){
  const base=String(fileName||'').trim();
  const dir=normalizeImageStoragePath(dirName);
  if(!base) return dir;
  return dir?`${dir}/${base}`:base;
}

function getImageStorageDirName(path=''){
  const normalized=normalizeImageStoragePath(path);
  const idx=normalized.lastIndexOf('/');
  return idx>=0?normalized.slice(0,idx):'';
}

function getImageStorageBaseName(path=''){
  const normalized=normalizeImageStoragePath(path);
  const idx=normalized.lastIndexOf('/');
  return idx>=0?normalized.slice(idx+1):normalized;
}

function parseSummaryArtifactId(value=''){
  const match=String(value||'').match(/__(\d{3,})\.html?$/i);
  return match?String(match[1]||'').padStart(3,'0'):'';
}

function parseSummaryFamilyId(value=''){
  const match=String(value||'').match(/^summary__(\d{3,})$/i);
  return match?String(match[1]||'').padStart(3,'0'):'';
}

function buildSummaryFamilyDirName(summaryId='001'){
  return `summary__${String(summaryId||'001').padStart(3,'0')}`;
}

function isSummaryFamilyDirName(value=''){
  return !!parseSummaryFamilyId(value);
}

function getSummaryFamilyDirNameFromPrompt(prompt){
  const direct=isSummaryFamilyDirName(prompt?.summary_family)?String(prompt.summary_family):'';
  if(direct) return direct;
  const derivedDir=getImageStorageDirName(prompt?.promptPath||'');
  return isSummaryFamilyDirName(derivedDir)?derivedDir:'';
}

function getSummaryFamilyIdFromPrompt(prompt){
  const familyDir=getSummaryFamilyDirNameFromPrompt(prompt);
  return familyDir?parseSummaryFamilyId(familyDir):'';
}

function getImagePromptRef(prompt){
  return normalizeImageStoragePath(prompt?.promptPath||prompt?.fileName||'');
}

function getImageRenderRef(prompt){
  return normalizeImageStoragePath(prompt?.imagePath||prompt?.imageFileName||'');
}

function doesImagePromptMatchRef(prompt,ref=''){
  const target=normalizeImageStoragePath(ref);
  if(!target) return false;
  const promptRef=getImagePromptRef(prompt);
  if(promptRef===target) return true;
  if(!target.includes('/')&&String(prompt?.fileName||'')===target) return true;
  const imageRef=getImageRenderRef(prompt);
  if(imageRef===target) return true;
  if(!target.includes('/')&&String(prompt?.imageFileName||'')===target) return true;
  return false;
}

function getSummaryPromptDisplayLabel(prompt){
  const explicit=String(prompt?.summary_label||'').trim();
  if(explicit) return explicit;
  const summaryFile=String(prompt?.summary_file||'').trim();
  if(summaryFile) return summaryFile.replace(/\.html?$/i,'');
  const familyDir=getSummaryFamilyDirNameFromPrompt(prompt);
  return familyDir||'Archived summary';
}

function buildExportedImageFileName(prompt,conv=S.conv){
  const convLabel=getConversationArtifactLabel(conv)||'Conversation';
  const imageBase=getImageStorageBaseName(prompt?.imageFileName||prompt?.imagePath||'');
  return `${convLabel}__${imageBase||('image.'+IMAGE_OUTPUT_FILE_EXTENSION)}`;
}

function getImageStyleOption(id){
  return IMAGE_STYLE_OPTIONS.find(option=>option.id===id)||IMAGE_STYLE_OPTIONS[0];
}

function getImageAspectOption(id){
  return IMAGE_ASPECT_OPTIONS.find(option=>option.id===id)||IMAGE_ASPECT_OPTIONS[0];
}

function getImageDialogPromptList(mode=IMAGE_DIALOG_STATE.mode){
  return IMAGE_DIALOG_STATE.promptsByMode[normalizeImageSourceMode(mode)]||[];
}

function shouldShowScratchDraftSlot(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  if(key!=='from-scratch') return false;
  return !getImageDialogPromptList(key).length||IMAGE_DIALOG_STATE.showScratchDraftSlot===true;
}

function areAllScratchImagePromptsCompleted(){
  return getImageDialogPromptList('from-scratch').every(prompt=>imagePromptHasSavedImage(prompt));
}

function canStepToNextImagePrompt(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  const list=getImageDialogPromptList(key);
  const totalSlots=getImageDialogSlotCount(key);
  const current=Math.max(0,Number(IMAGE_DIALOG_STATE.indexByMode[key])||0);
  if(!totalSlots) return false;
  if(current<totalSlots-1) return true;
  if(key==='from-scratch'&&!shouldShowScratchDraftSlot(key)&&list.length&&current===list.length-1&&areAllScratchImagePromptsCompleted()) return true;
  return false;
}

function getImageDialogSlotCount(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  const list=getImageDialogPromptList(key);
  return list.length+(shouldShowScratchDraftSlot(key)?1:0);
}

function isImageDialogBlankSlot(mode=IMAGE_DIALOG_STATE.mode,index=IMAGE_DIALOG_STATE.indexByMode[normalizeImageSourceMode(mode)]){
  const key=normalizeImageSourceMode(mode);
  return shouldShowScratchDraftSlot(key)&&Number(index)===getImageDialogPromptList(key).length;
}

function isCurrentImageSlotBlank(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  const prompt=getImageDialogCurrentPrompt(key);
  if(prompt) return false;
  if(key==='from-scratch'&&isImageDialogBlankSlot(key)){
    return !String(getImageDialogDraft(key)?.text||'').trim();
  }
  return !String(getImageDialogDraft(key)?.text||'').trim();
}

function getImageDialogCurrentPrompt(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  const list=getImageDialogPromptList(key);
  const idx=Number(IMAGE_DIALOG_STATE.indexByMode[key]);
  return idx>=0&&idx<list.length?list[idx]:null;
}

function getImageDialogDraft(mode=IMAGE_DIALOG_STATE.mode){
  return ensureImageDialogDraft(mode);
}

function setImageDialogStatus(text){
  IMAGE_DIALOG_STATE.statusText=String(text||'');
  const el=document.getElementById('img-dialog-status');
  if(el){
    el.textContent=IMAGE_DIALOG_STATE.statusText;
    el.classList.toggle('busy',!!IMAGE_DIALOG_STATE.statusBusy&&!!IMAGE_DIALOG_STATE.statusText);
  }
}

function setImageDialogStatusBusy(flag){
  IMAGE_DIALOG_STATE.statusBusy=!!flag;
  const el=document.getElementById('img-dialog-status');
  if(el) el.classList.toggle('busy',!!IMAGE_DIALOG_STATE.statusBusy&&!!IMAGE_DIALOG_STATE.statusText);
}

function setImageSourceNote(text='',tone='info'){
  IMAGE_DIALOG_STATE.sourceNoteText=String(text||'').trim();
  const el=document.getElementById('img-source-note');
  if(!el) return;
  el.textContent=IMAGE_DIALOG_STATE.sourceNoteText;
  el.style.display=IMAGE_DIALOG_STATE.sourceNoteText?'':'none';
  el.classList.toggle('is-warning',tone==='warning'&&!!IMAGE_DIALOG_STATE.sourceNoteText);
}

function clearImageDialogPreview(){
  if(IMAGE_DIALOG_STATE.previewUrl){
    try{URL.revokeObjectURL(IMAGE_DIALOG_STATE.previewUrl);}catch(e){}
  }
  IMAGE_DIALOG_STATE.previewUrl='';
  const img=document.getElementById('img-preview-image');
  const empty=document.getElementById('img-preview-empty');
  if(img){
    img.style.display='none';
    img.removeAttribute('src');
  }
  if(empty) empty.style.display='';
}

function showImageDialogPreview(previewUrl,altText='Generated image preview'){
  IMAGE_DIALOG_STATE.previewUrl=String(previewUrl||'');
  const img=document.getElementById('img-preview-image');
  const empty=document.getElementById('img-preview-empty');
  if(img){
    img.src=IMAGE_DIALOG_STATE.previewUrl;
    img.alt=String(altText||'Generated image preview');
    img.style.display='';
  }
  if(empty) empty.style.display='none';
}

function fitImagePreviewFrameToShell(){
  const shell=document.getElementById('img-preview-shell');
  const frame=document.getElementById('img-preview-frame');
  if(!shell||!frame) return;
  const state=getImageDialogControlState();
  const aspect=String(state.aspect||'1:1').split(':').map(part=>Number(part)||1);
  const ratio=Math.max(0.1,(aspect[0]||1)/(aspect[1]||1));
  const shellStyles=getComputedStyle(shell);
  const availableWidth=Math.max(120,shell.clientWidth-(parseFloat(shellStyles.paddingLeft)||0)-(parseFloat(shellStyles.paddingRight)||0));
  const availableHeight=Math.max(120,shell.clientHeight-(parseFloat(shellStyles.paddingTop)||0)-(parseFloat(shellStyles.paddingBottom)||0));
  let frameHeight=availableHeight;
  let frameWidth=frameHeight*ratio;
  if(frameWidth>availableWidth){
    frameWidth=availableWidth;
    frameHeight=frameWidth/ratio;
  }
  frame.style.width=Math.max(120,Math.floor(frameWidth))+'px';
  frame.style.height=Math.max(120,Math.floor(frameHeight))+'px';
  frame.style.aspectRatio=`${aspect[0]||1} / ${aspect[1]||1}`;
}

function renderImageChatHistory(messages){
  const el=document.getElementById('img-chat-history');
  if(!el) return;
  const chat=Array.isArray(messages)?messages:[];
  if(!chat.length){
    el.innerHTML='<div class="image-chat-body" style="color:var(--text-dim)">No chat yet for this prompt.</div>';
    return;
  }
  el.innerHTML=chat.map(entry=>`
    <div class="image-chat-msg">
      <div class="image-chat-role">${esc(String(entry?.role||'assistant').toUpperCase())}</div>
      <div class="image-chat-body">${esc(String(entry?.content||'')).replace(/\n/g,'<br>')}</div>
    </div>`).join('');
  el.scrollTop=el.scrollHeight;
}

function getDefaultImageDialogSettings(){
  return{
    style:IMAGE_STYLE_OPTIONS[0].id,
    aspect:IMAGE_ASPECT_OPTIONS[0].id,
    model:ensureImageModelId(APP_SETTINGS.imageHelperModel),
    last_source:'from-scratch',
    summary_prompt_file:''
  };
}

function normalizeImageDialogSettings(parsed,defaults=getDefaultImageDialogSettings()){
  return{
    style:getImageStyleOption(parsed?.style).id,
    aspect:getImageAspectOption(parsed?.aspect).id,
    model:ensureImageModelId(parsed?.model||defaults.model),
    last_source:normalizeImageSourceMode(parsed?.last_source),
    summary_prompt_file:normalizeImageStoragePath(parsed?.summary_prompt_file||'')
  };
}

function createImageDialogDraft(mode,seed={}){
  const key=normalizeImageSourceMode(mode);
  const defaults=IMAGE_DIALOG_STATE.settings||getDefaultImageDialogSettings();
  return{
    text:String(seed?.text||''),
    chat_history:Array.isArray(seed?.chat_history)?seed.chat_history.map(entry=>({
      role:String(entry?.role||'assistant'),
      content:String(entry?.content||'')
    })) : [],
    style:getImageStyleOption(seed?.style||defaults.style).id,
    aspect:getImageAspectOption(seed?.aspect||defaults.aspect).id,
    model:ensureImageModelId(seed?.model||defaults.model)
  };
}

function ensureImageDialogDraft(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  const next=createImageDialogDraft(key,IMAGE_DIALOG_STATE.draftsByMode[key]||{});
  IMAGE_DIALOG_STATE.draftsByMode[key]=next;
  return next;
}

function getImageDialogControlState(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  const prompt=getImageDialogCurrentPrompt(key);
  if(prompt){
    return{
      source:key,
      style:getImageStyleOption(prompt.style).id,
      aspect:getImageAspectOption(prompt.aspect).id,
      model:ensureImageModelId(prompt.model||APP_SETTINGS.imageHelperModel),
      locked:prompt.locked===true
    };
  }
  const draft=ensureImageDialogDraft(key);
  return{
    source:key,
    style:getImageStyleOption(draft.style).id,
    aspect:getImageAspectOption(draft.aspect).id,
    model:ensureImageModelId(draft.model||APP_SETTINGS.imageHelperModel),
    locked:false
  };
}

async function readImageDialogSettings(convNodeOrConv=S.conv){
  const defaults=getDefaultImageDialogSettings();
  if(!convNodeOrConv) return defaults;
  try{
    const dir=await getConversationDownloadSubdir(convNodeOrConv,CONV_DOWNLOADS_IMAGES_DIR,false);
    if(!dir) return defaults;
    const handle=await dir.getFileHandle('settings.json',{create:false});
    const parsed=await readJsonFile(handle);
    return normalizeImageDialogSettings(parsed,defaults);
  }catch(e){
    return defaults;
  }
}

async function persistImageDialogSettingsRecord(convNodeOrConv,record){
  const normalized=normalizeImageDialogSettings(record);
  if(!convNodeOrConv) return normalized;
  try{
    const dir=await getConversationDownloadSubdir(convNodeOrConv,CONV_DOWNLOADS_IMAGES_DIR,true);
    await writeJsonFile(dir,'settings.json',normalized);
  }catch(e){
    console.warn('Could not save image dialog settings:',e);
  }
  return normalized;
}

async function saveImageDialogSettings(){
  APP_SETTINGS.imageHelperModel=ensureImageModelId(document.getElementById('img-model')?.value||APP_SETTINGS.imageHelperModel);
  persistAppSettingsToBrowserStorage();
  if(S.fsRoot) await saveWorkspaceSettingsToDisk();
  const record=normalizeImageDialogSettings({
    style:getImageStyleOption(document.getElementById('img-style')?.value).id,
    aspect:getImageAspectOption(document.getElementById('img-aspect')?.value).id,
    model:ensureImageModelId(document.getElementById('img-model')?.value||APP_SETTINGS.imageHelperModel),
    last_source:normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode),
    summary_prompt_file:normalizeImageStoragePath(IMAGE_DIALOG_STATE.settings?.summary_prompt_file||'')
  });
  IMAGE_DIALOG_STATE.settings=await persistImageDialogSettingsRecord(S.conv,record);
  return IMAGE_DIALOG_STATE.settings;
}

function populateImageDialogControls(){
  const styleEl=document.getElementById('img-style');
  const aspectEl=document.getElementById('img-aspect');
  if(styleEl&&!styleEl.options.length){
    styleEl.innerHTML=IMAGE_STYLE_OPTIONS.map(option=>`<option value="${esc(option.id)}">${esc(option.label)}</option>`).join('');
  }
  if(aspectEl&&!aspectEl.options.length){
    aspectEl.innerHTML=IMAGE_ASPECT_OPTIONS.map(option=>`<option value="${esc(option.id)}">${esc(option.label)}</option>`).join('');
  }
  const state=getImageDialogControlState();
  if(styleEl) styleEl.value=state.style;
  if(aspectEl) aspectEl.value=state.aspect;
  const modelEl=document.getElementById('img-model');
  if(modelEl) modelEl.value=state.model;
  const summaryRadio=document.getElementById('img-source-summary');
  const scratchRadio=document.getElementById('img-source-scratch');
  if(summaryRadio) summaryRadio.checked=state.source==='from-summary';
  if(scratchRadio) scratchRadio.checked=state.source!=='from-summary';
  setImageSourceNote(IMAGE_DIALOG_STATE.sourceNoteText,IMAGE_DIALOG_STATE.sourceNoteText?'warning':'info');
  const controlsLocked=state.locked||IMAGE_DIALOG_STATE.chatBusy||IMAGE_DIALOG_STATE.generateBusy||IMAGE_DIALOG_STATE.busy;
  if(styleEl) styleEl.disabled=controlsLocked;
  if(aspectEl) aspectEl.disabled=controlsLocked;
  const modelSummary=document.getElementById('img-model-summary');
  if(modelSummary){
    modelSummary.classList.toggle('is-disabled',controlsLocked);
    modelSummary.dataset.disabled=controlsLocked?'true':'false';
    modelSummary.setAttribute('aria-disabled',controlsLocked?'true':'false');
  }
  updateModelPickerSummary('image');
  const frame=document.getElementById('img-preview-frame');
  if(frame) frame.style.aspectRatio=getImageAspectOption(state.aspect).ratio;
}

function normalizeLoadedImagePrompt(fileName,data,dirName=''){
  const baseName=getImageStorageBaseName(fileName);
  const match=String(baseName||'').match(/^(summary|scratch)-prompt__(\d{3,})\.json$/i);
  if(!match||!data) return null;
  const derivedMode=match[1].toLowerCase()==='summary'?'from-summary':'from-scratch';
  const promptId=String(data.id||match[2]||'').padStart(3,'0');
  const familyDir=derivedMode==='from-summary'
    ? (isSummaryFamilyDirName(data.summary_family)?String(data.summary_family):getImageStorageDirName(joinImageStoragePath(dirName,baseName)))
    : '';
  const promptPath=joinImageStoragePath(familyDir||dirName,buildImagePromptFileName(derivedMode,promptId));
  const imagePath=joinImageStoragePath(familyDir||dirName,buildImageRenderFileName(derivedMode,promptId));
  const payload={
    id:promptId,
    text:String(data.text||''),
    chat_history:Array.isArray(data.chat_history)?data.chat_history.map(entry=>({
      role:String(entry?.role||'assistant'),
      content:String(entry?.content||'')
    })) : [],
    summary_file:data.summary_file?String(data.summary_file):undefined,
    summary_family:familyDir||undefined,
    summary_label:data.summary_label?String(data.summary_label):undefined,
    style:getImageStyleOption(data.style).id,
    aspect:getImageAspectOption(data.aspect).id,
    model:ensureImageModelId(data.model||APP_SETTINGS.imageHelperModel),
    hasImage:data.hasImage===true||data.locked===true,
    locked:data.locked===true,
    updated_at:String(data.updated_at||''),
    fileName:buildImagePromptFileName(derivedMode,promptId),
    imageFileName:buildImageRenderFileName(derivedMode,promptId),
    promptPath,
    imagePath
  };
  return{mode:derivedMode,prompt:payload};
}

function compareImageDialogPrompts(a,b){
  const aMode=inferImagePromptModeFromRef(a?.promptPath||a?.fileName);
  const bMode=inferImagePromptModeFromRef(b?.promptPath||b?.fileName);
  if(aMode!==bMode) return aMode.localeCompare(bMode);
  if(aMode==='from-summary'){
    const familyDiff=(Number(getSummaryFamilyIdFromPrompt(a)||0)-Number(getSummaryFamilyIdFromPrompt(b)||0));
    if(familyDiff!==0) return familyDiff;
  }
  return Number(a?.id||0)-Number(b?.id||0);
}

async function reserveNextImagePromptId(convNodeOrConv,mode,dirName=''){
  const dir=await getConversationImageFamilyDir(convNodeOrConv,dirName,true);
  if(!dir) return '001';
  const re=new RegExp(`^${imageModeBaseLabel(mode)}-prompt__(\\d{3,})\\.json$`,'i');
  let maxId=0;
  for await(const [name,handle] of dir.entries()){
    if(handle.kind!=='file') continue;
    const match=String(name||'').match(re);
    if(match) maxId=Math.max(maxId,parseInt(match[1],10)||0);
  }
  return String(maxId+1).padStart(3,'0');
}

async function loadImageDialogPrompts(){
  const out={'from-summary':[],'from-scratch':[]};
  if(!S.conv) return out;
  try{
    const dir=await getConversationImageStorageDir(S.conv,false);
    if(!dir) return out;
    for await(const [name,handle] of dir.entries()){
      if(handle.kind==='file'){
        if(!/\.(json)$/i.test(name)||/^settings\.json$/i.test(name)) continue;
        try{
          const parsed=await readJsonFile(handle);
          const normalized=normalizeLoadedImagePrompt(name,parsed,'');
          if(normalized) out[normalized.mode].push(normalized.prompt);
        }catch(e){}
        continue;
      }
      if(handle.kind==='directory'&&isSummaryFamilyDirName(name)){
        for await(const [childName,childHandle] of handle.entries()){
          if(childHandle.kind!=='file'||!/\.(json)$/i.test(childName)||/^settings\.json$/i.test(childName)) continue;
          try{
            const parsed=await readJsonFile(childHandle);
            const normalized=normalizeLoadedImagePrompt(childName,parsed,name);
            if(normalized) out[normalized.mode].push(normalized.prompt);
          }catch(e){}
        }
      }
    }
    Object.keys(out).forEach(mode=>{
      out[mode].sort(compareImageDialogPrompts);
    });
  }catch(e){}
  return out;
}

function toPersistableImagePrompt(prompt){
  const out={
    id:String(prompt?.id||'').padStart(3,'0'),
    text:String(prompt?.text||''),
    chat_history:Array.isArray(prompt?.chat_history)?prompt.chat_history.map(entry=>({
      role:String(entry?.role||'assistant'),
      content:String(entry?.content||'')
    })) : [],
    style:getImageStyleOption(prompt?.style).id,
    aspect:getImageAspectOption(prompt?.aspect).id,
    model:ensureImageModelId(prompt?.model||APP_SETTINGS.imageHelperModel),
    hasImage:imagePromptHasSavedImage(prompt),
    locked:prompt?.locked===true,
    updated_at:String(prompt?.updated_at||new Date().toISOString())
  };
  if(inferImagePromptModeFromRef(prompt?.promptPath||prompt?.fileName)==='from-summary'){
    if(prompt?.summary_file) out.summary_file=String(prompt.summary_file);
    if(prompt?.summary_family) out.summary_family=String(prompt.summary_family);
    if(prompt?.summary_label) out.summary_label=String(prompt.summary_label);
  }
  return out;
}

async function persistImagePrompt(prompt){
  if(!prompt||!S.conv) return false;
  prompt.updated_at=new Date().toISOString();
  const dir=await getConversationImageFamilyDir(S.conv,getSummaryFamilyDirNameFromPrompt(prompt),true);
  await writeJsonFile(dir,prompt.fileName,toPersistableImagePrompt(prompt));
  return true;
}

async function createImagePromptRecord(mode,options={}){
  const key=normalizeImageSourceMode(mode);
  const summaryFamily=key==='from-summary'
    ? (isSummaryFamilyDirName(options.summary_family)
      ? String(options.summary_family)
      : buildSummaryFamilyDirName(parseSummaryArtifactId(options.summary_file)||'001'))
    : '';
  const id=await reserveNextImagePromptId(S.conv,key,summaryFamily);
  const draft=ensureImageDialogDraft(key);
  const prompt={
    id,
    text:String(options.text||''),
    chat_history:Array.isArray(options.chat_history)?options.chat_history.map(entry=>({
      role:String(entry?.role||'assistant'),
      content:String(entry?.content||'')
    })) : [],
    summary_file:options.summary_file?String(options.summary_file):undefined,
    summary_family:summaryFamily||undefined,
    summary_label:options.summary_label?String(options.summary_label):undefined,
    style:getImageStyleOption(options.style||draft.style).id,
    aspect:getImageAspectOption(options.aspect||draft.aspect).id,
    model:ensureImageModelId(options.model||draft.model||APP_SETTINGS.imageHelperModel),
    hasImage:options.hasImage===true,
    locked:options.locked===true,
    updated_at:new Date().toISOString(),
    fileName:buildImagePromptFileName(key,id),
    imageFileName:buildImageRenderFileName(key,id),
    promptPath:joinImageStoragePath(summaryFamily,buildImagePromptFileName(key,id)),
    imagePath:joinImageStoragePath(summaryFamily,buildImageRenderFileName(key,id))
  };
  IMAGE_DIALOG_STATE.promptsByMode[key].push(prompt);
  IMAGE_DIALOG_STATE.promptsByMode[key].sort(compareImageDialogPrompts);
  if(key==='from-scratch') IMAGE_DIALOG_STATE.showScratchDraftSlot=false;
  IMAGE_DIALOG_STATE.indexByMode[key]=IMAGE_DIALOG_STATE.promptsByMode[key].findIndex(entry=>getImagePromptRef(entry)===getImagePromptRef(prompt));
  IMAGE_DIALOG_STATE.draftsByMode[key]=createImageDialogDraft(key,{
    style:prompt.style,
    aspect:prompt.aspect,
    model:prompt.model
  });
  try{
    await persistImagePrompt(prompt);
  }catch(e){
    const list=IMAGE_DIALOG_STATE.promptsByMode[key]||[];
    const idx=list.findIndex(entry=>getImagePromptRef(entry)===getImagePromptRef(prompt));
    if(idx>=0) list.splice(idx,1);
    IMAGE_DIALOG_STATE.draftsByMode[key]=createImageDialogDraft(key,{
      text:prompt.text,
      chat_history:prompt.chat_history,
      style:prompt.style,
      aspect:prompt.aspect,
      model:prompt.model
    });
    IMAGE_DIALOG_STATE.indexByMode[key]=key==='from-scratch'
      ? Math.max(0,Math.min(idx,list.length))
      : (list.length?Math.min(idx,list.length-1):-1);
    throw e;
  }
  return prompt;
}

async function ensureScratchImagePromptRecordFromDraft(mode=IMAGE_DIALOG_STATE.mode){
  const key=normalizeImageSourceMode(mode);
  if(key!=='from-scratch') return null;
  const existing=getImageDialogCurrentPrompt(key);
  if(existing) return existing;
  const draft=ensureImageDialogDraft(key);
  if(!String(draft?.text||'').trim()) return null;
  if(IMAGE_DIALOG_STATE.pendingPromptCreateByMode[key]){
    return await IMAGE_DIALOG_STATE.pendingPromptCreateByMode[key];
  }
  const pending=(async()=>{
    const created=await createImagePromptRecord(key,{
      text:draft.text,
      chat_history:draft.chat_history,
      style:draft.style,
      aspect:draft.aspect,
      model:draft.model
    });
    const latestDraft=ensureImageDialogDraft(key);
    const latestText=String(latestDraft?.text||'');
    const latestChat=Array.isArray(latestDraft?.chat_history)?latestDraft.chat_history.map(entry=>({
      role:String(entry?.role||'assistant'),
      content:String(entry?.content||'')
    })) : [];
    const latestStyle=getImageStyleOption(latestDraft?.style).id;
    const latestAspect=getImageAspectOption(latestDraft?.aspect).id;
    const latestModel=ensureImageModelId(latestDraft?.model||APP_SETTINGS.imageHelperModel);
    let changed=false;
    if(String(created.text||'')!==latestText){
      created.text=latestText;
      changed=true;
    }
    if(JSON.stringify(created.chat_history||[])!==JSON.stringify(latestChat)){
      created.chat_history=latestChat;
      changed=true;
    }
    if(getImageStyleOption(created.style).id!==latestStyle){
      created.style=latestStyle;
      changed=true;
    }
    if(getImageAspectOption(created.aspect).id!==latestAspect){
      created.aspect=latestAspect;
      changed=true;
    }
    if(ensureImageModelId(created.model||APP_SETTINGS.imageHelperModel)!==latestModel){
      created.model=latestModel;
      changed=true;
    }
    if(changed) await persistImagePrompt(created);
    return created;
  })();
  IMAGE_DIALOG_STATE.pendingPromptCreateByMode[key]=pending;
  try{
    return await pending;
  }finally{
    if(IMAGE_DIALOG_STATE.pendingPromptCreateByMode[key]===pending){
      IMAGE_DIALOG_STATE.pendingPromptCreateByMode[key]=null;
    }
  }
}

async function autoLockCurrentImagePromptIfNeeded(mode=IMAGE_DIALOG_STATE.mode){
  const prompt=getImageDialogCurrentPrompt(mode);
  if(!prompt||prompt.locked||!imagePromptHasSavedImage(prompt)) return false;
  prompt.locked=true;
  try{
    await persistImagePrompt(prompt);
  }catch(e){}
  return true;
}

async function setSummaryImagePromptFileForConversation(convNodeOrConv,promptFileName,baseSettings=null){
  const source=baseSettings?normalizeImageDialogSettings(baseSettings):await readImageDialogSettings(convNodeOrConv);
  return persistImageDialogSettingsRecord(convNodeOrConv,{
    ...source,
    summary_prompt_file:normalizeImageStoragePath(promptFileName||'')
  });
}

function isImagePromptSelectedForSummary(prompt){
  return !!prompt&&doesImagePromptMatchRef(prompt,IMAGE_DIALOG_STATE.settings?.summary_prompt_file||'');
}

async function readImagePromptByFileName(convNodeOrConv,promptFileName){
  const fileName=normalizeImageStoragePath(promptFileName||'');
  if(!convNodeOrConv||!fileName) return null;
  try{
    const imagesDir=await getConversationImageStorageDir(convNodeOrConv,false);
    if(!imagesDir) return null;
    if(fileName.includes('/')){
      const dirName=getImageStorageDirName(fileName);
      const baseName=getImageStorageBaseName(fileName);
      const dir=await getConversationImageFamilyDir(convNodeOrConv,dirName,false);
      if(!dir) return null;
      const handle=await dir.getFileHandle(baseName,{create:false});
      const parsed=await readJsonFile(handle);
      return normalizeLoadedImagePrompt(baseName,parsed,dirName)?.prompt||null;
    }
    try{
      const handle=await imagesDir.getFileHandle(fileName,{create:false});
      const parsed=await readJsonFile(handle);
      const normalized=normalizeLoadedImagePrompt(fileName,parsed,'');
      if(normalized?.prompt) return normalized.prompt;
    }catch(e){}
    for await(const [name,handle] of imagesDir.entries()){
      if(handle.kind!=='directory'||!isSummaryFamilyDirName(name)) continue;
      try{
        const promptHandle=await handle.getFileHandle(fileName,{create:false});
        const parsed=await readJsonFile(promptHandle);
        const normalized=normalizeLoadedImagePrompt(fileName,parsed,name);
        if(normalized?.prompt) return normalized.prompt;
      }catch(e){}
    }
  }catch(e){
    return null;
  }
  return null;
}

async function resolveSummaryImageSelectionForConversation(convNodeOrConv,options={}){
  const settings=options.settings?normalizeImageDialogSettings(options.settings):await readImageDialogSettings(convNodeOrConv);
  const promptFileName=normalizeImageStoragePath(settings.summary_prompt_file||'');
  if(!promptFileName) return{settings,status:'none',snapshot:null};
  const prompt=await readImagePromptByFileName(convNodeOrConv,promptFileName);
  if(!imagePromptHasSavedImage(prompt)){
    const cleared=options.clearStale===false?settings:await setSummaryImagePromptFileForConversation(convNodeOrConv,'',settings);
    return{settings:cleared,status:'missing',snapshot:null};
  }
  try{
    const dir=await getConversationImageFamilyDir(convNodeOrConv,getSummaryFamilyDirNameFromPrompt(prompt),false);
    if(!dir) throw new Error('Missing images dir');
    const handle=await dir.getFileHandle(prompt.imageFileName,{create:false});
    const file=await handle.getFile();
    const resolvedPromptRef=getImagePromptRef(prompt);
    const nextSettings=resolvedPromptRef!==promptFileName
      ? await setSummaryImagePromptFileForConversation(convNodeOrConv,resolvedPromptRef,settings)
      : settings;
    return{
      settings:nextSettings,
      status:'ok',
      snapshot:{
        promptFileName:resolvedPromptRef,
        imageFileName:getImageRenderRef(prompt),
        altText:prompt.text||'Summary image',
        bytes:new Uint8Array(await file.arrayBuffer()),
        mimeType:file.type||IMAGE_OUTPUT_MIME_TYPE,
        aspect:getImageAspectOption(prompt.aspect).id
      }
    };
  }catch(e){
    const cleared=options.clearStale===false?settings:await setSummaryImagePromptFileForConversation(convNodeOrConv,'',settings);
    return{settings:cleared,status:'missing',snapshot:null};
  }
}

async function listSavedSummaryArtifacts(convNodeOrConv=S.conv){
  if(!convNodeOrConv) return [];
  let dir=null;
  try{
    dir=await getConversationDownloadSubdir(convNodeOrConv,CONV_DOWNLOADS_SUMMARIES_DIR,false);
  }catch(e){dir=null;}
  if(!dir) return [];
  const candidates=[];
  for await(const [name,handle] of dir.entries()){
    if(handle.kind!=='file'||!/\.html?$/i.test(name)) continue;
    const summaryId=parseSummaryArtifactId(name);
    if(!summaryId) continue;
    try{
      const file=await handle.getFile();
      candidates.push({
        fileName:name,
        handle,
        summaryId,
        familyDirName:buildSummaryFamilyDirName(summaryId),
        displayLabel:String(name||'').replace(/\.html?$/i,''),
        mtime:Number(file.lastModified)||0
      });
    }catch(e){}
  }
  candidates.sort((a,b)=>Number(a.summaryId)-Number(b.summaryId)||Number(a.mtime)-Number(b.mtime));
  return candidates;
}

async function readSavedSummaryArtifactPayload(summaryArtifact){
  if(!summaryArtifact?.handle) return null;
  const html=await readTextFile(summaryArtifact.handle);
  return{
    ...summaryArtifact,
    html,
    text:extractTextFromHtmlDocument(html)
  };
}

async function getMostRecentSavedSummaryArtifact(){
  const summaries=await listSavedSummaryArtifacts(S.conv);
  if(!summaries.length) return null;
  return readSavedSummaryArtifactPayload(summaries[summaries.length-1]);
}

async function listSummaryImageFamilyState(convNodeOrConv=S.conv){
  let imagesDir=null;
  try{
    imagesDir=await getConversationImageStorageDir(convNodeOrConv,false);
  }catch(e){
    imagesDir=null;
  }
  if(!imagesDir) return [];
  const out=[];
  for await(const [name,handle] of imagesDir.entries()){
    if(handle.kind!=='directory'||!isSummaryFamilyDirName(name)) continue;
    let promptCount=0;
    for await(const [childName,childHandle] of handle.entries()){
      if(childHandle.kind!=='file') continue;
      if(/^summary-prompt__\d{3,}\.json$/i.test(childName)) promptCount++;
    }
    out.push({
      dirName:name,
      summaryId:parseSummaryFamilyId(name),
      handle,
      promptCount
    });
  }
  out.sort((a,b)=>Number(a.summaryId)-Number(b.summaryId));
  return out;
}

async function ensureSummaryImageFamilyDirs(convNodeOrConv,summaries){
  if(!convNodeOrConv||!Array.isArray(summaries)||!summaries.length) return false;
  let created=false;
  for(const summary of summaries){
    const familyDirName=isSummaryFamilyDirName(summary?.familyDirName)
      ? String(summary.familyDirName)
      : buildSummaryFamilyDirName(summary?.summaryId||parseSummaryArtifactId(summary?.fileName)||'001');
    await getConversationImageFamilyDir(convNodeOrConv,familyDirName,true);
    created=true;
  }
  return created;
}

async function ensureSummaryArtifactExists(showNotice=true){
  const info=await getMostRecentSavedSummaryArtifact();
  if(info) return info;
  if(showNotice){
    await appAlert('No summary saved for this conversation. Use the Summary button to create one first.',{title:'SUMMARY REQUIRED'});
  }
  return null;
}

function buildRecentConversationRoundsContext(conv,maxRounds=10){
  const rounds=getRoundOpeningDirectorMessages(conv).slice(-Math.max(1,maxRounds));
  if(!rounds.length) return 'No rounds yet.';
  const lines=[];
  rounds.forEach(msg=>{
    const roundNum=Number(msg?.num||msg?.roundId||0)||1;
    lines.push(`Round ${roundNum}`);
    lines.push(`Director: ${String(msg?.content||'').trim()}`);
    getConversationRoundTurnEntries(conv,msg).forEach(entry=>{
      if(entry.type!=='agent') return;
      lines.push(`${getAgentMessageSpeakerLabel(entry.agent,entry.msg)}: ${buildDirectorSnippet(stripDownloadDelimiters(entry.msg?.content||''),220)}`);
    });
    lines.push('');
  });
  return lines.join('\n').trim();
}

function extractImagePromptBlocks(text){
  const blocks=[];
  const re=new RegExp(IMAGE_PROMPT_MARKER_RE.source,'gi');
  let match;
  while((match=re.exec(String(text||'')))!==null){
    const prompt=String(match[1]||'').trim();
    if(prompt) blocks.push(prompt);
  }
  return blocks;
}

async function seedSummaryPromptFamily(summaryArtifact){
  const summaryInfo=await readSavedSummaryArtifactPayload(summaryArtifact);
  if(!summaryInfo) return false;
  const summaryLabel=String(summaryInfo.displayLabel||summaryInfo.fileName||'').replace(/\.html?$/i,'');
  const familyDirName=isSummaryFamilyDirName(summaryInfo.familyDirName)
    ? String(summaryInfo.familyDirName)
    : buildSummaryFamilyDirName(summaryInfo.summaryId||parseSummaryArtifactId(summaryInfo.fileName)||'001');
  const recentContext=buildRecentConversationRoundsContext(S.conv,10);
  const response=await requestHelperCompletion('',{
    system:'You turn Conflab conversation context into candidate image prompts. Return up to 6 distinct prompts. Each prompt MUST be wrapped in <<<PROMPT>>> and <<<END_PROMPT>>> markers. Do not include unwrapped prompts.',
    messages:[{
      role:'user',
      content:`Saved summary:\n\n${summaryInfo.text}\n\nRecent rounds for additional context:\n\n${recentContext}\n\nReturn up to 6 candidate image-generation prompts based on this conversation.`
    }]
  });
  const prompts=extractImagePromptBlocks(response);
  if(!prompts.length){
    await appAlert('The AI Helper did not return any prompt blocks for From Summary mode.',{title:'NO IMAGE PROMPTS'});
    return false;
  }
  for(const promptText of prompts){
    await createImagePromptRecord('from-summary',{
      text:promptText,
      chat_history:[],
      summary_file:summaryInfo.fileName,
      summary_family:familyDirName,
      summary_label:summaryLabel
    });
  }
  return true;
}

async function ensureSummaryModePromptSeed(options={}){
  if(IMAGE_DIALOG_STATE.busy) return false;
  const summaries=await listSavedSummaryArtifacts(S.conv);
  if(!summaries.length) return false;
  await ensureSummaryImageFamilyDirs(S.conv,summaries);
  const familyState=await listSummaryImageFamilyState(S.conv);
  const familyIndex={};
  familyState.forEach(entry=>{ familyIndex[entry.dirName]=entry; });
  const missingSummaries=summaries.filter(summary=>{
    const family=familyIndex[summary.familyDirName];
    return !family||family.promptCount<1;
  });
  if(!missingSummaries.length) return getImageDialogPromptList('from-summary').length>0;
  IMAGE_DIALOG_STATE.busy=true;
  setImageDialogStatusBusy(true);
  setImageDialogStatus('Generating summary-based prompt ideas...');
  renderImageDialog();
  try{
    let seeded=false;
    for(const summaryArtifact of missingSummaries){
      setImageDialogStatus(`Generating prompts for ${summaryArtifact.displayLabel}...`);
      renderImageDialog();
      if(await seedSummaryPromptFamily(summaryArtifact)){
        seeded=true;
      }
    }
    if(seeded) await refreshCurrentConversationDownloads();
    if(seeded&&IMAGE_DIALOG_STATE.indexByMode['from-summary']<0&&getImageDialogPromptList('from-summary').length){
      IMAGE_DIALOG_STATE.indexByMode['from-summary']=0;
    }
    return seeded||getImageDialogPromptList('from-summary').length>0;
  }catch(e){
    return false;
  }finally{
    IMAGE_DIALOG_STATE.busy=false;
    setImageDialogStatusBusy(false);
    setImageDialogStatus('');
    renderImageDialog();
  }
}

async function syncImageSourceModeState(options={}){
  const mode=normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode);
  setImageSourceNote('');
  const savedSummaries=await listSavedSummaryArtifacts(S.conv);
  IMAGE_DIALOG_STATE.hasSavedSummaryArtifact=savedSummaries.length>0;
  if(mode!=='from-summary') return;
  const hasPrompts=getImageDialogPromptList('from-summary').length>0;
  if(!savedSummaries.length){
    if(hasPrompts) return;
    setImageSourceNote('Must create summary.','warning');
    return;
  }
  if(!options.seedSummaryPrompts){
    if(!hasPrompts) setImageSourceNote('Select From Summary to create summary prompts.','warning');
    return;
  }
  const ok=await ensureSummaryModePromptSeed({showNotice:false});
  if(!ok&&!getImageDialogPromptList('from-summary').length){
    setImageSourceNote('Must create summary prompts.','warning');
  }
}

async function ensureImagePromptForGeneration(){
  let prompt=getImageDialogCurrentPrompt();
  if(prompt) return prompt;
  const mode=normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode);
  if(mode==='from-scratch'){
    prompt=await ensureScratchImagePromptRecordFromDraft(mode);
    if(prompt) return prompt;
  }
  const draft=getImageDialogDraft();
  const text=String(draft?.text||'').trim();
  if(!text) return null;
  let summaryInfo=null;
  if(IMAGE_DIALOG_STATE.mode==='from-summary'){
    summaryInfo=await ensureSummaryArtifactExists(true);
    if(!summaryInfo) return null;
  }
  prompt=await createImagePromptRecord(IMAGE_DIALOG_STATE.mode,{
    text,
    chat_history:draft.chat_history||[],
    summary_file:summaryInfo?.fileName||undefined,
    summary_family:summaryInfo?.familyDirName||undefined,
    summary_label:summaryInfo?.displayLabel||undefined
  });
  return prompt;
}

function renderImageDialog(){
  if(!IMAGE_DIALOG_STATE.open) return;
  populateImageDialogControls();
  const mode=normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode);
  const list=getImageDialogPromptList(mode);
  const totalSlots=getImageDialogSlotCount(mode);
  if(totalSlots<=0){
    IMAGE_DIALOG_STATE.indexByMode[mode]=-1;
  }else if(IMAGE_DIALOG_STATE.indexByMode[mode]<0){
    IMAGE_DIALOG_STATE.indexByMode[mode]=mode==='from-scratch'?0:list.length-1;
  }else if(IMAGE_DIALOG_STATE.indexByMode[mode]>=totalSlots){
    IMAGE_DIALOG_STATE.indexByMode[mode]=totalSlots-1;
  }
  const prompt=getImageDialogCurrentPrompt(mode);
  const draft=getImageDialogDraft(mode);
  const promptTextEl=document.getElementById('img-prompt-text');
  const chatInputEl=document.getElementById('img-chat-input');
  const titleEl=document.getElementById('img-prompt-title');
  const prevBtn=document.getElementById('img-prev-btn');
  const nextBtn=document.getElementById('img-next-btn');
  const cloneBtn=document.getElementById('img-clone-btn');
  const useSummaryBtn=document.getElementById('img-use-summary-btn');
  const deleteBtn=document.getElementById('img-delete-btn');
  const deleteImageBtn=document.getElementById('img-delete-image-btn');
  const exportBtn=document.getElementById('img-export-btn');
  const generateBtn=document.getElementById('img-generate-btn');
  const chatBtn=document.getElementById('img-chat-send');
  const hasImage=imagePromptHasSavedImage(prompt);
  const promptLocked=!!prompt?.locked;
  const deleteBusy=IMAGE_DIALOG_STATE.generateBusy||IMAGE_DIALOG_STATE.chatBusy;
  if(titleEl){
    if(prompt){
      const lockTitle=hasImage
        ? (prompt.locked
          ? 'Locked. Click to unlock this prompt for editing.'
          : 'Unlocked. Click to lock this prompt again.')
        : 'Unlocked. This prompt will lock after image generation.';
      const lockLabel=prompt.locked?'Locked prompt':'Unlocked prompt';
      const lockClass=prompt.locked?'locked':'unlocked';
      const passiveClass=hasImage?'':' is-passive';
      const lockGlyph=prompt.locked?'🔒':'🔓';
      const lockMarkup=`<button class="prompt-lock-toggle ${lockClass}${passiveClass}" type="button" ${hasImage?'onclick="toggleImagePromptLock()"':''} title="${esc(lockTitle)}" aria-label="${esc(lockLabel)}">${lockGlyph}</button>`;
      const summaryLabel=mode==='from-summary'
        ? `<span class="image-prompt-summary-label" title="${esc(getSummaryPromptDisplayLabel(prompt))}">SUMMARY: ${esc(getSummaryPromptDisplayLabel(prompt))}</span>`
        : '';
      titleEl.innerHTML=`<span>Prompt #${esc(prompt.id)} ${lockMarkup}</span>${summaryLabel}`;
    }else{
      titleEl.textContent=mode==='from-summary'?'Summary prompt -- blank':'Scratch prompt -- blank';
    }
  }
  if(promptTextEl){
    promptTextEl.value=prompt?prompt.text:(draft.text||'');
    promptTextEl.readOnly=promptLocked;
  }
  renderImageChatHistory(prompt?prompt.chat_history:(draft.chat_history||[]));
  if(chatInputEl) chatInputEl.disabled=promptLocked||IMAGE_DIALOG_STATE.chatBusy||IMAGE_DIALOG_STATE.generateBusy;
  if(chatBtn) chatBtn.disabled=promptLocked||IMAGE_DIALOG_STATE.chatBusy||IMAGE_DIALOG_STATE.generateBusy;
  if(generateBtn) generateBtn.disabled=promptLocked||IMAGE_DIALOG_STATE.generateBusy||IMAGE_DIALOG_STATE.chatBusy||isCurrentImageSlotBlank(mode);
  if(cloneBtn) cloneBtn.disabled=!prompt?.locked;
  if(useSummaryBtn){
    const visible=hasImage;
    const enabled=visible&&IMAGE_DIALOG_STATE.hasSavedSummaryArtifact;
    const active=visible&&isImagePromptSelectedForSummary(prompt);
    useSummaryBtn.style.display=visible?'':'none';
    useSummaryBtn.disabled=!enabled;
    useSummaryBtn.classList.toggle('is-active',active);
    useSummaryBtn.textContent=active?'In Summary':'Use in Summary';
    useSummaryBtn.title=!enabled?'Must create summary.':(active?'Remove this image from summary views':'Use this image in summary views');
  }
  if(deleteBtn){
    deleteBtn.disabled=!prompt||deleteBusy;
    deleteBtn.title=hasImage?'Delete this prompt and its image':'Delete this prompt';
  }
  if(deleteImageBtn){
    deleteImageBtn.style.display=hasImage?'':'none';
    deleteImageBtn.disabled=!hasImage||deleteBusy;
    deleteImageBtn.title='Delete this image and keep the prompt';
  }
  if(exportBtn){
    exportBtn.disabled=!hasImage||deleteBusy;
    exportBtn.title=hasImage?'Export this image from Conflab':'No generated image to export yet';
  }
  if(prevBtn) prevBtn.disabled=!totalSlots||IMAGE_DIALOG_STATE.indexByMode[mode]<=0;
  if(nextBtn) nextBtn.disabled=!canStepToNextImagePrompt(mode);
  setImageDialogStatus(IMAGE_DIALOG_STATE.statusText);
  void updateImageDialogPreview();
}

async function updateImageDialogPreview(){
  const state=getImageDialogControlState();
  const frame=document.getElementById('img-preview-frame');
  if(frame) frame.style.aspectRatio=getImageAspectOption(state.aspect).ratio;
  requestAnimationFrame(fitImagePreviewFrameToShell);
  clearImageDialogPreview();
  const prompt=getImageDialogCurrentPrompt();
  if(!imagePromptHasSavedImage(prompt)||!S.conv) return;
  try{
    const dir=await getConversationImageFamilyDir(S.conv,getSummaryFamilyDirNameFromPrompt(prompt),false);
    if(!dir) return;
    const handle=await dir.getFileHandle(prompt.imageFileName,{create:false});
    const file=await handle.getFile();
    const bytes=new Uint8Array(await file.arrayBuffer());
    const url=createImageObjectUrl(bytes,file.type||'');
    showImageDialogPreview(url,prompt.text||'Generated image preview');
  }catch(e){}
}

async function exportCurrentImagePrompt(){
  const prompt=getImageDialogCurrentPrompt();
  if(!imagePromptHasSavedImage(prompt)||!S.conv) return;
  try{
    const dir=await getConversationImageFamilyDir(S.conv,getSummaryFamilyDirNameFromPrompt(prompt),false);
    if(!dir) throw new Error('Missing images dir');
    const handle=await dir.getFileHandle(prompt.imageFileName,{create:false});
    const file=await handle.getFile();
    const bytes=new Uint8Array(await file.arrayBuffer());
    downloadBytesAsFile(
      bytes,
      buildExportedImageFileName(prompt,S.conv),
      file.type||IMAGE_OUTPUT_MIME_TYPE
    );
  }catch(e){
    await appAlert('Could not export this image.',{title:'EXPORT FAILED'});
  }
}

function inferImagePromptModeFromRef(ref=''){
  return /^summary-(?:prompt|image)__/i.test(getImageStorageBaseName(ref))?'from-summary':'from-scratch';
}

function findImageDialogPromptLocation(options={}){
  const promptFileName=normalizeImageStoragePath(options?.promptFileName||'');
  const imageFileName=normalizeImageStoragePath(options?.imageFileName||'');
  const preferredMode=inferImagePromptModeFromRef(promptFileName||imageFileName);
  const modes=[preferredMode,...['from-summary','from-scratch'].filter(mode=>mode!==preferredMode)];
  for(const mode of modes){
    const list=getImageDialogPromptList(mode);
    const index=list.findIndex(prompt=>
      (promptFileName&&doesImagePromptMatchRef(prompt,promptFileName))||
      (imageFileName&&doesImagePromptMatchRef(prompt,imageFileName))
    );
    if(index>=0){
      return{mode,index,prompt:list[index]};
    }
  }
  return null;
}

async function openImageDialogForSavedArtifact(convNode,item){
  const targetPath=String(convNode?.path||'').trim();
  const targetEntry=S.convTreeIndex?.[targetPath]||convNode;
  if(!targetEntry) throw new Error('Missing conversation entry for image artifact');
  if(!S.conv||String(S.conv.sourcePath||'')!==targetPath){
    await openConvFolder(targetEntry);
  }
  await openImageDialog();
  const match=findImageDialogPromptLocation({
    promptFileName:item?.promptFilePath||item?.promptFileName,
    imageFileName:item?.imagePath||item?.fileName,
    promptData:item?.promptData
  });
  if(!match) throw new Error('Saved image prompt could not be located');
  await autoLockCurrentImagePromptIfNeeded(IMAGE_DIALOG_STATE.mode);
  IMAGE_DIALOG_STATE.mode=match.mode;
  IMAGE_DIALOG_STATE.indexByMode[match.mode]=match.index;
  renderImageDialog();
}

async function openImageDialog(){
  if(!S.conv){
    await appAlert('Open a conversation first.',{title:'IMAGE GENERATION'});
    return;
  }
  IMAGE_DIALOG_STATE.open=true;
  IMAGE_DIALOG_STATE.convPath=String(S.conv.sourcePath||'');
  IMAGE_DIALOG_STATE.settings=await readImageDialogSettings();
  IMAGE_DIALOG_STATE.mode=normalizeImageSourceMode(IMAGE_DIALOG_STATE.settings.last_source);
  IMAGE_DIALOG_STATE.promptsByMode=await loadImageDialogPrompts();
  IMAGE_DIALOG_STATE.draftsByMode={
    'from-summary':createImageDialogDraft('from-summary'),
    'from-scratch':createImageDialogDraft('from-scratch')
  };
  IMAGE_DIALOG_STATE.pendingPromptCreateByMode={'from-summary':null,'from-scratch':null};
  IMAGE_DIALOG_STATE.showScratchDraftSlot=false;
  IMAGE_DIALOG_STATE.indexByMode={
    'from-summary':IMAGE_DIALOG_STATE.promptsByMode['from-summary'].length?IMAGE_DIALOG_STATE.promptsByMode['from-summary'].length-1:-1,
    'from-scratch':IMAGE_DIALOG_STATE.promptsByMode['from-scratch'].length?IMAGE_DIALOG_STATE.promptsByMode['from-scratch'].length-1:-1
  };
  APP_SETTINGS.imageHelperModel=ensureImageModelId(IMAGE_DIALOG_STATE.settings.model||APP_SETTINGS.imageHelperModel);
  persistAppSettingsToBrowserStorage();
  if(S.fsRoot) await saveWorkspaceSettingsToDisk();
  document.getElementById('modal-image-dialog').style.display='flex';
  await fetchOpenRouterImageModels().catch(()=>{});
  await syncImageSourceModeState({seedSummaryPrompts:IMAGE_DIALOG_STATE.mode==='from-summary'});
  renderImageDialog();
}

async function closeImageDialog(event){
  if(event?.target?.id&&event.target.id!=='modal-image-dialog') return;
  await autoLockCurrentImagePromptIfNeeded(IMAGE_DIALOG_STATE.mode);
  const modal=document.getElementById('modal-image-dialog');
  if(modal) modal.style.display='none';
  clearImageDialogPreview();
  closeModelPicker('image');
  IMAGE_DIALOG_STATE.open=false;
  IMAGE_DIALOG_STATE.statusText='';
  IMAGE_DIALOG_STATE.sourceNoteText='';
  IMAGE_DIALOG_STATE.statusBusy=false;
  IMAGE_DIALOG_STATE.pendingPromptCreateByMode={'from-summary':null,'from-scratch':null};
  IMAGE_DIALOG_STATE.showScratchDraftSlot=false;
}

async function onImageSourceChange(value){
  const next=normalizeImageSourceMode(value);
  const current=normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode);
  if(next===current) return;
  await autoLockCurrentImagePromptIfNeeded(current);
  IMAGE_DIALOG_STATE.mode=next;
  if(next==='from-scratch'&&getImageDialogPromptList(next).length){
    IMAGE_DIALOG_STATE.showScratchDraftSlot=false;
  }
  ensureImageDialogDraft(next);
  await saveImageDialogSettings();
  await syncImageSourceModeState({seedSummaryPrompts:next==='from-summary'});
  renderImageDialog();
}

async function onImageSettingChange(){
  if(!IMAGE_DIALOG_STATE.open) return;
  const mode=normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode);
  const prompt=getImageDialogCurrentPrompt(mode);
  if(prompt?.locked){
    renderImageDialog();
    return;
  }
  const styleId=getImageStyleOption(document.getElementById('img-style')?.value).id;
  const aspectId=getImageAspectOption(document.getElementById('img-aspect')?.value).id;
  const modelId=ensureImageModelId(document.getElementById('img-model')?.value||APP_SETTINGS.imageHelperModel);
  if(prompt){
    prompt.style=styleId;
    prompt.aspect=aspectId;
    prompt.model=modelId;
    await persistImagePrompt(prompt);
  }else{
    const draft=ensureImageDialogDraft(mode);
    draft.style=styleId;
    draft.aspect=aspectId;
    draft.model=modelId;
  }
  await saveImageDialogSettings();
  renderImageDialog();
}

async function onImagePromptTextInput(){
  const prompt=getImageDialogCurrentPrompt();
  const mode=normalizeImageSourceMode(IMAGE_DIALOG_STATE.mode);
  const value=String(document.getElementById('img-prompt-text')?.value||'');
  if(prompt){
    if(prompt.locked){
      renderImageDialog();
      return;
    }
    prompt.text=value;
    void persistImagePrompt(prompt);
    return;
  }
  const draft=ensureImageDialogDraft(mode);
  draft.text=value;
  if(mode==='from-scratch'&&String(value||'').trim()){
    await ensureScratchImagePromptRecordFromDraft(mode);
    renderImageDialog();
  }
}

function handleImageChatKeydown(event){
  if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){
    event.preventDefault();
    void submitImageChat();
  }
}

async function submitImageChat(){
  if(IMAGE_DIALOG_STATE.chatBusy) return;
  const input=document.getElementById('img-chat-input');
  const userText=String(input?.value||'').trim();
  if(!userText) return;
  const prompt=getImageDialogCurrentPrompt();
  if(prompt?.locked){
    await appAlert('This prompt is locked because an image was already generated from it. Click the lock icon to unlock it before refining again.',{title:'PROMPT LOCKED'});
    return;
  }
  const draft=getImageDialogDraft();
  const workingChat=(prompt?prompt.chat_history:draft.chat_history)||[];
  workingChat.push({role:'user',content:userText});
  if(prompt) prompt.chat_history=workingChat;
  else draft.chat_history=workingChat;
  if(input) input.value='';
  IMAGE_DIALOG_STATE.chatBusy=true;
  setImageDialogStatusBusy(true);
  setImageDialogStatus('Submitting prompt...');
  renderImageDialog();
  try{
    const summaryInfo=IMAGE_DIALOG_STATE.mode==='from-summary'?await ensureSummaryArtifactExists(false):null;
    const recentContext=buildRecentConversationRoundsContext(S.conv,10);
    const currentText=prompt?prompt.text:String(document.getElementById('img-prompt-text')?.value||draft.text||'');
    const response=await requestHelperCompletion('',{
      system:'You help discuss and refine image-generation prompts for Conflab. Reply conversationally to questions and discussion. ONLY include a revised prompt wrapped in <<<PROMPT>>> and <<<END_PROMPT>>> markers when the user explicitly asks for the prompt to change -- phrases like "make it ...", "change ...", "rewrite ...", "try ...". If the user is asking a question, brainstorming, or discussing, do NOT emit a <<<PROMPT>>> block.',
      messages:[{
        role:'user',
        content:[
          summaryInfo?`Saved summary:\n${summaryInfo.text}\n`:'',
          `Recent rounds:\n${recentContext}\n`,
          `Current prompt text:\n${currentText||'(blank)'}\n`,
          `Existing prompt chat:\n${workingChat.map(entry=>`${entry.role}: ${entry.content}`).join('\n')}\n`,
          `Latest user instruction:\n${userText}`
        ].filter(Boolean).join('\n')
      }]
    });
    workingChat.push({role:'assistant',content:response});
    const blocks=extractImagePromptBlocks(response);
    if(prompt){
      if(blocks[0]) prompt.text=blocks[0];
      await persistImagePrompt(prompt);
    }else{
      if(blocks[0]) draft.text=blocks[0];
      if(blocks[0]){
        await createImagePromptRecord(IMAGE_DIALOG_STATE.mode,{
          text:draft.text,
          chat_history:workingChat,
          summary_file:summaryInfo?.fileName||undefined,
          summary_family:summaryInfo?.familyDirName||undefined,
          summary_label:summaryInfo?.displayLabel||undefined
        });
      }
    }
  }catch(e){
  }finally{
    IMAGE_DIALOG_STATE.chatBusy=false;
    setImageDialogStatusBusy(false);
    setImageDialogStatus('');
    renderImageDialog();
  }
}

async function cloneImagePrompt(){
  const prompt=getImageDialogCurrentPrompt();
  if(!prompt?.locked) return;
  await createImagePromptRecord(IMAGE_DIALOG_STATE.mode,{
    text:prompt.text,
    chat_history:prompt.chat_history,
    summary_file:prompt?.summary_file,
    summary_family:prompt?.summary_family,
    summary_label:prompt?.summary_label,
    style:prompt.style,
    aspect:prompt.aspect,
    model:prompt.model
  });
  renderImageDialog();
}

async function toggleImagePromptLock(){
  const prompt=getImageDialogCurrentPrompt();
  if(!prompt) return;
  if(!imagePromptHasSavedImage(prompt)){
    renderImageDialog();
    return;
  }
  if(prompt.locked){
    const ok=await appConfirm(
      'Unlock this prompt for editing?\n\nThe current image will stay in place. Generating again will replace that image and lock the prompt again.',
      {title:'UNLOCK PROMPT',okLabel:'Unlock'}
    );
    if(!ok) return;
    prompt.locked=false;
  }else{
    prompt.locked=true;
  }
  await persistImagePrompt(prompt);
  renderImageDialog();
}

async function toggleImageUseInSummary(){
  const prompt=getImageDialogCurrentPrompt();
  if(!imagePromptHasSavedImage(prompt)) return;
  if(!IMAGE_DIALOG_STATE.hasSavedSummaryArtifact){
    await appAlert('Must create summary.',{title:'SUMMARY REQUIRED'});
    return;
  }
  const nextRef=isImagePromptSelectedForSummary(prompt)?'':getImagePromptRef(prompt);
  IMAGE_DIALOG_STATE.settings=await setSummaryImagePromptFileForConversation(S.conv,nextRef,IMAGE_DIALOG_STATE.settings);
  renderImageDialog();
}

async function deleteGeneratedImage(){
  const prompt=getImageDialogCurrentPrompt();
  if(!imagePromptHasSavedImage(prompt)) return;
  const ok=await appConfirm(
    'Delete this image?\n\nThe prompt will remain so you can keep editing it and generate again.',
    {title:'DELETE IMAGE',okLabel:'Delete'}
  );
  if(!ok) return;
  try{
    const dir=await getConversationImageFamilyDir(S.conv,getSummaryFamilyDirNameFromPrompt(prompt),true);
    try{await dir.removeEntry(prompt.imageFileName,{recursive:false});}catch(e){}
  }catch(e){
    await appAlert('Could not delete this image.',{title:'DELETE FAILED'});
    return;
  }
  prompt.hasImage=false;
  prompt.locked=false;
  if(doesImagePromptMatchRef(prompt,IMAGE_DIALOG_STATE.settings?.summary_prompt_file||'')){
    IMAGE_DIALOG_STATE.settings=await setSummaryImagePromptFileForConversation(S.conv,'',IMAGE_DIALOG_STATE.settings);
  }
  await persistImagePrompt(prompt);
  clearImageDialogPreview();
  await refreshCurrentConversationDownloads();
  renderImageDialog();
}

async function deleteImagePrompt(){
  const prompt=getImageDialogCurrentPrompt();
  const mode=IMAGE_DIALOG_STATE.mode;
  if(!prompt){
    IMAGE_DIALOG_STATE.draftsByMode[mode]=createImageDialogDraft(mode,ensureImageDialogDraft(mode));
    renderImageDialog();
    return;
  }
  const ok=await appConfirm(
    imagePromptHasSavedImage(prompt)
      ? 'Delete this prompt?\n\nThe generated image will also be deleted.'
      : 'Delete this prompt?',
    {title:'DELETE PROMPT',okLabel:'Delete'}
  );
  if(!ok) return;
  try{
    const dir=await getConversationImageFamilyDir(S.conv,getSummaryFamilyDirNameFromPrompt(prompt),true);
    await dir.removeEntry(prompt.fileName,{recursive:false});
    try{await dir.removeEntry(prompt.imageFileName,{recursive:false});}catch(e){}
  }catch(e){
    await appAlert('Could not delete this prompt.',{title:'DELETE FAILED'});
    return;
  }
  const list=getImageDialogPromptList(mode);
  const idx=list.findIndex(entry=>getImagePromptRef(entry)===getImagePromptRef(prompt));
  if(idx>=0) list.splice(idx,1);
  if(doesImagePromptMatchRef(prompt,IMAGE_DIALOG_STATE.settings?.summary_prompt_file||'')){
    IMAGE_DIALOG_STATE.settings=await setSummaryImagePromptFileForConversation(S.conv,'',IMAGE_DIALOG_STATE.settings);
  }
  if(mode==='from-scratch') IMAGE_DIALOG_STATE.showScratchDraftSlot=false;
  IMAGE_DIALOG_STATE.indexByMode[mode]=mode==='from-scratch'
    ? Math.max(0,Math.min(idx,list.length))
    : (list.length?Math.min(idx,list.length-1):-1);
  await refreshCurrentConversationDownloads();
  if(mode==='from-summary'&&!list.length){
    await syncImageSourceModeState();
  }
  renderImageDialog();
}

async function stepImagePrompt(delta){
  const mode=IMAGE_DIALOG_STATE.mode;
  const key=normalizeImageSourceMode(mode);
  const list=getImageDialogPromptList(key);
  const totalSlots=getImageDialogSlotCount(mode);
  if(!totalSlots) return;
  const current=Math.max(0,Number(IMAGE_DIALOG_STATE.indexByMode[mode])||0);
  if(Number(delta||0)!==0) await autoLockCurrentImagePromptIfNeeded(mode);
  if(key==='from-scratch'&&Number(delta||0)>0&&!shouldShowScratchDraftSlot(key)&&list.length&&current>=list.length-1&&areAllScratchImagePromptsCompleted()){
    IMAGE_DIALOG_STATE.showScratchDraftSlot=true;
    IMAGE_DIALOG_STATE.indexByMode[key]=list.length;
    renderImageDialog();
    return;
  }
  const next=Math.max(0,Math.min(totalSlots-1,current+Number(delta||0)));
  if(next===current) return;
  IMAGE_DIALOG_STATE.indexByMode[mode]=next;
  if(key==='from-scratch'&&shouldShowScratchDraftSlot(key)&&next<list.length){
    IMAGE_DIALOG_STATE.showScratchDraftSlot=false;
  }
  renderImageDialog();
}

function composeImageGenerationPrompt(text,styleLabel){
  return `Create an image with ${styleLabel} styling.\n\n${String(text||'').trim()}`;
}

async function requestImageGeneration({prompt,style,aspect,model}){
  await ensureProtectedSettingsReadyForProviderUse();
  if(!isProviderKeyConfigured('keyOpenRouter')){
    const err=createApiError('Invalid API key. Check your OpenRouter key in Settings.',401,'Missing OpenRouter API key');
    showHelperApiError(err);
    throw err;
  }
  try{
    const modelId=ensureImageModelId(model);
    const modelEntry=getOpenRouterModelEntry(modelId,'image');
    const outputModalities=Array.isArray(modelEntry?.outputModalities)?modelEntry.outputModalities:[];
    const modalities=outputModalities.includes('text')?['image','text']:['image'];
    const body={
      model:modelId,
      messages:[{role:'user',content:composeImageGenerationPrompt(prompt,style)}],
      modalities,
      image_config:{aspect_ratio:aspect}
    };
    const r=await fetchProtectedBridgeJson('/api/openrouter/chat',{
      method:'POST',
      payload:{body,bodyJson:JSON.stringify(body),referer:/^https?:/i.test(location?.origin||'')?location.origin:''},
      timeoutMs:OPENROUTER_TIMEOUT_MS,
      timeoutLabel:'OpenRouter image request'
    });
    if(!r.ok){
      const e=await r.json().catch(()=>({}));
      const msg=getPayloadErrorMessage(e)||('OpenRouter error '+r.status);
      throw createApiError(mapOpenRouterError(r.status,msg),r.status,msg);
    }
    const data=await r.json();
    const imageUrl=
      data?.choices?.[0]?.message?.images?.[0]?.image_url?.url||
      data?.choices?.[0]?.message?.images?.[0]?.imageUrl?.url||
      '';
    if(!/^data:image\//i.test(imageUrl)){
      throw createApiError('Image generation succeeded but no base64 image payload was returned.',0,'missing image payload');
    }
    const mimeType=((imageUrl.match(/^data:([^;]+);base64,/i)||[])[1]||'').toLowerCase();
    const base64=imageUrl.replace(/^data:image\/[a-z0-9.+-]+;base64,/i,'');
    return{dataUrl:imageUrl,bytes:base64ToBytes(base64),mimeType};
  }catch(e){
    showHelperApiError(e);
    throw e;
  }
}

async function generateImageFromPrompt(){
  if(IMAGE_DIALOG_STATE.generateBusy) return;
  let prompt=getImageDialogCurrentPrompt();
  if(prompt?.locked){
    await appAlert('This prompt is locked because an image has already been generated from it. Click the lock icon to unlock it before editing or generating again.',{title:'PROMPT LOCKED'});
    return;
  }
  prompt=await ensureImagePromptForGeneration();
  if(!prompt||!String(prompt.text||'').trim()){
    await appAlert('Enter a prompt before generating an image.',{title:'IMAGE PROMPT'});
    return;
  }
  IMAGE_DIALOG_STATE.generateBusy=true;
  setImageDialogStatusBusy(true);
  setImageDialogStatus('Generating image...');
  renderImageDialog();
  try{
    const styleId=getImageStyleOption(prompt.style).id;
    const aspectId=getImageAspectOption(prompt.aspect).id;
    const modelId=ensureImageModelId(prompt.model||APP_SETTINGS.imageHelperModel);
    const result=await requestImageGeneration({
      prompt:prompt.text,
      style:getImageStyleOption(styleId).label,
      aspect:aspectId,
      model:modelId
    });
    const savedImage=await transcodeImageBytes(result.bytes,result.mimeType,IMAGE_OUTPUT_MIME_TYPE,IMAGE_OUTPUT_JPEG_QUALITY);
    const dir=await getConversationImageFamilyDir(S.conv,getSummaryFamilyDirNameFromPrompt(prompt),true);
    await writeBinaryFile(dir,prompt.imageFileName,savedImage.bytes);
    clearImageDialogPreview();
    showImageDialogPreview(createImageObjectUrl(savedImage.bytes,savedImage.mimeType),prompt.text||'Generated image preview');
    prompt.hasImage=true;
    prompt.locked=true;
    prompt.style=styleId;
    prompt.aspect=aspectId;
    prompt.model=modelId;
    await persistImagePrompt(prompt);
    await saveImageDialogSettings();
    await refreshCurrentConversationDownloads();
  }catch(e){
  }finally{
    IMAGE_DIALOG_STATE.generateBusy=false;
    setImageDialogStatusBusy(false);
    setImageDialogStatus('');
    renderImageDialog();
  }
}

function parseGeneratedPersonaPayload(text,currentName){
  const src=String(text||'').trim();
  const nameMatch=src.match(/(?:^|\n)\s*NAME:\s*(.+)/i);
  const descriptionMatch=src.match(/(?:^|\n)\s*PERSONA DESCRIPTION:\s*([\s\S]*?)$/i);
  const backstoryMatch=src.match(/(?:^|\n)\s*BACKSTORY:\s*([\s\S]*?)(?:\n\s*SYSTEM PROMPT:|$)/i);
  let name=(nameMatch?.[1]||'').trim();
  let backstory=(backstoryMatch?.[1]||'').trim();
  if(descriptionMatch?.[1]){
    backstory=String(descriptionMatch[1]||'').trim();
  }
  if(!backstory){
    const parts=src.split(/\n{2,}/).map(x=>x.trim()).filter(Boolean);
    backstory=parts[0]||'';
  }
  if(currentName) name=currentName;
  return{name,backstory};
}

function cleanGeneratedName(raw,fallback){
  const plain=String(raw||'').replace(/^NAME:\s*/i,'').trim();
  const safe=plain.replace(/[^A-Za-z0-9\s'.-]/g,' ').replace(/\s+/g,' ').trim();
  return safe||fallback;
}

async function refreshPersonaNameUsageForGeneration(){
  if(!S.fsRoot) return;
  if(S._personaNameUsageRefreshPromise) return S._personaNameUsageRefreshPromise;
  S._personaNameUsageRefreshPromise=scanPersonaFolders()
    .catch(()=>{})
    .finally(()=>{S._personaNameUsageRefreshPromise=null;});
  return S._personaNameUsageRefreshPromise;
}

async function ensureGeneratedPersonaNameUnique(name,attrs){
  await refreshPersonaNameUsageForGeneration();
  const cleaned=cleanGeneratedName(name,'');
  if(cleaned){
    const verdict=evaluatePersonaNameCandidate(cleaned);
    if(verdict.accept) return verdict.name;
  }
  const generated=await generatePersonaNameFromAttributes(attrs);
  return getUniquePersonaDisplayName(generated||cleaned||buildPersonaNameFallback(attrs),'',true)||generated||cleaned||buildPersonaNameFallback(attrs);
}

async function generatePersonaNameFromAttributes(attrs,initial=''){
  await refreshPersonaNameUsageForGeneration();
  const collectedFirst=[];
  const collectedLast=[];
  const targetCount=50;
  const minAcceptedCount=25;
  for(let attempt=1;attempt<=2;attempt++){
    const prompt=buildGenerateNamePoolPrompt(attrs,{
      count:targetCount,
      attempt,
      avoidFirstNames:getPersonaNameAvoidanceList('first',32,collectedFirst),
      avoidLastNames:getPersonaNameAvoidanceList('last',32,collectedLast)
    });
    const text=await requestHelperCompletion(prompt);
    const parsed=parseGeneratedNamePoolPayload(text);
    collectedFirst.push(...parsed.firstNames);
    collectedLast.push(...parsed.surnames);
    const unusedFirst=filterGeneratedNamePartsAgainstPersonaUsage('first',collectedFirst,true);
    const unusedLast=filterGeneratedNamePartsAgainstPersonaUsage('last',collectedLast,true);
    if(unusedFirst.length>=minAcceptedCount&&unusedLast.length>=minAcceptedCount) break;
  }
  const unusedFirst=filterGeneratedNamePartsAgainstPersonaUsage('first',collectedFirst,true);
  const unusedLast=filterGeneratedNamePartsAgainstPersonaUsage('last',collectedLast,true);
  const allFirst=filterGeneratedNamePartsAgainstPersonaUsage('first',collectedFirst,false);
  const allLast=filterGeneratedNamePartsAgainstPersonaUsage('last',collectedLast,false);
  let chosen='';
  chosen=choosePersonaNameFromPools(unusedFirst,unusedLast);
  if(!chosen){
    chosen=choosePersonaNameFromPools(allFirst,unusedLast);
  }
  if(!chosen){
    chosen=choosePersonaNameFromPools(unusedFirst,allLast);
  }
  if(!chosen){
    chosen=choosePersonaNameFromPools(allFirst,allLast);
  }
  const fallback=getUniquePersonaDisplayName(buildPersonaNameFallback(attrs),'',true)||buildPersonaNameFallback(attrs);
  if(chosen) return chosen;
  return fallback;
}

function withPersonaDescriptionHeading(body,attrs){
  let cleaned=String(body||'').trim();
  // Strip common helper-model headings/labels so only the persona description remains.
  cleaned=cleaned.replace(/(?:^|\n)\s*(?:#+\s*)?NAME\s*:\s*[^\n]*/gi,'\n').trim();
  cleaned=cleaned.replace(/(?:^|\n)\s*(?:#+\s*)?(?:BACKSTORY|SYSTEM PROMPT|PERSONA DESCRIPTION)\s*:\s*/gi,'\n').trim();
  cleaned=cleaned.replace(/(?:^|\n)\s*(?:Generation|Age):\s*[^\n]*/gi,'\n').trim();
  cleaned=cleaned.replace(/^#+[^\n]*\n?/,'').trim();
  return cleaned;
}

async function generatePersonaDescriptionFromAttributes(attrs,name){
  const data=normalizePersonaAttributes(attrs||{});
  const identityLine=renderIdentityLine(name,data);
  if(isClusterDefault('background',data)&&isClusterDefault('worldview',data)&&isClusterDefault('lifeExperiences',data)&&isClusterDefault('personality',data)){
    return identityLine;
  }
  const prompt=buildGenerateDescriptionPrompt(data,name);
  const parsed=parseHelperJsonObject(await requestHelperCompletion(prompt));
  if(!parsed||typeof parsed!=='object') throw new Error('Helper model returned invalid description JSON.');
  return assembleSectionedDescription(identityLine,{
    background:parsed.background,
    worldview:parsed.worldview,
    lifeExperiences:parsed.lifeExperiences,
    personality:parsed.personality
  },[name]);
}

async function generateCombinedPersonaFromAttributes(attrs){
  const data=normalizePersonaAttributes(attrs||{});
  const parsed=parseHelperJsonObject(await requestHelperCompletion(buildGeneratePersonaPrompt(data)));
  if(!parsed||typeof parsed!=='object') throw new Error('Helper model returned invalid persona JSON.');
  const name=await ensureGeneratedPersonaNameUnique(parsed.name,data);
  const identityLine=renderIdentityLine(name,data);
  const description=assembleSectionedDescription(identityLine,{
    background:parsed.background,
    worldview:parsed.worldview,
    lifeExperiences:parsed.lifeExperiences,
    personality:parsed.personality
  },[parsed.name,name]);
  return{name,backstory:description};
}

async function rederivePersonaAttributesFromDescription(description,currentAttrs){
  const source=String(description||'').trim();
  if(!source) throw new Error('Description is empty.');
  if(!hasSectionedPersonaSections(source)){
    const reset={...normalizePersonaAttributes(currentAttrs||personaDefaultAttributes())};
    reset.culture='';
    reset.region='';
    reset.education='';
    reset.socioeconomic='';
    reset.political=personaEvenWorldBudget('political');
    reset.religious=personaEvenWorldBudget('religious');
    reset.epistemology=personaEvenWorldBudget('epistemology');
    reset.disabilities=['None'];
    reset.mentalHealth=['Normal'];
    reset.lifeStage=[];
    PERSONA_SLIDERS.forEach(sl=>{reset[sl.id]=0;});
    return normalizePersonaAttributes(reset);
  }
  const parsed=parseHelperJsonObject(await requestHelperCompletion(buildRederivePrompt(source)));
  if(!parsed||typeof parsed!=='object') throw new Error('Helper model returned invalid re-derive JSON.');
  return flattenPersonaRederivePayload(parsed,currentAttrs);
}

async function rederivePersonaAttributesAction(options={}){
  const description=String(document.getElementById('pe-backstory')?.value||'').trim();
  const currentRec=readPersonaRecordFromForm();
  const statusMessage=String(options.statusMessage||'Re-deriving structured fields...').trim()||'Re-deriving structured fields...';
  const hideDelay=Number.isFinite(options.hideDelay)?options.hideDelay:1200;
  setPersonaGenerationStatus(statusMessage);
  try{
    const nextAttrs=await rederivePersonaAttributesFromDescription(description,currentRec.attributes);
    const identity=parseIdentityLine(description);
    applyPersonaStructuredStateToForm(identity?{...nextAttrs,...identity}:nextAttrs,{
      name:identity?identity.name:currentRec.name
    });
    markPersonaDescriptionGenerated();
    if(!identity){
      setPersonaGenerationStatus('Re-derived with current identity fields preserved.',{active:false});
    }else{
      setPersonaGenerationStatus('Re-derived',{active:false});
    }
    if(options.keepStatusVisible!==true){
      setTimeout(()=>{setPersonaGenerationStatus('',{visible:false});},hideDelay);
    }
    return nextAttrs;
  }catch(e){
    setPersonaGenerationStatus('Error: '+e.message,{active:false,error:true});
    throw e;
  }
}

async function generatePersonaFromAttributes(attrs,currentName){
  const name=String(currentName||'').trim()||await generatePersonaNameFromAttributes(attrs);
  const description=await generatePersonaDescriptionFromAttributes(attrs,name);
  return{name,backstory:description};
}

async function generatePersonaName(){
  const attrs=readPersonaRecordFromForm().attributes;
  setPersonaGenerationStatus('Generating name...');
  try{
    const name=await generatePersonaNameFromAttributes(attrs);
    setPersonaNameFieldValue(name||'');
    markPersonaStructuredEdited();
    setPersonaGenerationStatus('Generated',{active:false});
    setTimeout(()=>{setPersonaGenerationStatus('',{visible:false});},1200);
  }catch(e){setPersonaGenerationStatus('Error: '+e.message,{active:false,error:true});}
}

async function generatePersonaDescription(){
  const attrs=readPersonaRecordFromForm().attributes;
  setPersonaGenerationStatus('Generating description...');
  try{
    let name=String(document.getElementById('pe-name').value||'').trim();
    if(!name){
      name=await generatePersonaNameFromAttributes(attrs);
      setPersonaNameFieldValue(name||'');
    }
    const description=await generatePersonaDescriptionFromAttributes(attrs,name);
    document.getElementById('pe-backstory').value=description;
    markPersonaDescriptionGenerated();
    setPersonaGenerationStatus('Generated',{active:false});
    setTimeout(()=>{setPersonaGenerationStatus('',{visible:false});},1200);
  }catch(e){setPersonaGenerationStatus('Error: '+e.message,{active:false,error:true});}
}

function setCombinedPersonaGenerationBusy(busy){
  const btn=document.getElementById('pe-generate-name-btn');
  if(!btn) return;
  btn.disabled=!!busy;
  btn.classList.toggle('bs-generating',!!busy);
  btn.textContent=busy?'Generating...':'Generate Name + Description';
  btn.title=busy?'Generating persona name and description.':'';
}

async function generatePersona(){
  const token=(S._personaCombinedGenerationToken||0)+1;
  S._personaCombinedGenerationToken=token;
  setCombinedPersonaGenerationBusy(true);
  setPersonaGenerationStatus('Generating persona...');
  try{
    const attrs=readPersonaRecordFromForm().attributes;
    const generated=await generateCombinedPersonaFromAttributes(attrs);
    if(S._personaCombinedGenerationToken!==token) return;
    setPersonaNameFieldValue(generated.name||'');
    markPersonaStructuredEdited();
    document.getElementById('pe-backstory').value=replacePersonaDescriptionIdentityLine(generated.backstory||'',generated.name||'',attrs);
    markPersonaDescriptionGenerated();
    setPersonaGenerationStatus('Generated',{active:false});
    setTimeout(()=>{
      if(S._personaCombinedGenerationToken===token) setPersonaGenerationStatus('',{visible:false});
    },1200);
  }catch(e){
    if(S._personaCombinedGenerationToken===token) setPersonaGenerationStatus('Error: '+e.message,{active:false,error:true});
  }finally{
    if(S._personaCombinedGenerationToken===token) setCombinedPersonaGenerationBusy(false);
  }
}

async function personaUseCurrentAiSetup(){
  const c=S.conv;
  const agentId=S.agentPersonaPickerFor;
  if(!c||!agentId) return;
  const setupOpen=!!document.getElementById('pe-setup-details')?.open;
  if(setupOpen){
    const path=String(document.getElementById('pe-path')?.value||'').trim();
    if(!path||!isPersonaEditorLocked()){
      await appAlert('Save this persona before using it on the agent.');
      return;
    }
    await assignPersonaToAgent(agentId,path);
    drawerClose();
    return;
  }
  const agent=c.agents.find(a=>a.id===agentId);
  if(!agent) return;
  agent.personaUuid='';
  agent.personaResolvedData=null;
  agent.personaMissing=false;
  agent.name=`Agent ${getAgentPanelNumber(agent,c)}`;
  agent.model=ensureModelId(document.getElementById('pe-model')?.value||'openrouter/free');
  agent.voiceName=String(document.getElementById('pe-voice')?.value||'');
  if(!agent.voiceName) agent.voiceActive=false;
  S.agentPersonaPickerFor='';
  updatePersonaModeUi();
  renderAgentGrid();
  renderRouting();
  writeMetaFile();
  syncDirectorComposerUi();
  drawerClose();
}

function findPersonaNameCollision(name,currentPath=''){
  const needle=String(name||'').trim().toLowerCase();
  if(!needle) return null;
  return (Array.isArray(S.personaPickerList)?S.personaPickerList:[]).find(node=>{
    if(!node||node.damaged) return false;
    if(currentPath&&node.path===currentPath) return false;
    return String(node.displayName||'').trim().toLowerCase()===needle;
  })||null;
}

function buildClonePersonaName(base){
  const trimmed=String(base||'').trim()||'Persona';
  const stem=/\bclone(?:\s+\d+)?$/i.test(trimmed)?trimmed:trimmed+' Clone';
  if(!findPersonaNameCollision(stem)) return stem;
  let idx=2;
  while(findPersonaNameCollision(`${stem} ${idx}`)) idx++;
  return `${stem} ${idx}`;
}

async function personaSave(){
  setPersonaSaveButtonsDisabled(true);
  try{
    const nameOnlyEdit=S.personaDirtyDirection==='structured-changed'&&isPersonaNameOnlyEdit();
    if(S.personaDirtyDirection==='description-changed'){
      await rederivePersonaAttributesAction({statusMessage:'Re-deriving sliders...',keepStatusVisible:true});
    }else if(S.personaDirtyDirection==='structured-changed'&&!nameOnlyEdit){
      setPersonaGenerationStatus('Regenerating description...');
      try{
        let name=String(document.getElementById('pe-name').value||'').trim();
        if(!name){
          name=await generatePersonaNameFromAttributes(readPersonaRecordFromForm().attributes);
          setPersonaNameFieldValue(name||'');
        }
        const description=await generatePersonaDescriptionFromAttributes(readPersonaRecordFromForm().attributes,name);
        document.getElementById('pe-backstory').value=description;
        markPersonaDescriptionGenerated();
        setPersonaGenerationStatus('Generated',{active:false});
      }catch(e){
        setPersonaGenerationStatus('Error: '+e.message,{active:false,error:true});
        throw e;
      }
    }
    const rec=readPersonaRecordFromForm();
    if(nameOnlyEdit){
      rec.backstory=replacePersonaDescriptionIdentityLine(rec.backstory,rec.name,rec.attributes);
    }
    document.getElementById('pe-name').value=rec.name;
    document.getElementById('pe-occupation').value=rec.attributes.occupation||'';
    document.getElementById('pe-backstory').value=rec.backstory;
    document.getElementById('pe-voice').value=rec.voiceName||'';
    if(!rec.name){await appAlert('Persona name is required.');document.getElementById('pe-name').focus();return;}
    const currentPath=document.getElementById('pe-path').value||'';
    const collision=findPersonaNameCollision(rec.name,currentPath);
    if(collision){
      await appAlert(`A persona named "${rec.name}" already exists. Persona names must be unique.`);
      document.getElementById('pe-name').focus();
      return;
    }
    rec.attributes=normalizePersonaAttributes(rec.attributes);
    rec.uuid=rec.uuid||createUUID();
    let parentHandle=null;
    let parentPath='';
    let targetFileName=buildPersonaFileName(rec.uuid,rec.name);
    let oldFileName='';
    if(currentPath){
      const segs=splitTreePath(currentPath);
      oldFileName=segs.pop()||'';
      parentPath=segs.join('/');
      parentHandle=await treeGetDirectoryHandleByPath(PERSONA_TREE_VIEW,parentPath);
      if(!parentHandle) throw new Error('Persona parent folder missing.');
      if(targetFileName===oldFileName) targetFileName=oldFileName;
    }else{
      const target=await treeGetCreateTarget(PERSONA_TREE_VIEW,false);
      if(!target){await appAlert('Unable to access Personas folder.');return;}
      parentHandle=target.parentHandle;
      parentPath=target.parentPath;
      targetFileName=buildPersonaFileName(rec.uuid,rec.name);
    }
    await writeJsonFile(parentHandle,targetFileName,rec);
    if(oldFileName&&oldFileName!==targetFileName) await parentHandle.removeEntry(oldFileName,{recursive:false});
    const nextPath=parentPath?parentPath+'/'+targetFileName:targetFileName;
    const setupOpen=!!document.getElementById('pe-setup-details')?.open;
    if(currentPath&&currentPath!==nextPath) delete S.personaSetupOpenByPath[currentPath];
    S.personaSetupOpenByPath[nextPath]=setupOpen;
    if(!currentPath) S.personaSetupNewOpen=setupOpen;
    document.getElementById('pe-path').value=nextPath;
    document.getElementById('pe-id').value=nextPath;
    document.getElementById('pe-uuid').value=rec.uuid;
    treeLoadUIState(PERSONA_TREE_VIEW);
    if(parentPath) S.personaTreeExpanded[parentPath]=true;
    await scanPersonaFolders();
    treeSelectPath(PERSONA_TREE_VIEW,nextPath);
    S.activePersona={path:nextPath};
    setPersonaDeleteButtonVisible(true);
    setPersonaEditorLocked(true,{skipSync:true});
    resetPersonaDirtyTracking();
    updatePersonaModeUi();
    renderPersonaList();
  }catch(e){
    await appAlert('Could not save persona.'+(e?.message?` ${e.message}`:''));
  }finally{
    setPersonaSaveButtonsDisabled(false);
  }
}

async function personaCloneCurrent(){
  if(!isPersonaEditorLocked()||!personaHasSavedRecord()) return;
  try{
    const source=normalizePersonaRecord(readPersonaRecordFromForm());
    if(!source){await appAlert('Could not clone this persona.');return;}
    const currentPath=String(document.getElementById('pe-path')?.value||'').trim();
    const segs=splitTreePath(currentPath);
    segs.pop();
    const parentPath=segs.join('/');
    const parentHandle=await treeGetDirectoryHandleByPath(PERSONA_TREE_VIEW,parentPath);
    if(!parentHandle){await appAlert('Could not open the persona folder for cloning.');return;}
    const cloneName=buildClonePersonaName(source.name);
    const cloneRec={
      uuid:createUUID(),
      name:cloneName,
      model:source.model,
      attributes:normalizePersonaAttributes(source.attributes),
      backstory:replacePersonaDescriptionIdentityLine(source.backstory,cloneName,source.attributes),
      voiceName:source.voiceName||''
    };
    const fileName=buildPersonaFileName(cloneRec.uuid,cloneRec.name);
    await writeJsonFile(parentHandle,fileName,cloneRec);
    const nextPath=parentPath?parentPath+'/'+fileName:fileName;
    const setupOpen=!!document.getElementById('pe-setup-details')?.open;
    S.personaSetupOpenByPath[nextPath]=setupOpen;
    if(parentPath) S.personaTreeExpanded[parentPath]=true;
    await scanPersonaFolders();
    treeSelectPath(PERSONA_TREE_VIEW,nextPath);
    document.getElementById('pe-id').value=nextPath;
    document.getElementById('pe-path').value=nextPath;
    document.getElementById('pe-uuid').value=cloneRec.uuid;
    applyPersonaRecordToForm(cloneRec,{forceOpen:setupOpen});
    setPersonaEditorLocked(false,{skipSync:true});
    S.activePersona={path:nextPath};
    setPersonaDeleteButtonVisible(true);
    openPersonaEditView();
    updatePersonaModeUi();
    renderPersonaList();
  }catch(e){
    await appAlert('Could not clone persona.'+(e?.message?` ${e.message}`:''));
  }
}

function buildVariantName(base){
  const b=String(base||'').trim()||'Persona';
  return b+' Variant';
}

function splitPersonaNameSuffix(name){
  const trimmed=String(name||'').trim();
  const m=trimmed.match(/^(.*?)(?:\s+(\d+))?$/);
  return{
    base:String(m?.[1]||trimmed).trim()||trimmed,
    num:parseInt(m?.[2]||'1',10)||1
  };
}

function getUniquePersonaDisplayName(name,currentPath='',saveAsNew=false){
  const trimmed=String(name||'').trim();
  if(!trimmed) return'';
  const {base}=splitPersonaNameSuffix(trimmed);
  const normalizedBase=base.toLowerCase();
  const used=new Set();
  let exactTaken=false;
  (Array.isArray(S.personaPickerList)?S.personaPickerList:[]).forEach(node=>{
    if(!node||node.damaged) return;
    if(!saveAsNew&&currentPath&&node.path===currentPath) return;
    const existing=String(node.displayName||'').trim();
    if(!existing) return;
    const parts=splitPersonaNameSuffix(existing);
    if(parts.base.toLowerCase()!==normalizedBase) return;
    used.add(parts.num);
    if(existing.toLowerCase()===trimmed.toLowerCase()) exactTaken=true;
  });
  if(!exactTaken&&!used.has(1)) return base;
  let next=2;
  while(used.has(next)) next++;
  return `${base} ${next}`;
}

async function createPersonaVariant(source){
  const base=normalizePersonaRecord(source);
  if(!base) return null;
  const variant={uuid:createUUID(),name:buildVariantName(base.name),model:base.model,attributes:normalizePersonaAttributes(base.attributes),backstory:base.backstory,voiceName:base.voiceName||''};
  try{
    const gen=await generatePersonaFromAttributes(variant.attributes,'');
    if(gen.name) variant.name=gen.name;
    if(gen.backstory) variant.backstory=gen.backstory;
  }catch(e){}
  variant.name=getUniquePersonaDisplayName(variant.name,'',true)||variant.name;
  const personasDir=await getPersonasDir(true);
  if(!personasDir) return null;
  const fileName=buildPersonaFileName(variant.uuid,variant.name);
  await writeJsonFile(personasDir,fileName,variant);
  return{path:fileName,data:variant};
}

async function openAgentPersonaPicker(agentId){
  const c=S.conv;if(!c)return;
  const exists=c.agents.some(a=>a.id===agentId);
  if(!exists) return;
  S.agentPersonaPickerFor=agentId;
  personaListBack();
  updatePersonaModeUi();
  drawerOpen('personas');
}

async function openAgentPersonaEditorOrPicker(agentId){
  const c=S.conv;if(!c) return;
  const agent=c.agents.find(a=>a.id===agentId);
  if(!agent) return;
  if(!String(agent.personaUuid||'').trim()){
    await openAgentPersonaPicker(agentId);
    return;
  }
  const node=S.personaUuidIndex?.[agent.personaUuid]||null;
  if(!node||node.type!=='persona'||node.damaged){
    await openAgentPersonaPicker(agentId);
    return;
  }
  S.agentPersonaPickerFor=agentId;
  updatePersonaModeUi();
  drawerOpen('personas');
  await openPersonaEditor(node);
}

async function assignPersonaToAgent(agentId,path){
  const c=S.conv;if(!c)return;
  const agent=c.agents.find(a=>a.id===agentId);if(!agent)return;
  let node=S.personaTreeIndex?.[path];
  if(!node||node.type!=='persona'||node.damaged) return;
  let rec=await readPersonaRecordFromNode(node);
  if(!rec){
    node.damaged=true;
    renderPersonaList();
    await appAlert('This persona appears damaged.');
    return;
  }
  const duplicate=c.agents.find(a=>a.id!==agentId&&a.personaUuid===rec.uuid);
  if(duplicate){
    const duplicateNum=getAgentPanelNumber(duplicate,c);
    const duplicateLabel=duplicateNum>0?`Agent ${duplicateNum}`:duplicate.name;
    const ok=await appConfirm(`"${rec.name}" is already assigned to ${duplicateLabel}. Create a variant?`,{title:'CREATE PERSONA VARIANT',okLabel:'Create Variant'});
    if(!ok) return;
    const variant=await createPersonaVariant(rec);
    if(!variant){await appAlert('Could not create variant persona.');return;}
    await scanPersonaFolders();
    node=S.personaTreeIndex?.[variant.path]||null;
    rec=(node?await readPersonaRecordFromNode(node):null)||variant.data;
  }
  agent.personaUuid=rec.uuid;
  applyPersonaRecordToAgent(agent,rec);
  S.agentPersonaPickerFor='';
  updatePersonaModeUi();
  renderAgentGrid();
  renderRouting();
  writeMetaFile();
  syncDirectorComposerUi();
}

function renderPersonaList(){
  const el=document.getElementById('persona-list');
  if(!el) return;
  updatePersonaModeUi();
  el.innerHTML='';
  treeLoadUIState(PERSONA_TREE_VIEW);
  treeUpdateRootTargetState(PERSONA_TREE_VIEW);
  const noFolder=document.getElementById('persona-no-folder');
  if(noFolder) noFolder.style.display=S.workspaceReady?'none':'block';
  if(!S.workspaceReady) return;
  const hasNodes=Array.isArray(S.personaTree)&&S.personaTree.length>0;
  const pendingParentPath=S[PERSONA_TREE_VIEW.createParentPathKey];
  if(!hasNodes&&!treeHasInlineCreate(PERSONA_TREE_VIEW)){
    el.innerHTML='<div style="padding:14px;font-size:11px;color:var(--text-dim);text-align:center">No personas yet.<br>Click + Persona to create one.</div>';
    return;
  }
  const renderNode=(node,depth)=>{
    const row=document.createElement('div');
    const selected=S.personaTreeSelectedPath===node.path;
    const basePad=8+(depth*14);
    row.style.paddingLeft=basePad+'px';
    if(node.type==='category'){
      const hasChildren=((node.children||[]).length>0)||(pendingParentPath===node.path);
      const expanded=(pendingParentPath===node.path)||(hasChildren&&!!S.personaTreeExpanded[node.path]);
      const row=treeCreateCategoryRow(PERSONA_TREE_VIEW,node,depth,selected,expanded,hasChildren);
      el.appendChild(row);
      if(expanded) renderLevel(node.children||[],depth+1,node.path);
      return;
    }
    row.className='c-row c-conv'+(selected?' sel':'');
    row.style.paddingLeft=basePad+'px';
    row.innerHTML=`
      <span class="c-caret"></span>
      <span class="c-icon c-icon-persona" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"></circle><path d="M4 20c0-3.3 3.6-6 8-6s8 2.7 8 6"></path></svg></span>
      <span class="c-label">${esc(node.displayName||node.name)}</span>
      ${node.damaged?'<span class="c-warn">damaged</span>':''}`;
    row.draggable=true;
    row.ondragstart=e=>startTreeDrag(e,'persona',node,row);
    row.ondragend=()=>endTreeDrag(row);
    row.onclick=async()=>{treeHideMenu(PERSONA_TREE_VIEW);treeSelectPath(PERSONA_TREE_VIEW,node.path||'');renderPersonaList();await openPersonaEditor(node);};
    row.oncontextmenu=async e=>{e.preventDefault();treeHideMenu(PERSONA_TREE_VIEW);treeSelectPath(PERSONA_TREE_VIEW,node.path||'');renderPersonaList();await openPersonaEditor(node);};
    el.appendChild(row);
  };
  const renderLevel=(nodes,depth,parentPath)=>{
    let insertedPending=false;
    const maybeInsertPending=beforeLeaf=>{
      if(insertedPending||pendingParentPath!==parentPath) return;
      if(beforeLeaf||!(nodes||[]).some(node=>node.type!=='category')){
        el.appendChild(treeCreatePendingCategoryRow(PERSONA_TREE_VIEW,depth));
        insertedPending=true;
      }
    };
    (nodes||[]).forEach(node=>{
      if(node.type!=='category') maybeInsertPending(true);
      renderNode(node,depth);
    });
    maybeInsertPending(false);
  };
  renderLevel(S.personaTree,0,'');
}

// -- FULLSCREEN ------------------------------------------------------------

function toggleFullscreen(){
  if(isSessionInteractionBlocked()) return;
  if(!document.fullscreenElement){
    requestAppFullscreen();
  } else {
    document.exitFullscreen().catch(()=>{});
  }
}
function closeConflabWindow(){
  const btn=document.getElementById('btn-close-window');
  if(btn){
    btn.classList.remove('close-blocked');
    btn.title='Close Conflab window';
  }
  try{ window.close(); }catch(e){}
  window.setTimeout(()=>{
    if(document.visibilityState==='hidden') return;
    const latestBtn=document.getElementById('btn-close-window');
    if(!latestBtn) return;
    latestBtn.classList.add('close-blocked');
    latestBtn.title='Use the browser close control if this window stays open';
  },300);
}
function requestAppFullscreen(){
  if(isSessionInteractionBlocked()) return Promise.resolve(false);
  const target=document.documentElement;
  if(document.fullscreenElement===target) return Promise.resolve(true);
  const fn=
    target.requestFullscreen?.bind(target)||
    target.webkitRequestFullscreen?.bind(target)||
    target.msRequestFullscreen?.bind(target);
  if(!fn) return Promise.resolve(false);
  try{
    const result=fn();
    return Promise.resolve(result).then(()=>true).catch(()=>false);
  }catch(e){
    return Promise.resolve(false);
  }
}
let EXTERNAL_URL_FULLSCREEN_RESTORE=null;
function buildExternalLinkPopupFeatures(){
  const screenWidth=Number(window.screen?.availWidth)||Number(window.innerWidth)||1280;
  const screenHeight=Number(window.screen?.availHeight)||Number(window.innerHeight)||900;
  const width=Math.max(900,Math.min(1440,Math.floor(screenWidth*0.82)));
  const height=Math.max(700,Math.min(1100,Math.floor(screenHeight*0.82)));
  const left=Math.max(0,Math.floor((screenWidth-width)/2));
  const top=Math.max(0,Math.floor((screenHeight-height)/2));
  return [
    'popup=yes',
    'noopener=yes',
    'noreferrer=yes',
    'resizable=yes',
    'scrollbars=yes',
    `width=${width}`,
    `height=${height}`,
    `left=${left}`,
    `top=${top}`
  ].join(',');
}
function openExternalUrlWithFullscreenRestore(url){
  const safe=mdSafeHref(url);
  if(!safe) return false;
  const shouldRestore=!!document.fullscreenElement;
  if(EXTERNAL_URL_FULLSCREEN_RESTORE){
    EXTERNAL_URL_FULLSCREEN_RESTORE.cleanup();
    EXTERNAL_URL_FULLSCREEN_RESTORE=null;
  }
  const restore=createFullscreenRestoreController(shouldRestore,{maxLifetimeMs:60*60*1000});
  if(shouldRestore) EXTERNAL_URL_FULLSCREEN_RESTORE=restore;
  try{
    const popup=window.open(safe,'conflab_external_link',buildExternalLinkPopupFeatures());
    if(!popup){
      restore.cleanup();
      if(EXTERNAL_URL_FULLSCREEN_RESTORE===restore) EXTERNAL_URL_FULLSCREEN_RESTORE=null;
      return false;
    }
    let closePoll=null;
    const baseCleanup=restore.cleanup;
    restore.cleanup=()=>{
      if(closePoll!==null){
        clearInterval(closePoll);
        closePoll=null;
      }
      if(EXTERNAL_URL_FULLSCREEN_RESTORE===restore) EXTERNAL_URL_FULLSCREEN_RESTORE=null;
      baseCleanup();
    };
    closePoll=setInterval(()=>{
      let isClosed=false;
      try{
        isClosed=!!popup.closed;
      }catch(e){
        isClosed=false;
      }
      if(!isClosed) return;
      if(closePoll!==null){
        clearInterval(closePoll);
        closePoll=null;
      }
      restore.attemptRestore();
      restore.cleanup();
    },250);
    try{popup.focus();}catch(e){}
    return true;
  }catch(e){
    restore.cleanup();
    if(EXTERNAL_URL_FULLSCREEN_RESTORE===restore) EXTERNAL_URL_FULLSCREEN_RESTORE=null;
    return false;
  }
}
function handleExternalAnchorOpen(event){
  if(event.defaultPrevented) return;
  if(event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey) return;
  const anchor=event.target?.closest?.('a[href]');
  if(!anchor) return;
  const href=String(anchor.getAttribute('href')||'').trim();
  if(!/^https?:\/\//i.test(href)&&!/^mailto:/i.test(href)) return;
  event.preventDefault();
  openExternalUrlWithFullscreenRestore(href);
}
function createFullscreenRestoreController(shouldRestore=false,opts={}){
  if(!shouldRestore) return{cleanup:()=>{},attemptRestore:()=>{}};
  let active=true;
  const timers=[];
  const maxLifetimeMs=Math.max(5000,Number(opts?.maxLifetimeMs)||5000);
  const cleanup=()=>{
    if(!active) return;
    active=false;
    window.removeEventListener('focus',onFocus,true);
    window.removeEventListener('afterprint',onAfterPrint,true);
    document.removeEventListener('visibilitychange',onVisibilityChange,true);
    timers.forEach(timer=>clearTimeout(timer));
  };
  const attemptRestore=()=>{
    if(!active) return;
    if(document.fullscreenElement){
      cleanup();
      return;
    }
    void requestAppFullscreen().then(ok=>{
      if(ok||document.fullscreenElement) cleanup();
    });
  };
  const queueAttempt=(delayMs=0)=>{
    timers.push(setTimeout(attemptRestore,Math.max(0,delayMs)));
  };
  const onFocus=()=>queueAttempt(60);
  const onAfterPrint=()=>queueAttempt(60);
  const onVisibilityChange=()=>{
    if(!document.hidden) queueAttempt(60);
  };
  window.addEventListener('focus',onFocus,true);
  window.addEventListener('afterprint',onAfterPrint,true);
  document.addEventListener('visibilitychange',onVisibilityChange,true);
  queueAttempt(400);
  timers.push(setTimeout(cleanup,maxLifetimeMs));
  return{cleanup,attemptRestore:()=>queueAttempt(60)};
}
document.addEventListener('click',handleExternalAnchorOpen,true);
document.addEventListener('fullscreenchange',()=>{
  const icon = document.getElementById('fs-icon');
  if(!icon)return;
  if(document.fullscreenElement){
    // Compress icon (exit fullscreen)
    icon.innerHTML=`<polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="10" y1="14" x2="3" y2="21"/><line x1="21" y1="3" x2="14" y2="10"/>`;
  } else {
    // Expand icon
    icon.innerHTML=`<polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>`;
  }
});
document.addEventListener('visibilitychange',()=>{
  if(!document.hidden) sendServerHeartbeat('visible');
});
window.addEventListener('focus',()=>{
  sendServerHeartbeat('focus');
});

// ── INTERRUPT ────────────────────────────────────────────────────
function setInterruptVisible(v){
  S.interruptVisible=!!v;
  syncDirectorComposerUi();
}
function onDirectorPrimaryAction(){
  if(S.interruptVisible||S.aborts.length){
    interruptAll();
    return;
  }
  sendMessage();
}
function interruptAll(){
  S.aborts.forEach(c=>c.abort());S.aborts=[];
  clearPendingDispatchTimer();
  clearAiDirectorTimers(true);
  ttsStop();setInterruptVisible(false);
  const c=S.conv;if(!c)return;
  c.agents.forEach(a=>{
    const st=document.getElementById('as_'+a.id);
    if(st&&st.classList.contains('thinking')){st.className='a-status ready';st.textContent='Interrupted';}
  });
}

// ── RESIZE HANDLES ────────────────────────────────────────────────
const MIN_AGENT_GRID_HEIGHT=140;
const MIN_DIRECTOR_PANEL_HEIGHT=170;
function getDirectorPanelElements(){
  const panel=document.getElementById('director-panel');
  const thread=document.getElementById('dir-thread');
  const input=document.getElementById('dir-input');
  const inputWrap=input?.closest('.dir-input-wrap')||null;
  return(panel&&thread&&input&&inputWrap)?{panel,thread,input,inputWrap}:null;
}

function getDirectorResizeMetrics(){
  const refs=getDirectorPanelElements();
  if(!refs) return null;
  const {panel,thread,input,inputWrap}=refs;
  const panelH=panel.getBoundingClientRect().height;
  const threadH=thread.getBoundingClientRect().height;
  const inputH=input.getBoundingClientRect().height;
  const inputWrapH=inputWrap.getBoundingClientRect().height;
  const inputExtra=Math.max(0,inputWrapH-inputH);
  const fixedChromeH=Math.max(0,panelH-threadH-inputWrapH);
  const minInputBoxH=inputExtra+DIR_INPUT_MIN;
  return{
    ...refs,
    panelH,threadH,inputH,inputWrapH,inputExtra,fixedChromeH,minInputBoxH
  };
}

function getDirectorPanelMinHeight(){
  const metrics=getDirectorResizeMetrics();
  if(!metrics) return MIN_DIRECTOR_PANEL_HEIGHT;
  return Math.max(MIN_DIRECTOR_PANEL_HEIGHT,Math.ceil(metrics.fixedChromeH+DIR_THREAD_MIN+metrics.minInputBoxH));
}

function fitDirectorInnerLayoutToPanel(targetPanelHeight,fixedChromeOverride=null){
  const metrics=getDirectorResizeMetrics();
  if(!metrics) return;
  const {thread,input,threadH,inputWrapH,inputExtra,fixedChromeH,minInputBoxH}=metrics;
  const panelH=Number.isFinite(targetPanelHeight)?targetPanelHeight:metrics.panelH;
  const fixedChrome=Number.isFinite(fixedChromeOverride)?fixedChromeOverride:fixedChromeH;
  const minResizable=DIR_THREAD_MIN+minInputBoxH;
  const available=Math.max(minResizable,panelH-fixedChrome);
  const total=inputWrapH+threadH;
  if(total<=available) return;
  let nextThread=threadH;
  let nextInputWrap=inputWrapH;
  let shrinkNeeded=total-available;
  let reducibleThread=Math.max(0,nextThread-DIR_THREAD_MIN);
  let reducibleInput=Math.max(0,nextInputWrap-minInputBoxH);
  const totalReducible=reducibleThread+reducibleInput;
  if(totalReducible<=0){
    nextThread=DIR_THREAD_MIN;
    nextInputWrap=minInputBoxH;
  }else{
    const threadShare=reducibleThread/totalReducible;
    let threadReduce=Math.min(reducibleThread,Math.round(shrinkNeeded*threadShare));
    let inputReduce=Math.min(reducibleInput,shrinkNeeded-threadReduce);
    shrinkNeeded-=threadReduce+inputReduce;
    nextThread-=threadReduce;
    nextInputWrap-=inputReduce;
    if(shrinkNeeded>0&&nextThread>DIR_THREAD_MIN){
      const extra=Math.min(shrinkNeeded,nextThread-DIR_THREAD_MIN);
      nextThread-=extra;
      shrinkNeeded-=extra;
    }
    if(shrinkNeeded>0&&nextInputWrap>minInputBoxH){
      const extra=Math.min(shrinkNeeded,nextInputWrap-minInputBoxH);
      nextInputWrap-=extra;
      shrinkNeeded-=extra;
    }
    nextThread=Math.max(DIR_THREAD_MIN,nextThread);
    nextInputWrap=Math.max(minInputBoxH,nextInputWrap);
  }
  thread.style.height=nextThread+'px';
  thread.style.flex='1 1 auto';
  input.style.height=Math.max(DIR_INPUT_MIN,nextInputWrap-inputExtra)+'px';
}

function runVerticalDrag(onMove,cursor='ns-resize'){
  const prevUserSelect=document.body.style.userSelect;
  const prevCursor=document.body.style.cursor;
  document.body.style.userSelect='none';
  document.body.style.cursor=cursor;
  let active=true;
  const cleanup=()=>{
    if(!active) return;
    active=false;
    document.body.style.userSelect=prevUserSelect;
    document.body.style.cursor=prevCursor;
    window.removeEventListener('mousemove',wrappedMove);
    window.removeEventListener('mouseup',cleanup);
    window.removeEventListener('blur',cleanup);
  };
  const wrappedMove=e=>{
    if((e.buttons&1)===0){cleanup();return;}
    onMove(e,cleanup);
  };
  window.addEventListener('mousemove',wrappedMove);
  window.addEventListener('mouseup',cleanup);
  window.addEventListener('blur',cleanup);
}

function getHistoryListMaxHeight(list){
  const app=document.getElementById('app');
  const historyPanel=document.getElementById('history-panel');
  if(!app||!historyPanel||!list) return Infinity;
  const appRect=app.getBoundingClientRect();
  const panelRect=historyPanel.getBoundingClientRect();
  const listRect=list.getBoundingClientRect();
  const chromeHeight=panelRect.height-listRect.height;
  const minDirectorH=getDirectorPanelMinHeight();
  const maxPanelHeight=Math.max(chromeHeight+80,appRect.bottom-panelRect.top-(minDirectorH+MIN_AGENT_GRID_HEIGHT+36));
  return Math.max(80,Math.floor(maxPanelHeight-chromeHeight));
}

function getPanelMaxHeight(panel){
  const app=document.getElementById('app');
  const footer=document.getElementById('app-footer');
  if(!app||!panel) return Infinity;
  const appRect=app.getBoundingClientRect();
  const panelRect=panel.getBoundingClientRect();
  const footerHeight=footer?footer.getBoundingClientRect().height:0;
  return Math.max(MIN_DIRECTOR_PANEL_HEIGHT,Math.floor(appRect.bottom-panelRect.top-footerHeight-MIN_AGENT_GRID_HEIGHT-18));
}

function initResizeHandles(){
  setupResize('hist-resize','history-panel');
  // Override: hist-resize should resize the list height, not the panel
  (()=>{
    const handle=document.getElementById('hist-resize');
    if(!handle) return;
    // Remove existing listener by cloning
    const fresh=handle.cloneNode(true);
    handle.parentNode.replaceChild(fresh,handle);
    let startY,startH;
    fresh.addEventListener('mousedown',e=>{
      e.preventDefault();
      const list=document.getElementById('history-list');
      if(!list) return;
      startY=e.clientY;
      startH=list.getBoundingClientRect().height;
      const maxH=getHistoryListMaxHeight(list);
      runVerticalDrag(e2=>{
        const newH=Math.min(maxH,Math.max(80,startH+(e2.clientY-startY)));
        list.style.height=newH+'px';
      });
    });
  })();
  setupResize('dir-resize','director-panel');
  setupThreadResize();
}
// Minimums matching CSS
const DIR_THREAD_MIN=26;  // 1 line
const DIR_INPUT_MIN=56;   // 2 lines

function setupThreadResize(){
  const handle=document.getElementById('dir-thread-resize');
  if(!handle)return;
  handle.addEventListener('mousedown',e=>{
    e.preventDefault();
    const thread=document.getElementById('dir-thread');
    const input=document.getElementById('dir-input');
    const startY=e.clientY;
    const startThreadH=thread.getBoundingClientRect().height;
    const startInputH=input.getBoundingClientRect().height;
    const totalResizable=startThreadH+startInputH;
    const minThread=DIR_THREAD_MIN;
    const maxThread=Math.max(minThread,totalResizable-DIR_INPUT_MIN);
    if(maxThread<=minThread){
      handle.title='No room to resize. Drag the Director panel taller first.';
      return;
    }
    handle.title='Drag to resize message area';
    runVerticalDrag(e2=>{
      const delta=e2.clientY-startY;
      // drag up (delta<0): thread shrinks, input grows
      // drag down (delta>0): thread grows, input shrinks
      let newThreadH=startThreadH+delta;
      if(newThreadH<minThread)newThreadH=minThread;
      if(newThreadH>maxThread)newThreadH=maxThread;
      const newInputH=totalResizable-newThreadH;
      thread.style.height=newThreadH+'px';
      thread.style.flex='1 1 auto';
      input.style.height=newInputH+'px';
    },'row-resize');
  });
}
function setupResize(handleId,panelId){
  const handle=document.getElementById(handleId);if(!handle)return;
  let startY,startH,minH=null;
  handle.addEventListener('mousedown',e=>{
    e.preventDefault();
    const p=document.getElementById(panelId);
    if(!p) return;
    startY=e.clientY;
    startH=p.getBoundingClientRect().height;
    const directorMetrics=panelId==='director-panel'?getDirectorResizeMetrics():null;
    if(panelId==='director-panel'){
      minH=getDirectorPanelMinHeight();
    }else if(minH===null){
      minH=startH;
    }
    const maxH=getPanelMaxHeight(p);
    runVerticalDrag(e2=>{
      const newH=Math.min(maxH,Math.max(minH,startH+(e2.clientY-startY)));
      p.style.height=newH+'px';p.style.minHeight='unset';p.style.maxHeight='unset';p.style.flexShrink='0';
      if(panelId==='director-panel'){
        const thread=document.getElementById('dir-thread');
        if(thread) thread.style.flex='1 1 auto';
        fitDirectorInnerLayoutToPanel(newH,directorMetrics?.fixedChromeH);
        const threadResize=document.getElementById('dir-thread-resize');
        if(threadResize) threadResize.title='Drag to resize message area';
      }
    });
  });
}

// ── INIT ──────────────────────────────────────────────────────────
function runStartupStep(name,fn){
  try{
    return fn();
  }catch(e){
    console.error('Conflab startup step failed: '+name,e);
    return null;
  }
}
function runStartupAsyncStep(name,fn){
  try{
    const result=fn();
    if(result&&typeof result.catch==='function') result.catch(e=>console.warn('Conflab startup async step failed: '+name,e));
    return result;
  }catch(e){
    console.error('Conflab startup step failed: '+name,e);
    return null;
  }
}
function hydrateStartupOverview(){
  runStartupStep('version labels',syncVersionLabels);
  runStartupStep('logo images',syncLogoImages);
  runStartupStep('overview panel',hydrateOverviewPanel);
  runStartupStep('overview background settings shortcut',bindOverviewBackgroundSettingsShortcut);
}

runStartupStep('load settings',loadAppSettings);
PROTECTED_SETTINGS_READY_PROMISE=runStartupAsyncStep('protected settings sync',initializeProtectedSettingsFromBrowserStorage);
if(!PROTECTED_SETTINGS_READY_PROMISE||typeof PROTECTED_SETTINGS_READY_PROMISE.then!=='function') PROTECTED_SETTINGS_READY_PROMISE=Promise.resolve();
hydrateStartupOverview();
runStartupStep('director color',applyDirectorColor);
runStartupStep('UI click sound',bindUiClickSound);
runStartupStep('TTS rate control',updateTtsRateControl);
runStartupStep('resize handles',initResizeHandles);
runStartupStep('tree UI handlers',bindTreeUiHandlers);
runStartupStep('conversation dialog dirty handlers',bindConvDialogDirtyHandlers);

// Default pill click routes by folder state; reconnect auto-opens the last valid workspace.
const _defaultPill=document.getElementById('fs-pill');
if(_defaultPill) _defaultPill.addEventListener('click', handleRootPillClick);

runStartupAsyncStep('folder reconnect',tryReconnectFolder);
runStartupStep('render all',renderAll); // include workspace visibility state at startup
runStartupStep('render persona list',renderPersonaList); // empty until folder is connected
hydrateStartupOverview();
runStartupStep('examples modal',hydrateExamplesModal);
runStartupStep('model displays',refreshAllModelDisplays);
runStartupAsyncStep('OpenRouter model list',fetchOpenRouterModels);
runStartupStep('server heartbeat',startServerHeartbeat);
runStartupAsyncStep('microphone permission pregrant',preGrantMicrophonePermission);
</script>
</body>
</html>











