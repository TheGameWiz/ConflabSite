param(
  [switch]$NoDesktopShortcut
)

$ErrorActionPreference = 'Stop'

$installRoot = $PSScriptRoot
$powershellExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$serverScript = Join-Path $installRoot 'conflab.ps1'
$iconPath = Join-Path $installRoot 'Conflab.ico'
$packageShortcutPath = Join-Path $installRoot 'Conflab.lnk'
$desktopShortcutPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Conflab.lnk'

foreach($required in @($serverScript,$iconPath)){
  if(!(Test-Path -LiteralPath $required)){
    throw "Missing required install file: $required"
  }
}

function Set-ConflabShortcut {
  param(
    [string]$ShortcutPath
  )

  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($ShortcutPath)
  $shortcut.TargetPath = $powershellExe
  $shortcut.Arguments = "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$serverScript`" -EntryFile Conflab.app -IdleTimeoutSeconds 3600"
  $shortcut.WorkingDirectory = $installRoot
  $shortcut.Description = 'Launch Conflab'
  if(Test-Path -LiteralPath $iconPath){
    $shortcut.IconLocation = $iconPath
  }
  $shortcut.Save()
}

Set-ConflabShortcut -ShortcutPath $packageShortcutPath

if(-not $NoDesktopShortcut){
  Set-ConflabShortcut -ShortcutPath $desktopShortcutPath
}

Write-Host "Conflab shortcuts refreshed."
Write-Host "Install root: $installRoot"
Write-Host "Package shortcut: $packageShortcutPath"
if(-not $NoDesktopShortcut){
  Write-Host "Desktop shortcut: $desktopShortcutPath"
}
