param(
  [switch]$NoBrowser,
  [string]$EntryFile = 'Conflab.html',
  [string]$ContentRoot = '',
  [int]$IdleTimeoutSeconds = 3600,
  [int]$Port = 47821,
  [switch]$EnableServerLog
)

$ErrorActionPreference = 'Stop'
$script:ServerLogEnabled = [bool]$EnableServerLog

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ResolvedContentRoot = $ScriptRoot
if(-not [string]::IsNullOrWhiteSpace($ContentRoot)){
  try{
    $candidateRoot = [System.IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($ContentRoot.Trim()))
  }catch{
    throw "Invalid ContentRoot path: $ContentRoot"
  }
  if(!(Test-Path -LiteralPath $candidateRoot -PathType Container)){
    throw "ContentRoot directory not found: $candidateRoot"
  }
  $ResolvedContentRoot = $candidateRoot
}

$ResolvedEntryFile = if([string]::IsNullOrWhiteSpace($EntryFile)){ 'Conflab.html' } else { $EntryFile.Trim() }
if([System.IO.Path]::IsPathRooted($ResolvedEntryFile)){
  try{
    $fullEntryPath = [System.IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($ResolvedEntryFile))
  }catch{
    throw "Invalid EntryFile path: $ResolvedEntryFile"
  }
  $contentRootPrefix = $ResolvedContentRoot.TrimEnd('\') + '\'
  if($fullEntryPath.StartsWith($contentRootPrefix,[System.StringComparison]::OrdinalIgnoreCase)){
    $ResolvedEntryFile = $fullEntryPath.Substring($contentRootPrefix.Length)
  } elseif($fullEntryPath.Equals($ResolvedContentRoot.TrimEnd('\'),[System.StringComparison]::OrdinalIgnoreCase)){
    $ResolvedEntryFile = ''
  } else {
    throw "EntryFile must be inside ContentRoot when using an absolute path."
  }
}

function Read-ConflabInstanceProbePayload {
  param($Client,[string]$HostAddress,[int]$PortNumber,[int]$TimeoutMilliseconds = 500)
  try{
    $stream = $Client.GetStream()
    $stream.ReadTimeout = $TimeoutMilliseconds
    $stream.WriteTimeout = $TimeoutMilliseconds
    $requestText = "GET /api/instance HTTP/1.1`r`nHost: ${HostAddress}:${PortNumber}`r`nConnection: close`r`nUser-Agent: Conflab-InstanceScan/1.0`r`n`r`n"
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($requestText)
    $stream.Write($bytes,0,$bytes.Length)
    $buffer = [byte[]]::new(8192)
    $read = $stream.Read($buffer,0,$buffer.Length)
    if($read -le 0){ return $null }
    $responseText = [System.Text.Encoding]::UTF8.GetString($buffer,0,$read)
    $jsonStart = $responseText.IndexOf('{')
    if($jsonStart -lt 0){ return $null }
    $payload = ConvertTo-PlainHashtable (($responseText.Substring($jsonStart)) | ConvertFrom-Json)
    if([string](Get-ObjectValue $payload 'identity' '') -ne $script:ConflabInstanceIdentity){ return $null }
    return $payload
  }catch{
    return $null
  }
}

function Test-LoopbackRequest {
  param($Context)
  try{
    return [System.Net.IPAddress]::IsLoopback($Context.Request.RemoteEndPoint.Address)
  }catch{
    return $false
  }
}

function Get-CurrentAppVersion {
  if($script:ActiveSession -and -not [string]::IsNullOrWhiteSpace([string]$script:ActiveSession.appVersion)){
    return [string]$script:ActiveSession.appVersion
  }
  return 'unknown'
}

function Get-ConflabInstancePayload {
  $workspacePath = if([string]::IsNullOrWhiteSpace([string]$script:ActiveWorkspacePath)){ $null } else { [string]$script:ActiveWorkspacePath }
  return [ordered]@{
    ok = $true
    identity = $script:ConflabInstanceIdentity
    schemaVersion = [int]$script:ConflabInstanceSchemaVersion
    app = $script:ConflabAppName
    appVersion = (Get-CurrentAppVersion)
    state = $(if($workspacePath){ 'active' } else { 'running_no_workspace' })
    host = $HostName
    port = [int]$Port
    baseUrl = $BaseUrl
    contentRoot = $ResolvedContentRoot
    workspacePath = $workspacePath
    serverTime = (Get-Date).ToString('o')
  }
}

function Handle-InstanceStatus {
  param($Context)
  if(-not (Test-LoopbackRequest $Context)){
    Send-Json $Context 403 (New-ErrorPayload 'forbidden' 'Instance identity is available only to loopback requests.')
    return
  }
  Send-Json $Context 200 (Get-ConflabInstancePayload)
}

function Test-ProviderSecretFieldName {
  param([string]$Name)
  return [string]$Name -in @('apiKey','keyOpenRouter','keyBraveSearch','secretStatus','secrets','settings')
}

function Test-ProviderBodyHasSecretFields {
  param($Value)
  if($null -eq $Value){ return $false }
  if($Value -is [System.Collections.IDictionary]){
    foreach($key in $Value.Keys){
      if(Test-ProviderSecretFieldName ([string]$key)){ return $true }
      if(Test-ProviderBodyHasSecretFields $Value[$key]){ return $true }
    }
    return $false
  }
  if($Value.PSObject -and $Value.PSObject.Properties.Count -gt 0 -and $Value.GetType().FullName -eq 'System.Management.Automation.PSCustomObject'){
    foreach($property in $Value.PSObject.Properties){
      if(Test-ProviderSecretFieldName $property.Name){ return $true }
      if(Test-ProviderBodyHasSecretFields $property.Value){ return $true }
    }
    return $false
  }
  if($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]){
    foreach($item in $Value){
      if(Test-ProviderBodyHasSecretFields $item){ return $true }
    }
  }
  return $false
}

function Remove-ProviderSecretFields {
  param($Value)
  $plain = ConvertTo-PlainHashtable $Value
  if($null -eq $plain){ return $null }
  if($plain -is [System.Collections.IDictionary]){
    $out = [ordered]@{}
    foreach($key in $plain.Keys){
      $name = [string]$key
      if(Test-ProviderSecretFieldName $name){ continue }
      $out[$name] = Remove-ProviderSecretFields $plain[$key]
    }
    return $out
  }
  if($plain -is [System.Collections.IEnumerable] -and $plain -isnot [string]){
    $items = @()
    foreach($item in $plain){ $items += ,(Remove-ProviderSecretFields $item) }
    return ,$items
  }
  return $plain
}

function Get-SettingsPath {
  return [System.IO.Path]::Combine($ResolvedContentRoot,'_conflab_settings.json')
}

function Protect-SecretValue {
  param([string]$PlainText)
  Add-Type -AssemblyName System.Security | Out-Null
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($PlainText)
  $protected = [System.Security.Cryptography.ProtectedData]::Protect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
  return [ordered]@{
    encrypted = $true
    provider = 'dpapi-current-user'
    scope = 'CurrentUser'
    encoding = 'base64'
    ciphertext = [Convert]::ToBase64String($protected)
  }
}

function Unprotect-SecretValue {
  param($Secret)
  if($null -eq $Secret){ return $null }
  if($Secret -is [string]){ return [string]$Secret }
  $encrypted = [bool](Get-ObjectValue $Secret 'encrypted' $false)
  $provider = [string](Get-ObjectValue $Secret 'provider' '')
  $ciphertext = [string](Get-ObjectValue $Secret 'ciphertext' '')
  if(!$encrypted -or $provider -ne 'dpapi-current-user' -or [string]::IsNullOrWhiteSpace($ciphertext)){ return $null }
  Add-Type -AssemblyName System.Security | Out-Null
  $bytes = [Convert]::FromBase64String($ciphertext)
  $plain = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
  return [System.Text.Encoding]::UTF8.GetString($plain)
}

function Test-EncryptedSecretValue {
  param($Secret)
  if($null -eq $Secret){ return $false }
  return ([bool](Get-ObjectValue $Secret 'encrypted' $false)) -and ([string](Get-ObjectValue $Secret 'provider' '') -eq 'dpapi-current-user')
}

function Read-SettingsData {
  $path = Get-SettingsPath
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){ return [ordered]@{} }
  $raw = [System.IO.File]::ReadAllText($path,[System.Text.Encoding]::UTF8)
  if([string]::IsNullOrWhiteSpace($raw)){ return [ordered]@{} }
  return ConvertTo-PlainHashtable ($raw | ConvertFrom-Json)
}

function Write-SettingsData {
  param($Settings)
  $path = Get-SettingsPath
  $parent = Get-FsParentPath $path
  if($parent -and !(Test-Path -LiteralPath $parent)){
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
  }
  $json = $Settings | ConvertTo-Json -Depth 80
  $encoding = [System.Text.UTF8Encoding]::new($false)
  $tempPath = [System.IO.Path]::Combine($parent,"_conflab_settings.$([Guid]::NewGuid().ToString('N')).tmp")
  $backupPath = [System.IO.Path]::Combine($parent,'_conflab_settings.bak')
  [System.IO.File]::WriteAllText($tempPath,$json,$encoding)
  if(Test-Path -LiteralPath $path){
    [System.IO.File]::Replace($tempPath,$path,$backupPath,$true)
  } else {
    [System.IO.File]::Move($tempPath,$path)
  }
}

function Protect-PlaintextSettingsSecrets {
  param($Settings)
  $changed = $false
  foreach($key in $script:SecretSettingKeys){
    $value = Get-ObjectValue $Settings $key $null
    if($value -is [string]){
      if([string]::IsNullOrWhiteSpace($value)){
        Set-ObjectValue $Settings $key ''
      } else {
        Set-ObjectValue $Settings $key (Protect-SecretValue $value.Trim())
        $changed = $true
      }
    }
  }
  return $changed
}

function ConvertTo-RedactedSettings {
  param($Settings)
  $result = ConvertTo-PlainHashtable $Settings
  if($null -eq $result){ $result = [ordered]@{} }
  $secretStatus = [ordered]@{}
  foreach($key in $script:SecretSettingKeys){
    $value = Get-ObjectValue $result $key $null
    $configured = $false
    $decryptFailed = $false
    if(Test-EncryptedSecretValue $value){
      try{
        $plain = Unprotect-SecretValue $value
        $configured = -not [string]::IsNullOrWhiteSpace($plain)
      }catch{
        $configured = $false
        $decryptFailed = $true
      }
    } elseif($value -is [string] -and -not [string]::IsNullOrWhiteSpace($value)){
      $configured = $true
    }
    Set-ObjectValue $result $key ''
    $secretStatus[$key] = [ordered]@{
      configured = $configured
      needsEntry = (-not $configured)
      decryptFailed = $decryptFailed
    }
  }
  $result['secretStatus'] = $secretStatus
  return $result
}

function Get-SecretReadState {
  param($Settings,[string]$Key)
  $value = Get-ObjectValue $Settings $Key $null
  if($value -is [string]){
    if([string]::IsNullOrWhiteSpace($value)){
      return [ordered]@{ ok = $false; code = 'missing_api_key'; value = '' }
    }
    return [ordered]@{ ok = $true; code = ''; value = [string]$value }
  }
  if(Test-EncryptedSecretValue $value){
    try{
      $plain = Unprotect-SecretValue $value
      if([string]::IsNullOrWhiteSpace($plain)){
        return [ordered]@{ ok = $false; code = 'missing_api_key'; value = '' }
      }
      return [ordered]@{ ok = $true; code = ''; value = [string]$plain }
    }catch{
      return [ordered]@{ ok = $false; code = 'decrypt_failed'; value = '' }
    }
  }
  return [ordered]@{ ok = $false; code = 'missing_api_key'; value = '' }
}

function Get-ProviderSecretOrRespond {
  param($Context,[string]$Key,[string]$ProviderName)
  try{
    $settings = Read-SettingsData
    $state = Get-SecretReadState $settings $Key
    if([bool](Get-ObjectValue $state 'ok' $false)){
      return [string](Get-ObjectValue $state 'value' '')
    }
    $code = [string](Get-ObjectValue $state 'code' 'missing_api_key')
    $message = if($code -eq 'decrypt_failed'){
      "$ProviderName API key must be re-entered in Settings."
    } else {
      "$ProviderName API key is required."
    }
    Send-Json $Context 401 (New-ErrorPayload 'missing_api_key' $message) -Protected
    return $null
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'settings_read_failed' 'Could not read provider settings.') -Protected
    return $null
  }
}

function ConvertFrom-JsonOrText {
  param([string]$Text)
  if([string]::IsNullOrWhiteSpace($Text)){ return @{} }
  try{
    return ConvertTo-PlainHashtable ($Text | ConvertFrom-Json)
  }catch{
    return @{ error = $Text }
  }
}

function Read-WebExceptionBody {
  param($Exception)
  try{
    $response = $Exception.Response
    if($null -eq $response){ return '' }
    $stream = $response.GetResponseStream()
    if($null -eq $stream){ return '' }
    $reader = New-Object System.IO.StreamReader($stream)
    try{ return [string]$reader.ReadToEnd() }finally{ $reader.Dispose() }
  }catch{
    return ''
  }
}

function Invoke-ProviderJsonRequest {
  param([string]$Uri,[string]$Method = 'GET',$Headers = @{},$Body = $null,[int]$TimeoutSeconds = 60)
  try{
    $params = @{
      Uri = $Uri
      Method = $Method
      Headers = $Headers
      TimeoutSec = $TimeoutSeconds
      UseBasicParsing = $true
    }
    if($null -ne $Body){
      $params.ContentType = 'application/json'
      if($Body -is [string]){
        $params.Body = [string]$Body
      } else {
        $params.Body = ($Body | ConvertTo-Json -Depth 100 -Compress)
      }
    }
    $response = Invoke-WebRequest @params
    return [ordered]@{
      status = [int]$response.StatusCode
      body = ConvertFrom-JsonOrText ([string]$response.Content)
    }
  }catch{
    $status = 502
    $response = $_.Exception.Response
    if($response){
      try{ $status = [int]$response.StatusCode }catch{}
    }
    $bodyText = Read-WebExceptionBody $_.Exception
    $body = ConvertFrom-JsonOrText $bodyText
    if($null -eq $body -or ($body -is [string] -and [string]::IsNullOrWhiteSpace($body))){
      $body = New-ErrorPayload 'provider_request_failed' 'Provider request failed.'
    }
    return [ordered]@{
      status = $status
      body = $body
    }
  }
}

function Handle-OpenRouterChat {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.') -Protected
    return
  }
  $apiKey = Get-ProviderSecretOrRespond $Context 'keyOpenRouter' 'OpenRouter'
  if($null -eq $apiKey){ return }
  $bodyJson = [string](Get-ObjectValue $payload 'bodyJson' '')
  if(-not [string]::IsNullOrWhiteSpace($bodyJson)){
    try{ $parsedBody = $bodyJson | ConvertFrom-Json }catch{
      Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid OpenRouter request body JSON.') -Protected
      return
    }
    if(Test-ProviderBodyHasSecretFields $parsedBody){
      Send-Json $Context 400 (New-ErrorPayload 'secret_fields_not_allowed' 'OpenRouter request body must not include provider secrets.') -Protected
      return
    }
    $body = $bodyJson
  } else {
    $body = Get-ObjectValue $payload 'body' $null
    if($null -eq $body){ $body = $payload }
    $body = Remove-ProviderSecretFields $body
  }
  $headers = @{
    Authorization = "Bearer $apiKey"
    'X-OpenRouter-Title' = 'Conflab'
  }
  $referer = [string](Get-ObjectValue $payload 'referer' '')
  if($referer -match '^https?://'){
    $headers['HTTP-Referer'] = $referer
  }
  $result = Invoke-ProviderJsonRequest 'https://openrouter.ai/api/v1/chat/completions' 'POST' $headers $body 120
  Send-Json $Context ([int]$result.status) $result.body -Protected
}

function Handle-OpenRouterModels {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $result = Invoke-ProviderJsonRequest 'https://openrouter.ai/api/v1/models' 'GET' @{ 'User-Agent' = $UserAgent } $null 60
  Send-Json $Context ([int]$result.status) $result.body -Protected
}

function Handle-OpenRouterImageModels {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $apiKey = Get-ProviderSecretOrRespond $Context 'keyOpenRouter' 'OpenRouter'
  if($null -eq $apiKey){ return }
  $headers = @{
    Authorization = "Bearer $apiKey"
    'X-OpenRouter-Title' = 'Conflab'
    'User-Agent' = $UserAgent
  }
  $result = Invoke-ProviderJsonRequest 'https://openrouter.ai/api/v1/models?output_modalities=image' 'GET' $headers $null 60
  Send-Json $Context ([int]$result.status) $result.body -Protected
}

function Handle-BraveSearchProxy {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.') -Protected
    return
  }
  $query = [string](Get-ObjectValue $payload 'query' '')
  if([string]::IsNullOrWhiteSpace($query)){
    Send-Json $Context 400 (New-ErrorPayload 'missing_query' 'A search query is required.') -Protected
    return
  }
  $count = 10
  $countValue = Get-ObjectValue $payload 'count' $null
  if($null -ne $countValue){
    try{ $count = [int]$countValue }catch{ $count = 10 }
  }
  $count = [Math]::Max(1,[Math]::Min(20,$count))
  $apiKey = Get-ProviderSecretOrRespond $Context 'keyBraveSearch' 'Brave Search'
  if($null -eq $apiKey){ return }
  $cacheKey = "brave-proxy:$query`:$count"
  $cached = Get-CacheValue $cacheKey
  if($null -ne $cached){
    Send-Json $Context 200 @{ results = $cached } -Protected
    return
  }
  $encodedQuery = [System.Uri]::EscapeDataString($query)
  $url = "https://api.search.brave.com/res/v1/web/search?q=${encodedQuery}&count=${count}"
  $headers = @{
    Accept = 'application/json'
    'User-Agent' = $UserAgent
    'X-Subscription-Token' = $apiKey
  }
  $result = Invoke-ProviderJsonRequest $url 'GET' $headers $null $FetchTimeoutSeconds
  if([int]$result.status -ge 200 -and [int]$result.status -lt 300){
    $results = @()
    $web = Get-ObjectValue $result.body 'web' $null
    $webResults = Get-ObjectValue $web 'results' @()
    foreach($item in @($webResults)){
      $profile = Get-ObjectValue $item 'profile' $null
      if((Get-ObjectValue $item 'is_sponsored' $false) -or (Get-ObjectValue $item 'is_ad' $false) -or (Get-ObjectValue $profile 'is_sponsored' $false)){ continue }
      $urlValue = [string](Get-ObjectValue $item 'url' '')
      if([string]::IsNullOrWhiteSpace($urlValue)){ continue }
      $results += @{
        title = [string](Get-ObjectValue $item 'title' '')
        url = $urlValue
        snippet = [string](Get-ObjectValue $item 'description' '')
      }
      if($results.Count -ge $count){ break }
    }
    Set-CacheValue $cacheKey $results
    Send-Json $Context 200 @{ results = $results } -Protected
    return
  }
  Send-Json $Context ([int]$result.status) $result.body -Protected
}

function Handle-SettingsRead {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  try{
    $settingsPath = Get-SettingsPath
    $exists = Test-Path -LiteralPath $settingsPath -PathType Leaf
    $settings = Read-SettingsData
    $migrated = Protect-PlaintextSettingsSecrets $settings
    if($migrated){ Write-SettingsData $settings }
    Send-Json $Context 200 @{
      ok = $true
      exists = $exists
      migrated = $migrated
      settings = ConvertTo-RedactedSettings $settings
    } -Protected
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'settings_read_failed' 'Could not read settings.') -Protected
  }
}

function Handle-SettingsSave {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.') -Protected
    return
  }
  try{
    $existing = Read-SettingsData
    Protect-PlaintextSettingsSecrets $existing | Out-Null
    $incoming = ConvertTo-PlainHashtable (Get-ObjectValue $payload 'settings' ([ordered]@{}))
    if($null -eq $incoming){ $incoming = [ordered]@{} }
    foreach($key in $incoming.Keys){
      if(($script:SecretSettingKeys -notcontains $key) -and $key -ne 'secretStatus'){
        $existing[$key] = $incoming[$key]
      }
    }

    $secretActions = Get-ObjectValue $payload 'secrets' ([ordered]@{})
    foreach($key in $script:SecretSettingKeys){
      $actionSpec = Get-ObjectValue $secretActions $key $null
      $action = [string](Get-ObjectValue $actionSpec 'action' '')
      if([string]::IsNullOrWhiteSpace($action)){
        $incomingSecret = Get-ObjectValue $incoming $key $null
        if($incomingSecret -is [string] -and -not [string]::IsNullOrWhiteSpace($incomingSecret)){
          $action = 'set'
          $actionSpec = [ordered]@{ value = $incomingSecret }
        } else {
          $action = 'preserve'
        }
      }
      if($action -eq 'set'){
        $raw = [string](Get-ObjectValue $actionSpec 'value' '')
        if([string]::IsNullOrWhiteSpace($raw)){
          $existing[$key] = ''
        } else {
          $existing[$key] = Protect-SecretValue $raw.Trim()
        }
      } elseif($action -eq 'clear'){
        $existing[$key] = ''
      } elseif($action -ne 'preserve'){
        Send-Json $Context 400 (New-ErrorPayload 'invalid_secret_action' 'Unsupported secret action.') -Protected
        return
      }
    }
    Write-SettingsData $existing
    Send-Json $Context 200 @{
      ok = $true
      settings = ConvertTo-RedactedSettings $existing
    } -Protected
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'settings_save_failed' 'Could not save settings.') -Protected
  }
}
$ResolvedEntryFile = ($ResolvedEntryFile -replace '\\','/').TrimStart('/')
if([string]::IsNullOrWhiteSpace($ResolvedEntryFile)){
  $ResolvedEntryFile = 'Conflab.html'
}
$DefaultConflabPort = 47821
if($Port -le 0){ $Port = $DefaultConflabPort }
if($Port -lt 1 -or $Port -gt 65535){ throw "Port must be between 1 and 65535." }
$HostName = '127.0.0.1'
$BaseUrl = "http://${HostName}:${Port}"
$CacheTtlSeconds = 3600
$FetchTimeoutSeconds = 10
$FetchCharLimit = 4000
$FetchByteLimit = 1500000
$UserAgent = "Conflab/1.0 (+${BaseUrl})"
$Cache = @{}
$script:LastHeartbeat = Get-Date
$script:ActiveSession = $null
$script:ActiveSessionEpoch = 0
$script:ActiveWorkspacePath = $null
$script:ShutdownRequested = $false
$script:ServerExitReason = 'unknown'
$script:ServerExitDetail = ''
$script:SecretSettingKeys = @('keyOpenRouter','keyBraveSearch')
$script:ConflabInstanceIdentity = 'conflab.local.instance'
$script:ConflabInstanceSchemaVersion = 1
$script:ConflabAppName = 'Conflab'

function New-BridgeAuthToken {
  $bytes = [byte[]]::new(32)
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try{
    $rng.GetBytes($bytes)
  }finally{
    $rng.Dispose()
  }
  return [Convert]::ToBase64String($bytes)
}

$script:BridgeAuthToken = New-BridgeAuthToken

function Test-ConflabPortInUse {
  param([string]$HostAddress,[int]$PortNumber,[int]$TimeoutMilliseconds = 500)
  $client = [System.Net.Sockets.TcpClient]::new()
  try{
    $connect = $client.BeginConnect($HostAddress,$PortNumber,$null,$null)
    if(-not $connect.AsyncWaitHandle.WaitOne($TimeoutMilliseconds)){ return $false }
    try{
      $client.EndConnect($connect) | Out-Null
    }catch [System.Net.Sockets.SocketException]{
      return $false
    }
    return $true
  }catch{
    return $false
  }finally{
    try{ $client.Close() }catch{}
  }
}

function Get-ConflabInstanceAtPort {
  param([string]$HostAddress,[int]$PortNumber,[int]$TimeoutMilliseconds = 500)
  $client = [System.Net.Sockets.TcpClient]::new()
  try{
    $connect = $client.BeginConnect($HostAddress,$PortNumber,$null,$null)
    if(-not $connect.AsyncWaitHandle.WaitOne($TimeoutMilliseconds)){ return $null }
    try{
      $client.EndConnect($connect) | Out-Null
    }catch{
      return $null
    }
    return Read-ConflabInstanceProbePayload -Client $client -HostAddress $HostAddress -PortNumber $PortNumber -TimeoutMilliseconds $TimeoutMilliseconds
  }catch{
    return $null
  }finally{
    try{ $client.Close() }catch{}
  }
}

function Open-ConflabBrowser {
  $entryUrlPath = ($ResolvedEntryFile -split '/') | ForEach-Object { [System.Uri]::EscapeDataString($_) }
  Start-Process "${BaseUrl}/$($entryUrlPath -join '/')" | Out-Null
}

function Touch-Heartbeat {
  $script:LastHeartbeat = Get-Date
}

function Test-AllowedLocalOrigin {
  param([string]$Origin)
  if([string]::IsNullOrWhiteSpace($Origin)){ return $false }
  return $Origin -in @(
    "http://${HostName}:${Port}",
    "http://localhost:${Port}"
  )
}

function Set-CorsHeaders {
  param($Context,[switch]$Protected)
  $origin = ''
  try{ $origin = [string]$Context.Request.Headers['Origin'] }catch{}
  if($Protected){
    if(Test-AllowedLocalOrigin $origin){
      $Context.Response.Headers['Access-Control-Allow-Origin'] = $origin
      $Context.Response.Headers['Vary'] = 'Origin'
    }
    return
  }
  $Context.Response.Headers['Access-Control-Allow-Origin'] = '*'
}

function Test-ProtectedEndpointPath {
  param([string]$Path)
  return $Path -in @(
    '/api/heartbeat',
    '/api/shutdown',
    '/api/picker/recent-workspaces',
    '/api/settings/read',
    '/api/settings/save',
    '/api/openrouter/chat',
    '/api/openrouter/models',
    '/api/openrouter/image-models',
    '/api/brave/search',
    '/api/search'
  )
}

function Test-BridgeAuthTokenValue {
  param([string]$Token)
  return -not [string]::IsNullOrWhiteSpace($Token) -and [string]::Equals($Token,$script:BridgeAuthToken,[System.StringComparison]::Ordinal)
}

function Test-BridgeAuthToken {
  param($Context)
  $token = ''
  try{ $token = [string]$Context.Request.Headers['X-Conflab-Bridge-Token'] }catch{}
  return Test-BridgeAuthTokenValue $token
}

function Require-BridgeAuth {
  param($Context)
  if(Test-BridgeAuthToken $Context){ return $true }
  Send-Json $Context 403 (New-ErrorPayload 'forbidden' 'Request is not authorized.') -Protected
  return $false
}

function Get-CacheValue {
  param([string]$Key)
  if(!$Cache.ContainsKey($Key)){ return $null }
  $entry = $Cache[$Key]
  if(((Get-Date) - $entry.Timestamp).TotalSeconds -ge $CacheTtlSeconds){
    $Cache.Remove($Key) | Out-Null
    return $null
  }
  return $entry.Data
}

function Set-CacheValue {
  param([string]$Key,[object]$Data)
  $Cache[$Key] = @{
    Timestamp = Get-Date
    Data = $Data
  }
}

function Send-Json {
  param($Context,[int]$StatusCode,[object]$Payload,[switch]$Protected)
  $json = ConvertTo-Json -InputObject $Payload -Depth 10 -Compress
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  $Context.Response.StatusCode = $StatusCode
  $Context.Response.ContentType = 'application/json; charset=utf-8'
  Set-CorsHeaders $Context -Protected:$Protected
  $Context.Response.Headers['Cache-Control'] = 'no-store'
  $Context.Response.ContentLength64 = $bytes.Length
  $Context.Response.OutputStream.Write($bytes,0,$bytes.Length)
  $Context.Response.Close()
}

function Send-Text {
  param($Context,[int]$StatusCode,[string]$Text,[string]$ContentType,[switch]$Protected)
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
  $Context.Response.StatusCode = $StatusCode
  $Context.Response.ContentType = $ContentType
  Set-CorsHeaders $Context -Protected:$Protected
  $Context.Response.Headers['Cache-Control'] = 'no-store'
  $Context.Response.ContentLength64 = $bytes.Length
  $Context.Response.OutputStream.Write($bytes,0,$bytes.Length)
  $Context.Response.Close()
}

function Get-JsonRequestEncoding {
  param($Context)
  $contentType = ''
  try{
    $contentType = [string]$Context.Request.ContentType
  }catch{}
  if($contentType -match 'charset\s*=\s*("?)([^";,\s]+)\1'){
    try{
      return [System.Text.Encoding]::GetEncoding($matches[2])
    }catch{}
  }
  return [System.Text.UTF8Encoding]::new($false,$true)
}

function Read-JsonBody {
  param($Context)
  try{
    $reader = New-Object System.IO.StreamReader($Context.Request.InputStream,(Get-JsonRequestEncoding $Context),$true)
    $raw = $reader.ReadToEnd()
    $reader.Dispose()
    if([string]::IsNullOrWhiteSpace($raw)){ return @{} }
    return $raw | ConvertFrom-Json
  }catch{
    return $null
  }
}

function Get-ObjectValue {
  param($Object,[string]$Name,$Default = $null)
  if($null -eq $Object){ return $Default }
  if($Object -is [System.Collections.IDictionary]){
    if($Object.Contains($Name)){ return $Object[$Name] }
    return $Default
  }
  $prop = $Object.PSObject.Properties[$Name]
  if($null -eq $prop){ return $Default }
  return $prop.Value
}

function ConvertTo-PlainHashtable {
  param($Value)
  if($null -eq $Value){ return $null }
  if($Value -is [System.Collections.IDictionary]){
    $out = [ordered]@{}
    foreach($key in $Value.Keys){ $out[[string]$key] = ConvertTo-PlainHashtable $Value[$key] }
    return $out
  }
  if($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]){
    $items = @()
    foreach($item in $Value){ $items += ,(ConvertTo-PlainHashtable $item) }
    return ,$items
  }
  if($Value.PSObject -and $Value.PSObject.Properties.Count -gt 0 -and $Value.GetType().FullName -eq 'System.Management.Automation.PSCustomObject'){
    $out = [ordered]@{}
    foreach($property in $Value.PSObject.Properties){ $out[$property.Name] = ConvertTo-PlainHashtable $property.Value }
    return $out
  }
  return $Value
}

function Set-ObjectValue {
  param($Object,[string]$Name,$Value)
  if($Object -is [System.Collections.IDictionary]){
    $Object[$Name] = $Value
    return
  }
  $property = $Object.PSObject.Properties[$Name]
  if($null -eq $property){
    Add-Member -InputObject $Object -NotePropertyName $Name -NotePropertyValue $Value -Force
  } else {
    $property.Value = $Value
  }
}

function New-ErrorPayload {
  param([string]$Code,[string]$Message)
  return @{
    error = @{
      code = $Code
      message = $Message
    }
  }
}

function Write-ServerLog {
  param([string]$Message)
  if(-not $script:ServerLogEnabled){ return }
  try{
    $path = [System.IO.Path]::Combine($ResolvedContentRoot,'_conflab_server.log')
    $line = "[$((Get-Date).ToString('o'))] $Message`r`n"
    $encoding = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::AppendAllText($path,$line,$encoding)
  }catch{}
}

function Get-ActiveSessionPayload {
  param([string]$Message = '')
  return @{
    ok = $true
    serverTime = (Get-Date).ToString('o')
    idleTimeoutSeconds = $IdleTimeoutSeconds
    activeSessionId = $(if($script:ActiveSession){ [string]$script:ActiveSession.sessionId } else { '' })
    ownerEpoch = $(if($script:ActiveSession){ [int]$script:ActiveSession.ownerEpoch } else { 0 })
    workspacePath = $(if([string]::IsNullOrWhiteSpace([string]$script:ActiveWorkspacePath)){ $null } else { [string]$script:ActiveWorkspacePath })
    message = [string]$Message
  }
}

function Set-ActiveSession {
  param($Payload)
  $sessionId = [string](Get-ObjectValue $Payload 'sessionId' '')
  if([string]::IsNullOrWhiteSpace($sessionId)){ return $null }
  $reason = [string](Get-ObjectValue $Payload 'reason' '')
  $appVersion = [string](Get-ObjectValue $Payload 'appVersion' '')
  $startedAt = [string](Get-ObjectValue $Payload 'startedAt' '')
  $workspacePath = Resolve-FsPath ([string](Get-ObjectValue $Payload 'workspacePath' '')) -AllowMissing
  $changed = ($null -eq $script:ActiveSession) -or ([string]$script:ActiveSession.sessionId -ne $sessionId)
  if($changed){
    $script:ActiveSessionEpoch = [int]$script:ActiveSessionEpoch + 1
  }
  $script:ActiveWorkspacePath = if([string]::IsNullOrWhiteSpace($workspacePath)){ $null } else { $workspacePath }
  $script:ActiveSession = @{
    sessionId = $sessionId
    ownerEpoch = [int]$script:ActiveSessionEpoch
    startedAt = $startedAt
    appVersion = $appVersion
    reason = $reason
    workspacePath = $script:ActiveWorkspacePath
    lastSeen = (Get-Date).ToString('o')
  }
  return $script:ActiveSession
}

function New-SessionRejectedPayload {
  param([string]$Code,[string]$Message)
  $payload = New-ErrorPayload $Code $Message
  if($script:ActiveSession){
    $payload.error.activeSessionId = [string]$script:ActiveSession.sessionId
    $payload.error.ownerEpoch = [int]$script:ActiveSession.ownerEpoch
  }
  return $payload
}

function Test-SessionMutationAllowed {
  param($Payload,$Context)
  $sessionId = [string](Get-ObjectValue $Payload 'sessionId' '')
  $ownerEpoch = [int](Get-ObjectValue $Payload 'ownerEpoch' 0)
  if([string]::IsNullOrWhiteSpace($sessionId) -or $ownerEpoch -le 0){
    Send-Json $Context 409 (New-SessionRejectedPayload 'session_required' 'A current Conflab session claim is required before modifying files.')
    return $false
  }
  if($null -eq $script:ActiveSession){
    Send-Json $Context 409 (New-SessionRejectedPayload 'session_missing' 'No active Conflab session is registered for file mutation.')
    return $false
  }
  if(([string]$script:ActiveSession.sessionId -ne $sessionId) -or ([int]$script:ActiveSession.ownerEpoch -ne $ownerEpoch)){
    Send-Json $Context 409 (New-SessionRejectedPayload 'session_superseded' 'This Conflab tab has been superseded by a newer session.')
    return $false
  }
  $script:ActiveSession.lastSeen = (Get-Date).ToString('o')
  return $true
}

function Resolve-FsPath {
  param([string]$RawPath,[switch]$AllowMissing)
  if([string]::IsNullOrWhiteSpace($RawPath)){ return $null }
  try{
    $trimmed = $RawPath.Trim()
    $expanded = [Environment]::ExpandEnvironmentVariables($trimmed)
    $full = [System.IO.Path]::GetFullPath($expanded)
    if(!$AllowMissing){
      if(!(Test-Path -LiteralPath $full)){
        return $null
      }
    }
    return $full
  }catch{
    return $null
  }
}

function Get-FsParentPath {
  param([string]$Path)
  if([string]::IsNullOrWhiteSpace($Path)){ return $null }
  try{
    $normalized = [System.IO.Path]::GetFullPath($Path)
    $root = [System.IO.Path]::GetPathRoot($normalized)
    if($normalized.TrimEnd('\') -eq $root.TrimEnd('\')){
      return $null
    }
    return [System.IO.Path]::GetDirectoryName($normalized)
  }catch{
    return $null
  }
}

function Get-FsEntryName {
  param([string]$Path)
  if([string]::IsNullOrWhiteSpace($Path)){ return '' }
  try{
    $normalized = [System.IO.Path]::GetFullPath($Path)
    $trimmed = $normalized.TrimEnd('\')
    $name = [System.IO.Path]::GetFileName($trimmed)
    if([string]::IsNullOrWhiteSpace($name)){
      return $normalized
    }
    return $name
  }catch{
    return $Path
  }
}

function Get-FsMimeType {
  param([string]$Path)
  switch(([System.IO.Path]::GetExtension($Path).ToLowerInvariant())){
    '.txt' { 'text/plain' }
    '.md' { 'text/markdown' }
    '.json' { 'application/json' }
    '.csv' { 'text/csv' }
    '.html' { 'text/html' }
    '.css' { 'text/css' }
    '.js' { 'application/javascript' }
    '.ts' { 'application/typescript' }
    '.svg' { 'image/svg+xml' }
    '.png' { 'image/png' }
    '.jpg' { 'image/jpeg' }
    '.jpeg' { 'image/jpeg' }
    '.gif' { 'image/gif' }
    '.webp' { 'image/webp' }
    '.pdf' { 'application/pdf' }
    '.zip' { 'application/zip' }
    '.mp3' { 'audio/mpeg' }
    '.wav' { 'audio/wav' }
    '.mp4' { 'video/mp4' }
    '.xml' { 'application/xml' }
    '.yaml' { 'application/yaml' }
    '.yml' { 'application/yaml' }
    '.py' { 'text/x-python' }
    '.sh' { 'text/x-shellscript' }
    '.bat' { 'application/x-msdos-program' }
    default { 'application/octet-stream' }
  }
}

function Get-FsEntryPayload {
  param($Item)
  if($null -eq $Item){ return $null }
  $kind = if($Item.PSIsContainer){ 'directory' } else { 'file' }
  $payload = @{
    name = $Item.Name
    path = $Item.FullName
    kind = $kind
    modified = $Item.LastWriteTime.ToString('o')
  }
  if(!$Item.PSIsContainer){
    $payload.size = [int64]$Item.Length
    $payload.mimeType = Get-FsMimeType $Item.FullName
  }
  return $payload
}

function Get-FsRootPayloads {
  $roots = [System.IO.DriveInfo]::GetDrives() | ForEach-Object {
    $label = if($_.IsReady -and -not [string]::IsNullOrWhiteSpace($_.VolumeLabel)){
      "$($_.VolumeLabel) ($($_.Name.TrimEnd('\')))"
    } else {
      $_.Name.TrimEnd('\')
    }
    [ordered]@{
      id = $_.Name
      label = $label
      path = $_.Name
      kind = 'drive'
      available = [bool]$_.IsReady
    }
  }
  return @($roots)
}

function New-PickerPathPayload {
  param([string]$Id,[string]$Label,[string]$Path,[string]$Kind = 'folder')
  $normalized = Resolve-FsPath $Path -AllowMissing
  if([string]::IsNullOrWhiteSpace($normalized)){ return $null }
  $exists = Test-Path -LiteralPath $normalized -PathType Container
  return [ordered]@{
    id = $Id
    label = $Label
    name = Get-FsEntryName $normalized
    path = $normalized
    kind = $Kind
    exists = [bool]$exists
    available = [bool]$exists
  }
}

function Get-ExpandedFolderPath {
  param([string]$Path)
  if([string]::IsNullOrWhiteSpace($Path)){ return '' }
  $expanded = [Environment]::ExpandEnvironmentVariables($Path)
  return (Resolve-FsPath $expanded -AllowMissing)
}

function Get-RegistryKnownFolderPath {
  param([string]$ValueName)
  if([string]::IsNullOrWhiteSpace($ValueName)){ return '' }
  try {
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
    $props = Get-ItemProperty -LiteralPath $key -Name $ValueName -ErrorAction Stop
    $prop = $props.PSObject.Properties[$ValueName]
    if($null -ne $prop -and -not [string]::IsNullOrWhiteSpace([string]$prop.Value)){
      return (Get-ExpandedFolderPath ([string]$prop.Value))
    }
  } catch {}
  return ''
}

function Get-WindowsKnownFolderPath {
  param([string]$Name)
  $registryName = switch($Name){
    'Desktop' { 'Desktop'; break }
    'Documents' { 'Personal'; break }
    'Pictures' { 'My Pictures'; break }
    'Music' { 'My Music'; break }
    'Videos' { 'My Video'; break }
    'Downloads' { '{374DE290-123F-4565-9164-39C4925E467B}'; break }
    default { '' }
  }
  $path = Get-RegistryKnownFolderPath $registryName
  if(-not [string]::IsNullOrWhiteSpace($path)){ return $path }

  $specialName = switch($Name){
    'Desktop' { 'DesktopDirectory'; break }
    'Documents' { 'MyDocuments'; break }
    'Pictures' { 'MyPictures'; break }
    'Music' { 'MyMusic'; break }
    'Videos' { 'MyVideos'; break }
    default { '' }
  }
  if(-not [string]::IsNullOrWhiteSpace($specialName)){
    try {
      $folder = [enum]::Parse([Environment+SpecialFolder], $specialName)
      return (Get-ExpandedFolderPath ([Environment]::GetFolderPath($folder)))
    } catch {}
  }
  return ''
}

function Get-OneDriveRootPaths {
  param([string]$UserHome)
  $items = @()
  $seen = @{}
  foreach($raw in @($env:OneDrive,$env:OneDriveConsumer,$env:OneDriveCommercial)){
    $path = Get-ExpandedFolderPath $raw
    if(-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path -PathType Container)){
      $key = $path.ToLowerInvariant()
      if(-not $seen.ContainsKey($key)){ $seen[$key] = $true; $items += $path }
    }
  }
  if(-not [string]::IsNullOrWhiteSpace($UserHome) -and (Test-Path -LiteralPath $UserHome -PathType Container)){
    try {
      foreach($dir in Get-ChildItem -LiteralPath $UserHome -Directory -ErrorAction SilentlyContinue){
        if($dir.Name -like 'OneDrive*'){
          $path = Resolve-FsPath $dir.FullName -AllowMissing
          $key = $path.ToLowerInvariant()
          if(-not $seen.ContainsKey($key)){ $seen[$key] = $true; $items += $path }
        }
      }
    } catch {}
  }
  return $items
}

function Get-ExistingDirectoryCandidate {
  param([string[]]$Candidates)
  foreach($candidate in @($Candidates)){
    $path = Get-ExpandedFolderPath $candidate
    if(-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path -PathType Container)){
      return $path
    }
  }
  return ''
}

function Get-PickerStandardShortcutPath {
  param([string]$Name,[string]$UserHome,[string[]]$OneDriveRoots,[hashtable]$ResolvedStandardPaths)
  $candidates = @()
  if($Name -eq 'Screenshots'){
    $picturesPath = ''
    if($ResolvedStandardPaths.ContainsKey('Pictures')){ $picturesPath = [string]$ResolvedStandardPaths['Pictures'] }
    if([string]::IsNullOrWhiteSpace($picturesPath)){ $picturesPath = Get-WindowsKnownFolderPath 'Pictures' }
    if(-not [string]::IsNullOrWhiteSpace($picturesPath)){ $candidates += ([System.IO.Path]::Combine($picturesPath,'Screenshots')) }
    foreach($root in @($OneDriveRoots)){
      if(-not [string]::IsNullOrWhiteSpace($root)){
        $candidates += ([System.IO.Path]::Combine($root,'Pictures','Screenshots'))
        $candidates += ([System.IO.Path]::Combine($root,'Screenshots'))
      }
    }
    if(-not [string]::IsNullOrWhiteSpace($UserHome)){
      $candidates += ([System.IO.Path]::Combine($UserHome,'Pictures','Screenshots'))
      $candidates += ([System.IO.Path]::Combine($UserHome,'Screenshots'))
    }
    return (Get-ExistingDirectoryCandidate $candidates)
  }

  $knownPath = Get-WindowsKnownFolderPath $Name
  if(-not [string]::IsNullOrWhiteSpace($knownPath)){ $candidates += $knownPath }
  foreach($root in @($OneDriveRoots)){
    if(-not [string]::IsNullOrWhiteSpace($root)){ $candidates += ([System.IO.Path]::Combine($root,$Name)) }
  }
  if(-not [string]::IsNullOrWhiteSpace($UserHome)){ $candidates += ([System.IO.Path]::Combine($UserHome,$Name)) }
  return (Get-ExistingDirectoryCandidate $candidates)
}

function Get-PickerShortcutPayloads {
  $userHome = [Environment]::GetFolderPath('UserProfile')
  $oneDriveRoots = Get-OneDriveRootPaths $userHome
  $resolvedStandardPaths = @{}
  $items = @()
  if(-not [string]::IsNullOrWhiteSpace($userHome)){
    $homePayload = New-PickerPathPayload 'home' 'Home' $userHome 'home'
    if($null -ne $homePayload -and [bool]$homePayload.available){ $items += ,$homePayload }
  }
  foreach($name in @('Desktop','Downloads','Documents','Pictures','Music','Videos','Screenshots')){
    $candidate = Get-PickerStandardShortcutPath -Name $name -UserHome $userHome -OneDriveRoots $oneDriveRoots -ResolvedStandardPaths $resolvedStandardPaths
    if([string]::IsNullOrWhiteSpace($candidate)){ continue }
    if($name -ne 'Screenshots'){ $resolvedStandardPaths[$name] = $candidate }
    $payload = New-PickerPathPayload ($name.ToLowerInvariant()) $name $candidate 'shortcut'
    if($null -ne $payload -and [bool]$payload.available){ $items += ,$payload }
  }
  return @($items)
}

function Get-PickerSettings {
  param($Settings)
  $picker = ConvertTo-PlainHashtable (Get-ObjectValue $Settings 'picker' ([ordered]@{}))
  if($null -eq $picker){ $picker = [ordered]@{} }
  if(-not ($picker.Contains('recentWorkspaces'))){ $picker['recentWorkspaces'] = @() }
  if(-not ($picker.Contains('lastWorkspacePath'))){ $picker['lastWorkspacePath'] = '' }
  if(-not ($picker.Contains('lastWorkspaceOpenedAt'))){ $picker['lastWorkspaceOpenedAt'] = '' }
  return $picker
}

function ConvertTo-RecentWorkspacePayload {
  param($Value)
  $rawPath = if($Value -is [string]){ [string]$Value } else { [string](Get-ObjectValue $Value 'path' '') }
  $path = Resolve-FsPath $rawPath -AllowMissing
  if([string]::IsNullOrWhiteSpace($path)){ return $null }
  $exists = Test-Path -LiteralPath $path -PathType Container
  $label = if($Value -is [string]){ '' } else { [string](Get-ObjectValue $Value 'label' '') }
  if([string]::IsNullOrWhiteSpace($label)){ $label = Get-FsEntryName $path }
  return [ordered]@{
    label = $label
    name = Get-FsEntryName $path
    path = $path
    exists = [bool]$exists
    available = [bool]$exists
    lastOpenedAt = $(if($Value -is [string]){ '' } else { [string](Get-ObjectValue $Value 'lastOpenedAt' '') })
  }
}

function Get-RecentWorkspacePayloads {
  param($Settings)
  $picker = Get-PickerSettings $Settings
  $seen = @{}
  $items = @()
  foreach($entry in @($picker.recentWorkspaces)){
    $payload = ConvertTo-RecentWorkspacePayload $entry
    if($null -eq $payload){ continue }
    $key = ([string]$payload.path).ToLowerInvariant().TrimEnd('\')
    if($seen.ContainsKey($key)){ continue }
    $seen[$key] = $true
    $items += ,$payload
  }
  return @($items)
}

function Get-LastWorkspacePayload {
  param($Settings)
  $picker = Get-PickerSettings $Settings
  $path = [string](Get-ObjectValue $picker 'lastWorkspacePath' '')
  if([string]::IsNullOrWhiteSpace($path)){
    $recent = @(Get-RecentWorkspacePayloads $Settings)
    foreach($entry in $recent){
      if($null -ne $entry){ return $entry }
    }
    return $null
  }
  return (ConvertTo-RecentWorkspacePayload ([ordered]@{
    label = Get-FsEntryName $path
    path = $path
    lastOpenedAt = [string](Get-ObjectValue $picker 'lastWorkspaceOpenedAt' '')
  }))
}

function Set-RecentWorkspacePath {
  param([string]$Path)
  $workspacePath = Resolve-FsPath $Path -AllowMissing
  if([string]::IsNullOrWhiteSpace($workspacePath)){ return $null }
  $settings = Read-SettingsData
  $picker = Get-PickerSettings $settings
  $openedAt = (Get-Date).ToString('o')
  $next = @([ordered]@{
    label = Get-FsEntryName $workspacePath
    path = $workspacePath
    lastOpenedAt = $openedAt
  })
  $seen = @{ ([string]$workspacePath).ToLowerInvariant().TrimEnd('\') = $true }
  foreach($entry in @($picker.recentWorkspaces)){
    $payload = ConvertTo-RecentWorkspacePayload $entry
    if($null -eq $payload){ continue }
    $key = ([string]$payload.path).ToLowerInvariant().TrimEnd('\')
    if($seen.ContainsKey($key)){ continue }
    $seen[$key] = $true
    $next += ,([ordered]@{
      label = [string]$payload.label
      path = [string]$payload.path
      lastOpenedAt = [string]$payload.lastOpenedAt
    })
    if($next.Count -ge 12){ break }
  }
  $picker['recentWorkspaces'] = @($next)
  $picker['lastWorkspacePath'] = $workspacePath
  $picker['lastWorkspaceOpenedAt'] = $openedAt
  $settings['picker'] = $picker
  Write-SettingsData $settings
  return $workspacePath
}

function Get-PickerStatePayload {
  $settings = Read-SettingsData
  $userHome = [Environment]::GetFolderPath('UserProfile')
  $workspacePath = if([string]::IsNullOrWhiteSpace([string]$script:ActiveWorkspacePath)){ $null } else { [string]$script:ActiveWorkspacePath }
  $lastWorkspace = Get-LastWorkspacePayload $settings
  $lastWorkspacePath = ''
  if($null -ne $lastWorkspace){ $lastWorkspacePath = [string]$lastWorkspace.path }
  $defaultWorkspacePath = $userHome
  if($workspacePath){
    $defaultWorkspacePath = $workspacePath
  } elseif($lastWorkspacePath -and $lastWorkspace -and [bool]$lastWorkspace.available){
    $defaultWorkspacePath = $lastWorkspacePath
  }
  return [ordered]@{
    ok = $true
    schemaVersion = 1
    currentWorkspaceRoot = $workspacePath
    userHome = $userHome
    roots = @(Get-FsRootPayloads)
    shortcuts = @(Get-PickerShortcutPayloads)
    recentWorkspaces = @(Get-RecentWorkspacePayloads $settings)
    lastWorkspace = $lastWorkspace
    lastWorkspacePath = $lastWorkspacePath
    defaultPaths = [ordered]@{
      workspace = $defaultWorkspacePath
      files = $userHome
    }
  }
}

function Handle-PickerState {
  param($Context)
  try{
    Send-Json $Context 200 (Get-PickerStatePayload)
  }catch{
    $message = 'Could not build picker state.'
    if($env:CONFLAB_DEBUG_ERRORS){ $message = "$message $($_.Exception.Message)" }
    Send-Json $Context 500 (New-ErrorPayload 'picker_state_failed' $message)
  }
}

function Handle-PickerRecentWorkspaces {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.') -Protected
    return
  }
  $path = [string](Get-ObjectValue $payload 'path' '')
  try{
    $storedPath = Set-RecentWorkspacePath $path
    if([string]::IsNullOrWhiteSpace($storedPath)){
      Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid workspace path is required.') -Protected
      return
    }
    Send-Json $Context 200 (Get-PickerStatePayload) -Protected
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'recent_workspace_save_failed' 'Could not save recent workspace.') -Protected
  }
}

function Handle-FsRoots {
  param($Context)
  try{
    Send-Json $Context 200 @{
      roots = @(Get-FsRootPayloads)
      userHome = [Environment]::GetFolderPath('UserProfile')
    }
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_roots_failed' 'Could not enumerate filesystem roots.')
  }
}

function Handle-FsStat {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' '')) -AllowMissing
  if([string]::IsNullOrWhiteSpace($path)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid filesystem path is required.')
    return
  }

  if(!(Test-Path -LiteralPath $path)){
    Send-Json $Context 200 @{
      exists = $false
      path = $path
      name = Get-FsEntryName $path
      parent = Get-FsParentPath $path
    }
    return
  }

  try{
    $item = Get-Item -LiteralPath $path -Force
    $entry = Get-FsEntryPayload $item
    $entry.exists = $true
    $entry.parent = Get-FsParentPath $item.FullName
    Send-Json $Context 200 $entry
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_stat_failed' 'Could not read filesystem metadata.')
  }
}

function Handle-FsList {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' ''))
  if([string]::IsNullOrWhiteSpace($path)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid directory path is required.')
    return
  }

  if(!(Test-Path -LiteralPath $path -PathType Container)){
    Send-Json $Context 404 (New-ErrorPayload 'directory_not_found' 'Directory not found.')
    return
  }

  try{
    $entries = @(Get-ChildItem -LiteralPath $path | Sort-Object @{ Expression = { -not $_.PSIsContainer } }, @{ Expression = { $_.Name.ToLowerInvariant() } } | ForEach-Object { Get-FsEntryPayload $_ })
    Send-Json $Context 200 @{
      path = $path
      parent = Get-FsParentPath $path
      entries = $entries
    }
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_list_failed' 'Could not list directory contents.')
  }
}

function Handle-FsRead {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' ''))
  if([string]::IsNullOrWhiteSpace($path) -or !(Test-Path -LiteralPath $path -PathType Leaf)){
    Send-Json $Context 404 (New-ErrorPayload 'file_not_found' 'File not found.')
    return
  }

  try{
    $bytes = [System.IO.File]::ReadAllBytes($path)
    Send-Json $Context 200 @{
      name = [System.IO.Path]::GetFileName($path)
      path = $path
      mimeType = Get-FsMimeType $path
      size = [int64]$bytes.Length
      base64 = [Convert]::ToBase64String($bytes)
    }
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_read_failed' 'Could not read file contents.')
  }
}

function Handle-FsReadMany {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $files = @()
  $errors = @()
  foreach($rawPath in @($payload.paths)){
    $path = Resolve-FsPath ([string]$rawPath)
    if([string]::IsNullOrWhiteSpace($path) -or !(Test-Path -LiteralPath $path -PathType Leaf)){
      $errors += @{
        path = [string]$rawPath
        code = 'file_not_found'
        message = 'File not found.'
      }
      continue
    }
    try{
      $bytes = [System.IO.File]::ReadAllBytes($path)
      $files += @{
        name = [System.IO.Path]::GetFileName($path)
        path = $path
        mimeType = Get-FsMimeType $path
        size = [int64]$bytes.Length
        base64 = [Convert]::ToBase64String($bytes)
      }
    }catch{
      $errors += @{
        path = $path
        code = 'fs_read_failed'
        message = 'Could not read file contents.'
      }
    }
  }

  Send-Json $Context 200 @{
    files = $files
    errors = $errors
  }
}

function Handle-FsEnsureDir {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' '')) -AllowMissing
  if([string]::IsNullOrWhiteSpace($path)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid directory path is required.')
    return
  }
  if(-not (Test-SessionMutationAllowed $payload $Context)){ return }

  try{
    if(!(Test-Path -LiteralPath $path)){
      New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
    $item = Get-Item -LiteralPath $path -Force
    if(!$item.PSIsContainer){
      Send-Json $Context 400 (New-ErrorPayload 'not_directory' 'Target path is not a directory.')
      return
    }
    Send-Json $Context 200 (Get-FsEntryPayload $item)
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_ensure_dir_failed' 'Could not create directory.')
  }
}

function Handle-FsEnsureFile {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' '')) -AllowMissing
  if([string]::IsNullOrWhiteSpace($path)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid file path is required.')
    return
  }
  if(-not (Test-SessionMutationAllowed $payload $Context)){ return }

  try{
    $parent = Get-FsParentPath $path
    if($parent -and !(Test-Path -LiteralPath $parent)){
      New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    if(!(Test-Path -LiteralPath $path)){
      [System.IO.File]::WriteAllBytes($path,[byte[]]@())
    }
    $item = Get-Item -LiteralPath $path -Force
    if($item.PSIsContainer){
      Send-Json $Context 400 (New-ErrorPayload 'not_file' 'Target path is not a file.')
      return
    }
    Send-Json $Context 200 (Get-FsEntryPayload $item)
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_ensure_file_failed' 'Could not create file.')
  }
}

function Handle-FsWrite {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' '')) -AllowMissing
  if([string]::IsNullOrWhiteSpace($path)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid file path is required.')
    return
  }
  if(-not (Test-SessionMutationAllowed $payload $Context)){ return }

  try{
    $parent = Get-FsParentPath $path
    if($parent -and !(Test-Path -LiteralPath $parent)){
      New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }

    $bytes = $null
    if($payload.PSObject.Properties.Name -contains 'base64'){
      $bytes = [Convert]::FromBase64String([string]$payload.base64)
    } elseif($payload.PSObject.Properties.Name -contains 'text'){
      $encoding = [System.Text.UTF8Encoding]::new($false)
      $bytes = $encoding.GetBytes([string]$payload.text)
    } else {
      $bytes = [byte[]]@()
    }
    [System.IO.File]::WriteAllBytes($path,$bytes)
    $item = Get-Item -LiteralPath $path -Force
    Send-Json $Context 200 (Get-FsEntryPayload $item)
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_write_failed' 'Could not write file.')
  }
}

function Handle-FsRemove {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $path = Resolve-FsPath ([string](Get-ObjectValue $payload 'path' ''))
  if([string]::IsNullOrWhiteSpace($path)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'A valid filesystem path is required.')
    return
  }
  if(-not (Test-SessionMutationAllowed $payload $Context)){ return }

  try{
    $recursive = !!(Get-ObjectValue $payload 'recursive' $false)
    if($recursive){
      Remove-Item -LiteralPath $path -Recurse -Force
    } else {
      Remove-Item -LiteralPath $path -Force
    }
    Send-Json $Context 200 @{
      ok = $true
      path = $path
    }
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_remove_failed' 'Could not remove filesystem entry.')
  }
}

function Handle-FsMove {
  param($Context)
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.')
    return
  }

  $sourcePath = Resolve-FsPath ([string](Get-ObjectValue $payload 'sourcePath' ''))
  $targetPath = Resolve-FsPath ([string](Get-ObjectValue $payload 'targetPath' '')) -AllowMissing
  if([string]::IsNullOrWhiteSpace($sourcePath) -or [string]::IsNullOrWhiteSpace($targetPath)){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_path' 'Valid sourcePath and targetPath values are required.')
    return
  }
  if(-not (Test-SessionMutationAllowed $payload $Context)){ return }

  try{
    $parent = Get-FsParentPath $targetPath
    if($parent -and !(Test-Path -LiteralPath $parent)){
      New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    Move-Item -LiteralPath $sourcePath -Destination $targetPath
    $item = Get-Item -LiteralPath $targetPath -Force
    Send-Json $Context 200 (Get-FsEntryPayload $item)
  }catch{
    Send-Json $Context 500 (New-ErrorPayload 'fs_move_failed' 'Could not move filesystem entry.')
  }
}

function Clean-TextBlock {
  param([string]$Text)
  $lines = foreach($line in ($Text -split "`r?`n")){
    $clean = [regex]::Replace($line,'\s+',' ').Trim()
    if($clean){ $clean }
  }
  return ($lines -join "`n")
}

function Strip-HtmlToText {
  param([string]$HtmlText)

  $title = ''
  $titleMatch = [regex]::Match($HtmlText,'<title[^>]*>(.*?)</title>','IgnoreCase,Singleline')
  if($titleMatch.Success){
    $title = [System.Net.WebUtility]::HtmlDecode([regex]::Replace($titleMatch.Groups[1].Value,'\s+',' ').Trim())
  }

  $block = $HtmlText
  foreach($pattern in @(
    '<script\b[^>]*>.*?</script>',
    '<style\b[^>]*>.*?</style>',
    '<noscript\b[^>]*>.*?</noscript>',
    '<svg\b[^>]*>.*?</svg>',
    '<form\b[^>]*>.*?</form>',
    '<nav\b[^>]*>.*?</nav>',
    '<footer\b[^>]*>.*?</footer>',
    '<aside\b[^>]*>.*?</aside>',
    '<!--.*?-->'
  )){
    $block = [regex]::Replace($block,$pattern,' ','IgnoreCase,Singleline')
  }

  foreach($container in @('article','main','body')){
    $match = [regex]::Match($block,"<${container}\b[^>]*>(.*?)</${container}>",'IgnoreCase,Singleline')
    if($match.Success){
      $block = $match.Groups[1].Value
      break
    }
  }

  $block = [regex]::Replace($block,'</?(?:p|div|section|article|main|li|ul|ol|br|h1|h2|h3|h4|h5|h6|tr|td|blockquote)\b[^>]*>',"`n",'IgnoreCase')
  $block = [regex]::Replace($block,'<[^>]+>',' ','Singleline')
  $text = [System.Net.WebUtility]::HtmlDecode($block)
  $text = Clean-TextBlock $text
  if($text.Length -gt $FetchCharLimit){
    $text = $text.Substring(0,$FetchCharLimit).Trim()
  }

  return @{
    title = $title
    content = $text
  }
}

function Invoke-UrlFetch {
  param([string]$Url)

  $headers = @{
    'User-Agent' = $UserAgent
    'Accept' = 'text/html,application/xhtml+xml'
  }

  $response = Invoke-WebRequest -Uri $Url -Headers $headers -TimeoutSec $FetchTimeoutSeconds -MaximumRedirection 5 -UseBasicParsing
  $htmlText = [string]$response.Content
  if($htmlText.Length -gt $FetchByteLimit){
    $htmlText = $htmlText.Substring(0,$FetchByteLimit)
  }
  return Strip-HtmlToText $htmlText
}

function Get-StaticContentType {
  param([string]$Path)
  switch(([System.IO.Path]::GetExtension($Path).ToLowerInvariant())){
    '.app' { 'text/html; charset=utf-8' }
    '.html' { 'text/html; charset=utf-8' }
    '.js' { 'application/javascript; charset=utf-8' }
    '.css' { 'text/css; charset=utf-8' }
    '.json' { 'application/json; charset=utf-8' }
    '.png' { 'image/png' }
    '.jpg' { 'image/jpeg' }
    '.jpeg' { 'image/jpeg' }
    '.gif' { 'image/gif' }
    '.svg' { 'image/svg+xml' }
    '.ico' { 'image/x-icon' }
    '.md' { 'text/markdown; charset=utf-8' }
    '.txt' { 'text/plain; charset=utf-8' }
    default { 'application/octet-stream' }
  }
}

function Resolve-StaticPath {
  param([string]$RawPath)

  $requestPath = if([string]::IsNullOrWhiteSpace($RawPath) -or $RawPath -eq '/'){
    "/$ResolvedEntryFile"
  } else {
    $RawPath
  }

  $decoded = [System.Uri]::UnescapeDataString($requestPath).TrimStart('/')
  if([string]::IsNullOrWhiteSpace($decoded)){
    $decoded = $ResolvedEntryFile
  }
  if($decoded.Contains('..')){ return $null }

  $candidate = Join-Path $ResolvedContentRoot ($decoded -replace '/','\')
  $fullCandidate = [System.IO.Path]::GetFullPath($candidate)
  $fullRoot = [System.IO.Path]::GetFullPath($ResolvedContentRoot)
  if(-not $fullCandidate.StartsWith($fullRoot,[System.StringComparison]::OrdinalIgnoreCase)){
    return $null
  }
  return $fullCandidate
}

function Handle-Search {
  param($Context)
  Handle-BraveSearchProxy $Context
}

function Handle-Fetch {
  param($Context)

  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 @{ error = 'Invalid JSON body.' }
    return
  }

  $url = [string](Get-ObjectValue $payload 'url' '')
  if([string]::IsNullOrWhiteSpace($url)){
    Send-Json $Context 400 @{ error = 'URL is required.' }
    return
  }

  try{
    $uri = [Uri]$url
  }catch{
    Send-Json $Context 400 @{ error = 'Invalid URL.' }
    return
  }

  if($uri.Scheme -notin @('http','https')){
    Send-Json $Context 400 @{ error = 'Only http and https URLs are supported.' }
    return
  }

  $cacheKey = "fetch:$url"
  $cached = Get-CacheValue $cacheKey
  if($null -ne $cached){
    Send-Json $Context 200 $cached
    return
  }

  try{
    $result = Invoke-UrlFetch $url
    $payloadOut = @{
      url = $url
      title = $result.title
      content = $result.content
    }
    Set-CacheValue $cacheKey $payloadOut
    Send-Json $Context 200 $payloadOut
  }catch{
    $message = if($_.Exception.Message){ $_.Exception.Message } else { 'Could not fetch URL.' }
    Send-Json $Context 502 @{ error = $message }
  }
}

function Handle-Options {
  param($Context)
  $Context.Response.StatusCode = 204
  $isProtected = Test-ProtectedEndpointPath $Context.Request.Url.AbsolutePath
  Set-CorsHeaders $Context -Protected:$isProtected
  $Context.Response.Headers['Access-Control-Allow-Headers'] = 'Content-Type, X-Conflab-Bridge-Token'
  $Context.Response.Headers['Access-Control-Allow-Methods'] = 'POST, GET, OPTIONS'
  $Context.Response.Headers['Cache-Control'] = 'no-store'
  $Context.Response.Close()
}

function Handle-Heartbeat {
  param($Context)
  if(-not (Require-BridgeAuth $Context)){ return }
  $payload = Read-JsonBody $Context
  if($null -eq $payload){
    Send-Json $Context 400 (New-ErrorPayload 'invalid_json' 'Invalid JSON body.') -Protected
    return
  }
  Touch-Heartbeat
  $sessionId = [string](Get-ObjectValue $payload 'sessionId' '')
  $claim = [bool](Get-ObjectValue $payload 'claim' $false)
  if(-not [string]::IsNullOrWhiteSpace($sessionId)){
    if($claim -or $null -eq $script:ActiveSession){
      Set-ActiveSession $payload | Out-Null
    } elseif([string]$script:ActiveSession.sessionId -eq $sessionId){
      $script:ActiveSession.lastSeen = (Get-Date).ToString('o')
    }
  }
  Send-Json $Context 200 (Get-ActiveSessionPayload '') -Protected
}

function Handle-Shutdown {
  param($Context)
  $payload = Read-JsonBody $Context
  $bodyToken = [string](Get-ObjectValue $payload 'bridgeToken' '')
  if((-not (Test-BridgeAuthToken $Context)) -and (-not (Test-BridgeAuthTokenValue $bodyToken))){
    Send-Json $Context 403 (New-ErrorPayload 'forbidden' 'Request is not authorized.') -Protected
    return
  }
  $reason = [string](Get-ObjectValue $payload 'reason' 'shutdown-request')
  $script:ServerExitReason = 'shutdown-request'
  $script:ServerExitDetail = $reason
  $script:ShutdownRequested = $true
  Send-Json $Context 200 @{
    ok = $true
    shuttingDown = $true
    serverTime = (Get-Date).ToString('o')
  } -Protected
}

function Add-BridgeTokenBootstrap {
  param([string]$HtmlText)
  $tokenJson = ConvertTo-Json -InputObject $script:BridgeAuthToken -Compress
  $bootstrap = "<script>window.__CONFLAB_BRIDGE_AUTH_TOKEN=${tokenJson};</script>"
  $headClose = [regex]::Match($HtmlText,'</head>','IgnoreCase')
  if($headClose.Success){
    return $HtmlText.Substring(0,$headClose.Index) + $bootstrap + "`r`n" + $HtmlText.Substring($headClose.Index)
  }
  return $bootstrap + "`r`n" + $HtmlText
}

function Test-TokenBearingStaticDocument {
  param([string]$Path)
  $fileName = [System.IO.Path]::GetFileName($Path)
  if([string]::Equals($fileName,'Conflab.html',[System.StringComparison]::OrdinalIgnoreCase)){ return $true }
  try{
    $entryPath = Join-Path $ResolvedContentRoot ($ResolvedEntryFile -replace '/','\')
    $fullEntryPath = [System.IO.Path]::GetFullPath($entryPath)
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    return [string]::Equals($fullPath,$fullEntryPath,[System.StringComparison]::OrdinalIgnoreCase)
  }catch{
    return $false
  }
}

function Handle-Static {
  param($Context)
  $path = Resolve-StaticPath $Context.Request.Url.AbsolutePath
  if(!$path -or !(Test-Path -LiteralPath $path -PathType Leaf)){
    Send-Text $Context 404 'Not found.' 'text/plain; charset=utf-8'
    return
  }

  $contentType = Get-StaticContentType $path
  $isTokenDocument = Test-TokenBearingStaticDocument $path
  if($isTokenDocument){
    $text = [System.IO.File]::ReadAllText($path,[System.Text.Encoding]::UTF8)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes((Add-BridgeTokenBootstrap $text))
  } else {
    $bytes = [System.IO.File]::ReadAllBytes($path)
  }
  $Context.Response.StatusCode = 200
  $Context.Response.ContentType = $contentType
  if(-not $isTokenDocument){
    $Context.Response.Headers['Access-Control-Allow-Origin'] = '*'
  }
  $Context.Response.Headers['Cache-Control'] = 'no-store'
  $Context.Response.ContentLength64 = $bytes.Length
  $Context.Response.OutputStream.Write($bytes,0,$bytes.Length)
  $Context.Response.Close()
}

if(Test-ConflabPortInUse -HostAddress $HostName -PortNumber $Port){
  $existingInstance = Get-ConflabInstanceAtPort -HostAddress $HostName -PortNumber $Port
  if($null -ne $existingInstance){
    if(!$NoBrowser){ Open-ConflabBrowser }
    return
  }
  throw "Could not bind Conflab to ${BaseUrl}. Another process may have claimed the fixed port."
}

$listener = [System.Net.HttpListener]::new()
try{
  $listener.Prefixes.Add("${BaseUrl}/")
  $listener.Start()
}catch{
  $listener.Close()
  throw "Could not bind Conflab to ${BaseUrl}. Another process may have claimed the port. $($_.Exception.Message)"
}
$pendingContextTask = $null

try{
  Touch-Heartbeat
  if(!$NoBrowser){
    Start-Sleep -Milliseconds 250
    Open-ConflabBrowser
  }

  while($listener.IsListening){
    if($script:ShutdownRequested){
      if($script:ServerExitReason -eq 'unknown'){
        $script:ServerExitReason = 'shutdown-request'
      }
      break
    }
    if($IdleTimeoutSeconds -gt 0){
      $idleSeconds = ((Get-Date) - $script:LastHeartbeat).TotalSeconds
      if($idleSeconds -ge $IdleTimeoutSeconds){
        $script:ServerExitReason = 'idle-timeout'
        $script:ServerExitDetail = "$([Math]::Round($idleSeconds,1))s idle; limit ${IdleTimeoutSeconds}s"
        break
      }
    }

    if($null -eq $pendingContextTask){
      $pendingContextTask = $listener.GetContextAsync()
    }
    if(-not $pendingContextTask.Wait(1000)){
      continue
    }

    $context = $pendingContextTask.Result
    $pendingContextTask = $null
    $requestPath = $context.Request.Url.AbsolutePath
    if((-not (Test-ProtectedEndpointPath $requestPath)) -or (Test-BridgeAuthToken $context)){
      Touch-Heartbeat
    }
    try{
      switch($context.Request.HttpMethod){
        'OPTIONS' { Handle-Options $context; continue }
        'POST' {
          switch($context.Request.Url.AbsolutePath){
            '/api/heartbeat' { Handle-Heartbeat $context }
            '/api/shutdown' { Handle-Shutdown $context }
            '/api/settings/read' { Handle-SettingsRead $context }
            '/api/settings/save' { Handle-SettingsSave $context }
            '/api/openrouter/chat' { Handle-OpenRouterChat $context }
            '/api/openrouter/models' { Handle-OpenRouterModels $context }
            '/api/openrouter/image-models' { Handle-OpenRouterImageModels $context }
            '/api/brave/search' { Handle-BraveSearchProxy $context }
            '/api/search' { Handle-Search $context }
            '/api/fetch' { Handle-Fetch $context }
            '/api/picker/recent-workspaces' { Handle-PickerRecentWorkspaces $context }
            '/api/fs/stat' { Handle-FsStat $context }
            '/api/fs/list' { Handle-FsList $context }
            '/api/fs/read' { Handle-FsRead $context }
            '/api/fs/read-many' { Handle-FsReadMany $context }
            '/api/fs/ensure-dir' { Handle-FsEnsureDir $context }
            '/api/fs/ensure-file' { Handle-FsEnsureFile $context }
            '/api/fs/write' { Handle-FsWrite $context }
            '/api/fs/remove' { Handle-FsRemove $context }
            '/api/fs/move' { Handle-FsMove $context }
            default { Send-Json $context 404 @{ error = 'Unknown endpoint.' } }
          }
        }
        'GET' {
          switch($context.Request.Url.AbsolutePath){
            '/api/instance' { Handle-InstanceStatus $context }
            '/api/picker/state' { Handle-PickerState $context }
            '/api/settings/read' { Handle-SettingsRead $context }
            '/api/fs/roots' { Handle-FsRoots $context }
            default { Handle-Static $context }
          }
        }
        default {
          Handle-Static $context
        }
      }
    }catch{
      $message = if($_.Exception.Message){ $_.Exception.Message } else { 'Server error.' }
      Write-ServerLog "Request handler failed for ${requestPath}: $message"
      try{
        if($context.Response.OutputStream.CanWrite){
          Send-Json $context 500 @{ error = $message }
        }
      }catch{
        $sendMessage = if($_.Exception.Message){ $_.Exception.Message } else { 'Could not send error response.' }
        Write-ServerLog "Could not send error response for ${requestPath}: $sendMessage"
      }
    }
    if($script:ShutdownRequested){
      if($script:ServerExitReason -eq 'unknown'){
        $script:ServerExitReason = 'shutdown-request'
      }
      break
    }
  }
}catch{
  $script:ServerExitReason = 'unhandled-exception'
  $script:ServerExitDetail = if($_.Exception.Message){ $_.Exception.Message } else { 'Unhandled server exception.' }
  Write-ServerLog "Unhandled server exception: $script:ServerExitDetail"
  throw
}finally{
  if($script:ServerExitReason -eq 'unknown'){
    $script:ServerExitReason = 'listener-exit'
  }
  Write-ServerLog "Server stopping; reason=$script:ServerExitReason; detail=$script:ServerExitDetail"
  try{
    if($listener.IsListening){
      $listener.Stop()
    }
  }catch{
    $stopMessage = if($_.Exception.Message){ $_.Exception.Message } else { 'Listener stop failed.' }
    Write-ServerLog "Listener stop failed: $stopMessage"
  }
  try{
    $listener.Close()
  }catch{
    $closeMessage = if($_.Exception.Message){ $_.Exception.Message } else { 'Listener close failed.' }
    Write-ServerLog "Listener close failed: $closeMessage"
  }
}
