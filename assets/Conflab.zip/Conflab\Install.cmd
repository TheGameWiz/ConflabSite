@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%Install.ps1"
if errorlevel 1 (
  echo.
  echo Conflab install failed.
  pause
  exit /b %errorlevel%
)
echo.
echo Conflab install complete.
pause
