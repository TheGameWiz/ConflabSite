CONFLAB QUICK START

1. Extract the Conflab zip to any folder you want.

2. Open the extracted "Conflab" folder.

3. Double-click "Install.cmd".

What Install does:

- Refreshes the "Conflab" shortcut inside this folder so it points to this exact extracted copy of Conflab.
- Creates a Desktop shortcut named "Conflab".
- Makes sure the shortcut uses the Conflab icon from this folder.

After install:

- You can launch Conflab by double-clicking the "Conflab" shortcut in this folder.
- You can also use the Desktop shortcut created by Install.
- You can move the shortcut wherever you want after that.
- You can pin the shortcut to the taskbar or Start menu if you want.

Notes:

- Conflab currently requires Windows and a Chromium-based browser such as Chrome or Edge.
- The local Conflab launcher uses built-in Windows PowerShell. No Python install is required.
- If Windows asks for permission to run the installer script, allow it.

Files you may care about:

- Install.cmd      - easy installer entry point
- Install.ps1      - installer logic
- Conflab          - launch shortcut
- conflab.ps1      - local launcher/server script
- Conflab.app      - the application

License:

© Copyright: David Todd - April, 2026
Conflab is distributed in this release package under the MIT License. See LICENSE.txt in this folder.
